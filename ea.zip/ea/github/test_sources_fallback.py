"""Fonti di riserva: Tesoro USA, BCE, CBOE e passaggio automatico quando FRED non risponde."""
import pandas as pd
import pytest

from xau_macro import sources

REAL = "Date,5 YR,7 YR,10 YR,20 YR,30 YR\n11/06/2026,1.45,1.62,1.80,2.10,2.25\n11/05/2026,1.40,1.60,1.78,2.05,2.20\n"
NOMINAL = ('Date,"1 Mo","2 Mo","3 Mo","4 Mo","6 Mo","1 Yr","2 Yr","3 Yr","5 Yr","7 Yr","10 Yr","20 Yr","30 Yr"\n'
           "11/06/2026,4.0,4.0,3.9,3.9,3.8,3.7,3.55,3.5,3.6,3.8,4.10,4.6,4.7\n"
           "11/05/2026,4.0,4.0,3.9,3.9,3.8,3.7,3.50,3.5,3.6,3.8,4.05,4.6,4.7\n")


def ecb_csv(days=3):
    rates = {"USD": 1.10, "JPY": 165.0, "GBP": 0.85, "CAD": 1.50, "SEK": 11.5, "CHF": 0.95}
    lines = ["KEY,FREQ,CURRENCY,CURRENCY_DENOM,EXR_TYPE,EXR_SUFFIX,TIME_PERIOD,OBS_VALUE,OBS_STATUS"]
    for d, ts in enumerate(pd.bdate_range("2026-10-01", periods=days)):
        day = f"{ts:%Y-%m-%d}"
        for c, v in rates.items():
            lines.append(f"EXR.D.{c}.EUR.SP00.A,D,{c},EUR,SP00,A,{day},{v * (1 + 0.001 * d)},A")
    return "\n".join(lines) + "\n"


VIX = "DATE,OPEN,HIGH,LOW,CLOSE\n11/05/2026,16.1,17.0,15.9,16.5\n11/06/2026,16.5,18.2,16.4,17.9\n"


def test_parse_treasury_real_and_nominal():
    r = sources.parse_treasury_csv(REAL, "10 YR")
    assert r.iloc[-1] == pytest.approx(1.80) and r.index[-1] == pd.Timestamp("2026-11-06")
    n = sources.parse_treasury_csv(NOMINAL, "2 Yr")
    assert n.iloc[0] == pytest.approx(3.50) and n.iloc[-1] == pytest.approx(3.55)


def test_parse_ecb_dollar_index_reasonable():
    s = sources.parse_ecb_dollar_index(ecb_csv())
    assert len(s) == 3
    assert 80 < s.iloc[0] < 120          # ordine di grandezza del DXY
    assert s.iloc[-1] < s.iloc[0]        # tutte le valute si rafforzano un po' sul dollaro... ma EUR/USD sale: dollaro giu'


def test_parse_cboe_vix():
    v = sources.parse_cboe_vix(VIX)
    assert v.iloc[-1] == pytest.approx(17.9)


class Resp:
    def __init__(self, text="", status=200, js=None):
        self.text, self.status_code, self._js = text, status, js

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")

    def json(self):
        return self._js


def big_treasury(column_header, value):
    rows = [column_header]
    for d in pd.bdate_range("2026-06-01", "2026-11-06"):
        rows.append(f"{d:%m/%d/%Y}," + value)
    return "\n".join(rows) + "\n"


def test_fetch_all_switches_to_fallbacks(monkeypatch):
    monkeypatch.setattr(sources.time, "sleep", lambda s: None)
    monkeypatch.delenv("FRED_API_KEY", raising=False)
    calls = {"fred": 0}
    real_txt = big_treasury("Date,5 YR,7 YR,10 YR,20 YR,30 YR", "1.4,1.6,1.8,2.1,2.2")
    nom_txt = big_treasury('Date,"1 Mo","2 Mo","3 Mo","4 Mo","6 Mo","1 Yr","2 Yr","3 Yr","5 Yr","7 Yr","10 Yr","20 Yr","30 Yr"',
                           "4,4,3.9,3.9,3.8,3.7,3.5,3.5,3.6,3.8,4.1,4.6,4.7")
    vix_rows = ["DATE,OPEN,HIGH,LOW,CLOSE"] + [f"{d:%m/%d/%Y},16,17,15,16.5" for d in pd.bdate_range("2026-06-01", "2026-11-06")]

    def fake_get(url, params=None, headers=None, timeout=None):
        if "stlouisfed" in url:
            calls["fred"] += 1
            return Resp("<html><body>Access denied</body></html>")
        if "treasury.gov" in url:
            if "2025" in url:
                return Resp("")
            return Resp(real_txt if "real_yield" in url else nom_txt)
        if "ecb.europa.eu" in url:
            return Resp(ecb_csv(30))
        if "cboe.com" in url:
            return Resp("\n".join(vix_rows) + "\n")
        raise AssertionError(url)

    monkeypatch.setattr(sources.requests, "get", fake_get)
    out = sources.fetch_all_fred("2025-06-01")
    assert set(out) == {"real_yield_10y", "dollar_broad", "nominal_2y", "breakeven_10y", "vix"}
    assert out["breakeven_10y"].iloc[-1] == pytest.approx(4.1 - 1.8)
    assert calls["fred"] == 3        # dopo il primo blocco non insiste con le altre serie


def test_fred_api_key_used_first(monkeypatch):
    monkeypatch.setenv("FRED_API_KEY", "abc")
    obs = [{"date": f"2026-10-{d:02d}", "value": str(1.5 + d / 100)} for d in range(1, 21)]

    def fake_get(url, params=None, headers=None, timeout=None):
        assert "api.stlouisfed.org" in url and params["api_key"] == "abc"
        return Resp(js={"observations": obs})

    monkeypatch.setattr(sources.requests, "get", fake_get)
    s = sources.fetch_fred("DFII10", "2026-01-01")
    assert len(s) == 20 and s.iloc[-1] == pytest.approx(1.70)
