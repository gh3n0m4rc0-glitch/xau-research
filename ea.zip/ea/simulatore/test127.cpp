#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-86s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
static bool has(const std::string&a,const char*b){ return a.find(b)!=std::string::npos; }
static bool logHas(const char*b){ for(int i=(int)g_shimLog.size()-1;i>=0 && i>=(int)g_shimLog.size()-6;i--) if(has(g_shimLog[i],b)) return true; return false; }
// buffer di un timeframe: n barre da t0, una ogni 'sec' secondi, prezzo fermo, EMA20 sopra/sotto EMA50 secondo emaDir
static void mkTf(TfData&d,int n,datetime t0,int sec,double px,double range,int emaDir){
  d.n=n; ArrayResize(d.r,n); ArrayResize(d.ema20,n); ArrayResize(d.ema50,n); ArrayResize(d.atr,n);
  for(int i=0;i<n;i++){ d.r[i].time=t0+(datetime)i*sec; d.r[i].open=px; d.r[i].close=px; d.r[i].high=px+range/2; d.r[i].low=px-range/2;
    d.ema20[i]=px+emaDir; d.ema50[i]=px; d.atr[i]=range; }
}
// onde di riferimento, scritte in modo indipendente: tutti i punti di svolta in un elenco
struct Pv{ int i; double p; int type; int c; double a; };
static double refAtr(datetime t){
  int j=-1; for(int q=0;q<g_d1.n;q++) if(g_d1.r[q].time<=t && t<g_d1.r[q].time+86400) j=q;
  if(j<0){ if(g_d1.n>0 && t>=g_d1.r[g_d1.n-1].time+86400) j=g_d1.n; else return 0.0; }
  double s=0; int c=0; for(int q=j-1;q>=0 && q>=j-20;q--){ double r=g_d1.r[q].high-g_d1.r[q].low; if(r>0){ s+=r; c++; } }
  return c>=10 ? s/c : 0.0;
}
static std::vector<Pv> refZz(const TfData&d,double k){
  std::vector<Pv> out; int dir=1, ei=0; double ep=d.r[0].high;
  for(int j=1;j<d.n;j++){ double A=refAtr(d.r[j].time); if(A<=0) continue; double thr=k*A;
    if(dir>0){ if(d.r[j].high>ep){ ep=d.r[j].high; ei=j; } else if(ep-d.r[j].close>=thr){ out.push_back({ei,ep,1,j,A}); dir=-1; ep=d.r[j].low; ei=j; } }
    else { if(d.r[j].low<ep){ ep=d.r[j].low; ei=j; } else if(d.r[j].close-ep>=thr){ out.push_back({ei,ep,-1,j,A}); dir=1; ep=d.r[j].high; ei=j; } } }
  return out;
}
static bool sameZz(const ZzState&z,const std::vector<Pv>&v,const TfData&d){
  int m=(int)v.size(); if(m<3) return !z.ok;
  return z.ok && z.n==m && z.t2==v[m-1].i && fabs(z.p2-v[m-1].p)<1e-9 && z.type2==v[m-1].type && z.c2==v[m-1].c && fabs(z.a2-v[m-1].a)<1e-9 &&
         z.t1==v[m-2].i && fabs(z.p1-v[m-2].p)<1e-9 && z.t0==v[m-3].i && fabs(z.p0-v[m-3].p)<1e-9 && z.time2==d.r[v[m-1].i].time && z.conf2==d.r[v[m-1].c].time;
}
static void rdStats(int f,int k,int side,int p,double n,double mean,double sd){ g_rdN[RdIdx(f,k,side,p)]=n; g_rdS[RdIdx(f,k,side,p)]=n*mean; g_rdQ[RdIdx(f,k,side,p)]=n*(sd*sd+mean*mean); }
static void trStats(int k,int p,double n,double mean,double sd){ g_stTN[k*NPER+p]=n; g_stTS[k*NPER+p]=n*mean; g_stTQ[k*NPER+p]=n*(sd*sd+mean*mean); }
static void zzSet(int sc,int type2,double p2,datetime conf2,double a2){
  g_zz[sc].ok=true; g_zz[sc].n=5; g_zz[sc].t0=380; g_zz[sc].p0=p2+(type2<0?-5:5); g_zz[sc].t1=390; g_zz[sc].p1=p2+(type2<0?25:-25); g_zz[sc].t2=396; g_zz[sc].p2=p2;
  g_zz[sc].type2=type2; g_zz[sc].c2=399; g_zz[sc].nbars=400; g_zz[sc].time2=conf2-3*OndaBarSec(sc); g_zz[sc].conf2=conf2; g_zz[sc].a2=a2; g_zz[sc].legDir=-type2; g_zz[sc].legExt=p2;
}
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true; g_minLot=0.01; g_lotStep=0.01; g_lotDigits=2; g_sym="XAUUSD"; g_currency="EUR";
  InpVirtualCapital=0.0; S_balance=3000.0;
  chk("versione 1.27", std::string(EA_VERSION)=="1.27");
  chk("regole fisse invariate: rischio base 1%, max 3% a trade, pareggio a 1,5R, R:R 2", fabs(InpRiskPercent-1.0)<1e-9 && fabs(InpMaxRiskPerTrade-3.0)<1e-9 && fabs(InpBE_R-1.5)<1e-9 && fabs(InpMinRR-2.0)<1e-9);
  chk("regole fisse invariate: scalping x0,75, stop giorno 7%, settimana 10%, lotto minimo 2,5%", fabs(InpScalpRiskMult-0.75)<1e-9 && fabs(InpDailyLossPct-7.0)<1e-9 && fabs(InpWeeklyLossPct-10.0)<1e-9 && fabs(InpMinLotMaxRiskPct-2.5)<1e-9);
  chk("restano le scelte di 1.26 (IN-TREND soglia 0,8 e x1,5, IN-DATO x0,5, osservazione accesa)", InpIN_TREND && fabs(InpTDThreshAtr-0.8)<1e-9 && fabs(TmRiskMult(ST_IN_TREND)-1.5)<1e-9 && fabs(TmRiskMult(ST_IN_DATA)-0.5)<1e-9 && InpObserveOn && InpObserveAuto);
  // ---------- nuove strategie: nomi, motori, famiglie, rischio
  chk("20 strategie; nomi nuovi", NSTRAT==20 && g_stratName[ST_IN_TREND2]=="IN-TREND2" && g_stratName[ST_ON_M5]=="ONDA-M5" && g_stratName[ST_ON_M15]=="ONDA-M15" && g_stratName[ST_ON_H1]=="ONDA-H1" && g_stratName[ST_ON_H4]=="ONDA-H4");
  chk("motori: M5 scalping, M15 intraday, H1 e H4 swing, IN-TREND2 intraday", g_stratEngine[ST_ON_M5]==ENG_SCALP && g_stratEngine[ST_ON_M15]==ENG_INTRA && g_stratEngine[ST_ON_H1]==ENG_SWING && g_stratEngine[ST_ON_H4]==ENG_SWING && g_stratEngine[ST_IN_TREND2]==ENG_INTRA);
  chk("famiglia ritracciamenti: le quattro ONDA e nessun'altra", IsOnda(ST_ON_M5) && IsOnda(ST_ON_M15) && IsOnda(ST_ON_H1) && IsOnda(ST_ON_H4) && !IsOnda(ST_IN_TREND) && !IsOnda(ST_IN_TREND2) && !IsOnda(ST_SW_TREND));
  chk("IN-TREND2 e' un movimento forte; famiglia provata = movimenti forti + ritracciamenti", IsTrendMove(ST_IN_TREND2) && IsProvenFam(ST_IN_TREND2) && IsProvenFam(ST_ON_M5) && IsProvenFam(ST_IN_DATA) && !IsProvenFam(ST_SC_VWAP) && !IsProvenFam(ST_SW_TREND));
  chk("scale: M5=0, M15=1, H1=2, H4=3 e ritorno", OndaScale(ST_ON_M5)==0 && OndaScale(ST_ON_M15)==1 && OndaScale(ST_ON_H1)==2 && OndaScale(ST_ON_H4)==3 && OndaStrat(0)==ST_ON_M5 && OndaStrat(3)==ST_ON_H4 && OndaBarSec(0)==300 && OndaBarSec(3)==14400);
  chk("accese: le quattro scale, il secondo ingresso, la lettura del mercato", InpON_M5 && InpON_M15 && InpON_H1 && InpON_H4 && InpIN_TREND2 && InpReadOn && InpReadLearn && InpReadTrendGate && InpOndaProven);
  chk("onde: M5 0,30, M15 0,40, H1 0,80, H4 1,50; margine stop 0,10", fabs(InpOndaM5K-0.30)<1e-9 && fabs(InpOndaM15K-0.40)<1e-9 && fabs(InpOndaH1K-0.80)<1e-9 && fabs(InpOndaH4K-1.50)<1e-9 && fabs(InpOndaBufAtr-0.10)<1e-9);
  chk("stop massimo: M5 0,30, M15 0,40, H1 e H4 nessuno", fabs(OndaStopMax(0)-0.30)<1e-9 && fabs(OndaStopMax(1)-0.40)<1e-9 && OndaStopMax(2)==0.0 && OndaStopMax(3)==0.0);
  chk("target 2R su tutte le scale (mai sotto l'R:R minimo), tempo 3 onde, ritardo 15 minuti", fabs(InpOndaTargetR-2.0)<1e-9 && fabs(InpOndaTargetRLong-2.0)<1e-9 && fabs(InpOndaHoldMult-3.0)<1e-9 && InpOndaMaxDelayMin==15);
  chk("rischio: M5 x0,75 (scalping), M15/H1/H4 x1, secondo ingresso x1", fabs(TmRiskMult(ST_ON_M5)-0.75)<1e-9 && fabs(TmRiskMult(ST_ON_M15)-1.0)<1e-9 && fabs(TmRiskMult(ST_ON_H1)-1.0)<1e-9 && fabs(TmRiskMult(ST_ON_H4)-1.0)<1e-9 && fabs(TmRiskMult(ST_IN_TREND2)-1.0)<1e-9);
  chk("rischio in piu' spento di serie (direzione chiara x1, letture a favore x1): lo decide l'utente", fabs(InpOndaClearMult-1.0)<1e-9 && fabs(InpReadBoostMult-1.0)<1e-9 && fabs(InpReadCutMult-0.5)<1e-9 && InpReadCutN==2);
  chk("venerdi' sera: scelta dell'utente = dimezzare H1 e H4; senza limite di ingressi al giorno", InpOndaWeekend==1 && !InpOndaFriCloseMinLot && InpOndaNoDayLimit);
  { TSignal o; o.Reset(); o.strat=ST_ON_H1; o.proven=true; TSignal q; q.Reset(); q.strat=ST_SC_VWAP; TSignal m; m.Reset(); m.strat=ST_IN_TREND; m.proven=true;
    chk("lotto minimo: tetto 2% per i ritracciamenti, 3% movimenti forti, 2,5% gli altri", fabs(MinLotCapFor(o)-2.0)<1e-9 && fabs(MinLotCapFor(m)-3.0)<1e-9 && fabs(MinLotCapFor(q)-2.5)<1e-9);
    InpOndaMinLotRiskPct=9.0; chk("il tetto dei ritracciamenti non supera mai il massimo per trade (3%)", fabs(MinLotCapFor(o)-3.0)<1e-9); InpOndaMinLotRiskPct=2.0; }
  chk("secondo ingresso: casella propria, soglia 1,2 escursioni", TmSlot(ST_IN_TREND2)==TM_TREND2 && TM_N==4 && TmSlot(ST_IN_TREND)!=TmSlot(ST_IN_TREND2) && fabs(InpTD2ThreshAtr-1.2)<1e-9);
  chk("accensione per strategia", StratEnabled(ST_ON_M5) && StratEnabled(ST_ON_H4) && StratEnabled(ST_IN_TREND2));
  InpON_M5=false; chk("spegnere una scala la spegne davvero", !StratEnabled(ST_ON_M5) && StratEnabled(ST_ON_M15)); InpON_M5=true;
  // ---------- date di prova (martedi' 4 novembre 2025, inverno)
  datetime wd=1762214400;
  chk("data di prova: martedi' 4 novembre 2025", DowOf(wd)==2 && Ymd(wd)==20251104);
  // ---------- giornate: 80 chiuse, escursioni diverse; escursione media = le 20 prima
  { mkTf(g_d1,80,wd-80*86400,86400,4000.0,40.0,1);
    for(int i=0;i<80;i++){ double rg=30.0+(i%7)*3.0; g_d1.r[i].high=4000.0+rg/2; g_d1.r[i].low=4000.0-rg/2; }
    OndaDayAtr();
    double s=0; for(int q=60;q<80;q++) s+=g_d1.r[q].high-g_d1.r[q].low;
    chk("escursione media di oggi = media delle 20 giornate chiuse (uguale a quella dei movimenti forti)", ArraySize(g_ondaDayA)==81 && fabs(g_ondaDayA[80]-s/20)<1e-9 && fabs(TdAtr()-s/20)<1e-9);
    chk("con meno di 10 giornate prima: nessuna misura", g_ondaDayA[5]==0.0 && g_ondaDayA[9]==0.0 && g_ondaDayA[10]>0.0);
    int j=0; chk("barra di oggi -> misura di oggi; barra di 3 giorni fa -> la sua", fabs(OndaAtrAt(wd+3600,j)-g_ondaDayA[80])<1e-9 && (j=0,fabs(OndaAtrAt(wd-3*86400+7200,j)-g_ondaDayA[77])<1e-9));
    j=0; chk("barra piu' vecchia del buffer giornaliero: nessuna misura", OndaAtrAt(wd-90*86400,j)==0.0); }
  // ---------- onde: caso costruito a mano (soglia 10 $ = 0,25 x 40)
  { mkTf(g_d1,80,wd-80*86400,86400,4000.0,40.0,1); OndaDayAtr();
    std::vector<double> c; double p=100; c.push_back(p);
    for(int i=0;i<15;i++){ p+=2; c.push_back(p); }     // sale a 130 (barra 15)
    for(int i=0;i<10;i++){ p-=2; c.push_back(p); }     // scende a 110 (barra 25)
    for(int i=0;i<20;i++){ p+=2; c.push_back(p); }     // sale a 150 (barra 45)
    for(int i=0;i<12;i++){ p-=2; c.push_back(p); }     // scende a 126 (barra 57)
    for(int i=0;i<8;i++){ p+=2; c.push_back(p); }      // sale a 142 (barra 65)
    TfData d; int n=(int)c.size(); mkTf(d,n,wd+14*3600-(datetime)n*3600,3600,100.0,1.0,1);
    for(int i=0;i<n;i++){ d.r[i].close=c[i]; d.r[i].open=i?c[i-1]:c[0]; d.r[i].high=std::max(d.r[i].open,c[i])+0.5; d.r[i].low=std::min(d.r[i].open,c[i])-0.5; }
    ZzState z; ZzCompute(d,0.25,z);
    chk("a mano: tre punti (massimo 130,5, minimo 109,5, massimo 150,5) e il quarto, minimo 125,5", z.ok && z.n==4 && z.type2==-1 && fabs(z.p2-125.5)<1e-9 && z.t2==57 && fabs(z.p1-150.5)<1e-9 && z.t1==45 && fabs(z.p0-109.5)<1e-9 && z.t0==25);
    chk("a mano: il minimo e' confermato dalla prima chiusura a 10 $ dal minimo (barra 62)", z.c2==62 && z.conf2==d.r[62].time && z.time2==d.r[57].time && fabs(z.a2-40.0)<1e-9);
    chk("a mano: la gamba in corso sale", z.legDir==1 && fabs(z.legExt-142.5)<1e-9 && z.nbars==n);
    d.n=61; ZzCompute(d,0.25,z); chk("a mano: una barra prima della conferma l'ultimo punto e' ancora il massimo", z.ok && z.n==3 && z.type2==1 && fabs(z.p2-150.5)<1e-9);
    d.n=20; ZzCompute(d,0.25,z); chk("meno di 30 barre: nessuna onda", !z.ok); }
  // ---------- onde: serie casuali contro il calcolo di riferimento, su tutte le scale
  { for(int i=0;i<80;i++){ double rg=30.0+(i%7)*3.0; g_d1.r[i].high=4000.0+rg/2; g_d1.r[i].low=4000.0-rg/2; }
    OndaDayAtr();
    unsigned sd=12345; auto rnd=[&](){ sd=sd*1103515245u+12345u; return ((sd>>16)&0x7fff)/32768.0-0.5; };
    const int secs[4]={300,900,3600,14400}; const double ks[4]={0.30,0.40,0.80,1.50}; const double st[4]={3.0,5.0,10.0,20.0};
    bool all=true, trim=true; int pivots=0;
    for(int rep=0;rep<40;rep++) for(int sc=0;sc<4;sc++){
      int n=(sc==3)?300:400; TfData d; mkTf(d,n,wd+14*3600-(datetime)n*secs[sc],secs[sc],4000.0,1.0,1);
      double p=4000.0; for(int i=0;i<n;i++){ double o=p; p+=rnd()*st[sc]*2; double hi=std::max(o,p)+fabs(rnd())*st[sc]*0.6, lo=std::min(o,p)-fabs(rnd())*st[sc]*0.6;
        d.r[i].open=o; d.r[i].close=p; d.r[i].high=hi; d.r[i].low=lo; }
      ZzState z; ZzCompute(d,ks[sc],z); std::vector<Pv> v=refZz(d,ks[sc]); pivots+=(int)v.size();
      if(!sameZz(z,v,d)) all=false;
      // riavvio con un buffer piu' corto: l'ultimo punto confermato deve essere lo stesso
      if(v.size()>=8){ int cut=n/4; TfData e; mkTf(e,n-cut,d.r[cut].time,secs[sc],4000.0,1.0,1); for(int i=cut;i<n;i++) e.r[i-cut]=d.r[i];
        ZzState y; ZzCompute(e,ks[sc],y); if(!(y.ok && y.time2==z.time2 && fabs(y.p2-z.p2)<1e-9 && y.type2==z.type2 && y.conf2==z.conf2)) trim=false; }
    }
    chk("160 serie casuali (M5, M15, H1, H4): stessi punti del calcolo di riferimento", all && pivots>800);
    chk("buffer accorciato di un quarto (come dopo un riavvio): stesso ultimo punto e stessa conferma", trim); }
  // ---------- tempo massimo: conta solo il mercato aperto
  { datetime fri=wd+3*86400;
    chk("martedi' alle 10:00, 4 barre H1 -> alle 14:00", OndaDeadline(wd+10*3600,4,3600)==wd+14*3600);
    chk("venerdi' alle 18:00, 10 barre H1 -> lunedi' alle 7:30 (il weekend non conta)", OndaDeadline(fri+18*3600,10,3600)==wd+6*86400+7*3600+1800);
    chk("la pausa serale non conta: martedi' 20:00, 2 barre H1 -> mercoledi' 00:00 circa", OndaDeadline(wd+20*3600,2,3600)>wd+22*3600 && OndaDeadline(wd+20*3600,2,3600)<=wd+24*3600+900); }
  // ---------- il segnale: trend al rialzo, minimo confermato su H1
  { mkTf(g_d1,80,wd-80*86400,86400,4000.0,40.0,1); mkTf(g_h4,300,wd-300*14400,14400,4000.0,20.0,1); mkTf(g_h1,400,wd-400*3600,3600,4000.0,10.0,1);
    OndaInit(); OndaDayAtr();
    g_ctx.nowUtc=wd+14*3600+60; g_ctx.bid=4000.0; g_ctx.ask=4000.2; g_ctx.spread=0.2; g_ctx.dow=2; S_bid=4000.0; S_ask=4000.2; S_now=g_ctx.nowUtc;
    zzSet(2,-1,3970.0,wd+13*3600,40.0);
    TSignal s; bool ok=S_Onda(s,2);
    chk("H1: minimo confermato nel trend al rialzo -> acquisto", ok && s.dir==1 && s.strat==ST_ON_H1 && s.engine==ENG_SWING && fabs(s.entry-4000.2)<1e-9);
    chk("stop sotto il minimo con margine 0,1 escursioni (3966,00)", ok && fabs(s.sl-3966.0)<0.011);
    chk("target a 2R piu' tre tick (rispetta l'R:R minimo)", ok && fabs(s.tp-(4000.2+2*34.2+0.03))<0.011 && (s.tp-s.entry)>=InpMinRR*(s.entry-s.sl));
    chk("provata, con tempo massimo = 3 x 16 barre + 5 = 53 ore di mercato", ok && s.proven && s.deadline==OndaDeadline(g_ctx.nowUtc,53,3600) && s.deadline>g_ctx.nowUtc+53*3600-1);
    chk("testo dell'idea: scala, trend, direzione chiara", ok && has(s.why,"H1") && has(s.why,"al rialzo") && has(s.why,"direzione chiara") && has(s.why,"2.0R"));
    InpOndaClearMult=1.25; ok=S_Onda(s,2); chk("direzione chiara su H1: il rischio in piu' vale solo se l'utente lo accende (x1,25)", ok && fabs(s.riskX-1.25)<1e-9); InpOndaClearMult=1.0;
    ok=S_Onda(s,2); chk("di serie il rischio resta x1", ok && fabs(s.riskX-1.0)<1e-9);
    zzSet(2,1,4010.0,wd+13*3600,40.0); ok=S_Onda(s,2);
    chk("trend al rialzo e ultimo punto = massimo: non vende, aspetta un minimo", !ok && has(g_ondaText[2],"aspetta un minimo"));
    zzSet(2,-1,3995.0,wd+13*3600,40.0); OndaMarkDone(2,"aperto buy"); ok=S_Onda(s,2);
    chk("punto gia' giocato: non si riprova", !ok && has(g_ondaText[2],"aperto buy"));
    zzSet(2,-1,3990.0,wd+13*3600,40.0); g_zz[2].time2+=3600; ok=S_Onda(s,2); chk("un punto nuovo si gioca", ok);
    g_zz[2].c2=398; ok=S_Onda(s,2); chk("conferma non sull'ultima barra chiusa: passato", !ok && has(g_ondaText[2],"passato")); g_zz[2].c2=399;
    g_ctx.nowUtc=wd+14*3600+15*60+59; ok=S_Onda(s,2); chk("15 minuti dopo la conferma: ancora in tempo", ok);
    g_ctx.nowUtc=wd+14*3600+16*60; ok=S_Onda(s,2); chk("16 minuti dopo: troppo tardi", !ok && has(g_ondaText[2],"passato")); g_ctx.nowUtc=wd+14*3600+60;
    g_ctx.ask=3986.05; g_ctx.bid=3985.85; ok=S_Onda(s,2); chk("prezzo tornato a 5 centesimi dallo stop: niente (i costi si mangerebbero l'idea)", !ok && has(g_ondaText[2],"tornato sul punto"));
    g_ctx.ask=3995.0; g_ctx.bid=3994.8; ok=S_Onda(s,2); chk("stop a 9 $ su H1 (meno di 0,25 escursioni): ancora troppo vicino", !ok);
    g_ctx.ask=3997.0; g_ctx.bid=3996.8; ok=S_Onda(s,2); chk("stop a 11 $ su H1: si puo' entrare", ok && fabs((s.entry-s.sl)-11.0)<0.011); g_ctx.ask=4000.2; g_ctx.bid=4000.0;
    // conto piccolo: lo stop si stringe fino al minimo della scala
    zzSet(2,-1,3950.0,wd+13*3600,40.0); g_zz[2].time2+=7200; ok=S_Onda(s,2); double sFull=s.entry-s.sl;
    chk("3000 euro, stop largo 54 $: il lotto minimo rischia meno del 2%, stop intero", ok && fabs(sFull-54.2)<0.011);
    S_balance=2000.0; ok=S_Onda(s,2); double sT=s.entry-s.sl; double pctT=100.0*(sT/1.08+0.07)*1.0/2000.0;
    chk("2000 euro: stop stretto quanto serve per stare nel 2%, mai sotto 0,5 escursioni", ok && sT<sFull-1.0 && sT>=20.0-0.011 && pctT<=2.05 && (s.tp-s.entry)>=2.0*sT);
    S_balance=300.0; ok=S_Onda(s,2); chk("300 euro: si ferma al minimo della scala (0,5 escursioni = 20 $)", ok && fabs((s.entry-s.sl)-20.0)<0.011); S_balance=3000.0;
    // M15: tetto dello stop
    zzSet(1,-1,3970.0,wd+13*3600+45*60,40.0); ok=S_Onda(s,1);
    chk("M15: stop piu' largo di 0,4 escursioni -> tagliato a 16 $, target 32 $", ok && s.engine==ENG_INTRA && fabs((s.entry-s.sl)-16.0)<0.011 && fabs((s.tp-s.entry)-32.03)<0.011);
    // M5: solo con direzione chiara
    zzSet(0,-1,3996.0,wd+13*3600+55*60,40.0); ok=S_Onda(s,0);
    chk("M5 con D1, H4 e H1 d'accordo: entra (motore scalping)", ok && s.engine==ENG_SCALP && s.strat==ST_ON_M5 && fabs((s.entry-s.sl)-8.2)<0.011);
    mkTf(g_h1,400,wd-400*3600,3600,4000.0,10.0,-1); ok=S_Onda(s,0);
    chk("M5 con H1 contrario: non entra", !ok && has(g_ondaText[0],"non d'accordo"));
    ok=S_Onda(s,1); chk("M15 entra anche senza direzione chiara", ok && !has(s.why,"direzione chiara"));
    InpOndaM5NeedAll=false; ok=S_Onda(s,0); chk("M5 senza l'obbligo (parametro): entra", ok); InpOndaM5NeedAll=true;
    // vendita nel trend al ribasso
    mkTf(g_d1,80,wd-80*86400,86400,4000.0,40.0,-1); zzSet(2,1,4010.0,wd+13*3600,40.0); g_zz[2].time2+=10800; ok=S_Onda(s,2);
    chk("trend al ribasso, massimo confermato -> vendita, stop sopra il massimo + margine + spread", ok && s.dir==-1 && fabs(s.entry-4000.0)<1e-9 && fabs(s.sl-4014.2)<0.011 && fabs(s.tp-(4000.0-2*14.2-0.03))<0.011);
    zzSet(2,-1,3995.0,wd+13*3600,40.0); ok=S_Onda(s,2); chk("trend al ribasso e ultimo punto = minimo: non compra (contro trend perde)", !ok && has(g_ondaText[2],"aspetta un massimo"));
    for(int i=0;i<80;i++) g_d1.ema20[i]=g_d1.ema50[i]; ok=S_Onda(s,2); chk("trend giornaliero incerto: niente", !ok && has(g_ondaText[2],"incerto"));
    g_zz[2].ok=false; mkTf(g_d1,80,wd-80*86400,86400,4000.0,40.0,1); ok=S_Onda(s,2); chk("dati insufficienti: niente", !ok && has(g_ondaText[2],"insufficienti"));
    mkTf(g_h1,400,wd-400*3600,3600,4000.0,10.0,1);
    { std::string pn=OndaPanel(); chk("pannello: una voce per scala accesa", has(pn,"Ritracciamenti") && has(pn,"M5") && has(pn,"M15") && has(pn,"H1") && has(pn,"H4") && pn.size()<420); } }
  // ---------- uscite obbligate dei ritracciamenti
  { datetime fri=wd+3*86400; int mi=0; std::string why;
    g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].strat=ST_ON_H1; g_meta[mi].engine=ENG_SWING; g_meta[mi].dir=1; g_meta[mi].openTime=wd+9*3600; g_meta[mi].deadline=wd+13*3600;
    S_now=wd+12*3600+59*60; chk("prima del tempo massimo: resta", !ForcedExit(mi,why));
    S_now=wd+13*3600; chk("al tempo massimo: chiude", ForcedExit(mi,why) && has(why,"tempo massimo"));
    g_meta[mi].deadline=wd+30*86400; S_now=wd+21*3600; chk("la sera di un giorno normale non chiude (non e' un intraday qualsiasi)", !ForcedExit(mi,why));
    g_meta[mi].strat=ST_ON_M15; g_meta[mi].engine=ENG_INTRA; chk("anche M15 resta aperto la sera fino al suo tempo massimo", !ForcedExit(mi,why));
    S_now=fri+20*3600+300; chk("venerdi' sera: M15 chiude", ForcedExit(mi,why) && has(why,"venerdi"));
    g_meta[mi].strat=ST_ON_M5; g_meta[mi].engine=ENG_SCALP; chk("venerdi' sera: M5 chiude", ForcedExit(mi,why));
    g_meta[mi].strat=ST_ON_H1; g_meta[mi].engine=ENG_SWING; chk("venerdi' sera: H1 non chiude (si dimezza)", !ForcedExit(mi,why));
    g_meta[mi].strat=ST_ON_H4; chk("venerdi' sera: H4 non chiude (si dimezza)", !ForcedExit(mi,why));
    InpOndaWeekend=2; chk("con la scelta 'chiudere': H4 chiude", ForcedExit(mi,why)); InpOndaWeekend=0; chk("con la scelta 'tenere': resta", !ForcedExit(mi,why)); InpOndaWeekend=1;
    g_meta[mi].deadline=0; g_meta[mi].strat=ST_ON_H1; g_meta[mi].openTime=wd; S_now=wd+149*3600; chk("senza tempo massimo salvato: riserva di 150 barre, prima resta", !ForcedExit(mi,why));
    S_now=wd+150*3600; chk("senza tempo massimo salvato: a 150 barre chiude", ForcedExit(mi,why) && has(why,"tempo massimo"));
    // dimezzamento del venerdi' sera
    P.clear(); SimPos q; q.ticket=7001; q.id=7001; q.type=0; q.vol=0.02; q.open=4000.0; q.sl=3990.0; q.tp=4020.0; q.time=wd+9*3600; q.magic=0; q.comment="XC ONDA-H1"; P.push_back(q);
    S_bid=4005.0; S_ask=4005.2; S_now=fri+20*3600+300; g_ctx.nowUtc=S_now; g_ctx.bid=S_bid; g_ctx.ask=S_ask;
    g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].id=7001; g_meta[mi].strat=ST_ON_H1; g_meta[mi].engine=ENG_SWING; g_meta[mi].dir=1; g_meta[mi].entry=4000.0; g_meta[mi].sl0=3990.0;
    g_meta[mi].riskPx=10.0; g_meta[mi].lots0=0.02; g_meta[mi].openTime=wd+9*3600; g_meta[mi].deadline=wd+30*86400;
    PositionSelectByTicket(7001); ManageOne(7001,mi);
    chk("venerdi' sera, H1 da 0,02 lotti: meta' chiusa, resta 0,01, il bot avvisa", P.size()==1 && fabs(P[0].vol-0.01)<1e-9 && g_meta[mi].wkDone && logHas("dimezzato prima del weekend"));
    PositionSelectByTicket(7001); ManageOne(7001,mi); chk("una volta sola: al minuto dopo non taglia ancora", P.size()==1 && fabs(P[0].vol-0.01)<1e-9);
    g_meta[mi].wkDone=false; g_meta[mi].lots0=0.01; PositionSelectByTicket(7001); ManageOne(7001,mi);
    chk("un solo lotto minimo: non si divide, resta aperto e il bot dice quanto rischia nel weekend", P.size()==1 && fabs(P[0].vol-0.01)<1e-9 && g_meta[mi].wkDone && logHas("resta intero nel weekend") && logHas("rischio fino allo stop"));
    g_meta[mi].wkDone=false; InpOndaFriCloseMinLot=true; PositionSelectByTicket(7001);
    chk("con InpOndaFriCloseMinLot: il lotto minimo che non si divide viene chiuso", ForcedExit(mi,why) && has(why,"un solo lotto minimo")); InpOndaFriCloseMinLot=false;
    S_now=wd+86400+10*3600; g_ctx.nowUtc=S_now; g_meta[mi].wkDone=false; PositionSelectByTicket(7001); ManageOne(7001,mi);
    chk("gli altri giorni non dimezza", fabs(P[0].vol-0.01)<1e-9 && !g_meta[mi].wkDone);
    // pareggio a 1,5R anche per i ritracciamenti, niente trailing
    S_bid=4016.0; S_ask=4016.2; g_ctx.bid=S_bid; g_ctx.ask=S_ask; PositionSelectByTicket(7001); ManageOne(7001,mi);
    chk("a +1,5R lo stop va a pareggio (regola fissa)", g_meta[mi].beDone && P[0].sl>=4000.0 && P[0].sl<4002.0);
    double slBe=P[0].sl; S_bid=4019.0; S_ask=4019.2; g_ctx.bid=S_bid; g_ctx.ask=S_ask; PositionSelectByTicket(7001); ManageOne(7001,mi);
    chk("niente trailing: lo stop resta a pareggio fino al target", fabs(P[0].sl-slBe)<1e-9);
    P.clear(); g_meta[mi].Reset(); }
  // ---------- file dei metadati: tempo massimo e weekend sopravvivono a un riavvio
  { g_isTester=false; S_tester=false; g_login=123456; for(int i=0;i<MAX_META;i++) g_meta[i].Reset();
    g_meta[0].active=true; g_meta[0].id=9001; g_meta[0].strat=ST_ON_H4; g_meta[0].engine=ENG_SWING; g_meta[0].dir=-1; g_meta[0].entry=4000.0; g_meta[0].sl0=4050.0; g_meta[0].riskPx=50.0;
    g_meta[0].lots0=0.03; g_meta[0].openTime=wd; g_meta[0].deadline=wd+9*86400+1800; g_meta[0].wkDone=true;
    g_meta[1].active=true; g_meta[1].id=9002; g_meta[1].strat=ST_ON_M5; g_meta[1].engine=ENG_SCALP; g_meta[1].dir=1; g_meta[1].deadline=wd+7200;
    MetaSave(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); MetaLoad();
    int a=MetaFind(9001), b=MetaFind(9002);
    chk("salvataggio e rilettura: tempo massimo e 'weekend gia' gestito' tornano uguali", a>=0 && b>=0 && g_meta[a].deadline==wd+9*86400+1800 && g_meta[a].wkDone && g_meta[a].strat==ST_ON_H4 && g_meta[b].deadline==wd+7200 && !g_meta[b].wkDone);
    // file scritto dalla 1.26 (21 campi): si legge lo stesso, senza tempo massimo
    { std::string path="simfiles/"+MetaFile(); FILE*f=fopen(path.c_str(),"w"); if(f){ fprintf(f,"9003;%d;1;1;0;5;4000.00000;3990.00000;4020.00000;10.00000;30.00;0.03;0.700;0;1;0;0;%ld;0;0;0\r\n",ST_IN_TREND,(long)wd); fclose(f); }
      for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); MetaLoad(); int c=MetaFind(9003);
      chk("file della 1.26 (senza i campi nuovi): letto, tempo massimo 0", c>=0 && g_meta[c].strat==ST_IN_TREND && g_meta[c].beDone && g_meta[c].deadline==0 && !g_meta[c].wkDone);
      remove(path.c_str()); }
    for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); g_isTester=true; S_tester=true; }
  // ---------- lettura del mercato: etichette
  { RdInit(); StInit();
    chk("14 letture, 4 famiglie", NREAD==14 && NFAM==4 && g_rdName[RD_D1]=="trend giornaliero" && g_rdName[RD_MACRO]=="macro" && g_rdName[RD_LIQ]=="liquidita' presa" && g_famName[FAM_ONDA]=="ritracciamenti");
    chk("famiglie: ritracciamenti, movimenti forti, vecchie di tendenza, vecchie di inversione", RdFamily(ST_ON_M15)==FAM_ONDA && RdFamily(ST_IN_TREND2)==FAM_MF && RdFamily(ST_SW_TREND)==FAM_TREND && RdFamily(ST_SC_SWEEP)==FAM_REV);
    for(int k=0;k<NREAD;k++) g_rdDir[k]=0;
    g_rdDir[RD_D1]=1; g_rdDir[RD_MACRO]=-1; g_rdDir[RD_LIQ]=1; g_rdDir[RD_ZONE]=-1;
    TSignal s; s.Reset(); s.strat=ST_SC_SWEEP; s.dir=1; RdEval(s);
    chk("acquisto: a favore trend giornaliero e liquidita', contro macro e zona", s.rdFav==((1<<RD_D1)|(1<<RD_LIQ)) && s.rdAg==((1<<RD_MACRO)|(1<<RD_ZONE)) && s.rdConf==0);
    s.dir=-1; RdEval(s); chk("vendita: al contrario", s.rdAg==((1<<RD_D1)|(1<<RD_LIQ)) && s.rdFav==((1<<RD_MACRO)|(1<<RD_ZONE)));
    chk("elenco per il diario", RdList(s.rdFav)=="macro, zona di domanda/offerta" && RdList(0)=="");
    chk("nessuna lettura provata: il rischio non cambia", fabs(ReadRiskMult(s)-1.0)<1e-9);
    // misura: a favore +0,40R, contro -0,20R, 50 casi per periodo e lato
    for(int p=0;p<NPER;p++){ rdStats(FAM_REV,RD_ZONE,0,p,50,0.40,1.2); rdStats(FAM_REV,RD_ZONE,1,p,50,-0.20,1.2); }
    chk("lettura provata: 200+200 casi, +0,60R di differenza, 4 periodi d'accordo", RdEvaluate(FAM_REV,RD_ZONE)==RDS_USEFUL);
    for(int p=0;p<NPER;p++){ rdStats(FAM_REV,RD_LIQ,0,p,50,-0.20,1.2); rdStats(FAM_REV,RD_LIQ,1,p,50,0.40,1.2); }
    chk("provata al contrario: le idee vanno meglio con la lettura contro", RdEvaluate(FAM_REV,RD_LIQ)==RDS_INVERSE);
    for(int p=0;p<NPER;p++){ rdStats(FAM_REV,RD_FVG,0,p,50,0.10,1.2); rdStats(FAM_REV,RD_FVG,1,p,50,0.02,1.2); }
    chk("non provata: differenza sotto 0,10R", RdEvaluate(FAM_REV,RD_FVG)==RDS_TEST);
    for(int p=0;p<NPER;p++){ rdStats(FAM_REV,RD_FVG,0,p,50,0.20,1.2); rdStats(FAM_REV,RD_FVG,1,p,50,0.02,1.2); }
    chk("non provata: +0,18R ma non lontano dal caso (2,5 errori standard)", RdEvaluate(FAM_REV,RD_FVG)==RDS_TEST);
    for(int p=0;p<NPER;p++){ double mf=(p<2)?-0.3:1.5; rdStats(FAM_REV,RD_FVG,0,p,50,mf,1.2); rdStats(FAM_REV,RD_FVG,1,p,50,0.0,1.2); }
    chk("non provata: meglio solo in 2 periodi su 4", RdEvaluate(FAM_REV,RD_FVG)==RDS_TEST);
    for(int p=0;p<NPER;p++){ rdStats(FAM_REV,RD_FVG,0,p,6,1.0,0.5); rdStats(FAM_REV,RD_FVG,1,p,6,-1.0,0.5); }
    chk("non provata: 24 casi per lato sono pochi (ne servono 30)", RdEvaluate(FAM_REV,RD_FVG)==RDS_TEST);
    for(int p=0;p<NPER;p++){ rdStats(FAM_REV,RD_FVG,0,p,0,0,0); rdStats(FAM_REV,RD_FVG,1,p,0,0,0); } rdStats(FAM_REV,RD_FVG,0,3,40,0.6,1.0); rdStats(FAM_REV,RD_FVG,1,3,40,-0.4,1.0);
    chk("conto vero (un periodo solo): 40 casi per lato non bastano, ne servono 60", RdEvaluate(FAM_REV,RD_FVG)==RDS_TEST);
    rdStats(FAM_REV,RD_FVG,0,3,70,0.6,1.0); rdStats(FAM_REV,RD_FVG,1,3,70,-0.4,1.0); chk("conto vero: 70 casi per lato, +1,0R di differenza -> provata", RdEvaluate(FAM_REV,RD_FVG)==RDS_USEFUL);
    InpReadLearn=false; chk("misura spenta: nessuna lettura conta", RdEvaluate(FAM_REV,RD_ZONE)==RDS_TEST); InpReadLearn=true;
    RdRefresh(false);
    chk("dopo il ricalcolo: zona provata, liquidita' al contrario, solo per le vecchie di inversione", g_rdState[FAM_REV*NREAD+RD_ZONE]==RDS_USEFUL && g_rdState[FAM_REV*NREAD+RD_LIQ]==RDS_INVERSE && g_rdState[FAM_ONDA*NREAD+RD_ZONE]==RDS_TEST && g_rdState[FAM_TREND*NREAD+RD_ZONE]==RDS_TEST);
    // acquisto: zona contro (-1) e liquidita' a favore ma provata al contrario (-1) -> due letture provate contro
    for(int k=0;k<NREAD;k++) g_rdDir[k]=0; g_rdDir[RD_ZONE]=-1; g_rdDir[RD_LIQ]=1;
    s.Reset(); s.strat=ST_SC_SWEEP; s.dir=1; RdEval(s);
    chk("due letture provate contro l'idea: rischio dimezzato", s.rdConf==-2 && fabs(ReadRiskMult(s)-0.5)<1e-9);
    s.dir=-1; RdEval(s); chk("due letture provate a favore: di serie il rischio resta x1 (alzarlo e' una scelta)", s.rdConf==2 && fabs(ReadRiskMult(s)-1.0)<1e-9);
    InpReadBoostMult=1.3; chk("con InpReadBoostMult 1,3: rischio x1,3", fabs(ReadRiskMult(s)-1.3)<1e-9); InpReadBoostMult=9.0; chk("mai oltre x1,5", fabs(ReadRiskMult(s)-1.5)<1e-9); InpReadBoostMult=1.0;
    g_rdDir[RD_LIQ]=0; s.dir=1; RdEval(s); chk("una sola lettura provata contro: non basta a tagliare", s.rdConf==-1 && fabs(ReadRiskMult(s)-1.0)<1e-9);
    s.strat=ST_ON_H1; g_rdDir[RD_LIQ]=1; RdEval(s); chk("per i ritracciamenti quelle letture non sono provate: nessun effetto", s.rdConf==0 && s.rdAg==(1<<RD_ZONE));
    InpReadOn=false; s.strat=ST_SC_SWEEP; RdEval(s); chk("lettura spenta: nessuna etichetta, rischio x1", s.rdFav==0 && s.rdAg==0 && fabs(ReadRiskMult(s)-1.0)<1e-9); InpReadOn=true;
    { std::string pn=RdPanel(); chk("pannello: cosa vede e quali letture contano", has(pn,"Lettura del mercato") && has(pn,"Letture provate (3)") && has(pn,"al contrario") && pn.size()<520); } }
  // ---------- conti delle idee: RdAdd
  { RdInit(); datetime t24=1717200000; /* giugno 2024 */
    RdAdd(ST_SC_SWEEP,(1<<RD_D1)|(1<<RD_LIQ),(1<<RD_MACRO),t24,1.5,true);
    RdAdd(ST_SC_SWEEP,(1<<RD_MACRO),(1<<RD_D1),t24,-1.0,true);
    RdAdd(ST_SC_SWEEP,(1<<RD_D1),0,t24,2.0,false);
    int p=ObPeriod(t24);
    chk("ogni idea chiusa finisce nel conto della sua famiglia, lato a favore o contro", p==2 && g_rdTot==3.0 && g_rdN[RdIdx(FAM_REV,RD_D1,0,p)]==2.0 && fabs(g_rdS[RdIdx(FAM_REV,RD_D1,0,p)]-3.5)<1e-9 && g_rdN[RdIdx(FAM_REV,RD_D1,1,p)]==1.0 &&
        g_rdN[RdIdx(FAM_REV,RD_MACRO,0,p)]==1.0 && g_rdN[RdIdx(FAM_REV,RD_MACRO,1,p)]==1.0 && g_rdN[RdIdx(FAM_REV,RD_LIQ,0,p)]==1.0 && g_rdN[RdIdx(FAM_ONDA,RD_D1,0,p)]==0.0);
    chk("conto 'nel verso del trend giornaliero': solo le idee approvate con il trend a favore", g_stTN[ST_SC_SWEEP*NPER+p]==1.0 && fabs(g_stTS[ST_SC_SWEEP*NPER+p]-1.5)<1e-9); }
  // ---------- vecchie strategie: aprono solo nel verso del trend se li' guadagnano
  { RdInit(); StInit(); StRefresh(false);
    chk("SC-VWAP parte in osservazione", StratObserved(ST_SC_VWAP));
    TSignal s; s.Reset(); s.strat=ST_SC_VWAP; s.dir=1; s.rdFav=(1<<RD_D1);
    chk("senza numeri: l'idea resta sulla carta", IdeaObserved(s) && !StTrendEvaluate(ST_SC_VWAP));
    for(int p=0;p<NPER;p++) trStats(ST_SC_VWAP,p,30,0.35,1.2);
    chk("120 idee nel trend a +0,35R, 4 periodi positivi: promosse", StTrendEvaluate(ST_SC_VWAP));
    RdRefresh(false);
    chk("ora l'idea nel verso del trend apre un ordine", g_stCond[ST_SC_VWAP] && !IdeaObserved(s));
    s.rdFav=0; s.rdAg=(1<<RD_D1); chk("l'idea contro il trend resta sulla carta", IdeaObserved(s));
    s.rdFav=(1<<RD_D1); InpReadTrendGate=false; chk("con il collegamento spento resta tutto sulla carta", IdeaObserved(s)); InpReadTrendGate=true;
    for(int p=0;p<NPER;p++) trStats(ST_SC_VWAP,p,30,0.08,1.2); chk("+0,08R non basta", !StTrendEvaluate(ST_SC_VWAP));
    for(int p=0;p<NPER;p++) trStats(ST_SC_VWAP,p,30,(p<2)?-0.2:1.0,1.2); chk("guadagna solo in 2 periodi su 4: no", !StTrendEvaluate(ST_SC_VWAP));
    for(int p=0;p<NPER;p++) trStats(ST_SC_VWAP,p,10,1.0,0.5); chk("40 idee sono poche (ne servono 60)", !StTrendEvaluate(ST_SC_VWAP));
    for(int p=0;p<NPER;p++) trStats(ST_ON_H1,p,30,0.35,1.2); chk("non riguarda le strategie gia' provate", !StTrendEvaluate(ST_ON_H1));
    TSignal o; o.Reset(); o.strat=ST_ON_H1; o.dir=1; chk("i ritracciamenti non sono in osservazione", !StratObserved(ST_ON_H1) && !IdeaObserved(o) && !StratObserved(ST_IN_TREND2)); }
  // ---------- file delle letture: scrittura e rilettura
  { remove("simfiles/XauCommittee_tester_letture.csv"); RdInit(); StInit();
    for(int p=0;p<NPER;p++){ rdStats(FAM_REV,RD_ZONE,0,p,50,0.40,1.2); rdStats(FAM_REV,RD_ZONE,1,p,50,-0.20,1.2); trStats(ST_SC_VWAP,p,30,0.35,1.2); }
    rdStats(FAM_ONDA,RD_MACRO,0,3,12,0.25,1.0); g_rdTot=900.0; RdRefresh(false);
    g_isTester=true; RdSave();
    FILE*f=fopen("simfiles/XauCommittee_tester_letture.csv","r"); chk("il Tester scrive XauCommittee_tester_letture.csv", f!=NULL); if(f) fclose(f);
    RdLoad(); chk("nel Tester si riparte da zero", g_rdTot==0.0 && g_rdN[RdIdx(FAM_REV,RD_ZONE,0,0)]==0.0);
    g_isTester=false; S_tester=false; g_login=123456; remove(("simfiles/"+RdFile(false)).c_str());
    RdLoad();
    chk("il conto parte da quello che ha misurato il Tester (900 idee, zona 200+200, macro 12)", fabs(g_rdTot-900)<1e-6 && fabs(g_rdN[RdIdx(FAM_REV,RD_ZONE,0,1)]-50)<1e-6 && fabs(g_rdS[RdIdx(FAM_REV,RD_ZONE,1,2)]+10.0)<1e-3 &&
        fabs(g_rdN[RdIdx(FAM_ONDA,RD_MACRO,0,3)]-12)<1e-6 && fabs(g_stTN[ST_SC_VWAP*NPER+0]-30)<1e-6);
    chk("e con quei conti la zona e' provata da subito e SC-VWAP apre nel trend", g_rdState[FAM_REV*NREAD+RD_ZONE]==RDS_USEFUL && g_stCond[ST_SC_VWAP]);
    InpObjFromTester=false; RdLoad(); chk("InpObjFromTester spento: il conto parte da zero", g_rdTot==0.0 && g_rdState[FAM_REV*NREAD+RD_ZONE]==RDS_TEST); InpObjFromTester=true;
    // file rovinato: conti piu' grandi del totale non vengono creduti
    { FILE*g=fopen("simfiles/XauCommittee_tester_letture.csv","r"); std::string all; if(g){ char buf[4096]; size_t r; while((r=fread(buf,1,sizeof buf,g))>0) all.append(buf,r); fclose(g); }
      size_t at=all.find("totale;-;-;-;900"); if(at!=std::string::npos) all.replace(at,16,"totale;-;-;-;20");
      g=fopen("simfiles/XauCommittee_tester_letture.csv","w"); if(g){ fwrite(all.data(),1,all.size(),g); fclose(g); }
      RdLoad(); chk("file rovinato (conti oltre il totale): scartati, niente e' provato", g_rdN[RdIdx(FAM_REV,RD_ZONE,0,1)]==0.0 && g_rdState[FAM_REV*NREAD+RD_ZONE]==RDS_TEST && !g_stCond[ST_SC_VWAP]); }
    g_isTester=true; S_tester=true; remove("simfiles/XauCommittee_tester_letture.csv"); RdInit(); }
  // ---------- letture che guardano il grafico
  { g_ctx.nowUtc=wd+15*3600; g_liqDir=0;
    RdLiqLevel(3990.0,-1,"il minimo di Asia",0.8,3988.5,3996.0,3992.0,3991.0);
    chk("minimo bucato di piu' della tolleranza e chiusura tornata sopra: liquidita' presa, a favore dei rialzi", g_liqDir==1 && fabs(g_liqExt-3988.5)<1e-9 && has(g_liqName,"minimo di Asia"));
    g_liqDir=0; RdLiqLevel(3990.0,-1,"il minimo di Asia",0.8,3989.5,3996.0,3992.0,3991.0); chk("bucato di poco (dentro la tolleranza): niente", g_liqDir==0);
    RdLiqLevel(3990.0,-1,"il minimo di Asia",0.8,3988.5,3996.0,3989.0,3991.0); chk("bucato ma non recuperato: niente", g_liqDir==0);
    RdLiqLevel(4010.0,1,"il massimo di ieri",0.8,4000.0,4011.5,4008.0,4009.0); chk("massimo preso e respinto: a favore dei ribassi", g_liqDir==-1 && has(g_liqName,"massimo di ieri"));
    g_liqDir=0; RdLiqLevel(0.0,1,"x",0.8,4000.0,4011.5,4008.0,4009.0); chk("livello mancante: niente", g_liqDir==0);
    // sbilanciamento M15: vuoto di 6 $ lasciato da una barra di spinta, non riempito
    mkTf(g_m15,40,wd,900,4000.0,2.0,1);
    for(int i=30;i<40;i++){ g_m15.r[i].open=4010.0; g_m15.r[i].close=4010.0; g_m15.r[i].high=4011.0; g_m15.r[i].low=4009.0; }
    g_m15.r[29].open=4001.0; g_m15.r[29].close=4009.0; g_m15.r[29].high=4010.0; g_m15.r[29].low=4001.0; g_m15.r[30].low=4007.0;
    RdFvgOnM15(40.0);
    chk("sbilanciamento rialzista non riempito tra 4001 e 4007", fabs(g_fvgUpLo-4001.0)<1e-9 && fabs(g_fvgUpHi-4007.0)<1e-9 && g_fvgDnHi==0.0);
    g_m15.r[38].low=4000.5; RdFvgOnM15(40.0); chk("una barra dopo lo riempie: non c'e' piu'", g_fvgUpHi==0.0); }
  // ---------- secondo ingresso della giornata di tendenza (soglia 1,2 escursioni = 48 $)
  { mkTf(g_d1,80,wd-80*86400,86400,4000.0,40.0,1); TmInit();
    datetime a=wd+13*3600; std::vector<double> c; for(int i=0;i<20;i++) c.push_back(4000.0); for(int i=0;i<110;i++) c.push_back(4000.0+i*0.5);
    auto upto=[&](int nb){ std::vector<double> x(c.begin(),c.begin()+nb); int n=(int)x.size(); ArrayResize(g_m1.r,n); g_m1.n=n; datetime t0=a-20*60;
      for(int i=0;i<n;i++){ g_m1.r[i].time=t0+i*60; g_m1.r[i].open=i?x[i-1]:x[0]; g_m1.r[i].close=x[i]; g_m1.r[i].high=std::max(g_m1.r[i].open,x[i])+0.1; g_m1.r[i].low=std::min(g_m1.r[i].open,x[i])-0.1; }
      g_ctx.nowUtc=t0+(datetime)n*60; g_ctx.dow=2; double px=x[n-1]; g_ctx.bid=px; g_ctx.ask=px+0.2; g_ctx.spread=0.2; S_bid=px; S_ask=px+0.2; S_now=g_ctx.nowUtc; };
    TSignal s1, s2;
    upto(20+65); bool f1=S_InTrendDay(s1); bool f2=S_InTrend2(s2);
    chk("a +32 $ (0,8 escursioni): scatta il primo ingresso, non il secondo", f1 && s1.strat==ST_IN_TREND && s1.dir==1 && !f2);
    upto(20+90); f2=S_InTrend2(s2); chk("a +44 $: il secondo aspetta ancora", !f2);
    upto(20+97); f2=S_InTrend2(s2);
    chk("a +48 $ (1,2 escursioni): scatta il secondo ingresso, stesso verso", f2 && s2.strat==ST_IN_TREND2 && s2.dir==1 && has(s2.why,"secondo ingresso") && (s2.tp-s2.entry)>=InpMinRR*(s2.entry-s2.sl)-0.011);
    TmMarkDone(ST_IN_TREND2,Ymd(g_ctx.nowUtc),"aperto buy"); f2=S_InTrend2(s2); chk("una volta al giorno: non si ripete", !f2);
    f1=S_InTrendDay(s1); chk("il primo ingresso ha il suo conto separato", g_tmDoneKey[TM_TREND]!=Ymd(g_ctx.nowUtc));
    InpTD2ThreshAtr=0.5; TmInit(); upto(20+66); f2=S_InTrend2(s2); chk("la soglia del secondo non scende mai sotto quella del primo + 0,05 (a +32,5 $ no)", !f2);
    upto(20+70); f2=S_InTrend2(s2); chk("e a +34,5 $ (0,85 escursioni) si'", f2); InpTD2ThreshAtr=1.2;
    InpIN_TREND2=false; chk("spento: non e' attivo", !StratEnabled(ST_IN_TREND2)); InpIN_TREND2=true; }
  // ---------- movimenti forti e ritracciamenti aperti: posti, perdite di fila, verso opposto
  { P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); g_netting=false; g_lossesInRowToday=0; InpOnlyStrategy=PICK_ALL;
    for(int e=0;e<3;e++) g_tradesToday[e]=0;
    auto pos=[&](ulong tk,int eng,int strat,int dir,double open,double sl){ SimPos q; q.ticket=tk; q.id=(long)tk; q.type=(dir>0)?0:1; q.vol=0.01; q.open=open; q.sl=sl; q.tp=0; q.time=wd; q.magic=(ulong)MagicOfEngine(eng); q.comment="XC"; P.push_back(q);
      int k=MetaFree(); g_meta[k].Reset(); g_meta[k].active=true; g_meta[k].id=(long)tk; g_meta[k].strat=strat; g_meta[k].engine=eng; g_meta[k].dir=dir; };
    auto sig=[&](int strat,int dir){ TSignal s; s.Reset(); s.strat=strat; s.engine=g_stratEngine[strat]; s.dir=dir; PortfolioChecks(s); return s; };
    chk("scelte: ritracciamenti fuori dagli slot, movimenti forti oltre le perdite di fila e gli slot, niente chiusura dei ritracciamenti opposti", InpOndaOwnSlots && InpTDNoStreak && InpTDNoSlot && !InpTDFlipOnda);
    pos(8001,ENG_INTRA,ST_ON_M15,1,4000,3990); pos(8002,ENG_INTRA,ST_ON_M15,1,4001,3991);
    PortfolioScan();
    chk("due ritracciamenti M15 aperti: contano nelle 4 posizioni ma non occupano gli slot dell'intraday", g_cntAll==2 && g_cntOnda==2 && g_cntEng[ENG_INTRA]==0 && g_cntDir[0]==2);
    InpOndaOwnSlots=false; PortfolioScan(); chk("con InpOndaOwnSlots spento li occupano (come prima)", g_cntEng[ENG_INTRA]==2 && g_cntOnda==0); InpOndaOwnSlots=true;
    { TSignal s=sig(ST_IN_PULLBACK,1); chk("una vecchia strategia intraday trova ancora posto", !s.veto); }
    { TSignal s=sig(ST_ON_H1,1); chk("un altro ritracciamento nello stesso verso: nessun veto di portafoglio", !s.veto); }
    // perdite di fila
    g_lossesInRowToday=3;
    { TSignal a=sig(ST_IN_TREND,1), b=sig(ST_ON_M15,1), c=sig(ST_IN_PULLBACK,1), d=sig(ST_IN_TREND2,1), e=sig(ST_IN_DATA,1);
      chk("3 perdite di fila oggi: i ritracciamenti e le vecchie strategie si fermano", b.veto && has(b.vetoWhy,"perdite di fila") && c.veto);
      chk("3 perdite di fila oggi: i movimenti forti (IN-TREND, IN-TREND2, IN-DATO) entrano lo stesso", !a.veto && !d.veto && !e.veto); }
    InpTDNoStreak=false; { TSignal a=sig(ST_IN_TREND,1); chk("con InpTDNoStreak spento si fermano anche loro (come nella 1.26)", a.veto && has(a.vetoWhy,"perdite di fila")); } InpTDNoStreak=true;
    g_lossesInRowToday=0;
    // slot: movimento forte di ieri e di oggi ancora aperti
    P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset();
    pos(8003,ENG_INTRA,ST_IN_TREND,1,4000,3985); pos(8004,ENG_INTRA,ST_IN_TREND,1,4010,3995);
    { TSignal a=sig(ST_IN_TREND2,1), b=sig(ST_IN_PULLBACK,1);
      chk("due movimenti forti aperti (ieri e oggi): il secondo ingresso non si ferma per gli slot", !a.veto);
      chk("ma una vecchia strategia intraday si' (slot pieni)", b.veto && has(b.vetoWhy,"slot del motore")); }
    InpTDNoSlot=false; { TSignal a=sig(ST_IN_TREND2,1); chk("con InpTDNoSlot spento si ferma (come nella 1.26)", a.veto && has(a.vetoWhy,"slot del motore")); } InpTDNoSlot=true;
    pos(8005,ENG_SWING,ST_ON_H1,1,4000,3960); pos(8006,ENG_SWING,ST_ON_H4,1,4000,3900);
    { TSignal a=sig(ST_IN_TREND2,1), b=sig(ST_ON_M5,1); chk("quattro posizioni aperte: tetto fisso, non entra nessuno", a.veto && has(a.vetoWhy,"posizioni massime") && b.veto && has(b.vetoWhy,"posizioni massime")); }
    // verso opposto
    P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset();
    pos(8007,ENG_SWING,ST_ON_H1,1,4000,3960); pos(8008,ENG_INTRA,ST_ON_M15,1,4000,3990);
    { TSignal a=sig(ST_IN_TREND,-1); chk("movimento forte contro ritracciamenti ancora a rischio: di serie non entra (sui dati chiuderli peggiora)", a.veto && has(a.vetoWhy,"posizione opposta") && !a.flip); }
    InpTDFlipOnda=true;
    { TSignal a=sig(ST_IN_TREND,-1); chk("con InpTDFlipOnda acceso: passa, e prima di entrare chiudera' i ritracciamenti", !a.veto && a.flip && OppOndaAtRisk(-1)==2 && OppOndaAtRisk(1)==0);
      TSignal b=sig(ST_SW_TREND,-1); chk("vale solo per i movimenti forti", b.veto && !b.flip); }
    pos(8009,ENG_INTRA,ST_IN_TREND,1,4000,3985);
    { TSignal a=sig(ST_IN_TREND,-1); chk("se la posizione opposta non e' un ritracciamento: non entra", a.veto && !a.flip); }
    P.pop_back(); g_meta[MetaFind(8009)].Reset();
    P[1].sl=4000.5;   // il ritracciamento M15 e' gia' a pareggio: non e' a rischio
    S_bid=4003.0; S_ask=4003.2;
    { int nc=CloseOppOnda(-1,"prova"); chk("chiude solo i ritracciamenti ancora a rischio (quello a pareggio resta)", nc==1 && P.size()==1 && P[0].ticket==8008); }
    InpTDFlipOnda=false; P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); }
  // ---------- pannello: mai oltre il limite di MT5, le righe meno importanti lasciano il posto
  { g_pnN=0; PnAdd(std::string(900,'a')+"\n",0); PnAdd(std::string(500,'b')+"\n",7); PnAdd(std::string(400,'c')+"\n",4); PnAdd(std::string(150,'d')+"\n",1); PnAdd(std::string(150,'e')+"\n",3); PnAdd(std::string(150,'f')+"\n",9);
    std::string t=PnBuild(2040);
    chk("testo troppo lungo: escono prima le righe di priorita' 9, poi 7, finche' ci sta", t.size()<=2040 && has(t,"aaa") && has(t,"ccc") && has(t,"ddd") && has(t,"eee") && !has(t,"bbb") && !has(t,"fff"));
    chk("l'ordine delle righe rimaste non cambia", t.find("aaa")<t.find("ccc") && t.find("ccc")<t.find("ddd") && t.find("ddd")<t.find("eee"));
    g_pnN=0; PnAdd("uno\n",0); PnAdd("due\n",9); PnAdd("",5); t=PnBuild(2040); chk("testo corto: resta tutto, le righe vuote non contano", t=="uno\ndue\n" && g_pnN==2);
    g_pnN=0; PnAdd(std::string(3000,'z'),0); t=PnBuild(2040); chk("anche solo righe obbligatorie troppo lunghe: tagliato a 2040 caratteri", t.size()==2040);
    chk("limite del pannello sotto i 2045 caratteri di MT5", PN_BUDGET<=2045); }
  printf("FALLITI %d\n", fails); return fails?1:0;
}
