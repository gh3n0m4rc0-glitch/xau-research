#!/usr/bin/env python3
"""Trasforma il sorgente MQL5 in C++ compilabile con lo shim (solo per i controlli).

- toglie #property, #include <Trade\\Trade.mqh>, input group
- input/sinput -> variabili globali normali
- array dinamici T x[] -> DynArr<T> x ; parametri T &x[] -> DynArr<T> &x
- array statici T x[N] -> FixArr<T, N> x (con controllo dei limiti)
- genera ApplyInput(nome, valore) per il simulatore
Segnala anche i costrutti non ammessi in MQL5 (puntatori, auto, ->, ecc.).
"""
import re
import sys

src = open(sys.argv[1], encoding="utf-8").read()
out_path = sys.argv[2]

problems = []
lines = src.split("\n")

struct_names = set(re.findall(r"^\s*struct\s+(\w+)", src, re.M))
known_types = {
    "int", "double", "string", "bool", "long", "ulong", "uint", "datetime", "char", "uchar",
    "short", "ushort", "float", "color", "MqlRates", "MqlTick", "MqlDateTime", "MqlBookInfo",
    "MqlCalendarValue", "MqlCalendarEvent", "MqlTradeRequest", "MqlTradeResult",
} | struct_names

inputs = []
res = []
in_block_comment = False
for no, line in enumerate(lines, 1):
    s = line
    st = s.strip()
    if st.startswith("#property") or st.startswith("#include") or st.startswith("input group"):
        res.append("// " + s)
        continue
    # controlli MQL5 (fuori dai commenti)
    code = re.sub(r'"(\\.|[^"\\])*"', '""', s).split("//")[0]
    if re.search(r"\bInp\w+\s*(=[^=]|\+=|-=|\*=|/=|\+\+|--)", code) and not re.match(r"^\s*(input|sinput)\b", s):
        problems.append(f"riga {no}: assegnazione a un input (in MQL5 gli input sono costanti): {st}")
    for bad, why in ((r"->", "operatore -> (in MQL5 i puntatori usano il punto)"),
                     (r"\bauto\b", "auto non esiste in MQL5"),
                     (r"\bnullptr\b", "nullptr non esiste"),
                     (r"\bnew\b", "new (evitiamo i puntatori)"),
                     (r"\bstd::", "std:: non esiste"),
                     (r"\bstatic_cast\b", "static_cast non esiste"),
                     (r"\bunsigned\b", "unsigned non esiste (usa uint/ulong)"),
                     (r"\blong\s+long\b", "long long non esiste"),
                     (r"\bsize_t\b", "size_t non esiste"),
                     (r"\binline\b", "inline"),
                     (r"\bgoto\b", "goto"),
                     (r"\bconstexpr\b", "constexpr")):
        if re.search(bad, code):
            problems.append(f"riga {no}: {why}: {st}")
    m = re.match(r"^(\s*)(input|sinput)\s+(\w+)\s+(\w+)\s*=", s)
    if m:
        inputs.append((m.group(3), m.group(4)))
        s = m.group(1) + s[m.end(2):].lstrip()
    # parametri array dinamici
    s = re.sub(r"\b(const\s+)?(\w+)\s*&\s*(\w+)\s*\[\s*\]", lambda mm: f"{mm.group(1) or ''}DynArr<{mm.group(2)}> &{mm.group(3)}", s)
    # dichiarazioni di array dinamici
    m = re.match(r"^(\s*)(static\s+)?(\w+)\s+(\w+)\s*\[\s*\]\s*;(.*)$", s)
    if m and m.group(3) in known_types:
        s = f"{m.group(1)}{m.group(2) or ''}DynArr<{m.group(3)}> {m.group(4)};{m.group(5)}"
    # dichiarazioni di array statici
    m = re.match(r"^(\s*)(static\s+)?(\w+)\s+(\w+)\s*\[\s*(\w+)\s*\]\s*(;|=)(.*)$", s)
    if m and m.group(3) in known_types:
        s = f"{m.group(1)}{m.group(2) or ''}FixArr<{m.group(3)}, {m.group(5)}> {m.group(4)} {m.group(6)}{m.group(7)}"
    res.append(s)

# struct passati per valore (vietato in MQL5)
for no, line in enumerate(lines, 1):
    m = re.match(r"^\s*[\w<>]+\s+\w+\s*\(([^)]*)\)\s*$", line)
    if not m:
        continue
    for prm in m.group(1).split(","):
        prm = prm.strip()
        if not prm:
            continue
        toks = prm.replace("const ", "").split()
        if len(toks) >= 2 and toks[0] in struct_names | {"MqlRates", "MqlTick", "MqlDateTime", "MqlTradeTransaction", "MqlTradeRequest", "MqlTradeResult"} and "&" not in prm:
            problems.append(f"riga {no}: struct passata per valore: {line.strip()}")

# inizializzatori di membri dentro le struct (vietati in MQL5)
depth = 0
in_struct = False
for no, line in enumerate(lines, 1):
    code = line.split("//")[0]
    if re.match(r"^\s*struct\s+\w+", code):
        in_struct = True
        depth = 0
    if in_struct:
        if depth == 1 and re.match(r"^\s*[\w]+\s+\w+\s*=", code) and "(" not in code:
            problems.append(f"riga {no}: inizializzatore di membro in struct: {line.strip()}")
        depth += code.count("{") - code.count("}")
        if depth <= 0 and "}" in code:
            in_struct = False

body = "\n".join(res)

# ApplyInput per il simulatore
ap = ["void ApplyInput(const std::string &name, const std::string &val) {"]
for typ, name in inputs:
    if typ in ("double", "float"):
        conv = "std::stod(val)"
    elif typ in ("int", "long", "ulong", "uint"):
        conv = "(" + typ + ")std::stoll(val)"
    elif typ == "bool":
        conv = "(val == \"true\" || val == \"1\")"
    elif typ == "string":
        conv = "val"
    else:
        conv = f"({typ})std::stoi(val)"
    ap.append(f"  if(name == \"{name}\") {{ {name} = {conv}; return; }}")
ap.append("  fprintf(stderr, \"input sconosciuto: %s\\n\", name.c_str()); exit(2);")
ap.append("}")

with open(out_path, "w", encoding="utf-8") as f:
    f.write(body)
    f.write("\n\n// ---- generato ----\n")
    f.write("\n".join(ap))
    f.write("\n")

if problems:
    print("PROBLEMI MQL5:")
    for p in problems:
        print("  " + p)
    sys.exit(1)
print(f"ok: {len(inputs)} input, {len(struct_names)} struct")
