#define main sim_main
#include "sim.cpp"
#undef main
int main(int argc,char**argv){ int r=sim_main(argc,argv); printf("\n----- pannello piu' lungo (%zu caratteri)\n%s\n", g_shimCommentMax, g_shimCommentLongest.c_str()); return r; }
