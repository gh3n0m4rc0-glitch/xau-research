#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-62s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
static void bars(DynArr<MqlRates> &r,int n,double lastRange){ ArrayResize(r,n);
  for(int i=0;i<n;i++){ r[i].open=4000; r[i].close=4000; r[i].high=4005; r[i].low=3995; }
  r[n-1].high=4000+lastRange/2; r[n-1].low=4000-lastRange/2;
}
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true;
  DynArr<MqlRates> r;
  bars(r,40,25.0); BigDayCompute(r,40);
  chk("C1: ieri 25$ con ATR 10$ -> 2,5 ATR, acceso", g_bigDay && fabs(g_bigDayAtr-2.5)<1e-9);
  bars(r,40,15.0); BigDayCompute(r,40);
  chk("C1: ieri 15$ con ATR 10$ -> 1,5 ATR, spento", !g_bigDay && fabs(g_bigDayAtr-1.5)<1e-9);
  bars(r,40,20.0); BigDayCompute(r,40);
  chk("C1: esattamente 2 ATR -> spento (serve oltre)", !g_bigDay);
  chk("C1: ATR D1 calcolato (ultime 20 barre)", g_d1Atr>10.0 && g_d1Atr<10.6);
  bars(r,40,25.0); BigDayCompute(r,10);
  chk("C1: storico corto (10 barre) -> spento, nessun errore", !g_bigDay && g_d1Atr==0.0);
  // C3
  bars(r,40,10.0); BigDayCompute(r,40);
  g_sess.asiaDone=true; g_sess.asiaH=4003.0; g_sess.asiaL=4000.0;
  chk("C3: Asia 3$ con ATR D1 10$ -> stretta", TightAsia());
  g_sess.asiaH=4006.0;
  chk("C3: Asia 6$ -> non stretta", !TightAsia());
  g_sess.asiaDone=false; g_sess.asiaH=4003.0;
  chk("C3: Asia non ancora finita -> no", !TightAsia());
  g_sess.asiaDone=true;
  TSignal s; s.strat=ST_SC_SWEEP;
  chk("C3: spento di default, nessun bonus anche su SC-SWEEP", !TightAsiaBonus(s));
  chk("P4 acceso di default nella 1.20", InpP4FirstDayLong);
  chk("C1 acceso di default, C3 spento", InpC1BigDayRisk && !InpC3TightAsia);
  printf("FALLITI %d\n", fails); return fails?1:0;
}
