#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-62s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
static void bars(DynArr<MqlRates> &r,int n,double lastRange){ ArrayResize(r,n);
  for(int i=0;i<n;i++){ r[i].open=4000; r[i].close=4000; r[i].high=4005; r[i].low=3995; }
  r[n-1].high=4000+lastRange/2; r[n-1].low=4000-lastRange/2;
}
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true;
  DynArr<MqlRates> r;
  bars(r,40,25.0); BigDayCompute(r,40);
  chk("C1: ieri 25$ con ATR 10$ -> 2,5 ATR, acceso", g_bigDay && fabs(g_bigDayAtr-2.5)<1e-9);
  bars(r,40,15.0); BigDayCompute(r,40);
  chk("C1: ieri 15$ con ATR 10$ -> 1,5 ATR, spento", !g_bigDay && fabs(g_bigDayAtr-1.5)<1e-9);
  bars(r,40,20.0); BigDayCompute(r,40);
  chk("C1: esattamente 2 ATR -> spento (serve oltre)", !g_bigDay);
  chk("C1: ATR D1 calcolato (ultime 20 barre)", g_d1Atr>10.0 && g_d1Atr<10.6);
  bars(r,40,25.0); BigDayCompute(r,10);
  chk("C1: storico corto (10 barre) -> spento, nessun errore", !g_bigDay && g_d1Atr==0.0);
  // C3: Asia della seduta (18 NY -> Londra), lunedi' 16/11/2026, inverno: 23:00 UTC domenica -> 08:00 UTC
  bars(r,40,10.0); BigDayCompute(r,40);
  auto F=[&](int y,int mo,int d,int hh,double hi,double lo){ MqlDateTime t; t.year=y; t.mon=mo; t.day=d; t.hour=hh; t.min=0; t.sec=0; datetime u=StructToTime(t); C3AsiaFeed(u, HourOf(u), LondonOpenUTC(u), hi, lo); };
  F(2026,11,13,20,4050,4040);           // venerdi' sera: altra seduta
  F(2026,11,15,23,4003.0,4000.0);       // riapertura domenica 18 NY
  F(2026,11,16,3,4002.5,4000.5);
  chk("C3: Asia non ancora finita (03 UTC) -> no", !TightAsia());
  F(2026,11,16,8,4001.0,4000.2);        // apertura di Londra: Asia chiusa
  chk("C3: Asia 3$ (23-08 UTC) con ATR D1 10$ -> stretta", TightAsia() && fabs(g_c3H-4003.0)<1e-9 && fabs(g_c3L-4000.0)<1e-9);
  F(2026,11,16,9,4010.0,3990.0);        // Londra non allarga l'Asia
  chk("C3: le barre dopo Londra non cambiano l'Asia", fabs(g_c3H-4003.0)<1e-9 && TightAsia());
  F(2026,11,16,23,4020.0,4013.0);       // nuova seduta (martedi'): 7$ -> non stretta a Londra
  F(2026,11,17,8,4019.0,4014.0);
  chk("C3: seduta dopo, Asia 7$ -> non stretta", !TightAsia() && fabs(g_c3H-4020.0)<1e-9);
  F(2026,6,15,22,4003.0,4000.0);        // estate: riapertura 22 UTC, Londra 07 UTC
  F(2026,6,16,7,4001.0,4000.5);
  chk("C3: estate, Asia 22-07 UTC chiusa a Londra -> stretta", TightAsia() && fabs(g_c3H-4003.0)<1e-9);
  TSignal s; s.strat=ST_SC_SWEEP;
  chk("C3: spento di default, nessun bonus anche su SC-SWEEP", !TightAsiaBonus(s));
  chk("P4 acceso di default nella 1.20", InpP4FirstDayLong);
  chk("C1 acceso di default, C3 spento", InpC1BigDayRisk && !InpC3TightAsia);
  printf("FALLITI %d\n", fails); return fails?1:0;
}
