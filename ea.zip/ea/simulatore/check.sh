#!/bin/bash
# build + trasformazione + compilazione del simulatore
set -e
cd "$(dirname "$0")/.."
./build.sh >/dev/null
python3 shim/transform.py out/XauCommitteeEA.mq5 shim/ea_cpp.inc
cd shim
g++ -std=c++17 -O1 -g -Wall -Wextra -Wno-unused-parameter -Wno-unused-variable -Wno-unused-but-set-variable \
  -Werror=return-type -Wno-missing-field-initializers -Wconversion -Wno-sign-conversion \
  -fsanitize=address,undefined -fno-sanitize-recover=undefined -ftrivial-auto-var-init=pattern -o sim sim.cpp 2> build.log || { grep -E "error" build.log | head -40; exit 1; }
grep -E "warning" build.log | grep "ea_cpp.inc" | head -60 || true
echo "COMPILAZIONE OK"
