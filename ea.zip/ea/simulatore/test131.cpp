// test131.cpp - XAU Committee EA 1.31: stop protetti nella pausa serale del broker
#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-100s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
static bool has(const std::string&a,const char*b){ return a.find(b)!=std::string::npos; }
static bool near(double a,double b,double e=1e-6){ return fabs(a-b)<=e; }
static void mkTf(TfData&d,int n,datetime t0,int sec,double px,double range){
  d.n=n; ArrayResize(d.r,n); ArrayResize(d.ema20,n); ArrayResize(d.ema50,n); ArrayResize(d.atr,n);
  for(int i=0;i<n;i++){ d.r[i].time=t0+(datetime)i*sec; d.r[i].open=px; d.r[i].close=px; d.r[i].high=px+range/2; d.r[i].low=px-range/2; d.ema20[i]=px; d.ema50[i]=px; d.atr[i]=range; }
}
static MqlRates bar(datetime t,double c){ MqlRates b; b.time=t; b.open=c; b.high=c+0.05; b.low=c-0.05; b.close=c; b.tick_volume=10; b.spread=20; b.real_volume=0; return b; }
static void px(datetime t,double bid,double sp=0.2){ S_now=t; S_bid=bid; S_ask=bid+sp; }
// M1 di 'days' giorni (dal lunedi' 'd0') con la pausa serale da 'cl' (minuto del giorno, primo minuto senza prezzi) lunga 'len' minuti
static void mkM1(datetime d0,int days,int cl,int len,int holidayDay=-1,int holidayCl=0){
  M1.clear();
  for(int day=0; day<days; day++){
    datetime ds=d0+(datetime)day*86400; int dow=DowOf(ds);
    if(dow==0||dow==6) continue;
    int c=(day==holidayDay)?holidayCl:cl;
    for(int m=0;m<1440;m++){
      datetime t=ds+(datetime)m*60;
      int rel=(m-c+1440)%1440;                     // minuti dall'inizio della pausa
      int relEnd=(c+len)%1440;
      bool inBreak = (c+len<=1440) ? (m>=c && m<c+len) : (m>=c || m<relEnd);
      if(day==holidayDay && m>=holidayCl && m<cl+len) inBreak=true;
      (void)rel;
      if(inBreak) continue;
      M1.push_back(bar(t,4000.0));
    }
  }
}
static void reset(){
  P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset();
  g_rgN=0; ArrayResize(g_rgTk,0); ArrayResize(g_rgSl,0); ArrayResize(g_rgDir,0);
  g_rgStartT=0; g_rgOpenT=0; g_rgLastTick=0; g_rgDoneDay=0; g_rgReloaded=true; g_rgLast=""; g_rgStatFake=0;
  GV.clear();
}
static void pos(ulong tk,int dir,double open,double sl,double tp,int strat=ST_ON_M15){
  SimPos q; q.ticket=tk; q.id=(long)tk; q.type=(dir>0)?0:1; q.vol=0.02; q.open=open; q.sl=sl; q.tp=tp; q.time=S_now-3600; q.magic=(ulong)MagicOfEngine(ENG_INTRA); q.comment="XC ONDA-M15"; P.push_back(q);
  int k=MetaFree(); g_meta[k].Reset(); g_meta[k].active=true; g_meta[k].id=(long)tk; g_meta[k].strat=strat; g_meta[k].engine=ENG_INTRA; g_meta[k].dir=dir;
  g_meta[k].entry=open; g_meta[k].sl0=sl; g_meta[k].tp=tp; g_meta[k].riskPx=fabs(open-sl); g_meta[k].lots0=0.02; g_meta[k].openTime=S_now-3600; g_meta[k].deadline=S_now+30*86400;
}
static SimPos* find(ulong tk){ for(auto&p:P) if(p.ticket==tk) return &p; return nullptr; }
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true; S_tester=true; g_minLot=0.01; g_lotStep=0.01; g_lotDigits=2; g_sym="XAUUSD"; g_currency="EUR";
  InpVirtualCapital=0.0; S_balance=3000.0; g_spreadAvg=0.2; if(system("mkdir -p simfiles")!=0) return 2;
  const datetime MON=1793577600, WED=1793750400, THU=1793836800, FRI=1793923200;
  mkTf(g_d1,60,MON-60*86400,86400,4000.0,40.0);                        // escursione giornaliera 40 $
  // ---------- di serie
  chk("versione 1.31", std::string(EA_VERSION)=="1.31");
  chk("di serie: stop d'emergenza (modo 1), 10 minuti prima, rimessi 10 minuti dopo con spread sotto 2x, al massimo 30 minuti, 1 escursione",
      InpRollGuard==1 && InpRollBeforeMin==10 && InpRollAfterMin==10 && near(InpRollSpreadMult,2.0) && InpRollMaxWaitMin==30 && near(InpRollEmergAtr,1.0));
  chk("regole fisse invariate: rischio 1%, pareggio a 1,5R, 6 posizioni", near(InpRiskPercent,1.0) && near(InpBE_R,1.5) && InpMaxPos==6);
  // ---------- impara la pausa dalle M1
  { reset(); mkM1(MON-14*86400,17,23*60,120); px(WED+12*3600,4000.0); g_rgLearnDay=0; RgLearn();
    chk("pausa dalle 23:00 alle 01:00 del server (come il demo dal 2026): la impara dalle candele", g_rgClose==23*60 && g_rgLen==120);
    mkM1(MON-14*86400,17,0,60); g_rgLearnDay=0; RgLearn();
    chk("pausa dalle 00:00 alle 01:00 (demo fino al 2025)", g_rgClose==0 && g_rgLen==60);
    mkM1(MON-14*86400,17,23*60,120,16,21*60+30); g_rgLearnDay=0; RgLearn();
    chk("una chiusura anticipata di festa (21:30) non sposta l'orario", g_rgClose==23*60);
    mkM1(MON-14*86400,17,23*60,120); for(size_t i=0;i<M1.size();i++){}
    { // gli ultimi due giorni il broker chiude un'ora prima (cambio dell'ora legale): la protezione parte un'ora prima
      std::vector<MqlRates> keep; for(auto&b:M1){ datetime ds=b.time-b.time%86400; int m=(int)((b.time%86400)/60); bool last2=(ds>=MON+86400); if(last2 && m>=22*60) continue; keep.push_back(b);} M1=keep;
      g_rgLearnDay=0; RgLearn(); chk("cambio dell'ora (chiude alle 22:00 da due giorni): parte dalle 22:00", g_rgClose==22*60); }
    M1.clear(); g_rgLearnDay=0; g_rgClose=-1; RgLearn(); chk("senza candele non inventa nulla (protezione ferma)", g_rgClose<0 && RollPanel()==""); }
  // ---------- quali sere
  { g_rgClose=23*60; g_rgLen=120;
    chk("mercoledi' sera: c'e'", RgNextClose(WED+22*3600)==WED+23*3600);
    chk("giovedi' sera: c'e'", RgNextClose(THU+22*3600)==THU+23*3600);
    chk("venerdi': no (e' il weekend, gia' gestito dalle regole del venerdi')", RgNextClose(FRI+22*3600)==0);
    g_rgClose=0; g_rgLen=60;
    chk("pausa alle 00:00: quella di giovedi' notte vale (l'ultimo minuto e' giovedi')", RgNextClose(THU+23*3600+50*60)==FRI);
    chk("quella di venerdi' notte no", RgNextClose(FRI+23*3600+50*60)==0); }
  // ---------- la sera: stop allargati, prezzi finti, stop rimessi
  { reset(); g_rgClose=23*60; g_rgLen=120; g_rgLearnDay=WED; InpRollGuard=1;
    px(WED+22*3600+40*60,4000.0); pos(5001,1,4005.0,3990.0,4050.0); pos(5002,-1,3995.0,4010.0,3950.0);
    RgTick(true); chk("alle 22:40 (20 minuti prima) non tocca nulla", find(5001)->sl==3990.0 && g_rgStartT==0);
    px(WED+22*3600+50*60,4000.0); RgTick(true);
    chk("alle 22:50: acquisto, stop d'emergenza 1 escursione sotto lo stop vero (3950)", near(find(5001)->sl,3950.0,0.011) && RgSaved(5001));
    chk("vendita: stop d'emergenza sopra (4050)", near(find(5002)->sl,4050.0,0.011) && RgSaved(5002));
    chk("stop veri salvati anche fuori dall'EA (variabili globali del terminale)", near(GlobalVariableGet("XCRG_5001"),3990.0) && near(GlobalVariableGet("XCRG_5002"),4010.0));
    chk("rischio aperto calcolato sugli stop veri (non su quelli d'emergenza)", near(RgRealSl(5001,3950.0),3990.0) && near(RgRealSl(9999,3950.0),3950.0));
    PortfolioScan(); double r1=g_openRiskMoney; chk("rischio aperto: 15 $ + 15 $ di distanza, non 55 + 55", r1>0 && near(r1, (15.0+15.0)*0.02*ValuePerPriceUnit(),0.01));
    chk("pannello: stop allargati e quando tornano", has(RollPanel(),"2 stop allargati") && has(RollPanel(),"10 min dopo la riapertura"));
    // prezzi finti alla riapertura: bid giu' di 30 $ (prende lo stop vero 3990, non quello d'emergenza 3950), ask su di 25 $
    px(THU+1*3600,3970.0,25.0); RgTick(true); brokerTick();
    chk("riapertura con bid finto a 3970 e ask a 3995: nessuna delle due chiusa", find(5001)!=nullptr && find(5002)!=nullptr);
    chk("riapertura vista all'01:00", g_rgOpenT==THU+1*3600);
    px(THU+1*3600+5*60,4001.0,0.2); RgTick(true);
    chk("01:05: troppo presto, stop ancora larghi", near(find(5001)->sl,3950.0,0.011));
    px(THU+1*3600+10*60,4001.0,0.2); RgTick(true);
    chk("01:10 con spread normale: stop veri rimessi (3990 e 4010)", near(find(5001)->sl,3990.0) && near(find(5002)->sl,4010.0) && !RgSaved(5001) && g_rgStartT==0);
    chk("variabili globali cancellate", !GlobalVariableCheck("XCRG_5001") && !GlobalVariableCheck("XCRG_5002"));
    chk("diario: 1 stop finto evitato (il bid 3970 passa dallo stop vero 3990; l'ask 3995 non arriva a 4010)", g_rgStatFake==1);
    { FILE*f=fopen(("simfiles/"+RgFile()).c_str(),"r"); char l[512]; std::string all; if(f){ while(fgets(l,sizeof l,f)) all+=l; fclose(f);}
      chk("diario della pausa scritto (XauCommittee_tester_pausa.csv)", has(all,"stop_finti_evitati") && has(all,";22:50;01:00;01:10;2;")); }
    px(THU+2*3600,4001.0); RgTick(true); chk("stessa sera: non riparte", g_rgStartT==0 && near(find(5001)->sl,3990.0)); }
  // ---------- prezzo vero oltre lo stop alla riapertura: chiude al mercato
  { reset(); g_rgClose=23*60; g_rgLen=120; g_rgLearnDay=WED;
    px(WED+22*3600+51*60,4000.0); pos(5101,1,4005.0,3990.0,4050.0); RgTick(true);
    px(THU+1*3600,3985.0); RgTick(true); brokerTick();
    px(THU+1*3600+10*60,3984.0); RgTick(true);
    chk("01:10 il prezzo vero (3984) e' sotto lo stop 3990: chiusa al mercato", find(5101)==nullptr && g_rgN==0 && g_rgStatShut>=1); }
  // ---------- spread ancora largo: aspetta, poi al massimo 30 minuti
  { reset(); g_rgClose=23*60; g_rgLen=120; g_rgLearnDay=WED;
    px(WED+22*3600+52*60,4000.0); pos(5201,1,4005.0,3990.0,4050.0); RgTick(true);
    px(THU+1*3600,4000.0,1.5); RgTick(true);
    px(THU+1*3600+12*60,4000.0,1.5); RgTick(true); chk("01:12 spread 1,5 (oltre 2x 0,2): aspetta", RgSaved(5201));
    px(THU+1*3600+30*60,4000.0,1.5); RgTick(true); chk("01:30: rimette comunque (tempo massimo)", !RgSaved(5201) && near(find(5201)->sl,3990.0)); }
  // ---------- nella pausa pareggio e trailing aspettano, le uscite a ora fissa no
  { reset(); g_rgClose=23*60; g_rgLen=120; g_rgLearnDay=WED;
    px(WED+22*3600+50*60,4000.0); pos(5301,1,4000.0,3990.0,4050.0); RgTick(true);
    px(WED+22*3600+55*60,4016.0); ManagePositions(); chk("a +1,6R nella pausa: niente pareggio (lo stop resta d'emergenza)", near(find(5301)->sl,3950.0,0.011));
    int mi=MetaFind(5301); g_meta[mi].deadline=WED+22*3600+56*60; px(WED+22*3600+57*60,4016.0); ManagePositions();
    chk("uscita a ora fissa durante la protezione: chiude lo stesso", find(5301)==nullptr); }
  // ---------- modo 2: nessuno stop
  { reset(); g_rgClose=23*60; g_rgLen=120; g_rgLearnDay=WED; InpRollGuard=2;
    px(WED+22*3600+50*60,4000.0); pos(5401,-1,3995.0,4010.0,3950.0); RgTick(true);
    chk("modo 2: stop tolto (0)", near(find(5401)->sl,0.0) && RgSaved(5401) && has(RollPanel(),"stop tolti"));
    PortfolioScan(); chk("modo 2: rischio aperto sempre sullo stop vero", near(g_openRiskMoney,15.0*0.02*ValuePerPriceUnit(),0.01));
    px(THU+1*3600,4000.0); RgTick(true); px(THU+1*3600+10*60,4000.0); RgTick(true);
    chk("modo 2: rimesso 4010", near(find(5401)->sl,4010.0)); InpRollGuard=1; }
  // ---------- modo 0: come la 1.30
  { reset(); g_rgClose=23*60; g_rgLen=120; g_rgLearnDay=WED; InpRollGuard=0;
    px(WED+22*3600+50*60,4000.0); pos(5501,1,4005.0,3990.0,4050.0); RgTick(true);
    chk("modo 0: stop vero lasciato (come la 1.30)", near(find(5501)->sl,3990.0) && !RgSaved(5501) && RollPanel()=="" && !RgBusy()); InpRollGuard=1; }
  // ---------- riavvio dell'EA nella pausa
  { reset(); g_rgClose=23*60; g_rgLen=120; g_rgLearnDay=WED;
    px(WED+22*3600+50*60,4000.0); pos(5601,1,4005.0,3990.0,4050.0); RgTick(true);
    g_rgN=0; ArrayResize(g_rgTk,0); ArrayResize(g_rgSl,0); ArrayResize(g_rgDir,0); g_rgStartT=0; g_rgOpenT=0; g_rgLastTick=0; g_rgReloaded=false;   // EA riavviato
    px(THU+1*3600+2*60,4000.0); RgTick(true);
    chk("riavvio: ritrova lo stop vero salvato", RgSaved(5601) && near(RgRealSl(5601,0),3990.0));
    px(THU+1*3600+12*60,4000.0); RgTick(true);
    chk("e lo rimette dopo 10 minuti", near(find(5601)->sl,3990.0) && !RgSaved(5601)); }
  // ---------- venerdi': non tocca nulla
  { reset(); g_rgClose=23*60; g_rgLen=120; g_rgLearnDay=FRI;
    px(FRI+22*3600+50*60,4000.0); pos(5701,1,4005.0,3990.0,4050.0); RgTick(true);
    chk("venerdi' alle 22:50: stop vero lasciato", near(find(5701)->sl,3990.0) && !RgSaved(5701)); }
  // ---------- posizione senza stop: lasciata stare
  { reset(); g_rgClose=23*60; g_rgLen=120; g_rgLearnDay=WED;
    px(WED+22*3600+50*60,4000.0); pos(5801,1,4005.0,0.0,4050.0); RgTick(true);
    chk("posizione senza stop: non la tocca", near(find(5801)->sl,0.0) && !RgSaved(5801)); }
  reset();
  printf("FALLITI %d\n", fails); return fails?1:0;
}
