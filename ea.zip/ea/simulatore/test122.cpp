#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-62s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
int main(){
  string js = "{\n \"timestamp_utc\": \"2026-11-10T14:00:00Z\",\n \"bias\": 0.3,\n \"confidence\": 0.4,\n"
              " \"extra\": {\"sintesi\": \"annidato\", \"ultimo_dato\": \"no\"},\n"
              " \"macro_incompleta\": true,\n \"fonti_mancanti_testo\": \"dollaro\",\n"
              " \"extra_sintesi\": \"CPI m/m 0.4 vs 0.3%: oro giu'\",\n"
              " \"ultimo_dato\": \"CPI m/m 0.4 (previsione 0.3%): oro giu'\",\n \"ultimo_dato_ora_utc\": \"2026-11-10T13:30:00Z\"\n}";
  ParseMacro(js);
  chk("1.22: bias letto come prima", fabs(g_macroBias-0.3)<1e-9);
  chk("1.22: macro incompleta letta", g_macroIncomplete);
  chk("1.22: fonte mancante = dollaro", g_macroMissing=="dollaro");
  chk("1.22: sintesi extra dal primo livello (non quella annidata)", StringFind(g_extraText,"CPI")==0);
  chk("1.22: ultimo dato e ora", StringFind(g_lastDataText,"CPI m/m 0.4")==0 && g_lastDataTime>0);
  g_mBias=0.3; g_mConf=0.4; g_mSource="GitHub";
  chk("1.22: pannello macro dice INCOMPLETA", StringFind(MacroText(),"INCOMPLETA: manca dollaro")>0);
  string old = "{\"timestamp_utc\": \"2026-11-10T14:00:00Z\", \"bias\": 0.1, \"confidence\": 0.2}";
  ParseMacro(old);
  chk("1.22: file vecchio senza campi nuovi -> niente avvisi", !g_macroIncomplete && g_extraText=="" && g_lastDataTime==0);
  printf("%s\n", fails? "TEST 1.22 FALLITI":"TEST 1.22 OK"); return fails?1:0;
}
