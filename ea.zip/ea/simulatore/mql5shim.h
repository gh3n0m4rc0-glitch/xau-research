// Shim MQL5 -> C++ per controllare tipi/sintassi ed eseguire l'EA in un broker simulato.
// Non e' MetaTrader: serve solo a trovare errori prima della compilazione vera in MetaEditor.
#pragma once
#include <string>
#include <vector>
#include <map>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <cfloat>
#include <climits>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <iostream>
#include <type_traits>
#include <deque>

typedef std::string string;
typedef long datetime;
typedef unsigned int uint;
typedef unsigned long ulong;
typedef unsigned short ushort;
typedef unsigned char uchar;
typedef int color;

[[noreturn]] inline void ShimFail(const char *msg, long a = 0, long b = 0) {
  fprintf(stderr, "\n*** ERRORE RUNTIME (in MT5 sarebbe 'critical error'): %s (%ld, %ld)\n", msg, a, b);
  abort();
}

template <class T, int N> struct FixArr;

template <class T> struct DynArr {
  std::vector<T> v;
  DynArr() {}
  template <int N> DynArr(const FixArr<T, N> &f) { v.assign(f.a, f.a + N); }
  T &operator[](int i) {
    if (i < 0 || i >= (int)v.size()) ShimFail("array out of range (dinamico)", i, (long)v.size());
    return v[i];
  }
  const T &operator[](int i) const {
    if (i < 0 || i >= (int)v.size()) ShimFail("array out of range (dinamico)", i, (long)v.size());
    return v[i];
  }
};

template <class T, int N> struct FixArr {
  T a[N];
  T &operator[](int i) {
    if (i < 0 || i >= N) ShimFail("array out of range (statico)", i, N);
    return a[i];
  }
  const T &operator[](int i) const {
    if (i < 0 || i >= N) ShimFail("array out of range (statico)", i, N);
    return a[i];
  }
};

template <class T> int ArraySize(const DynArr<T> &x) { return (int)x.v.size(); }
template <class T, int N> int ArraySize(const FixArr<T, N> &) { return N; }
template <class T> int ArrayResize(DynArr<T> &x, int n, int reserve = 0) {
  if (n < 0) return -1;
  x.v.resize(n);
  return n;
}
template <class T, class V> int ArrayInitialize(DynArr<T> &x, V val) {
  for (auto &e : x.v) e = (T)val;
  return (int)x.v.size();
}
template <class T, int N, class V> int ArrayInitialize(FixArr<T, N> &x, V val) {
  for (int i = 0; i < N; i++) x.a[i] = (T)val;
  return N;
}
template <class T> void ArrayFree(DynArr<T> &x) { x.v.clear(); }

// ----------------------------------------------------------------- costanti
#define WHOLE_ARRAY -1
#define EMPTY_VALUE DBL_MAX
#define INVALID_HANDLE -1
#define WRONG_VALUE -1
#define INIT_SUCCEEDED 0
#define INIT_FAILED 1
#define INIT_PARAMETERS_INCORRECT 32767
#define CP_ACP 0
#define CP_UTF8 65001
#define TIME_DATE 1
#define TIME_MINUTES 2
#define TIME_SECONDS 4
#define FILE_READ 1
#define FILE_WRITE 2
#define FILE_BIN 4
#define FILE_CSV 8
#define FILE_TXT 16
#define FILE_ANSI 32
#define FILE_UNICODE 64
#define FILE_SHARE_READ 128
#define FILE_SHARE_WRITE 256
#define FILE_COMMON 4096
#define SEEK_END_MQL 2

enum ENUM_TIMEFRAMES { PERIOD_CURRENT = 0, PERIOD_M1 = 1, PERIOD_M5 = 5, PERIOD_M15 = 15, PERIOD_M30 = 30,
                       PERIOD_H1 = 16385, PERIOD_H4 = 16388, PERIOD_D1 = 16408, PERIOD_W1 = 32769 };
enum ENUM_SYMBOL_INFO_DOUBLE { SYMBOL_BID, SYMBOL_ASK, SYMBOL_POINT, SYMBOL_TRADE_TICK_VALUE, SYMBOL_TRADE_TICK_SIZE,
                               SYMBOL_VOLUME_MIN, SYMBOL_VOLUME_MAX, SYMBOL_VOLUME_STEP, SYMBOL_TRADE_CONTRACT_SIZE };
enum ENUM_SYMBOL_INFO_INTEGER { SYMBOL_DIGITS, SYMBOL_SPREAD, SYMBOL_TRADE_STOPS_LEVEL, SYMBOL_TRADE_FREEZE_LEVEL,
                                SYMBOL_TRADE_MODE, SYMBOL_FILLING_MODE };
enum ENUM_ACCOUNT_INFO_DOUBLE { ACCOUNT_BALANCE, ACCOUNT_EQUITY, ACCOUNT_MARGIN, ACCOUNT_MARGIN_FREE, ACCOUNT_MARGIN_LEVEL };
enum ENUM_ACCOUNT_INFO_INTEGER { ACCOUNT_LOGIN, ACCOUNT_MARGIN_MODE, ACCOUNT_TRADE_ALLOWED, ACCOUNT_TRADE_EXPERT, ACCOUNT_LEVERAGE };
enum ENUM_ACCOUNT_INFO_STRING { ACCOUNT_CURRENCY, ACCOUNT_SERVER, ACCOUNT_COMPANY, ACCOUNT_NAME };
enum ENUM_ACCOUNT_MARGIN_MODE { ACCOUNT_MARGIN_MODE_RETAIL_NETTING, ACCOUNT_MARGIN_MODE_EXCHANGE, ACCOUNT_MARGIN_MODE_RETAIL_HEDGING };
enum ENUM_POSITION_PROPERTY_INTEGER { POSITION_TICKET, POSITION_TIME, POSITION_TYPE, POSITION_MAGIC, POSITION_IDENTIFIER };
enum ENUM_POSITION_PROPERTY_DOUBLE { POSITION_VOLUME, POSITION_PRICE_OPEN, POSITION_SL, POSITION_TP, POSITION_PRICE_CURRENT,
                                     POSITION_PROFIT, POSITION_SWAP };
enum ENUM_POSITION_PROPERTY_STRING { POSITION_SYMBOL, POSITION_COMMENT };
enum ENUM_POSITION_TYPE { POSITION_TYPE_BUY, POSITION_TYPE_SELL };
enum ENUM_ORDER_PROPERTY_INTEGER { ORDER_TICKET, ORDER_TIME_SETUP, ORDER_TYPE, ORDER_MAGIC };
enum ENUM_ORDER_PROPERTY_DOUBLE { ORDER_VOLUME_CURRENT, ORDER_PRICE_OPEN, ORDER_SL, ORDER_TP };
enum ENUM_ORDER_PROPERTY_STRING { ORDER_SYMBOL, ORDER_COMMENT };
enum ENUM_ORDER_TYPE { ORDER_TYPE_BUY, ORDER_TYPE_SELL, ORDER_TYPE_BUY_LIMIT, ORDER_TYPE_SELL_LIMIT, ORDER_TYPE_BUY_STOP,
                       ORDER_TYPE_SELL_STOP };
enum ENUM_ORDER_TYPE_TIME { ORDER_TIME_GTC, ORDER_TIME_DAY, ORDER_TIME_SPECIFIED };
enum ENUM_DEAL_PROPERTY_INTEGER { DEAL_TICKET, DEAL_ORDER, DEAL_TIME, DEAL_TYPE, DEAL_ENTRY, DEAL_MAGIC, DEAL_POSITION_ID };
enum ENUM_DEAL_PROPERTY_DOUBLE { DEAL_VOLUME, DEAL_PRICE, DEAL_COMMISSION, DEAL_SWAP, DEAL_PROFIT, DEAL_FEE };
enum ENUM_DEAL_PROPERTY_STRING { DEAL_SYMBOL, DEAL_COMMENT };
enum ENUM_DEAL_ENTRY { DEAL_ENTRY_IN, DEAL_ENTRY_OUT, DEAL_ENTRY_INOUT, DEAL_ENTRY_OUT_BY };
enum ENUM_DEAL_TYPE { DEAL_TYPE_BUY, DEAL_TYPE_SELL, DEAL_TYPE_BALANCE, DEAL_TYPE_CREDIT };
enum ENUM_TRADE_TRANSACTION_TYPE { TRADE_TRANSACTION_ORDER_ADD, TRADE_TRANSACTION_DEAL_ADD, TRADE_TRANSACTION_POSITION };
enum ENUM_MQL_INFO_INTEGER { MQL_TESTER, MQL_OPTIMIZATION, MQL_VISUAL_MODE, MQL_TRADE_ALLOWED };
enum ENUM_TERMINAL_INFO_INTEGER { TERMINAL_TRADE_ALLOWED, TERMINAL_CONNECTED };
enum ENUM_STATISTICS { STAT_PROFIT, STAT_TRADES, STAT_EQUITY_DDREL_PERCENT, STAT_BALANCE_DDREL_PERCENT };
enum ENUM_BOOK_TYPE { BOOK_TYPE_SELL = 1, BOOK_TYPE_BUY, BOOK_TYPE_SELL_MARKET, BOOK_TYPE_BUY_MARKET };
enum ENUM_CALENDAR_EVENT_IMPORTANCE { CALENDAR_IMPORTANCE_NONE, CALENDAR_IMPORTANCE_LOW, CALENDAR_IMPORTANCE_MODERATE,
                                      CALENDAR_IMPORTANCE_HIGH };
enum ENUM_LOG_LEVELS { LOG_LEVEL_NO_LOGS, LOG_LEVEL_ERRORS, LOG_LEVEL_ALL };
enum ENUM_FILE_POSITION { SEEK_SET_MQL, SEEK_CUR_MQL, SEEK_END_POS };
#undef SEEK_END
#define SEEK_END SEEK_END_POS

#define TRADE_RETCODE_PLACED 10008
#define TRADE_RETCODE_DONE 10009
#define TRADE_RETCODE_DONE_PARTIAL 10010
#define TRADE_RETCODE_INVALID_STOPS 10016
#define TRADE_RETCODE_NO_MONEY 10019
#define TRADE_RETCODE_INVALID 10013

struct MqlRates { datetime time; double open, high, low, close; long tick_volume; int spread; long real_volume; };
struct MqlTick { datetime time; double bid, ask, last; ulong volume; long time_msc; uint flags; double volume_real; };
struct MqlDateTime { int year, mon, day, hour, min, sec, day_of_week, day_of_year; };
struct MqlBookInfo { ENUM_BOOK_TYPE type; double price; long volume; double volume_real; };
struct MqlCalendarValue { ulong id; ulong event_id; datetime time; datetime period; int revision; long actual_value;
                          long prev_value; long revised_prev_value; long forecast_value; };
struct MqlCalendarEvent { ulong id; ENUM_CALENDAR_EVENT_IMPORTANCE importance; string name; string event_code; };
struct MqlTradeRequest { ulong magic; string symbol; double volume, price, sl, tp; string comment; };
struct MqlTradeResult { uint retcode; ulong deal, order; double volume, price; string comment; };
struct MqlTradeTransaction { ulong deal; ulong order; string symbol; ENUM_TRADE_TRANSACTION_TYPE type; ulong position;
                             double price, volume; };

// ----------------------------------------------------------------- matematica / stringhe
template <class A, class B> auto MathMax(A a, B b) -> typename std::common_type<A, B>::type { return a > b ? a : b; }
template <class A, class B> auto MathMin(A a, B b) -> typename std::common_type<A, B>::type { return a < b ? a : b; }
inline double MathAbs(double x) { return std::fabs(x); }
inline double MathSqrt(double x) {
  if (x < 0) ShimFail("MathSqrt di numero negativo");
  return std::sqrt(x);
}
inline double MathPow(double a, double b) { return std::pow(a, b); }
inline double MathFloor(double x) { return std::floor(x); }
inline double MathCeil(double x) { return std::ceil(x); }
inline double MathRound(double x) { return std::round(x); }
inline double MathLog(double x) { return std::log(x); }
inline double MathLog10(double x) { return std::log10(x); }
inline double MathExp(double x) { return std::exp(x); }
inline double MathMod(double a, double b) { return std::fmod(a, b); }
inline bool MathIsValidNumber(double x) { return std::isfinite(x); }
inline int MathRand() { return rand() % 32768; }
inline void MathSrand(int s) { srand(s); }
inline double NormalizeDouble(double v, int d) {
  if (!std::isfinite(v)) ShimFail("NormalizeDouble su valore non finito");
  double p = std::pow(10.0, d);
  return std::round(v * p) / p;
}
inline string DoubleToString(double v, int digits = 8) {
  if (!std::isfinite(v)) ShimFail("DoubleToString su valore non finito (NaN/inf)");
  char b[128];
  snprintf(b, sizeof b, "%.*f", digits, v);
  return b;
}
inline string IntegerToString(long v, int len = 0, ushort fill = ' ') {
  string s = std::to_string(v);
  while ((int)s.size() < len) s = (char)fill + s;
  return s;
}
inline int StringLen(const string &s) { return (int)s.size(); }
inline int StringFind(const string &s, const string &f, int start = 0) {
  if (start < 0) start = 0;
  size_t p = s.find(f, start);
  return p == string::npos ? -1 : (int)p;
}
inline string StringSubstr(const string &s, int start, int len = -1) {
  if (start < 0 || start >= (int)s.size()) return "";
  if (len < 0) return s.substr(start);
  return s.substr(start, len);
}
inline int StringReplace(string &s, const string &f, const string &r) {
  if (f.empty()) return 0;
  int c = 0;
  size_t p = 0;
  while ((p = s.find(f, p)) != string::npos) {
    s.replace(p, f.size(), r);
    p += r.size();
    c++;
  }
  return c;
}
inline bool StringToLower(string &s) {
  for (auto &c : s) c = (char)tolower(c);
  return true;
}
inline bool StringToUpper(string &s) {
  for (auto &c : s) c = (char)toupper(c);
  return true;
}
inline int StringTrimLeft(string &s) {
  size_t p = s.find_first_not_of(" \t\r\n");
  s = (p == string::npos) ? "" : s.substr(p);
  return (int)s.size();
}
inline int StringTrimRight(string &s) {
  size_t p = s.find_last_not_of(" \t\r\n");
  s = (p == string::npos) ? "" : s.substr(0, p + 1);
  return (int)s.size();
}
inline double StringToDouble(const string &s) { return atof(s.c_str()); }
inline long StringToInteger(const string &s) { return atol(s.c_str()); }
inline ushort StringGetCharacter(const string &s, int pos) {
  if (pos < 0 || pos >= (int)s.size()) return 0;
  return (ushort)(uchar)s[pos];
}
inline int StringSplit(const string &s, ushort sep, DynArr<string> &out) {
  out.v.clear();
  string cur;
  for (char c : s) {
    if ((ushort)(uchar)c == sep) {
      out.v.push_back(cur);
      cur.clear();
    } else
      cur += c;
  }
  out.v.push_back(cur);
  return (int)out.v.size();
}
template <class C> string CharArrayToString(const DynArr<C> &a, int start = 0, int count = -1, uint cp = CP_ACP) {
  string s;
  int n = (int)a.v.size();
  int end = (count < 0) ? n : std::min(n, start + count);
  for (int i = start; i < end; i++) {
    if (a.v[i] == 0) break;
    s += (char)a.v[i];
  }
  return s;
}

// controllo del formato a runtime: tipo dell'argomento contro lo specificatore
template <class T> char FmtKind() {
  if (std::is_same<T, string>::value) return 's';
  if (std::is_floating_point<T>::value) return 'f';
  if (std::is_same<T, int>::value || std::is_same<T, uint>::value || std::is_same<T, short>::value ||
      std::is_same<T, ushort>::value || std::is_same<T, char>::value || std::is_same<T, uchar>::value)
    return 'd';
  if (std::is_same<T, const char *>::value || std::is_same<T, char *>::value) return 's';
  return 'L';
}
inline const char *FmtConv(const string &s) { return s.c_str(); }
template <class T> T FmtConv(T v) { return v; }
inline void FmtCheck(const string &fmt, const std::vector<char> &kinds) {
  size_t k = 0;
  for (size_t i = 0; i < fmt.size(); i++) {
    if (fmt[i] != '%') continue;
    i++;
    if (i < fmt.size() && fmt[i] == '%') continue;
    while (i < fmt.size() && strchr("-+ #0123456789.", fmt[i])) i++;
    if (i >= fmt.size()) break;
    char c = fmt[i];
    char need = (c == 's') ? 's' : (strchr("fFeEgG", c) ? 'f' : 'd');
    if (k >= kinds.size()) ShimFail(("StringFormat: argomenti mancanti in '" + fmt + "'").c_str());
    if (kinds[k] != need) ShimFail(("StringFormat: tipo sbagliato in '" + fmt + "'").c_str(), (long)k);
    k++;
  }
}
template <class... A> string StringFormat(const string &fmt, A... args) {
  FmtCheck(fmt, {FmtKind<A>()...});
  char b[2048];
  snprintf(b, sizeof b, fmt.c_str(), FmtConv(args)...);
  return b;
}

inline void ShimOut(std::ostringstream &) {}
template <class T, class... R> void ShimOut(std::ostringstream &o, const T &v, const R &...r) {
  o << v;
  ShimOut(o, r...);
}
extern bool g_shimQuiet;
extern std::vector<string> g_shimLog;
template <class... A> void Print(const A &...a) {
  std::ostringstream o;
  ShimOut(o, a...);
  g_shimLog.push_back(o.str());
  if (!g_shimQuiet) printf("%s\n", o.str().c_str());
}
template <class... A> void PrintFormat(const string &fmt, A... a) { Print(StringFormat(fmt, a...)); }
template <class... A> void Alert(const A &...a) { Print(a...); }
extern string g_shimComment;
template <class... A> void Comment(const A &...a) {
  std::ostringstream o;
  ShimOut(o, a...);
  g_shimComment = o.str();
}

// ----------------------------------------------------------------- tempo
inline bool TimeToStruct(datetime t, MqlDateTime &d) {
  time_t tt = (time_t)t;
  struct tm g;
  gmtime_r(&tt, &g);
  d.year = g.tm_year + 1900;
  d.mon = g.tm_mon + 1;
  d.day = g.tm_mday;
  d.hour = g.tm_hour;
  d.min = g.tm_min;
  d.sec = g.tm_sec;
  d.day_of_week = g.tm_wday;
  d.day_of_year = g.tm_yday;
  return true;
}
inline datetime StructToTime(MqlDateTime &d) {
  struct tm g;
  memset(&g, 0, sizeof g);
  g.tm_year = d.year - 1900;
  g.tm_mon = d.mon - 1;
  g.tm_mday = d.day;
  g.tm_hour = d.hour;
  g.tm_min = d.min;
  g.tm_sec = d.sec;
  return (datetime)timegm(&g);
}
inline string TimeToString(datetime t, int mode = TIME_DATE | TIME_MINUTES) {
  MqlDateTime d;
  TimeToStruct(t, d);
  char b[64] = "";
  string s;
  if (mode & TIME_DATE) {
    snprintf(b, sizeof b, "%04d.%02d.%02d", d.year, d.mon, d.day);
    s = b;
  }
  if (mode & (TIME_MINUTES | TIME_SECONDS)) {
    if (!s.empty()) s += " ";
    if (mode & TIME_SECONDS)
      snprintf(b, sizeof b, "%02d:%02d:%02d", d.hour, d.min, d.sec);
    else
      snprintf(b, sizeof b, "%02d:%02d", d.hour, d.min);
    s += b;
  }
  return s;
}
inline datetime StringToTime(const string &s) {
  MqlDateTime d = {1970, 1, 1, 0, 0, 0, 0, 0};
  int n = sscanf(s.c_str(), "%d.%d.%d %d:%d:%d", &d.year, &d.mon, &d.day, &d.hour, &d.min, &d.sec);
  if (n < 3) return 0;
  return StructToTime(d);
}
inline int PeriodSeconds(ENUM_TIMEFRAMES tf = PERIOD_CURRENT) {
  switch (tf) {
    case PERIOD_M1: return 60;
    case PERIOD_M5: return 300;
    case PERIOD_M15: return 900;
    case PERIOD_M30: return 1800;
    case PERIOD_H1: return 3600;
    case PERIOD_H4: return 14400;
    case PERIOD_D1: return 86400;
    case PERIOD_W1: return 604800;
    default: return 60;
  }
}

// ----------------------------------------------------------------- API del terminale (implementate nel simulatore)
extern string _Symbol;
datetime TimeCurrent();
datetime TimeTradeServer();
datetime TimeGMT();
datetime TimeLocal();
int MQLInfoInteger(ENUM_MQL_INFO_INTEGER p);
int TerminalInfoInteger(ENUM_TERMINAL_INFO_INTEGER p);
bool SymbolSelect(const string &s, bool sel);
double SymbolInfoDouble(const string &s, ENUM_SYMBOL_INFO_DOUBLE p);
long SymbolInfoInteger(const string &s, ENUM_SYMBOL_INFO_INTEGER p);
bool SymbolInfoTick(const string &s, MqlTick &t);
double AccountInfoDouble(ENUM_ACCOUNT_INFO_DOUBLE p);
long AccountInfoInteger(ENUM_ACCOUNT_INFO_INTEGER p);
string AccountInfoString(ENUM_ACCOUNT_INFO_STRING p);
datetime iTime(const string &s, ENUM_TIMEFRAMES tf, int shift);
int CopyRates(const string &s, ENUM_TIMEFRAMES tf, int start, int count, DynArr<MqlRates> &out);
int CopyRates(const string &s, ENUM_TIMEFRAMES tf, datetime from, datetime to, DynArr<MqlRates> &out);
bool OrderCalcProfit(ENUM_ORDER_TYPE t, const string &s, double vol, double open, double close, double &profit);
bool OrderCalcMargin(ENUM_ORDER_TYPE t, const string &s, double vol, double price, double &margin);
int PositionsTotal();
ulong PositionGetTicket(int i);
bool PositionSelectByTicket(ulong t);
long PositionGetInteger(ENUM_POSITION_PROPERTY_INTEGER p);
double PositionGetDouble(ENUM_POSITION_PROPERTY_DOUBLE p);
string PositionGetString(ENUM_POSITION_PROPERTY_STRING p);
int OrdersTotal();
ulong OrderGetTicket(int i);
bool OrderSelect(ulong t);
long OrderGetInteger(ENUM_ORDER_PROPERTY_INTEGER p);
double OrderGetDouble(ENUM_ORDER_PROPERTY_DOUBLE p);
string OrderGetString(ENUM_ORDER_PROPERTY_STRING p);
bool HistorySelect(datetime from, datetime to);
bool HistorySelectByPosition(long id);
int HistoryDealsTotal();
ulong HistoryDealGetTicket(int i);
bool HistoryDealSelect(ulong t);
long HistoryDealGetInteger(ulong t, ENUM_DEAL_PROPERTY_INTEGER p);
double HistoryDealGetDouble(ulong t, ENUM_DEAL_PROPERTY_DOUBLE p);
string HistoryDealGetString(ulong t, ENUM_DEAL_PROPERTY_STRING p);
bool GlobalVariableCheck(const string &n);
double GlobalVariableGet(const string &n);
datetime GlobalVariableSet(const string &n, double v);
bool GlobalVariableDel(const string &n);
int FileOpen(const string &name, int flags, short delim = '\t', uint cp = CP_ACP);
uint FileWriteString(int h, const string &s, int len = -1);
string FileReadString(int h, int len = -1);
bool FileIsEnding(int h);
void FileClose(int h);
ulong FileSize(int h);
bool FileSeek(int h, long off, ENUM_FILE_POSITION origin);
bool FileIsExist(const string &name, int flags = 0);
bool SendNotification(const string &s);
bool EventSetTimer(int s);
void EventKillTimer();
int GetLastError();
void ResetLastError();
int WebRequest(const string &method, const string &url, const string &headers, int timeout, const DynArr<char> &data,
               DynArr<char> &result, string &result_headers);
int CalendarValueHistory(DynArr<MqlCalendarValue> &v, datetime from, datetime to, const string &country = "",
                         const string &currency = "");
bool CalendarEventById(ulong id, MqlCalendarEvent &e);
bool MarketBookAdd(const string &s);
bool MarketBookRelease(const string &s);
bool MarketBookGet(const string &s, DynArr<MqlBookInfo> &b);
double TesterStatistics(ENUM_STATISTICS s);

class CTrade {
 public:
  ulong m_magic = 0;
  ulong m_dev = 10;
  uint m_ret = 0;
  ulong m_order = 0, m_deal = 0;
  double m_price = 0;
  void SetExpertMagicNumber(const ulong magic) { m_magic = magic; }
  void SetDeviationInPoints(const ulong d) { m_dev = d; }
  bool SetTypeFillingBySymbol(const string &s) { return true; }
  void LogLevel(ENUM_LOG_LEVELS l) {}
  void SetAsyncMode(bool a) {}
  bool Buy(double volume, const string &symbol = "", double price = 0.0, double sl = 0.0, double tp = 0.0,
           const string &comment = "");
  bool Sell(double volume, const string &symbol = "", double price = 0.0, double sl = 0.0, double tp = 0.0,
            const string &comment = "");
  bool BuyLimit(double volume, double price, const string &symbol = "", double sl = 0.0, double tp = 0.0,
                ENUM_ORDER_TYPE_TIME tt = ORDER_TIME_GTC, datetime exp = 0, const string &comment = "");
  bool SellLimit(double volume, double price, const string &symbol = "", double sl = 0.0, double tp = 0.0,
                 ENUM_ORDER_TYPE_TIME tt = ORDER_TIME_GTC, datetime exp = 0, const string &comment = "");
  bool PositionModify(const ulong ticket, const double sl, const double tp);
  bool PositionClose(const ulong ticket, const ulong deviation = ULONG_MAX);
  bool PositionClosePartial(const ulong ticket, const double volume, const ulong deviation = ULONG_MAX);
  bool OrderDelete(const ulong ticket);
  uint ResultRetcode() const { return m_ret; }
  ulong ResultOrder() const { return m_order; }
  ulong ResultDeal() const { return m_deal; }
  double ResultPrice() const { return m_price; }
  string ResultRetcodeDescription() const { return "retcode " + std::to_string(m_ret); }
};
