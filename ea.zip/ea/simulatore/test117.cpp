#define main sim_main
#include "sim.cpp"
#undef main
static datetime U(int y,int mo,int d,int h,int mi){ MqlDateTime t; t.year=y; t.mon=mo; t.day=d; t.hour=h; t.min=mi; t.sec=0; return StructToTime(t); }
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-58s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true;
  // calendario
  chk("DowYmd 2026-11-09 = lunedi", DowYmd(2026,11,9)==1);
  chk("DowYmd 2027-03-26 = venerdi", DowYmd(2027,3,26)==5);
  chk("primo giorno: 2026-01-02 si (1 gen festa)", IsFirstTradingDay(20260102));
  chk("primo giorno: 2026-01-01 no", !IsFirstTradingDay(20260101));
  chk("primo giorno: 2026-03-02 si (1 marzo domenica)", IsFirstTradingDay(20260302));
  chk("primo giorno: 2026-11-03 no", !IsFirstTradingDay(20261103));
  chk("scadenza: 2026-11-24 si (4o ultimo, Thanksgiving escluso)", IsExpiryWindow(20261124));
  chk("scadenza: 2026-11-25 si (giorno dopo)", IsExpiryWindow(20261125));
  chk("scadenza: 2026-11-23 no", !IsExpiryWindow(20261123));
  chk("scadenza: 2026-11-30 no", !IsExpiryWindow(20261130));
  chk("scadenza: 2026-10-27 si (ottobre: 30,29,28,27)", IsExpiryWindow(20261027));
  // P2 liquidita' sottile
  string why;
  chk("P2 Thanksgiving 26/11/2026 15:00 UTC bloccato", ThinLiquidity(U(2026,11,26,15,0), 15.0, 8.0, why)); printf("   -> %s\n", why.c_str());
  chk("P2 festa Giappone 23/11/2026 02:00 UTC bloccato", ThinLiquidity(U(2026,11,23,2,0), 2.0, 8.0, why)); printf("   -> %s\n", why.c_str());
  chk("P2 festa Giappone 23/11/2026 10:00 UTC libero (Londra)", !ThinLiquidity(U(2026,11,23,10,0), 10.0, 8.0, why));
  chk("P2 giorno normale 24/11/2026 02:00 UTC libero", !ThinLiquidity(U(2026,11,24,2,0), 2.0, 8.0, why));
  // riapertura: 50 barre prima di una pausa di 2 giorni, poi barre dopo
  datetime t0=U(2026,11,13,20,0), t1=U(2026,11,15,23,0);
  ArrayResize(g_m1.r, 120);
  for(int i=0;i<60;i++){ g_m1.r[i].time=t0+i*60; }
  for(int i=60;i<120;i++){ g_m1.r[i].time=t1+(i-60)*60; }
  g_m1.n=120;   // ultima barra chiusa = t1 + 59 min
  chk("P2 50 min dopo la riapertura bloccato", ThinLiquidity(t1+50*60, 23.8, 8.0, why));
  ArrayResize(g_m1.r, 200);
  for(int i=120;i<200;i++){ g_m1.r[i].time=t1+(i-60)*60; }
  g_m1.n=200;   // ultima barra = t1 + 139 min
  chk("P2 140 min dopo la riapertura libero", !ThinLiquidity(t1+140*60, 1.3, 8.0, why));
  InpP2ThinLiquidity=false;
  chk("P2 spento: Thanksgiving libero", !ThinLiquidity(U(2026,11,26,15,0), 15.0, 8.0, why));
  InpP2ThinLiquidity=true;
  // P1 corsa verticale: serie deterministica
  DynArr<MqlRates> r; ArrayResize(r, 230);
  double c=1000.0;
  for(int i=0;i<230;i++){ double x=0.01*(((i*7919)%13)-6)/6.0; if(i>=210) x+=0.012; c*=exp(x); r[i].close=c; }
  RunBrakeCompute(r, 230);
  printf("P1 serie con corsa: runZ %.4f dist200 %.4f freno %d\n", g_runZ, g_ma200Dist, (int)g_runBrake);
  chk("P1 freno acceso dopo la corsa", g_runBrake);
  c=1000.0; for(int i=0;i<230;i++){ double x=0.01*(((i*7919)%13)-6)/6.0; c*=exp(x); r[i].close=c; }
  RunBrakeCompute(r, 230);
  printf("P1 serie piatta: runZ %.4f dist200 %.4f freno %d\n", g_runZ, g_ma200Dist, (int)g_runBrake);
  chk("P1 freno spento senza corsa", !g_runBrake);
  // P5 stop in Asia
  InpP5AsiaStopBuffer=true;
  g_ctx.hUtc=2.0; g_ctx.lonOpen=8.0; g_ctx.atrH1=4.0; g_ctx.spread=0.2;
  g_lvN=0; LvAdd(2000.0, LV_PDL, 1.0); LvAdd(2030.0, LV_ROUNDM, 1.0);
  TSignal s; MakeSignal(s, ST_SW_TREND, 1, 2010.0, 2000.3, 2.5, 0.7, "test");
  AsiaStopAdjust(s);
  printf("P5 long: sl %.2f tp %.2f rr %.3f | %s\n", s.sl, s.tp, (s.tp-s.entry)/(s.entry-s.sl), s.why.c_str());
  chk("P5 long: stop spostato a 1999.00, R:R invariato", fabs(s.sl-1999.0)<1e-6 && fabs((s.tp-s.entry)/(s.entry-s.sl)-2.5)<0.002);
  MakeSignal(s, ST_SW_TREND, -1, 2020.0, 2029.5, 2.5, 0.7, "test");
  AsiaStopAdjust(s);
  printf("P5 short: sl %.2f tp %.2f\n", s.sl, s.tp);
  chk("P5 short: stop spostato a 2031.20 (livello+margine+spread)", fabs(s.sl-2031.2)<1e-6);
  g_ctx.hUtc=12.0; MakeSignal(s, ST_SW_TREND, 1, 2010.0, 2000.3, 2.5, 0.7, "test"); AsiaStopAdjust(s);
  chk("P5 fuori dalle ore asiatiche: stop invariato", fabs(s.sl-2000.3)<1e-6);
  // P6 scadenza
  InpP6ExpiryTargets=true;
  g_ctx.nowUtc=U(2026,11,24,15,0);
  MakeSignal(s, ST_IN_BREAKOUT, 1, 2010.0, 2000.0, 2.5, 0.7, "test"); ExpiryTargetAdjust(s);
  printf("P6 24/11: tp %.2f (%.3fR) | %s\n", s.tp, (s.tp-s.entry)/10.0, s.why.c_str());
  chk("P6 breakout 2.5R -> 2.125R il giorno di scadenza", fabs(s.tp-2031.25)<0.011);
  MakeSignal(s, ST_IN_BREAKOUT, 1, 2010.0, 2000.0, 2.2, 0.7, "test"); ExpiryTargetAdjust(s);
  chk("P6 mai sotto 1:2 (2.2R -> 2.0R)", fabs(s.tp-2030.0)<0.011);
  MakeSignal(s, ST_IN_PULLBACK, 1, 2010.0, 2000.0, 2.5, 0.7, "test"); ExpiryTargetAdjust(s);
  chk("P6 non tocca i non-breakout", fabs(s.tp-2035.0)<0.011);
  g_ctx.nowUtc=U(2026,11,20,15,0);
  MakeSignal(s, ST_IN_BREAKOUT, 1, 2010.0, 2000.0, 2.5, 0.7, "test"); ExpiryTargetAdjust(s);
  chk("P6 giorno normale: target invariato", fabs(s.tp-2035.0)<0.011);

  // 1.17 rientro dopo pareggio
  S_now=U(2026,11,10,14,0);
  for(int e=0;e<3;e++){ g_reArmed[e]=false; g_reDir[e]=0; g_reT[e]=0; }
  int mi=0; g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].engine=ENG_INTRA; g_meta[mi].dir=1; g_meta[mi].tranche=0;
  g_meta[mi].riskMoney=100.0; g_meta[mi].beDone=true; g_meta[mi].strat=0;
  FinalizeTrade(mi, 62.0);   // 0.62R: parziale a +1.5R e resto chiuso al cuscinetto
  chk("rientro: armato dopo un trade tornato al pareggio (+0.62R)", g_reArmed[ENG_INTRA] && g_reDir[ENG_INTRA]==1);
  TSignal q; MakeSignal(q, ST_IN_PULLBACK, 1, 2010.0, 2000.0, 2.5, 0.7, "test");
  q.engine=ENG_INTRA; q.score=0.68; q.quorum=7; q.devil=0; q.desk[D_CONTEXT]=0.6; q.desk[D_MACRO]=0.6;
  chk("rientro: idea confermata nella stessa direzione -> si", ReentryEligible(q));
  q.dir=-1; chk("rientro: direzione opposta -> no", !ReentryEligible(q)); q.dir=1;
  q.score=0.64; chk("rientro: punteggio solo 0.64 (serve 0.65) -> no", !ReentryEligible(q)); q.score=0.68;
  q.quorum=6; chk("rientro: quorum 6/8 (serve 7) -> no", !ReentryEligible(q)); q.quorum=7;
  q.desk[D_CONTEXT]=0.5; chk("rientro: contesto debole -> no", !ReentryEligible(q)); q.desk[D_CONTEXT]=0.6;
  S_now=U(2026,11,10,18,30); chk("rientro: oltre 4 ore per l'intraday -> no", !ReentryEligible(q));
  S_now=U(2026,11,10,15,0); chk("rientro: entro 4 ore -> si", ReentryEligible(q));
  g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].engine=ENG_INTRA; g_meta[mi].dir=1; g_meta[mi].riskMoney=100.0; g_meta[mi].beDone=false;
  FinalizeTrade(mi, -100.0);
  chk("rientro: una perdita piena disarma", !g_reArmed[ENG_INTRA]);
  g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].engine=ENG_INTRA; g_meta[mi].dir=1; g_meta[mi].riskMoney=100.0; g_meta[mi].beDone=true; g_meta[mi].reentry=true;
  FinalizeTrade(mi, 60.0);
  chk("rientro: un rientro tornato a pareggio non si riarma (una volta sola)", !g_reArmed[ENG_INTRA]);
  g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].engine=ENG_INTRA; g_meta[mi].dir=1; g_meta[mi].riskMoney=100.0; g_meta[mi].beDone=true;
  FinalizeTrade(mi, 240.0);
  chk("rientro: un trade chiuso in buon profitto (+2.4R) non arma", !g_reArmed[ENG_INTRA]);
  InpReentryOn=false; g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].engine=ENG_INTRA; g_meta[mi].dir=1; g_meta[mi].riskMoney=100.0; g_meta[mi].beDone=true;
  FinalizeTrade(mi, 62.0); chk("rientro spento: non arma", !g_reArmed[ENG_INTRA]); InpReentryOn=true;

  // 1.18 idee A+
  g_regime=0; g_runBrake=false; g_lossStreak=0;
  TSignal a; MakeSignal(a, ST_IN_PULLBACK, 1, 2010.0, 2000.0, 2.5, 0.7, "test");
  a.engine=ENG_INTRA; a.score=0.72; a.quorum=7; a.devil=1; a.desk[D_CONTEXT]=0.6; a.desk[D_MACRO]=0.55; a.recovery=false;
  chk("A+: punteggio 0.72, 7/8, contesto e macro a favore -> si", AplusEligible(a, 0));
  chk("A+: macro o contesto contrari -> no", !AplusEligible(a, 1));
  a.score=0.69; chk("A+: punteggio 0.69 -> no", !AplusEligible(a, 0)); a.score=0.72;
  a.quorum=6; chk("A+: quorum 6/8 -> no", !AplusEligible(a, 0)); a.quorum=7;
  a.devil=2; chk("A+: avvocato del diavolo 2 -> no", !AplusEligible(a, 0)); a.devil=1;
  g_runBrake=true; chk("A+: freno corse acceso -> no", !AplusEligible(a, 0)); g_runBrake=false;
  g_lossStreak=2; chk("A+: due perdite di fila -> no", !AplusEligible(a, 0)); g_lossStreak=0;
  g_regime=REG_VOLATILE; chk("A+: regime volatile -> no", !AplusEligible(a, 0)); g_regime=0;
  a.engine=ENG_SWING; a.score=0.70; chk("A+ swing: serve 0.70 (0.65+0.05) -> si", AplusEligible(a, 0));
  InpAplusOn=false; chk("A+ spento -> no", !AplusEligible(a, 0)); InpAplusOn=true;
  printf("\nRISULTATO: %d falliti\n", fails);
  return fails?1:0;
}
