// test130.cpp - XAU Committee EA 1.30: fine mese, oro contro argento, rischio cosciente della volatilita', bot che si parlano
#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-100s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
static bool has(const std::string&a,const char*b){ return a.find(b)!=std::string::npos; }
static bool near(double a,double b,double e=1e-6){ return fabs(a-b)<=e; }
static void mkTf(TfData&d,int n,datetime t0,int sec,double px,double range,int emaDir){
  d.n=n; ArrayResize(d.r,n); ArrayResize(d.ema20,n); ArrayResize(d.ema50,n); ArrayResize(d.atr,n);
  for(int i=0;i<n;i++){ d.r[i].time=t0+(datetime)i*sec; d.r[i].open=px; d.r[i].close=px; d.r[i].high=px+range/2; d.r[i].low=px-range/2; d.ema20[i]=px+emaDir; d.ema50[i]=px; d.atr[i]=range; }
}
static MqlRates bar(datetime t,double c){ MqlRates b; b.time=t; b.open=c; b.high=c+0.05; b.low=c-0.05; b.close=c; b.tick_volume=10; b.spread=0; b.real_volume=0; return b; }
static void setNow(datetime t,double px){ S_now=t; g_ctx.nowUtc=t; g_ctx.dow=DowOf(t); g_ctx.bid=px; g_ctx.ask=px+0.2; g_ctx.spread=0.2; S_bid=px; S_ask=px+0.2; }
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true; S_tester=true; g_minLot=0.01; g_lotStep=0.01; g_lotDigits=2; g_sym="XAUUSD"; g_currency="EUR";
  InpVirtualCapital=0.0; S_balance=3000.0;
  // ---------- di serie
  chk("versione 1.30", std::string(EA_VERSION)=="1.30");
  chk("22 strategie: le due nuove si chiamano IN-MESE e IN-ARGENTO, motore intraday, famiglia dei movimenti forti", NSTRAT==22 && g_stratName[ST_IN_MESE]=="IN-MESE" && g_stratName[ST_IN_ARG]=="IN-ARGENTO" &&
      g_stratEngine[ST_IN_MESE]==ENG_INTRA && g_stratEngine[ST_IN_ARG]==ENG_INTRA && IsTrendMove(ST_IN_MESE) && IsTrendMove(ST_IN_ARG) && RdFamily(ST_IN_MESE)==FAM_MF);
  chk("di serie: fine mese acceso (stop 0,5, 15:55 -> 10:00 NY, rischio pieno)", InpIN_MESE && near(InpMeseStopAtr,0.5) && InpMeseEntryMin==955 && InpMeseExitMin==600 && near(InpMeseRiskMult,1.0) && near(TmRiskMult(ST_IN_MESE),1.0));
  chk("di serie: oro contro argento acceso (3:00-8:00 NY, soglia 0,25, stop 0,3, esce 15:55, meta' rischio)", InpIN_ARG && InpArgSymbol=="XAGUSD" && InpArgFromMin==180 && InpArgAtMin==480 && InpArgExitMin==955 &&
      near(InpArgThreshAtr,0.25) && near(InpArgStopAtr,0.30) && near(InpArgRiskMult,0.5) && near(TmRiskMult(ST_IN_ARG),0.5));
  chk("di serie: rischio cosciente (modo 1), calmo sotto 0,85 -> x1,25, agitato da 1,5, pareggio come gli altri", InpVolMode==1 && near(InpVolCalmBelow,0.85) && near(InpVolCalmMult,1.25) && near(InpVolHotAbove,1.5) && near(InpVolHotBE_R,0.0));
  chk("di serie: bot che si parlano accesi, nome ORO, gestione attenta oltre il 5% di tutti, nessun pareggio diverso", InpBusOn && InpBusName=="ORO" && near(InpBusCarefulRisk,5.0) && near(InpBusCarefulBE_R,0.0) && InpBusPeers=="ORO,NAS,US30,JPY");
  chk("regole fisse invariate: rischio 1%, max 3% a trade, pareggio a 1,5R, 6 posizioni", near(InpRiskPercent,1.0) && near(InpMaxRiskPerTrade,3.0) && near(InpBE_R,1.5) && InpMaxPos==6);
  // ---------- ultimo giorno di borsa del mese (lunedi'-giovedi')
  chk("mar 30 set 2025: si'", LastTradingDayMonThu(1759190400+20*3600));
  chk("gio 30 ott 2025: no (venerdi' 31 e' ancora ottobre)", !LastTradingDayMonThu(1761782400+20*3600));
  chk("ven 31 ott 2025: no (il venerdi' sui dati non regge)", !LastTradingDayMonThu(1761868800+20*3600));
  chk("gio 27 e ven 28 nov 2025: no (fine mese di sabato/domenica, l'ultimo giorno di borsa e' venerdi')", !LastTradingDayMonThu(1764201600+20*3600) && !LastTradingDayMonThu(1764288000+20*3600));
  chk("mer 31 dic 2025 e mar 31 mar 2026: si'", LastTradingDayMonThu(1767139200+20*3600) && LastTradingDayMonThu(1774915200+20*3600));
  chk("ven 30 gen 2026: no", !LastTradingDayMonThu(1769731200+20*3600));
  // ---------- IN-MESE: mar 30 set 2025 (ora legale di New York: 15:55 NY = 19:55 UTC)
  { datetime d=1759190400; mkTf(g_d1,80,d-80*86400,86400,3800.0,40.0,1); TmInit(); TSignal s;
    setNow(d+19*3600+50*60,3800.0); bool ok=S_InMese(s);
    chk("alle 19:50 UTC aspetta e dice a che ora compra", !ok && has(g_tmText[TM_MESE],"compra alle 19:55"));
    setNow(d+19*3600+55*60+20,3800.0); ok=S_InMese(s);
    chk("alle 19:55 UTC compra", ok && s.strat==ST_IN_MESE && s.dir==1 && s.engine==ENG_INTRA);
    chk("stop 0,5 escursioni (20 $), target almeno 2R", near(s.entry-s.sl,20.0,0.05) && (s.tp-s.entry)>=InpMinRR*(s.entry-s.sl)-0.011);
    chk("esce il giorno dopo alle 10:00 NY (14:00 UTC del 1 ottobre)", s.deadline==d+86400+14*3600 && has(s.why,"fine mese") && s.proven==InpTDProven);
    setNow(d+19*3600+55*60+(InpTDMaxDelayMin+2)*60,3800.0); ok=S_InMese(s);
    chk("troppo tardi: non entra", !ok && has(g_tmText[TM_MESE],"non riuscito"));
    TmMarkDone(ST_IN_MESE,Ymd(d),"aperto buy"); setNow(d+19*3600+55*60+20,3800.0); ok=S_InMese(s);
    chk("una volta sola al giorno", !ok && has(g_tmText[TM_MESE],"oggi aperto"));
    TmInit(); setNow(1761868800+19*3600+55*60+20,3800.0); ok=S_InMese(s);
    chk("venerdi' 31 ottobre: niente", !ok && g_tmText[TM_MESE]=="");
    TmInit(); setNow(1767139200+20*3600+55*60+20,3800.0); ok=S_InMese(s);
    chk("31 dicembre (ora solare: 15:55 NY = 20:55 UTC): compra, esce il 1 gennaio alle 15:00 UTC", ok && s.deadline==1767139200+86400+15*3600);
    InpIN_MESE=false; chk("spento: non e' attivo", !StratEnabled(ST_IN_MESE)); InpIN_MESE=true; }
  // ---------- IN-ARGENTO: mar 4 nov 2025 (ora solare: 3:00 NY = 8:00 UTC, 8:00 NY = 13:00 UTC, 15:55 NY = 20:55 UTC)
  { datetime d=1762214400; mkTf(g_d1,80,d-80*86400,86400,4000.0,40.0,1); TmInit();
    OS.clear(); otherInit(); OtherSym*o=findOther("XAGUSD"); int kd=tfIndex(PERIOD_D1);
    for(int i=25;i>=1;i--){ MqlRates b=bar(d-(datetime)i*86400,48.0); b.high=48.5; b.low=47.5; o->AG[kd].push_back(b); }   // escursione media dell'argento: 1,0
    auto prices=[&](double g0,double g1,double s0,double s1){ M1.clear(); o->M1.clear();
      M1.push_back(bar(d+7*3600+59*60,g0)); M1.push_back(bar(d+12*3600+59*60,g1)); o->M1.push_back(bar(d+7*3600+59*60,s0)); o->M1.push_back(bar(d+12*3600+59*60,s1)); };
    TSignal s;
    prices(4000.0,4020.0,48.0,48.1); setNow(d+10*3600,4010.0); bool ok=S_InArg(s);
    chk("alle 10:00 UTC misura ancora", !ok && has(g_tmText[TM_ARG],"misura oro contro argento fino alle 13:00"));
    setNow(d+13*3600+30,4020.0); ok=S_InArg(s);
    chk("oro +0,5 escursioni, argento +0,1: differenza 0,4 -> compra l'oro alle 13:00 UTC", ok && s.strat==ST_IN_ARG && s.dir==1 && near(g_argLastDiff,0.4,1e-9) && has(s.why,"oro piu' forte"));
    chk("stop 0,3 escursioni dell'oro (12 $), esce alle 15:55 NY (20:55 UTC)", near(s.entry-s.sl,12.0,0.05) && s.deadline==d+20*3600+55*60);
    TmInit(); prices(4000.0,4020.0,48.0,48.3); setNow(d+13*3600+30,4020.0); ok=S_InArg(s);
    chk("argento +0,3: differenza 0,2 sotto la soglia -> nessun segnale", !ok && has(g_tmText[TM_ARG],"nessun segnale"));
    ok=S_InArg(s); chk("e al minuto dopo resta 'nessun segnale' per tutto il giorno", !ok && has(g_tmText[TM_ARG],"oggi nessun segnale") && has(g_tmText[TM_ARG],"differenza 0.20"));
    TmInit(); prices(4000.0,3990.0,48.0,48.1); setNow(d+13*3600+30,3990.0); ok=S_InArg(s);
    chk("oro -0,25, argento +0,1: differenza -0,35 -> vende l'oro", ok && s.dir==-1 && near(s.sl-s.entry,12.0,0.25) && has(s.why,"oro piu' debole"));
    TmInit(); setNow(d+13*3600+(InpTDMaxDelayMin+2)*60,3990.0); ok=S_InArg(s);
    chk("troppo tardi dopo le 13:00: non entra", !ok);
    TmInit(); prices(4000.0,4020.0,48.0,48.1); o->M1.clear(); setNow(d+13*3600+30,4020.0); ok=S_InArg(s);
    chk("prezzi dell'argento mancanti: non entra e lo dice", !ok && has(g_tmText[TM_ARG],"mancanti"));
    TmInit(); prices(4000.0,4020.0,48.0,48.1); setNow(d+21*3600,4020.0); ok=S_InArg(s);
    chk("dopo l'uscita delle 15:55 NY non fa nulla", !ok && g_tmText[TM_ARG]=="");
    InpArgSymbol="XAGUSD.x"; std::string sy=ArgSym(); chk("simbolo dell'argento sbagliato: lo cerca da solo (o lo lascia vuoto)", sy!="XAGUSD.x"); InpArgSymbol="XAGUSD";
    InpIN_ARG=false; chk("spento: non e' attivo", !StratEnabled(ST_IN_ARG)); InpIN_ARG=true;
    M1.clear(); OS.clear(); TmInit(); }
  // ---------- posizione opposta: le due nuove non sono un'opinione sul trend, su un conto hedging entrano lo stesso
  { P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); g_netting=false; g_lossesInRowToday=0; InpOnlyStrategy=PICK_ALL; for(int e=0;e<3;e++) g_tradesToday[e]=0;
    datetime wd=1762214400;
    auto pos=[&](ulong tk,int eng,int strat,int dir,double open,double sl){ SimPos q; q.ticket=tk; q.id=(long)tk; q.type=(dir>0)?0:1; q.vol=0.01; q.open=open; q.sl=sl; q.tp=0; q.time=wd; q.magic=(ulong)MagicOfEngine(eng); q.comment="XC"; P.push_back(q);
      int k=MetaFree(); g_meta[k].Reset(); g_meta[k].active=true; g_meta[k].id=(long)tk; g_meta[k].strat=strat; g_meta[k].engine=eng; g_meta[k].dir=dir; };
    auto sig=[&](int strat,int dir){ TSignal s; s.Reset(); s.strat=strat; s.engine=g_stratEngine[strat]; s.dir=dir; PortfolioChecks(s); return s; };
    pos(8101,ENG_INTRA,ST_ON_M15,1,4000,3990);
    { TSignal a=sig(ST_IN_ARG,-1), b=sig(ST_IN_MESE,-1), c=sig(ST_IN_TREND,-1);
      chk("ritracciamento in acquisto aperto: IN-ARGENTO e IN-MESE in vendita entrano (conto hedging)", !a.veto && !b.veto);
      chk("gli altri movimenti forti no (come prima)", c.veto && has(c.vetoWhy,"posizione opposta")); }
    InpMfHedgeOk=false; { TSignal a=sig(ST_IN_ARG,-1); chk("con InpMfHedgeOk spento: non entra (come gli altri)", a.veto && has(a.vetoWhy,"posizione opposta")); } InpMfHedgeOk=true;
    g_netting=true; { TSignal a=sig(ST_IN_ARG,-1); chk("conto netting: non entra", a.veto); } g_netting=false;
    P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); }
  // ---------- uscita a ora fissa
  { datetime wd=1762214400; std::string why; int mi=0; g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].strat=ST_IN_ARG; g_meta[mi].engine=ENG_INTRA; g_meta[mi].dir=1;
    g_meta[mi].openTime=wd+13*3600; g_meta[mi].deadline=wd+20*3600+55*60;
    S_now=wd+20*3600+54*60; chk("IN-ARGENTO: alle 20:54 UTC resta aperto", !ForcedExit(mi,why));
    S_now=wd+20*3600+55*60; chk("alle 20:55 UTC chiude", ForcedExit(mi,why) && has(why,"fine della tenuta"));
    g_meta[mi].strat=ST_IN_MESE; g_meta[mi].openTime=1759190400+19*3600+55*60; g_meta[mi].deadline=1759190400+86400+14*3600;
    S_now=1759190400+86400+3*3600; chk("IN-MESE: la notte resta aperto (non e' un intraday qualsiasi)", !ForcedExit(mi,why));
    S_now=1759190400+86400+14*3600; chk("alle 10:00 NY del giorno dopo chiude", ForcedExit(mi,why) && has(why,"fine della tenuta"));
    g_meta[mi].Reset(); }
  // ---------- rischio cosciente della volatilita'
  { g_h1.n=0; g_atrRatioH1=1.0;
    chk("volatilita' normale: stato 0, rischio x1", VolState()==0 && near(VolCalmMult(),1.0) && near(BeAtOpen(),0.0));
    g_atrRatioH1=0.7; chk("calmo (0,7): rischio x1,25", VolState()==-1 && near(VolCalmMult(),1.25));
    InpVolCalmMult=3.0; chk("mai oltre x2", near(VolCalmMult(),2.0)); InpVolCalmMult=0.5; chk("mai sotto x1 (il calmo non toglie)", near(VolCalmMult(),1.0)); InpVolCalmMult=1.25;
    g_atrRatioH1=1.6; chk("agitato (1,6): stesso rischio, nessun taglio (anche se V e' acceso)", VolState()==1 && near(VolCalmMult(),1.0) && near(VolTargetMult(),1.0));
    chk("agitato, di serie: pareggio come gli altri", near(BeAtOpen(),0.0));
    InpVolHotBE_R=1.0; chk("agitato con InpVolHotBE_R 1: pareggio a +1R", near(BeAtOpen(),1.0)); InpVolHotBE_R=0.0;
    InpVolMode=0; chk("modo 0 (come la 1.29): taglio per volatilita' alta, niente calmo", VolState()==0 && VolTargetMult()<0.999 && near(VolCalmMult(),1.0)); InpVolMode=1;
    g_atrRatioH1=1.0; }
  // ---------- pareggio salvato per posizione
  { datetime wd=1762214400; int mi=0; P.clear(); SimPos q; q.ticket=7101; q.id=7101; q.type=0; q.vol=0.02; q.open=4000.0; q.sl=3990.0; q.tp=4030.0; q.time=wd+9*3600; q.magic=0; q.comment="XC ONDA-H1"; P.push_back(q);
    g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].id=7101; g_meta[mi].strat=ST_ON_H1; g_meta[mi].engine=ENG_SWING; g_meta[mi].dir=1; g_meta[mi].entry=4000.0; g_meta[mi].sl0=3990.0;
    g_meta[mi].riskPx=10.0; g_meta[mi].lots0=0.02; g_meta[mi].openTime=wd+9*3600; g_meta[mi].deadline=wd+30*86400; g_meta[mi].beR=1.0;
    setNow(wd+86400+10*3600,4011.0); PositionSelectByTicket(7101); ManageOne(7101,mi);
    chk("gestione attenta (pareggio a 1R): a +1,1R lo stop va a pareggio", g_meta[mi].beDone && P[0].sl>=4000.0);
    g_meta[mi].beDone=false; g_meta[mi].beR=0.0; P[0].sl=3990.0; P[0].vol=0.02; g_meta[mi].partialDone=false; PositionSelectByTicket(7101); ManageOne(7101,mi);
    chk("senza gestione attenta (1,5R): a +1,1R resta", !g_meta[mi].beDone && near(P[0].sl,3990.0));
    P.clear(); g_meta[mi].Reset();
    g_isTester=false; S_tester=false; g_login=123456; for(int i=0;i<MAX_META;i++) g_meta[i].Reset();
    g_meta[0].active=true; g_meta[0].id=9101; g_meta[0].strat=ST_IN_ARG; g_meta[0].engine=ENG_INTRA; g_meta[0].dir=-1; g_meta[0].deadline=wd+20*3600+55*60; g_meta[0].beR=1.2;
    MetaSave(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); MetaLoad(); int a=MetaFind(9101);
    chk("salvataggio e rilettura: IN-ARGENTO, uscita e pareggio tornano uguali", a>=0 && g_meta[a].strat==ST_IN_ARG && g_meta[a].deadline==wd+20*3600+55*60 && near(g_meta[a].beR,1.2));
    { std::string path="simfiles/"+MetaFile(); FILE*f=fopen(path.c_str(),"w"); if(f){ fprintf(f,"9102;%d;1;1;0;5;4000.00000;3990.00000;4020.00000;10.00000;30.00;0.03;0.700;0;0;0;0;%ld;0;0;0;%ld;0\r\n",ST_ON_M15,(long)wd,(long)(wd+7200)); fclose(f); }
      for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); MetaLoad(); int c=MetaFind(9102);
      chk("file della 1.29 (senza il pareggio): letto, pareggio come gli altri", c>=0 && g_meta[c].strat==ST_ON_M15 && g_meta[c].deadline==wd+7200 && near(g_meta[c].beR,0.0));
      remove(path.c_str()); }
    for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); g_isTester=true; S_tester=true; }
  // ---------- bot che si parlano
  { datetime wd=1762214400; g_isTester=false; S_tester=false; g_login=123456; P.clear(); setNow(wd+10*3600,4000.0);
    auto peer=[&](const char*nm,const char*line){ std::string path=std::string("simfiles/BotComuni_123456_")+nm+".txt"; FILE*f=fopen(path.c_str(),"w"); if(f){ fprintf(f,"%s\r\n",line); fclose(f); } };
    auto rm=[&](const char*nm){ std::string path=std::string("simfiles/BotComuni_123456_")+nm+".txt"; remove(path.c_str()); };
    BusWrite(); FILE*f=fopen("simfiles/BotComuni_123456_ORO.txt","r"); char buf[256]={0}; if(f){ if(!fgets(buf,255,f)) buf[0]=0; fclose(f); }
    std::string own=buf; chk("scrive il suo stato nella cartella comune: nome, simbolo, ora, posizioni, rischio, oggi", has(own,"ORO;XAUUSD;") && has(own,";0;0.00;"));
    BusRead(); chk("nessun altro bot: nessuno attivo, nessuna gestione attenta", g_busN==0 && !BusCareful() && has(BusPanel(),"nessuno attivo"));
    char l1[128]; snprintf(l1,sizeof l1,"NAS;USTEC;%ld;3;2.50;0.40",(long)(wd+10*3600-120)); peer("NAS",l1);
    char l2[128]; snprintf(l2,sizeof l2,"US30;US30;%ld;1;1.00;-0.20",(long)(wd+10*3600-60)); peer("US30",l2);
    BusRead(); chk("legge NAS e US30: 3,5% di rischio in tutto", g_busN==2 && near(g_busTotRisk,3.5) && !BusCareful());
    std::string pn=BusPanel(); chk("pannello: una riga con gli altri bot e il totale", has(pn,"NAS 3 pos") && has(pn,"US30 1 pos") && has(pn,"tutti insieme 3.5%") && pn.size()<=201);
    snprintf(l1,sizeof l1,"NAS;USTEC;%ld;4;4.20;0.40",(long)(wd+10*3600-120)); peer("NAS",l1);
    BusRead(); chk("NAS 4,2% + US30 1%: oltre il 5% -> gestione attenta, nessun blocco", g_busN==2 && BusCareful() && has(BusShort(),"gestione attenta"));
    { TSignal s; s.Reset(); s.strat=ST_ON_M15; s.engine=ENG_INTRA; s.dir=1; PortfolioChecks(s); chk("la nuova posizione non viene fermata dal rischio degli altri bot", !s.veto); }
    chk("di serie il pareggio non cambia; con InpBusCarefulBE_R 1,2 si'", near(BeAtOpen(),0.0) && (InpBusCarefulBE_R=1.2, near(BeAtOpen(),1.2))); InpBusCarefulBE_R=0.0;
    snprintf(l1,sizeof l1,"NAS;USTEC;%ld;4;4.20;0.40",(long)(wd+10*3600-700)); peer("NAS",l1);
    BusRead(); chk("NAS fermo da piu' di 10 minuti: non conta", g_busN==1 && near(g_busTotRisk,1.0) && !BusCareful());
    peer("JPY","rotto"); BusRead(); chk("file rovinato: ignorato", g_busN==1);
    InpBusCarefulRisk=0.0; snprintf(l1,sizeof l1,"NAS;USTEC;%ld;4;9.00;0.40",(long)(wd+10*3600-60)); peer("NAS",l1); BusRead(); chk("soglia 0: mai gestione attenta", !BusCareful()); InpBusCarefulRisk=5.0;
    g_isTester=true; S_tester=true; chk("nel Tester: niente file, niente gestione attenta", !BusCareful() && BusPanel()=="");
    rm("NAS"); rm("US30"); rm("JPY"); rm("ORO"); }
  printf("FALLITI %d\n", fails); return fails?1:0;
}
