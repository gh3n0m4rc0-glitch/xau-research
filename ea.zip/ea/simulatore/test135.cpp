// test135.cpp - XAU Committee EA 1.35: test134 + NOTTE di New York e uscita a 12 ore
//  - lettura del feed (righe a meta', righe nel futuro, buchi)
//  - i soldi dell'assorbimento restano fuori da equity, saldo e margine del resto del bot
#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-100s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
static bool near(double a,double b,double e=1e-6){ return fabs(a-b)<=e; }
static void ringReset(){ for(int i=0;i<ABS_RING;i++){ g_absMin[i]=-1; g_absVal[i]=0; } g_absPos=0; g_absFirst=0; g_absLast=0; }
static void put(const char*mode,const char*txt){ FILE*f=fopen("simfiles/GC_delta.csv",mode); fputs(txt,f); fclose(f); }
static SimPos mk(ulong tk,int dir,double open,double vol,ulong magic){ SimPos q; q.ticket=tk; q.id=(long)tk; q.type=(dir>0)?0:1; q.vol=vol; q.open=open; q.sl=0; q.tp=0; q.time=S_now-600; q.magic=magic; q.comment=""; return q; }
static SimDeal dl(ulong tk,ulong magic,long pos,double profit){ SimDeal d; d.ticket=tk; d.order=tk; d.time=S_now-300; d.type=0; d.entry=1; d.magic=magic; d.posid=pos; d.vol=0.01; d.price=4000; d.comm=0; d.swap=0; d.profit=profit; d.fee=0; d.comment=""; return d; }
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true; S_tester=true; g_minLot=0.01; g_lotStep=0.01; g_lotDigits=2; g_sym="XAUUSD"; g_currency="EUR";
  InpVirtualCapital=0.0; S_balance=3000.0; if(system("mkdir -p simfiles")!=0) return 2;
  const datetime T0=1795428000;                       // lunedi' 23 nov 2026 10:00 (ora del server = UTC nel test)
  const long M0=(long)T0/60;
  // ---------- di serie
  chk("versione 1.35", std::string(EA_VERSION)=="1.35");
  chk("assorbimento acceso di serie, rischio 0,5% a trade, lotto minimo accettato fino al 2%", InpAbsOn && near(InpAbsRiskPct,0.5) && near(InpAbsMinLotMaxRisk,2.0));
  chk("regole 1.34: 2 ore 0,08 ATR, 1 ora 0,11 (eff. 5,13), 15 min 0,05 (eff. 12)",
      InpAbsUse2h && InpAbsUse1h && InpAbsUse15m && near(InpAbsMin2h,0.08) && near(InpAbsMove1h,0.11) && near(InpAbsEff1h,5.13) && near(InpAbsMin15m,0.05) && near(InpAbsEffMax15m,12.0));
  chk("1.34: solo nel verso delle posizioni del bot (InpAbsWithBot acceso di serie)", InpAbsWithBot);
  chk("stop 0,5 ATR, target 1,5 ATR, uscita dopo 720 min (12 ore), un trade per verso ogni 45 min",
      near(InpAbsStopAtr,0.5) && near(InpAbsTargetAtr,1.5) && InpAbsHoldMinutes==720 && InpAbsGapMinutes==45);
  chk("1.35: NOTTE di New York accesa di serie", InpAbsUseNight);
  chk("spread massimo 0,60 $, lascia libero il 50% dell'equity in margine, buco massimo 2 minuti",
      near(InpAbsMaxSpread,0.60) && near(InpAbsKeepFreeMargin,50.0) && InpAbsMaxHoleMin==2);
  chk("magic proprio (base+10): il resto del bot non lo conta come suo", AbsMagic()==InpMagicBase+10 && !IsOurMagic(AbsMagic()) && IsOurMagic(InpMagicBase+1));
  chk("resto del bot uguale alla 1.32: rischio 1%, lotto scelto 0,03 poi 0,02, 6 posizioni",
      near(InpRiskPercent,1.0) && near(InpUserMinLots,0.03) && near(InpUserMinLots2,0.02) && InpMaxPos==6);
  // ---------- lettura del feed
  ringReset(); S_now=T0+5*60;
  put("w","utc;buy;sell;none;ticks;last\r\n2026.11.23 10:00;100;40;0;12;4000.10\r\n2026.11.23 10:01;10;30;0;9;4000.20\r\n2026.11.23 10:02;7;7;1;5;4000.00\r\n2026.11.23 10:03;5");
  AbsReadFeed();
  long s=0;
  chk("legge le righe complete: ultimo minuto 10:02", g_absLast==M0+2 && g_absFirst==M0);
  chk("delta 10:00-10:02 = (100-40)+(10-30)+(7-7) = 40", AbsDelta(M0,M0+2,s) && s==40);
  chk("riga a meta' (il feed la sta scrivendo): non la legge e non la salta", g_absMin[(M0+3)%ABS_RING]!=M0+3);
  put("a","0;20;0;7;4000.50\r\n");                    // la riga diventa 10:03;50;20;...
  AbsReadFeed();
  chk("riga finita al giro dopo: 10:03 letta intera (50-20 = 30)", g_absLast==M0+3 && g_absMin[(M0+3)%ABS_RING]==M0+3 && g_absVal[(M0+3)%ABS_RING]==30);
  put("a","2026.11.23 10:30;100;0;0;1;4001.00\r\n");
  AbsReadFeed();
  chk("riga nel futuro (solo nel replay): aspetta", g_absLast==M0+3);
  S_now=T0+31*60; AbsReadFeed();
  chk("quando arriva l'ora la legge", g_absLast==M0+30);
  chk("buco di 2 minuti nella finestra: va bene", AbsDelta(M0,M0+5,s));
  chk("buco di 3 minuti: finestra scartata (niente segnale)", !AbsDelta(M0,M0+6,s));
  chk("finestra prima dell'inizio del feed: scartata", !AbsDelta(M0-10,M0+2,s));
  put("w","utc;buy;sell;none;ticks;last\r\n2026.11.23 10:40;1;2;0;3;4000\r\n");
  S_now=T0+41*60; AbsReadFeed();
  chk("il feed ricomincia il file da capo: lo rilegge dall'inizio", g_absLast==M0+40 && g_absVal[(M0+40)%ABS_RING]==-1);
  // ---------- dal vivo con un file lungo (mesi di feed): al primo giro legge solo la coda
  { FILE*f=fopen("simfiles/GC_delta.csv","w"); fputs("utc;buy;sell;none;ticks;last\r\n",f);
    const int N=60000; for(int i=0;i<N;i++){ datetime t=T0-(datetime)(N-1-i)*60; MqlDateTime d; TimeToStruct(t,d);
      fprintf(f,"%04d.%02d.%02d %02d:%02d;%d;%d;0;5;4000.00\r\n",d.year,d.mon,d.day,d.hour,d.min,10+(i%7),10); }
    fclose(f);
    g_isTester=false; S_tester=false; ringReset(); S_now=T0+60; AbsReadFeed(); g_isTester=true; S_tester=true;
    long sum=0; bool ok=AbsDelta(M0-119,M0,sum); long exp=0; for(int i=N-120;i<N;i++) exp+=(i%7);
    chk("file di 60.000 minuti (oltre 2 MB): legge l'ultimo pezzo, non da capo", g_absFirst>M0-N+1000 && g_absFirst<M0-14*1440);
    chk("dopo il salto: ultimo minuto giusto e finestra di 2 ore completa e giusta", g_absLast==M0 && ok && sum==exp);
    ringReset(); S_now=T0+60; AbsReadFeed();
    chk("nel replay (tester) invece legge tutto dall'inizio", g_absFirst==M0-N+1 && g_absLast==M0); }
  // ---------- soldi dell'assorbimento fuori dal conto del resto del bot
  P.clear(); D.clear(); S_bid=4010.0; S_ask=4010.2; S_now=T0+3600;
  ulong mainMg=(ulong)MagicOfEngine(ENG_INTRA), absMg=(ulong)AbsMagic();
  P.push_back(mk(11,1,4000.0,0.03,mainMg));            // trade del bot: +10 $ a 0,03 lotti
  P.push_back(mk(12,-1,4000.0,0.05,absMg));            // assorbimento: vendita a 4000, ask 4010.2 -> in perdita
  D.push_back(dl(1,mainMg,5,25.0));                    // chiuso del bot +25
  D.push_back(dl(2,absMg,6,-40.0));                    // chiuso dell'assorbimento -40
  S_balance=3000.0+25.0-40.0;
  g_absLastDeal=0; g_absHistFrom=0; g_absClosed=0; g_absPnlDirty=true; g_absLastBal=-1;
  AbsAccountRefresh();
  double absFlo=posProfit(P[1]);
  chk("chiusi dell'assorbimento contati: -40", near(g_absClosed,-40.0));
  chk("risultato dell'assorbimento = chiusi + aperto", near(g_absPart,-40.0+absFlo));
  chk("saldo del bot = conto senza l'assorbimento (3000 + 25)", near(AccBalance(),3025.0));
  chk("equity del bot = 3000 + 25 + il suo trade aperto", near(AccEquity(),3025.0+posProfit(P[0])));
  chk("margine dell'assorbimento tolto dal margine usato dal bot", near(g_absMargin,marginOf(4000.0,0.05)) && near(AccountInfoDouble(ACCOUNT_MARGIN)-g_absMargin,marginOf(4000.0,0.03)));
  chk("l'assorbimento calcola il rischio sul conto intero", near(AbsEquity(),equity()));
  D.push_back(dl(3,absMg,7,10.0)); D.push_back(dl(4,mainMg,8,-15.0)); S_balance+=10.0-15.0;
  AbsAccountRefresh();
  chk("deal nuovi: conta solo quelli nuovi dell'assorbimento (-40 + 10), niente doppi", near(g_absClosed,-30.0));
  chk("saldo del bot dopo: 3000 + 25 - 15", near(AccBalance(),3010.0));
  P.erase(P.begin()+1); AbsAccountRefresh();
  chk("assorbimento chiuso: nessun aperto e nessun margine", near(g_absPart,-30.0) && near(g_absMargin,0.0));
  InpAbsOn=false; double eq0=AccEquity(); AbsAccountRefresh();
  chk("con InpAbsOn = false i trade gia' fatti restano fuori dal conto del bot", near(AccEquity(),eq0));
  // ---------- avviso se il feed si ferma (solo dal vivo)
  g_isTester=false; S_tester=false; S_push=0; g_absAlertAt=0;
  S_now=T0+2*3600; g_absLast=AbsNowMin()-40; AbsFeedAlert();
  chk("dal vivo, feed fermo da 40 minuti a mercato aperto: avviso sul telefono", S_push==1);
  S_now+=600; g_absLast=AbsNowMin()-50; AbsFeedAlert();
  chk("non ripete l'avviso prima di 6 ore", S_push==1);
  S_now+=7*3600; g_absLast=AbsNowMin()-20; AbsFeedAlert();
  chk("feed in ritardo di 20 minuti: nessun avviso", S_push==1);
  g_absLast=0; S_now+=3600; AbsFeedAlert();
  chk("feed mai partito (AMP non ancora pronto): nessun avviso", S_push==1);
  S_now=T0-2*86400+12*3600; g_absAlertAt=0; g_absLast=AbsNowMin()-600; AbsFeedAlert();
  chk("sabato (mercato chiuso): nessun avviso", S_push==1);
  g_isTester=true; S_tester=true;
  // ---------- 1.34: mai contro il bot, mai da solo
  { InpAbsOn=true; g_isTester=true; S_tester=true; P.clear(); D.clear(); S_bid=4010.0; S_ask=4010.2; S_now=T0+5*3600;
    ulong mg=(ulong)MagicOfEngine(ENG_INTRA), am=(ulong)AbsMagic();
    g_absLastBuy=0; g_absLastSell=0; int n0=g_absNOpen;
    AbsSignal(-1,"2 ore",20.0,"prova");
    chk("bot senza posizioni: segnale saltato", g_absNOpen==n0 && g_absMsg.find("non ha posizioni")!=std::string::npos);
    P.push_back(mk(21,1,4000.0,0.03,mg));
    AbsSignal(-1,"2 ore",20.0,"prova");
    chk("bot in acquisto, segnale di vendita: saltato (non va contro)", g_absNOpen==n0 && g_absMsg.find("verso opposto")!=std::string::npos);
    P.push_back(mk(22,1,4000.0,0.05,am));
    AbsSignal(-1,"2 ore",20.0,"prova");
    chk("le posizioni dell'assorbimento non contano come posizioni del bot", g_absNOpen==n0 && g_absMsg.find("verso opposto")!=std::string::npos);
    P.erase(P.begin()+1);
    AbsSignal(1,"2 ore",20.0,"prova");
    chk("bot in acquisto, segnale di acquisto: passa il filtro", g_absMsg.find("non ha posizioni")==std::string::npos && g_absMsg.find("verso opposto")==std::string::npos);
    P.push_back(mk(23,-1,4000.0,0.03,mg)); P.push_back(mk(24,-1,4000.0,0.03,mg));
    g_absLastBuy=0; AbsSignal(1,"2 ore",20.0,"prova");
    chk("1 acquisto e 2 vendite del bot: conta il verso netto, acquisto saltato", g_absMsg.find("verso opposto")!=std::string::npos);
    InpAbsWithBot=false; g_absLastBuy=0; AbsSignal(1,"2 ore",20.0,"prova");
    chk("con InpAbsWithBot = false torna come la 1.33", g_absMsg.find("verso opposto")==std::string::npos);
    InpAbsWithBot=true; P.clear(); }
  printf("FALLITI %d\n", fails); return fails?1:0;
}
