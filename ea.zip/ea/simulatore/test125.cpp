#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-70s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
// barre M1 dal tempo t0 (UTC = server, offset 0) con prezzo che va da p0 a p1 in 'n' minuti, poi piatto
static void m1(datetime t0,int n,double p0,double p1,int tot){
  tot+=10; ArrayResize(g_m1.r,tot); g_m1.n=tot;   // 10 barre piatte prima dell'inizio
  for(int i=0;i<tot;i++){ int k=i-10; double p=(k<0)? p0 : (k<n)? p0+(p1-p0)*k/(double)n : p1; g_m1.r[i].time=t0+k*60; g_m1.r[i].open=p; g_m1.r[i].close=p; g_m1.r[i].high=p+0.1; g_m1.r[i].low=p-0.1; }
}
static TSignal sig(int dir,int eng=ENG_SCALP,int st=STYPE_TREND){ TSignal s; s.Reset(); s.strat=ST_SC_VWAP; s.engine=eng; s.stype=st; s.dir=dir; s.veto=false; s.entry=4000; return s; }
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true;
  chk("versione 1.25 o successiva", std::string(EA_VERSION)>="1.25");
  chk("OF1 e OF2 accesi di default, soglia 3 bp", InpOF1FixNoChase && InpOF2VolumeNeutral && fabs(InpOF1MinBp-3.0)<1e-9);
  chk("restano le scelte della 1.24 (Wyckoff spento, T5 acceso)", !InpSW_WYCKOFF && InpT5NoShortAfterCrash);
  // inverno: 2025-11-05, fixing 10:30 UTC
  datetime day=1762300800; datetime fxw=day+10*3600+1800;
  chk("fixing d'inverno alle 10:30 UTC", FixAmUtc(day+12*3600)==fxw);
  datetime sday=1751328000; // 2025-07-01
  chk("fixing d'estate alle 09:30 UTC (10:30 di Londra)", FixAmUtc(sday+12*3600)==sday+9*3600+1800);
  // salita di 10 $ (25 bp) tra 10:15 e 10:30, ora 10:33
  m1(fxw-900,15,3990,4000,19);   // barre fino alle 10:33
  g_ctx.nowUtc=fxw+180;
  chk("prezzo alle 10:15 letto dalle M1", fabs(M1PriceAtUtc(fxw-900)-3990)<0.01);
  chk("prezzo alle 10:30 letto dalle M1", fabs(M1PriceAtUtc(fxw)-4000)<0.01);
  std::string w; TSignal L=sig(1); chk("10:33 dopo +25 bp: long scalping -> veto OF1", FixChase(L,w) && w.find("OF1")!=std::string::npos);
  TSignal S=sig(-1); chk("10:33 dopo +25 bp: short (contro il movimento) permesso", !FixChase(S,w));
  TSignal I=sig(1,ENG_INTRA,STYPE_BREAKOUT); chk("anche l'intraday in rottura nel verso -> veto", FixChase(I,w));
  TSignal W=sig(1,ENG_SWING); chk("lo swing non e' toccato", !FixChase(W,w));
  g_ctx.nowUtc=fxw+900; chk("10:45: finestra finita, nessun veto", !FixChase(L,w));
  g_ctx.nowUtc=fxw-60; chk("10:29: prima del fixing, nessun veto", !FixChase(L,w));
  g_ctx.nowUtc=fxw+180;
  InpOF1FixNoChase=false; chk("OF1 spento: nessun veto", !FixChase(L,w)); InpOF1FixNoChase=true;
  // movimento piccolo: 0,8 $ = 2 bp
  m1(fxw-900,15,3999.2,4000,19); g_ctx.nowUtc=fxw+180;
  chk("movimento di 2 bp (sotto 3): nessun veto", !FixChase(L,w));
  // discesa: veto agli short
  m1(fxw-900,15,4010,4000,19);
  TSignal S2=sig(-1); chk("dopo una discesa di 25 bp: short -> veto, long permesso", FixChase(S2,w) && !FixChase(L,w));
  // buco nei dati: nessuna decisione
  m1(fxw-900,15,3990,4000,19); for(int i=15;i<29;i++) g_m1.r[i].time+=3600; // barre dalle 10:20 spostate di un'ora
  g_ctx.nowUtc=fxw+180+3600*0; chk("dati con buco: nessun veto (prudenza)", !FixChase(L,w));
  // OF2: il desk Volumi non dipende piu' dal delta
  m1(day,300,4000,4000,300);
  g_microHead=-1; g_microCount=0; for(int i=0;i<50;i++) MicroPush(day+i*60,4000,4001,3999,4000,100,+100);
  TSignal a=sig(1); double up=DeskVolume(a);
  g_microHead=-1; g_microCount=0; for(int i=0;i<50;i++) MicroPush(day+i*60,4000,4001,3999,4000,100,-100);
  TSignal b=sig(1); double dn=DeskVolume(b);
  chk("OF2 acceso: delta a favore o contro -> stesso desk Volumi", fabs(up-dn)<1e-9);
  { std::string l; b.desk[D_SESSION]=0.6; DevilsAdvocate(b,l); chk("OF2 acceso: nessuna obiezione 'delta contrario'", l.find("delta contrario")==std::string::npos); }
  InpOF2VolumeNeutral=false;
  g_microHead=-1; g_microCount=0; for(int i=0;i<50;i++) MicroPush(day+i*60,4000,4001,3999,4000,100,+100);
  TSignal c=sig(1); double up0=DeskVolume(c);
  g_microHead=-1; g_microCount=0; for(int i=0;i<50;i++) MicroPush(day+i*60,4000,4001,3999,4000,100,-100);
  TSignal e=sig(1); double dn0=DeskVolume(e);
  chk("OF2 spento: il delta torna a contare come nella 1.24", up0>dn0+0.1);
  { std::string l; e.desk[D_SESSION]=0.6; DevilsAdvocate(e,l); chk("OF2 spento: torna l'obiezione 'delta contrario'", l.find("delta contrario")!=std::string::npos); }
  InpOF2VolumeNeutral=true;

  // ---------- 1.25 parte 2: costi veri, volatilita', diario, protezioni
  chk("K, V, D, S accesi di default; 3% per verso", InpCostTrack && InpVolTarget && InpDecisionLog && InpSafetyAlerts && InpWeekendHalfSwing && fabs(InpMaxDirRiskPct-3.0)<1e-9);
  g_h1.n=0;
  g_atrRatioH1=1.0; chk("V: volatilita' normale -> rischio invariato", fabs(VolTargetMult()-1.0)<1e-9);
  g_atrRatioH1=1.2; chk("V: fino a 1,2 volte il normale -> invariato", fabs(VolTargetMult()-1.0)<1e-9);
  g_atrRatioH1=1.8; chk("V: 1,8 volte -> rischio x0,67", fabs(VolTargetMult()-1.2/1.8)<1e-6);
  g_atrRatioH1=4.0; chk("V: 4 volte -> mai sotto x0,5", fabs(VolTargetMult()-0.5)<1e-9);
  g_atrRatioH1=0.5; chk("V: volatilita' bassa -> mai sopra il rischio base", VolTargetMult()<=1.0+1e-9);
  InpVolTarget=false; g_atrRatioH1=3.0; chk("V spento: nessun taglio", fabs(VolTargetMult()-1.0)<1e-9); InpVolTarget=true; g_atrRatioH1=1.0;
  // costi misurati
  g_costCommN=0; chk("K: senza trade misurati la commissione e' il parametro", fabs(CommPerLotEff()-InpCommissionPerLot)<1e-9);
  g_costCommN=3; g_costCommLot=2.5; chk("K: dopo 3 trade usa la commissione vera (2,5/lotto)", fabs(CommPerLotEff()-2.5)<1e-9);
  InpCostTrack=false; chk("K spento: torna il parametro", fabs(CommPerLotEff()-InpCommissionPerLot)<1e-9); InpCostTrack=true;
  g_costCommN=0;
  g_costSlipN=2; g_costSlipPx=0.30; chk("K: slittamento stimato 10% dello spread con meno di 5 ingressi", fabs(SlipEstPx(0.20)-0.02)<1e-9);
  g_costSlipN=5; chk("K: dopo 5 ingressi usa lo slittamento vero (0,30)", fabs(SlipEstPx(0.20)-0.30)<1e-9);
  g_costSlipPx=-0.05; chk("K: slittamento a favore non riduce i costi stimati", fabs(SlipEstPx(0.20))<1e-9);
  g_costSlipN=0; g_costSlipPx=0;
  { double a=0; int n=0; a=CostAvg(a,n,1.0); n++; a=CostAvg(a,n,3.0); n++; chk("K: media dei costi (1 e 3 -> 2)", fabs(a-2.0)<1e-9); }
  // mercato aperto
  { datetime wed=1762300800+12*3600; // mer 5/11/2025 12:00 UTC
    chk("S: mercoledi' 12 UTC mercato aperto", MarketShouldBeOpen(wed));
    chk("S: sabato chiuso", !MarketShouldBeOpen(wed+3*86400));
    chk("S: venerdi' 21 UTC chiuso", !MarketShouldBeOpen(wed+2*86400+9*3600));
    chk("S: pausa giornaliera 21:30 UTC chiusa", !MarketShouldBeOpen(wed+9*3600+1800)); }
  // diario delle decisioni
  { remove("simfiles/XauCommittee_tester_decisioni.csv");
    TSignal d=sig(1); d.sl=3995; d.tp=4010; d.score=0.71; d.quorum=7; d.passed=true; d.vetoWhy="prova; con punto e virgola"; for(int i=0;i<NDESK;i++) d.desk[i]=0.6;
    g_ctx.spread=0.15; DecisionLog(d,"aperto",12); DecisionLog(d,"respinto",0);
    FILE*f=fopen("simfiles/XauCommittee_tester_decisioni.csv","r"); int lines=0; int semis=0; char buf[4096]; std::string first,second;
    if(f){ while(fgets(buf,sizeof buf,f)){ lines++; if(lines==1) first=buf; if(lines==2) second=buf; } fclose(f); }
    for(char c: first) if(c==';') semis++;
    int semis2=0; for(char c: second) if(c==';') semis2++;
    chk("D: diario scritto (intestazione + 2 idee)", lines==3);
    chk("D: stesse colonne in intestazione e righe (il ; nel veto non rompe il CSV)", semis>20 && semis==semis2);
    chk("D: c'e' la colonna di ogni desk", first.find("Contesto HTF")!=std::string::npos && first.find("Costi")!=std::string::npos);
    InpDecisionLog=false; DecisionLog(d,"x",0); f=fopen("simfiles/XauCommittee_tester_decisioni.csv","r"); int l2=0; if(f){ while(fgets(buf,sizeof buf,f)) l2++; fclose(f);} 
    chk("D spento: niente righe nuove", l2==3); InpDecisionLog=true; }

  // ---------- 1.25 parte 3: meno regole (conferme forti, obiezioni misurate, idee fantasma)
  chk("MR: acceso di default (7/8, +0,06, max 2 obiezioni, rischio x0,6, 30 casi)", InpOverrideOn && InpOverrideQuorum==7 && fabs(InpOverrideExtraScore-0.06)<1e-9 &&
      InpOverrideMaxSoft==2 && fabs(InpOverrideRiskMult-0.6)<1e-9 && InpObjLearn && InpObjMinN==30 && InpObjFromTester);
  { double mn=MinScoreFor(ENG_SCALP);
    auto mk=[&](int soft,int q,double sc,double st)->TSignal{ TSignal s=sig(1); s.softN=soft; s.softWhy="macro contraria (x)"; s.quorum=q; for(int i=0;i<NDESK;i++) s.desk[i]=0.6; s.desk[D_STRAT]=st; s.devil=soft>0?3:0; s.score=sc; return s; };
    TSignal a=mk(1,7,mn+0.07,0.7); ResolveSoft(a,a.score); chk("MR: 1 obiezione secondaria + 7/8 desk + punteggio alto -> passa scavalcando", a.overrideOk && !a.veto);
    TSignal b=mk(1,6,mn+0.07,0.7); ResolveSoft(b,b.score); chk("MR: con 6/8 desk l'obiezione blocca (come prima)", !b.overrideOk && b.veto && b.vetoWhy.find("macro contraria")!=std::string::npos);
    TSignal c=mk(1,7,mn+0.03,0.7); ResolveSoft(c,c.score); chk("MR: punteggio solo +0,03 sopra la soglia -> blocca", !c.overrideOk && c.veto);
    TSignal d=mk(3,8,mn+0.2,0.9); ResolveSoft(d,d.score); chk("MR: 3 obiezioni secondarie insieme -> blocca anche con 8/8", !d.overrideOk && d.veto);
    TSignal e=mk(1,7,mn+0.07,0.5); ResolveSoft(e,e.score); chk("MR: strategia debole (0,5) -> blocca", !e.overrideOk && e.veto);
    TSignal f=mk(1,8,mn+0.2,0.9); Veto(f,"spread anomalo"); ResolveSoft(f,f.score); chk("MR: un veto obbligatorio non si scavalca mai", !f.overrideOk && f.veto);
    TSignal g=mk(1,7,mn+0.07,0.7); g.devil=5; ResolveSoft(g,g.score); chk("MR: avvocato del diavolo con 5 argomenti -> blocca", !g.overrideOk && g.veto);
    TSignal h=mk(0,6,mn+0.01,0.6); ResolveSoft(h,h.score); chk("MR: nessuna obiezione -> niente da scavalcare, nessun veto", !h.overrideOk && !h.veto);
    InpOverrideOn=false; TSignal i2=mk(1,8,mn+0.2,0.9); ResolveSoft(i2,i2.score); chk("MR spento: le obiezioni secondarie bloccano come nella 1.24", !i2.overrideOk && i2.veto); InpOverrideOn=true; }
  // giudizio sulle obiezioni (stesso metro degli studi: 30 casi, 3 periodi su 4)
  // varianza degli R = 1 (idee da -1/+2): i quadrati servono al controllo "lontano dal caso"
  auto setp=[&](int k,int p,double n,double s){ g_obN[k*NPER+p]=n; g_obS[k*NPER+p]=s; g_obQ[k*NPER+p]=n>0? n*(1.0+(s/n)*(s/n)):0; };
  auto totp=[&](int p,double n,double s){ g_obTotN[p]=n; g_obTotS[p]=s; g_obTotQ[p]=n>0? n*(1.0+(s/n)*(s/n)):0; };
  ObjInit(); chk("MR: senza casi ogni obiezione e' da provare", ObjEvaluate(OB_RSIDIV)==OBS_TEST);
  ObjInit(); for(int p=0;p<4;p++){ totp(p,100,5); setp(OB_RSIDIV,p,15,-4.5); }
  chk("MR: idee con l'obiezione -0,30R contro +0,11R senza, 4 periodi su 4 -> provata", ObjEvaluate(OB_RSIDIV)==OBS_USEFUL);
  for(int p=0;p<4;p++){ g_obQ[OB_RSIDIV*NPER+p]=15*(9.0+0.09); g_obTotQ[p]=100*9.0+5; }
  chk("MR: stessa differenza ma R molto sparsi (varianza 9) -> non lontana dal caso, resta da provare", ObjEvaluate(OB_RSIDIV)==OBS_TEST);
  ObjInit(); for(int p=0;p<4;p++){ totp(p,100,5); setp(OB_RSIDIV,p,15,(p<2)?-9.0:3.0); }
  chk("MR: peggio solo in 2 periodi su 4 -> resta da provare", ObjEvaluate(OB_RSIDIV)==OBS_TEST);
  ObjInit(); for(int p=0;p<4;p++){ totp(p,100,5); setp(OB_SESS,p,20,2.0); }
  chk("MR: idee con l'obiezione +0,10R, senza +0,04R -> inutile (non conta)", ObjEvaluate(OB_SESS)==OBS_USELESS);
  ObjInit(); totp(3,200,10); setp(OB_SESS,3,40,4.0);
  chk("MR: un anno solo con 40 casi -> ancora da provare (ne servono 60)", ObjEvaluate(OB_SESS)==OBS_TEST);
  setp(OB_SESS,3,70,7.0); totp(3,230,13);
  chk("MR: un anno solo con 70 casi -> giudicata", ObjEvaluate(OB_SESS)==OBS_USELESS);
  ObjInit(); for(int p=0;p<4;p++){ totp(p,100,5); setp(OB_RSIDIV,p,15,-4.5); setp(OB_SESS,p,20,2.0); }
  ObjRefresh(false);
  { TSignal s=sig(1); SoftVeto(s,OB_TREND2,"contro il trend su due timeframe"); chk("MR: obiezione da provare -> secondaria (decide la fine del comitato)", s.softN==1 && !s.veto && (s.objMask&(1<<OB_TREND2))); }
  { std::string l; TSignal s=sig(1); s.obstacleR=-1; s.desk[D_SESSION]=0.3; int c=DevilsAdvocate(s,l);
    chk("MR: argomento 'sessione debole' misurato inutile -> non conta nel diavolo", l.find("sessione debole")==std::string::npos && (s.objMask&(1<<OB_SESS)) && c==0); }
  g_obState[OB_TREND2]=OBS_USEFUL;
  { TSignal s=sig(1); SoftVeto(s,OB_TREND2,"contro il trend su due timeframe"); chk("MR: obiezione provata -> blocca da sola", s.veto && s.softN==0 && s.vetoWhy.find("provata")!=std::string::npos); }
  g_obState[OB_TREND2]=OBS_USELESS;
  { TSignal s=sig(1); SoftVeto(s,OB_TREND2,"x"); chk("MR: obiezione inutile -> non blocca, resta nel diario", !s.veto && s.softN==0 && ObjList(s.objMask).find("(inutile)")!=std::string::npos); }
  InpObjLearn=false; { TSignal s=sig(1); SoftVeto(s,OB_TREND2,"x"); chk("MR: apprendimento spento -> tutte da provare", s.softN==1 && !s.veto); } InpObjLearn=true;
  // idee fantasma
  ObjInit(); GhostInit(); ObjRefresh(false);
  { datetime t0=1762300800+12*3600; S_now=t0+30; g_ctx.spread=0.20; g_costSlipN=0;
    double mn=MinScoreFor(ENG_SCALP);
    TSignal L=sig(1); L.entry=4000; L.sl=3990; L.tp=4020; L.score=mn+0.1; L.quorum=7; L.objMask=(1<<OB_RSIDIV);
    TSignal Sh=sig(-1); Sh.strat=ST_SC_SWEEP; Sh.entry=4000; Sh.sl=4010; Sh.tp=3980; Sh.score=mn+0.1; Sh.quorum=7; Sh.objMask=0;
    TSignal low=sig(1); low.strat=ST_SC_ORB; low.entry=4000; low.sl=3990; low.tp=4020; low.score=mn-0.05; low.quorum=7;
    GhostAdd(L); GhostAdd(L); GhostAdd(Sh); GhostAdd(low);
    chk("MR: idee fantasma: la stessa idea ripetuta conta una volta, le deboli no", GhostOpen()==2);
    ArrayResize(g_m1.r,2); g_m1.n=2;
    g_m1.r[0].time=t0; g_m1.r[0].open=4000; g_m1.r[0].close=4000; g_m1.r[0].high=4025; g_m1.r[0].low=3985;
    g_m1.r[1].time=t0+60; g_m1.r[1].open=4000; g_m1.r[1].close=4000; g_m1.r[1].high=4000; g_m1.r[1].low=4000;
    GhostUpdate(); chk("MR: la barra in cui nasce l'idea non conta", GhostOpen()==2);
    g_m1.r[0].time=t0+60; g_m1.r[0].high=4021; g_m1.r[0].low=3999; g_m1.r[1].time=t0+120;
    GhostUpdate();
    double cst=g_gh[0].costR;
    chk("MR: long tocca il target, short tocca lo stop: entrambe chiuse", GhostOpen()==0 && fabs(g_obTotN[3]-2)<1e-9);
    chk("MR: R dopo i costi (+2 e -1, meno i costi)", fabs(g_obS[OB_RSIDIV*NPER+3]-(2.0-cst))<1e-6 && fabs(g_obTotS[3]-(2.0-cst-1.0-cst))<1e-6 && cst>0 && cst<0.2);
    S_now=t0+180; GhostAdd(L); g_m1.r[0].time=t0+240; g_m1.r[0].high=4021; g_m1.r[0].low=3989; g_m1.r[1].time=t0+300; GhostUpdate();
    chk("MR: stop e target nella stessa barra -> conta lo stop (prudenza)", fabs(g_obS[OB_RSIDIV*NPER+3]-(2.0-cst-1.0-cst))<1e-6);
    S_now=t0+360; GhostAdd(L); g_m1.r[0].time=t0+360+240*60; g_m1.r[0].high=4006; g_m1.r[0].low=4004; g_m1.r[0].close=4005; g_m1.r[1].time=g_m1.r[0].time+60; GhostUpdate();
    chk("MR: scaduta dopo 4 ore (scalping) -> chiusa al prezzo (+0,5R)", GhostOpen()==0 && fabs(g_obS[OB_RSIDIV*NPER+3]-(2.0-cst-1.0-cst+0.5-cst))<1e-6); }
  // file: il Tester impara, il conto riparte da li'
  { remove("simfiles/XauCommittee_tester_obiezioni.csv");
    ObjInit(); for(int p=0;p<4;p++){ totp(p,100,5); setp(OB_RSIDIV,p,15,-4.5); } ObjRefresh(false);
    g_isTester=true; ObjSave();
    double n=ObjReadFile(ObjFile(true)); ObjRefresh(false);
    chk("MR: file del Tester riletto uguale (400 idee, divergenza RSI provata)", fabs(n-400)<1e-9 && fabs(g_obS[OB_RSIDIV*NPER+2]+4.5)<1e-6 && fabs(g_obQ[OB_RSIDIV*NPER+2]-16.35)<1e-3 && ObjState(OB_RSIDIV)==OBS_USEFUL);
    g_isTester=false; S_tester=false; remove(("simfiles/"+ObjFile(false)).c_str()); ObjLoad();
    chk("MR: sul conto, senza file suo, parte da quello del Tester", fabs(g_obTotN[1]-100)<1e-9 && ObjState(OB_RSIDIV)==OBS_USEFUL);
    InpObjFromTester=false; ObjLoad(); chk("MR: con 'parti dal Tester' spento riparte da zero", g_obTotN[1]==0); InpObjFromTester=true;
    g_isTester=true; S_tester=true; ObjLoad(); chk("MR: nel Tester si impara sempre da zero", g_obTotN[1]==0);
    remove("simfiles/XauCommittee_tester_obiezioni.csv"); }
  ObjInit(); GhostInit(); ObjRefresh(false);
  printf("FALLITI %d\n", fails); return fails?1:0;
}
