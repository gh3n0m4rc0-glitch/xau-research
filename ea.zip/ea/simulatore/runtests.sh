#!/bin/bash
# $1 = cartella mt5 (con shim/sim)
cd "$1/shim"
run(){ echo "== $*"; timeout 1500 ./sim "$@" 2>&1 | grep -E "^SIM|fallito|ERROR|runtime error|AddressSanitizer|DIAG" | tail -6; }
run seed=1 days=60
run seed=2 days=60
run seed=3 days=60 rw=1
run seed=4 days=60 flow=300
run seed=5 days=60 flow=-200
run seed=6 days=60 reinitvc=1000
run seed=7 days=60 mh=1
rm -f simfiles/XauCommittee_123456_*   # il live riparte pulito (stato salvato dei run precedenti)
run seed=8 days=60 mode=live
