// Broker simulato per eseguire XauCommitteeEA (trasformato in C++) su dati sintetici dell'oro.
#include "mql5shim.h"
#include <random>

bool g_shimQuiet = true;
std::vector<string> g_shimLog;
string g_shimComment;
string _Symbol = "XAUUSD";

// ---------------------------------------------------------------- stato del simulatore
static bool S_tester = true;
static datetime S_now = 0;            // ora server del tick corrente
static double S_bid = 4000.0, S_ask = 4000.2;
static const double S_eurusd = 1.08;
static const double S_contract = 100.0;
static const double S_leverage = 20.0;
static const double S_commSide = 3.5;   // USD per lato per lotto
static double S_balance = 500.0;
static double S_peakEq = 0, S_maxDDpct = 0;
static int S_lastErr = 0;
static bool S_timer = false;
static int S_gmtOff(datetime utc);

struct SimPos { ulong ticket; long id; int type; double vol, open, sl, tp; datetime time; ulong magic; string comment; double sl0 = 0, mfe = 0, mae = 0; };
static std::vector<std::pair<double,double>> S_exc;  // (mfeR, maeR) alla chiusura
struct Ghost { int dir; double open, R; };
static std::vector<Ghost> S_ghost, S_ghostEA;
static int S_gUp = 0, S_gDn = 0, S_gUpEA = 0, S_gDnEA = 0;
static void ghostStep(std::vector<Ghost> &g, int &up, int &dn) {
  for (int j = (int)g.size() - 1; j >= 0; j--) {
    double fav = g[j].dir > 0 ? S_bid - g[j].open : g[j].open - S_ask;
    if (fav >= 1.5 * g[j].R) { up++; g.erase(g.begin() + j); }
    else if (fav <= -g[j].R) { dn++; g.erase(g.begin() + j); }
  }
}
struct SimOrd { ulong ticket; int type; double vol, price, sl, tp; datetime setup; ulong magic; string comment; };
struct SimDeal { ulong ticket, order; datetime time; int type, entry; ulong magic; long posid; double vol, price, comm, swap, profit, fee; string comment; };
static std::vector<SimPos> P;
static std::vector<SimOrd> O;
static std::vector<SimDeal> D;
static std::vector<int> H;            // deal selezionati
static int selPos = -1, selOrd = -1;
static ulong nextTicket = 1000, nextDeal = 500000;
static std::deque<MqlTradeTransaction> TQ;
static std::map<string, double> GV;
static int S_closedTrades = 0;

// barre
static std::vector<MqlRates> M1;      // M1 chiuse
static MqlRates M1cur;
static bool M1curOn = false;
static const ENUM_TIMEFRAMES TFS[6] = {PERIOD_M5, PERIOD_M15, PERIOD_H1, PERIOD_H4, PERIOD_D1, PERIOD_W1};
static std::vector<MqlRates> AG[6];

static int tfIndex(ENUM_TIMEFRAMES tf) {
  for (int i = 0; i < 6; i++)
    if (TFS[i] == tf) return i;
  return -1;
}
static datetime bucketStart(ENUM_TIMEFRAMES tf, datetime t) {
  if (tf == PERIOD_W1) {
    datetime day = t - (t % 86400);
    int dow = (int)(((day / 86400) + 4) % 7);  // 0 = domenica
    return day - dow * 86400;
  }
  int s = PeriodSeconds(tf);
  return t - (t % s);
}
static void aggAdd(const MqlRates &b) {
  for (int i = 0; i < 6; i++) {
    datetime bs = bucketStart(TFS[i], b.time);
    std::vector<MqlRates> &v = AG[i];
    if (v.empty() || v.back().time != bs) {
      MqlRates n = b;
      n.time = bs;
      v.push_back(n);
    } else {
      MqlRates &x = v.back();
      x.high = std::max(x.high, b.high);
      x.low = std::min(x.low, b.low);
      x.close = b.close;
      x.tick_volume += b.tick_volume;
    }
  }
}
static void completedList(ENUM_TIMEFRAMES tf, const MqlRates *&base, int &m) {
  if (tf == PERIOD_M1) {
    base = M1.empty() ? nullptr : &M1[0];
    m = (int)M1.size();
    return;
  }
  int k = tfIndex(tf);
  if (k < 0) ShimFail("timeframe non gestito dal simulatore");
  std::vector<MqlRates> &v = AG[k];
  datetime fs = bucketStart(tf, S_now);
  m = (int)v.size();
  while (m > 0 && v[m - 1].time >= fs) m--;
  base = v.empty() ? nullptr : &v[0];
}

// ---------------------------------------------------------------- altri simboli (intermarket)
struct OtherSym { string name; double px, beta, noise, goldBeta; std::vector<MqlRates> M1; std::vector<MqlRates> AG[6]; };
static std::vector<OtherSym> OS;
static bool S_fx = true;
static OtherSym *findOther(const string &s) {
  for (auto &o : OS)
    if (o.name == s) return &o;
  return nullptr;
}
static void otherInit() {
  if (!S_fx) return;
  OS.push_back({"EURUSD", 1.10, -1.0, 0.00008, 0, {}, {}});
  OS.push_back({"USDJPY", 150.0, 0.7, 0.00010, 0, {}, {}});
  OS.push_back({"GBPUSD", 1.30, -0.9, 0.00009, 0, {}, {}});
  OS.push_back({"USDCAD", 1.36, 0.5, 0.00007, 0, {}, {}});
  OS.push_back({"USDCHF", 0.88, 0.9, 0.00008, 0, {}, {}});
  OS.push_back({"XAGUSD", 48.0, 0.0, 0.00050, 1.2, {}, {}});
  OS.push_back({"US500", 6000.0, 0.0, 0.00035, 0, {}, {}});
}
static void otherAgg(OtherSym &o, const MqlRates &b) {
  for (int i = 0; i < 6; i++) {
    datetime bs = bucketStart(TFS[i], b.time);
    std::vector<MqlRates> &v = o.AG[i];
    if (v.empty() || v.back().time != bs) {
      MqlRates n = b;
      n.time = bs;
      v.push_back(n);
    } else {
      MqlRates &x = v.back();
      x.high = std::max(x.high, b.high);
      x.low = std::min(x.low, b.low);
      x.close = b.close;
      x.tick_volume += b.tick_volume;
    }
  }
}
static void otherCompleted(OtherSym &o, ENUM_TIMEFRAMES tf, const MqlRates *&base, int &m) {
  if (tf == PERIOD_M1) {
    base = o.M1.empty() ? nullptr : &o.M1[0];
    m = (int)o.M1.size();
    while (m > 0 && o.M1[m - 1].time >= bucketStart(PERIOD_M1, S_now)) m--;
    return;
  }
  int k = tfIndex(tf);
  if (k < 0) ShimFail("timeframe non gestito (altri simboli)");
  std::vector<MqlRates> &v = o.AG[k];
  datetime fs = bucketStart(tf, S_now);
  m = (int)v.size();
  while (m > 0 && v[m - 1].time >= fs) m--;
  base = v.empty() ? nullptr : &v[0];
}

// ---------------------------------------------------------------- API tempo/info
datetime TimeCurrent() { return S_now; }
datetime TimeTradeServer() { return S_now; }
datetime TimeGMT() { return S_tester ? S_now : S_now - 3600 * S_gmtOff(S_now); }
datetime TimeLocal() { return S_now; }
int MQLInfoInteger(ENUM_MQL_INFO_INTEGER p) {
  if (p == MQL_TESTER) return S_tester ? 1 : 0;
  if (p == MQL_TRADE_ALLOWED) return 1;
  return 0;
}
int TerminalInfoInteger(ENUM_TERMINAL_INFO_INTEGER p) { return 1; }
bool SymbolSelect(const string &s, bool) { return s == "XAUUSD" || findOther(s) != nullptr; }
double SymbolInfoDouble(const string &s, ENUM_SYMBOL_INFO_DOUBLE p) {
  switch (p) {
    case SYMBOL_BID: return S_bid;
    case SYMBOL_ASK: return S_ask;
    case SYMBOL_POINT: return 0.01;
    case SYMBOL_TRADE_TICK_SIZE: return 0.01;
    case SYMBOL_TRADE_TICK_VALUE: return 0.01 * S_contract / S_eurusd;
    case SYMBOL_VOLUME_MIN: return 0.01;
    case SYMBOL_VOLUME_MAX: return 100.0;
    case SYMBOL_VOLUME_STEP: return 0.01;
    case SYMBOL_TRADE_CONTRACT_SIZE: return S_contract;
  }
  return 0;
}
long SymbolInfoInteger(const string &s, ENUM_SYMBOL_INFO_INTEGER p) {
  if (p == SYMBOL_DIGITS) return 2;
  if (p == SYMBOL_SPREAD) return (long)std::lround((S_ask - S_bid) / 0.01);
  return 0;
}
bool SymbolInfoTick(const string &s, MqlTick &t) {
  t.time = S_now;
  t.bid = S_bid;
  t.ask = S_ask;
  t.last = S_bid;
  t.volume = 1;
  t.time_msc = S_now * 1000;
  t.flags = 6;
  t.volume_real = 1;
  return true;
}
static double posProfit(const SimPos &p) {
  double px = (p.type == 0) ? S_bid : S_ask;
  double d = (p.type == 0) ? px - p.open : p.open - px;
  return d * S_contract * p.vol / S_eurusd;
}
static double marginOf(double price, double vol) { return price * S_contract * vol / S_leverage / S_eurusd; }
static double equity() {
  double e = S_balance;
  for (auto &p : P) e += posProfit(p);
  return e;
}
static double marginUsed() {
  double m = 0;
  for (auto &p : P) m += marginOf(p.open, p.vol);
  return m;
}
double AccountInfoDouble(ENUM_ACCOUNT_INFO_DOUBLE p) {
  switch (p) {
    case ACCOUNT_BALANCE: return S_balance;
    case ACCOUNT_EQUITY: return equity();
    case ACCOUNT_MARGIN: return marginUsed();
    case ACCOUNT_MARGIN_FREE: return equity() - marginUsed();
    case ACCOUNT_MARGIN_LEVEL: return marginUsed() > 0 ? 100 * equity() / marginUsed() : 0;
  }
  return 0;
}
long AccountInfoInteger(ENUM_ACCOUNT_INFO_INTEGER p) {
  if (p == ACCOUNT_LOGIN) return 123456;
  if (p == ACCOUNT_MARGIN_MODE) return ACCOUNT_MARGIN_MODE_RETAIL_HEDGING;
  if (p == ACCOUNT_LEVERAGE) return 20;
  return 1;
}
string AccountInfoString(ENUM_ACCOUNT_INFO_STRING p) { return p == ACCOUNT_CURRENCY ? "EUR" : "Sim"; }

datetime iTime(const string &s, ENUM_TIMEFRAMES tf, int shift) {
  if (shift == 0) return bucketStart(tf, S_now);
  const MqlRates *b;
  int m;
  completedList(tf, b, m);
  if (shift > m) return 0;
  return b[m - shift].time;
}
int CopyRates(const string &s, ENUM_TIMEFRAMES tf, int start, int count, DynArr<MqlRates> &out) {
  if (start < 1) ShimFail("CopyRates con start_pos 0 non simulato");
  const MqlRates *b;
  int m;
  if (s != "XAUUSD") {
    OtherSym *o = findOther(s);
    if (!o) ShimFail("CopyRates su simbolo inesistente");
    otherCompleted(*o, tf, b, m);
  } else
    completedList(tf, b, m);
  int last = m - start;          // indice della barra con shift = start
  int first = last - count + 1;
  if (first < 0) first = 0;
  if (last < first) {
    out.v.clear();
    return 0;
  }
  out.v.assign(b + first, b + last + 1);
  return (int)out.v.size();
}
int CopyRates(const string &s, ENUM_TIMEFRAMES tf, datetime from, datetime to, DynArr<MqlRates> &out) {
  const MqlRates *b;
  int m;
  if (s != "XAUUSD") {
    OtherSym *o = findOther(s);
    if (!o) ShimFail("CopyRates su simbolo inesistente");
    otherCompleted(*o, tf, b, m);
  } else
    completedList(tf, b, m);
  out.v.clear();
  for (int i = 0; i < m; i++)
    if (b[i].time >= from && b[i].time <= to) out.v.push_back(b[i]);
  return (int)out.v.size();
}
bool OrderCalcProfit(ENUM_ORDER_TYPE t, const string &s, double vol, double open, double close, double &profit) {
  double d = (t == ORDER_TYPE_BUY) ? close - open : open - close;
  profit = d * S_contract * vol / S_eurusd;
  return true;
}
bool OrderCalcMargin(ENUM_ORDER_TYPE t, const string &s, double vol, double price, double &margin) {
  margin = marginOf(price, vol);
  return true;
}

// ---------------------------------------------------------------- posizioni, ordini, storico
int PositionsTotal() { return (int)P.size(); }
ulong PositionGetTicket(int i) {
  if (i < 0 || i >= (int)P.size()) return 0;
  selPos = i;
  return P[i].ticket;
}
bool PositionSelectByTicket(ulong t) {
  for (int i = 0; i < (int)P.size(); i++)
    if (P[i].ticket == t) {
      selPos = i;
      return true;
    }
  return false;
}
static SimPos &curPos() {
  if (selPos < 0 || selPos >= (int)P.size()) ShimFail("nessuna posizione selezionata");
  return P[selPos];
}
long PositionGetInteger(ENUM_POSITION_PROPERTY_INTEGER p) {
  SimPos &x = curPos();
  switch (p) {
    case POSITION_TICKET: return (long)x.ticket;
    case POSITION_TIME: return x.time;
    case POSITION_TYPE: return x.type;
    case POSITION_MAGIC: return (long)x.magic;
    case POSITION_IDENTIFIER: return x.id;
  }
  return 0;
}
double PositionGetDouble(ENUM_POSITION_PROPERTY_DOUBLE p) {
  SimPos &x = curPos();
  switch (p) {
    case POSITION_VOLUME: return x.vol;
    case POSITION_PRICE_OPEN: return x.open;
    case POSITION_SL: return x.sl;
    case POSITION_TP: return x.tp;
    case POSITION_PRICE_CURRENT: return x.type == 0 ? S_bid : S_ask;
    case POSITION_PROFIT: return posProfit(x);
    case POSITION_SWAP: return 0;
  }
  return 0;
}
string PositionGetString(ENUM_POSITION_PROPERTY_STRING p) {
  SimPos &x = curPos();
  return p == POSITION_SYMBOL ? "XAUUSD" : x.comment;
}
int OrdersTotal() { return (int)O.size(); }
ulong OrderGetTicket(int i) {
  if (i < 0 || i >= (int)O.size()) return 0;
  selOrd = i;
  return O[i].ticket;
}
bool OrderSelect(ulong t) {
  for (int i = 0; i < (int)O.size(); i++)
    if (O[i].ticket == t) {
      selOrd = i;
      return true;
    }
  return false;
}
static SimOrd &curOrd() {
  if (selOrd < 0 || selOrd >= (int)O.size()) ShimFail("nessun ordine selezionato");
  return O[selOrd];
}
long OrderGetInteger(ENUM_ORDER_PROPERTY_INTEGER p) {
  SimOrd &x = curOrd();
  switch (p) {
    case ORDER_TICKET: return (long)x.ticket;
    case ORDER_TIME_SETUP: return x.setup;
    case ORDER_TYPE: return x.type;
    case ORDER_MAGIC: return (long)x.magic;
  }
  return 0;
}
double OrderGetDouble(ENUM_ORDER_PROPERTY_DOUBLE p) {
  SimOrd &x = curOrd();
  switch (p) {
    case ORDER_VOLUME_CURRENT: return x.vol;
    case ORDER_PRICE_OPEN: return x.price;
    case ORDER_SL: return x.sl;
    case ORDER_TP: return x.tp;
  }
  return 0;
}
string OrderGetString(ENUM_ORDER_PROPERTY_STRING p) { return p == ORDER_SYMBOL ? "XAUUSD" : curOrd().comment; }
bool HistorySelect(datetime from, datetime to) {
  H.clear();
  for (int i = 0; i < (int)D.size(); i++)
    if (D[i].time >= from && D[i].time <= to) H.push_back(i);
  return true;
}
bool HistorySelectByPosition(long id) {
  H.clear();
  for (int i = 0; i < (int)D.size(); i++)
    if (D[i].posid == id) H.push_back(i);
  return true;
}
int HistoryDealsTotal() { return (int)H.size(); }
ulong HistoryDealGetTicket(int i) {
  if (i < 0 || i >= (int)H.size()) return 0;
  return D[H[i]].ticket;
}
static SimDeal *dealBy(ulong t) {
  for (auto &d : D)
    if (d.ticket == t) return &d;
  return nullptr;
}
bool HistoryDealSelect(ulong t) { return dealBy(t) != nullptr; }
long HistoryDealGetInteger(ulong t, ENUM_DEAL_PROPERTY_INTEGER p) {
  SimDeal *d = dealBy(t);
  if (!d) ShimFail("deal inesistente", (long)t);
  switch (p) {
    case DEAL_TICKET: return (long)d->ticket;
    case DEAL_ORDER: return (long)d->order;
    case DEAL_TIME: return d->time;
    case DEAL_TYPE: return d->type;
    case DEAL_ENTRY: return d->entry;
    case DEAL_MAGIC: return (long)d->magic;
    case DEAL_POSITION_ID: return d->posid;
  }
  return 0;
}
double HistoryDealGetDouble(ulong t, ENUM_DEAL_PROPERTY_DOUBLE p) {
  SimDeal *d = dealBy(t);
  if (!d) ShimFail("deal inesistente", (long)t);
  switch (p) {
    case DEAL_VOLUME: return d->vol;
    case DEAL_PRICE: return d->price;
    case DEAL_COMMISSION: return d->comm;
    case DEAL_SWAP: return d->swap;
    case DEAL_PROFIT: return d->profit;
    case DEAL_FEE: return d->fee;
  }
  return 0;
}
string HistoryDealGetString(ulong t, ENUM_DEAL_PROPERTY_STRING p) {
  SimDeal *d = dealBy(t);
  if (!d) ShimFail("deal inesistente", (long)t);
  return p == DEAL_SYMBOL ? "XAUUSD" : d->comment;
}
static void queueTx(ulong deal, long pos) {
  MqlTradeTransaction t;
  t.deal = deal;
  t.order = 0;
  t.symbol = "XAUUSD";
  t.type = TRADE_TRANSACTION_DEAL_ADD;
  t.position = (ulong)pos;
  t.price = 0;
  t.volume = 0;
  TQ.push_back(t);
}
static ulong addDeal(int type, int entry, ulong magic, long pos, double vol, double price, double profit, const string &cmt) {
  SimDeal d;
  d.ticket = nextDeal++;
  d.order = 0;
  d.time = S_now;
  d.type = type;
  d.entry = entry;
  d.magic = magic;
  d.posid = pos;
  d.vol = vol;
  d.price = price;
  d.comm = -S_commSide * vol / S_eurusd;
  d.swap = 0;
  d.profit = profit;
  d.fee = 0;
  d.comment = cmt;
  D.push_back(d);
  S_balance += profit + d.comm;
  queueTx(d.ticket, pos);
  return d.ticket;
}

// ---------------------------------------------------------------- GV, file, varie
bool GlobalVariableCheck(const string &n) { return GV.count(n) > 0; }
double GlobalVariableGet(const string &n) { return GV.count(n) ? GV[n] : 0.0; }
datetime GlobalVariableSet(const string &n, double v) {
  GV[n] = v;
  return S_now;
}
bool GlobalVariableDel(const string &n) { return GV.erase(n) > 0; }

struct SimFile { std::fstream f; string path; };
static std::map<int, SimFile *> FH;
static int nextFH = 1;
static string simPath(const string &name) { return "simfiles/" + name; }
int FileOpen(const string &name, int flags, short, uint) {
  string p = simPath(name);
  std::ios::openmode m = std::ios::binary;
  bool rd = flags & FILE_READ, wr = flags & FILE_WRITE;
  if (rd && !wr) {
    std::ifstream t(p);
    if (!t.good()) return INVALID_HANDLE;
    m |= std::ios::in;
  } else if (wr && !rd)
    m |= std::ios::out | std::ios::trunc;
  else {
    std::ofstream touch(p, std::ios::app);
    m |= std::ios::in | std::ios::out;
  }
  SimFile *sf = new SimFile();
  sf->path = p;
  sf->f.open(p, m);
  if (!sf->f.is_open()) {
    delete sf;
    return INVALID_HANDLE;
  }
  int h = nextFH++;
  FH[h] = sf;
  return h;
}
static SimFile *fh(int h) {
  if (!FH.count(h)) ShimFail("handle file non valido", h);
  return FH[h];
}
uint FileWriteString(int h, const string &s, int) {
  SimFile *f = fh(h);
  f->f.write(s.data(), (std::streamsize)s.size());
  return (uint)s.size();
}
string FileReadString(int h, int) {
  SimFile *f = fh(h);
  string l;
  std::getline(f->f, l);
  if (!l.empty() && l.back() == '\r') l.pop_back();
  return l;
}
bool FileIsEnding(int h) {
  SimFile *f = fh(h);
  return f->f.peek() == EOF;
}
void FileClose(int h) {
  SimFile *f = fh(h);
  f->f.close();
  delete f;
  FH.erase(h);
}
ulong FileSize(int h) {
  SimFile *f = fh(h);
  std::ifstream t(f->path, std::ios::binary | std::ios::ate);
  return (ulong)t.tellg();
}
bool FileSeek(int h, long off, ENUM_FILE_POSITION o) {
  SimFile *f = fh(h);
  f->f.clear();
  f->f.seekp(off, o == SEEK_END_POS ? std::ios::end : std::ios::beg);
  return true;
}
bool FileIsExist(const string &name, int) {
  std::ifstream t(simPath(name));
  return t.good();
}
static int S_push = 0;
bool SendNotification(const string &s) {
  if (S_tester) ShimFail("SendNotification chiamata nel tester");
  S_push++;
  return true;
}
bool EventSetTimer(int) {
  S_timer = true;
  return true;
}
void EventKillTimer() { S_timer = false; }
int GetLastError() { return S_lastErr; }
void ResetLastError() { S_lastErr = 0; }
int WebRequest(const string &, const string &, const string &, int, const DynArr<char> &, DynArr<char> &, string &) {
  if (S_tester) ShimFail("WebRequest chiamata nel tester (in MT5 non funziona)");
  S_lastErr = 4014;
  return -1;
}
int CalendarValueHistory(DynArr<MqlCalendarValue> &v, datetime, datetime, const string &, const string &) {
  if (S_tester) ShimFail("Calendario chiamato nel tester");
  v.v.clear();
  return 0;
}
bool CalendarEventById(ulong, MqlCalendarEvent &) { return false; }
bool MarketBookAdd(const string &) { return false; }
bool MarketBookRelease(const string &) { return true; }
bool MarketBookGet(const string &, DynArr<MqlBookInfo> &b) {
  b.v.clear();
  return false;
}
double TesterStatistics(ENUM_STATISTICS s) {
  if (s == STAT_EQUITY_DDREL_PERCENT) return S_maxDDpct;
  if (s == STAT_PROFIT) return S_balance;
  return 0;
}

// ---------------------------------------------------------------- CTrade
static bool volOk(double v) { return v >= 0.01 - 1e-9 && std::fabs(v * 100 - std::round(v * 100)) < 1e-6; }
static bool openPos(CTrade &t, int type, double vol, double sl, double tp, const string &cmt, ulong ticket) {
  double px = type == 0 ? S_ask : S_bid;
  if (!volOk(vol)) {
    t.m_ret = TRADE_RETCODE_INVALID;
    return false;
  }
  if ((type == 0 && ((sl > 0 && sl >= S_bid) || (tp > 0 && tp <= S_bid))) ||
      (type == 1 && ((sl > 0 && sl <= S_ask) || (tp > 0 && tp >= S_ask)))) {
    t.m_ret = TRADE_RETCODE_INVALID_STOPS;
    return false;
  }
  if (equity() - marginUsed() < marginOf(px, vol)) {
    t.m_ret = TRADE_RETCODE_NO_MONEY;
    return false;
  }
  SimPos p{ticket, (long)ticket, type, vol, px, sl, tp, S_now, t.m_magic, cmt, sl, 0, 0};
  S_ghost.push_back({type == 0 ? 1 : -1, px, 4.5});                 // stessa entrata, stop fisso
  S_ghostEA.push_back({type == 0 ? 1 : -1, px, std::fabs(px - sl)}); // stessa entrata, stop dell'EA
  P.push_back(p);
  t.m_deal = addDeal(type, DEAL_ENTRY_IN, t.m_magic, (long)ticket, vol, px, 0.0, cmt);
  t.m_order = ticket;
  t.m_price = px;
  t.m_ret = TRADE_RETCODE_DONE;
  return true;
}
bool CTrade::Buy(double v, const string &, double, double sl, double tp, const string &c) { return openPos(*this, 0, v, sl, tp, c, nextTicket++); }
bool CTrade::Sell(double v, const string &, double, double sl, double tp, const string &c) { return openPos(*this, 1, v, sl, tp, c, nextTicket++); }
static bool placeLimit(CTrade &t, int type, double v, double price, double sl, double tp, const string &c) {
  if (!volOk(v) || (type == ORDER_TYPE_BUY_LIMIT && price >= S_ask) || (type == ORDER_TYPE_SELL_LIMIT && price <= S_bid)) {
    t.m_ret = TRADE_RETCODE_INVALID;
    return false;
  }
  SimOrd o{nextTicket++, type, v, price, sl, tp, S_now, t.m_magic, c};
  O.push_back(o);
  t.m_order = o.ticket;
  t.m_deal = 0;
  t.m_ret = TRADE_RETCODE_PLACED;
  return true;
}
bool CTrade::BuyLimit(double v, double price, const string &, double sl, double tp, ENUM_ORDER_TYPE_TIME, datetime, const string &c) {
  return placeLimit(*this, ORDER_TYPE_BUY_LIMIT, v, price, sl, tp, c);
}
bool CTrade::SellLimit(double v, double price, const string &, double sl, double tp, ENUM_ORDER_TYPE_TIME, datetime, const string &c) {
  return placeLimit(*this, ORDER_TYPE_SELL_LIMIT, v, price, sl, tp, c);
}
bool CTrade::PositionModify(const ulong ticket, const double sl, const double tp) {
  for (auto &p : P)
    if (p.ticket == ticket) {
      if ((p.type == 0 && sl > 0 && sl >= S_bid) || (p.type == 1 && sl > 0 && sl <= S_ask)) {
        m_ret = TRADE_RETCODE_INVALID_STOPS;
        return false;
      }
      p.sl = sl;
      p.tp = tp;
      m_ret = TRADE_RETCODE_DONE;
      return true;
    }
  m_ret = TRADE_RETCODE_INVALID;
  return false;
}
static void closeVol(int idx, double vol, const string &why) {
  SimPos &p = P[idx];
  double px = p.type == 0 ? S_bid : S_ask;
  double d = p.type == 0 ? px - p.open : p.open - px;
  double profit = d * S_contract * vol / S_eurusd;
  addDeal(p.type == 0 ? 1 : 0, DEAL_ENTRY_OUT, p.magic, p.id, vol, px, profit, why);
  p.vol = std::round((p.vol - vol) * 100) / 100;
  if (p.vol < 0.005) {
    double r0 = std::fabs(p.open - p.sl0);
    if (r0 > 0) S_exc.push_back({p.mfe / r0, p.mae / r0});
    P.erase(P.begin() + idx);
    S_closedTrades++;
  }
}
bool CTrade::PositionClose(const ulong ticket, const ulong) {
  for (int i = 0; i < (int)P.size(); i++)
    if (P[i].ticket == ticket) {
      closeVol(i, P[i].vol, "chiusura EA");
      m_ret = TRADE_RETCODE_DONE;
      return true;
    }
  m_ret = TRADE_RETCODE_INVALID;
  return false;
}
bool CTrade::PositionClosePartial(const ulong ticket, const double volume, const ulong) {
  for (int i = 0; i < (int)P.size(); i++)
    if (P[i].ticket == ticket) {
      if (!volOk(volume) || volume >= P[i].vol) {
        m_ret = TRADE_RETCODE_INVALID;
        return false;
      }
      closeVol(i, volume, "parziale");
      m_ret = TRADE_RETCODE_DONE;
      return true;
    }
  m_ret = TRADE_RETCODE_INVALID;
  return false;
}
bool CTrade::OrderDelete(const ulong ticket) {
  for (int i = 0; i < (int)O.size(); i++)
    if (O[i].ticket == ticket) {
      O.erase(O.begin() + i);
      m_ret = TRADE_RETCODE_DONE;
      return true;
    }
  m_ret = TRADE_RETCODE_INVALID;
  return false;
}

// ---------------------------------------------------------------- EA trasformato
#include "ea_cpp.inc"

// ---------------------------------------------------------------- motore dei tick
static void brokerTick() {
  // escursioni (per diagnosi)
  for (auto &p : P) {
    double fav = p.type == 0 ? S_bid - p.open : p.open - S_ask;
    p.mfe = std::max(p.mfe, fav);
    p.mae = std::max(p.mae, -fav);
  }
  // stop e target
  for (int i = (int)P.size() - 1; i >= 0; i--) {
    SimPos &p = P[i];
    if (p.type == 0) {
      if (p.sl > 0 && S_bid <= p.sl) closeVol(i, p.vol, "[sl]");
      else if (p.tp > 0 && S_bid >= p.tp) closeVol(i, p.vol, "[tp]");
    } else {
      if (p.sl > 0 && S_ask >= p.sl) closeVol(i, p.vol, "[sl]");
      else if (p.tp > 0 && S_ask <= p.tp) closeVol(i, p.vol, "[tp]");
    }
  }
  // ordini limite
  for (int i = (int)O.size() - 1; i >= 0; i--) {
    SimOrd o = O[i];
    bool fill = (o.type == ORDER_TYPE_BUY_LIMIT && S_ask <= o.price) || (o.type == ORDER_TYPE_SELL_LIMIT && S_bid >= o.price);
    if (!fill) continue;
    O.erase(O.begin() + i);
    CTrade t;
    t.m_magic = o.magic;
    openPos(t, o.type == ORDER_TYPE_BUY_LIMIT ? 0 : 1, o.vol, o.sl, o.tp, o.comment, o.ticket);
  }
  double e = equity();
  if (e > S_peakEq) S_peakEq = e;
  if (S_peakEq > 0) S_maxDDpct = std::max(S_maxDDpct, 100.0 * (1 - e / S_peakEq));
  if (marginUsed() > 0 && 100 * e / marginUsed() < 50 && !P.empty()) {
    Print("SIM: stop out del broker");
    closeVol(0, P[0].vol, "[so]");
  }
}
static void dispatchTx() {
  int guard = 0;
  while (!TQ.empty()) {
    MqlTradeTransaction t = TQ.front();
    TQ.pop_front();
    MqlTradeRequest rq;
    MqlTradeResult rs;
    OnTradeTransaction(t, rq, rs);
    if (++guard > 10000) ShimFail("troppe transazioni");
  }
}

// ---------------------------------------------------------------- generatore di dati sintetici
static std::mt19937_64 RNG;
static double U() { return std::uniform_real_distribution<double>(0, 1)(RNG); }
static double N01() { return std::normal_distribution<double>(0, 1)(RNG); }
static int S_gmtOff(datetime utc) {
  MqlDateTime d;
  TimeToStruct(utc, d);
  // stessa regola dell'EA: ora legale USA
  auto nthSun = [](int y, int mon, int n) {
    MqlDateTime x = {y, mon, 1, 0, 0, 0, 0, 0};
    datetime f = StructToTime(x);
    MqlDateTime fx;
    TimeToStruct(f, fx);
    int to = (7 - fx.day_of_week) % 7;
    return f + (to + 7 * (n - 1)) * 86400;
  };
  datetime a = nthSun(d.year, 3, 2) + 7 * 3600, b = nthSun(d.year, 11, 1) + 6 * 3600;
  return (utc >= a && utc < b) ? 3 : 2;
}
static bool marketOpen(datetime srv) {
  MqlDateTime d;
  TimeToStruct(srv, d);
  if (d.day_of_week == 0 || d.day_of_week == 6) return false;
  return d.hour >= 1;
}
static double sessMult(double hu) {
  if (hu < 7) return 0.45;
  if (hu < 8) return 1.3;
  if (hu < 12) return 1.0;
  if (hu < 13) return 1.4;
  if (hu < 15) return 1.8;
  if (hu < 17) return 1.3;
  if (hu < 21) return 0.7;
  return 0.4;
}
static int S_regime = 2;
static bool S_rw = false;
static bool S_mh = false;
static double S_flow = 0;
static double S_reinitVC = -1;
static bool S_gvbug = false;  // stato salvato sbagliato come quello delle versioni 1.12-1.14  // a meta' test: OnDeinit + nuovo capitale virtuale + OnInit   // deposito (+) o prelievo (-) a meta' test   // scrive un macro_history.csv di prova   // passeggiata casuale pura (nessun vantaggio possibile)
static double S_volm = 1.0, S_anchor = 4000.0, S_px = 4000.0, S_newsBoost = 0;
static int S_newsLeft = 0, S_newsDir = 0;
static bool isNewsMinute(datetime utc) {
  MqlDateTime d;
  TimeToStruct(utc, d);
  int dstAdj = S_gmtOff(utc) == 3 ? 0 : 1;
  int hm = d.hour * 60 + d.min;
  if (d.day_of_week == 5 && d.day <= 7 && hm == (12 + dstAdj) * 60 + 30) return true;  // NFP
  int ymd = d.year * 10000 + d.mon * 100 + d.day;
  static const int fomc[] = {20260128, 20260318, 20260429, 20260617, 20260729, 20260916, 20261028, 20261209};
  for (int f : fomc)
    if (f == ymd && hm == (18 + dstAdj) * 60) return true;
  return false;
}
static int S_lastDay = -1;
static void dayRegime(datetime utc) {
  int dk = (int)(utc / 86400);
  if (dk == S_lastDay) return;
  S_lastDay = dk;
  if (S_rw) {
    S_regime = 4;
    return;
  }
  if (U() < 0.4) {
    double r = U();
    S_regime = r < 0.28 ? 0 : (r < 0.56 ? 1 : (r < 0.88 ? 2 : 3));
    S_anchor = S_px;
  }
}
struct GenTick { datetime srv; double bid, ask; };
// genera i tick di un minuto (UTC) e la barra M1
static void genMinute(datetime utc, std::vector<GenTick> &ticks) {
  ticks.clear();
  datetime srv = utc + 3600 * S_gmtOff(utc);
  if (!marketOpen(srv)) return;
  dayRegime(utc);
  double hu = (utc % 86400) / 3600.0;
  double sm = sessMult(hu);
  S_volm = 0.985 * S_volm + 0.015 * (0.6 + U());
  double sigma = 0.9 * sm * S_volm * (S_regime == 3 ? 1.8 : 1.0);
  double drift = 0;
  if (S_regime == 0) drift = 0.025 * sigma;
  if (S_regime == 1) drift = -0.025 * sigma;
  if (S_regime == 2) drift = -0.01 * (S_px - S_anchor);
  if (isNewsMinute(utc)) {
    S_newsLeft = 30;
    S_newsDir = U() < 0.5 ? 1 : -1;
    drift += S_newsDir * (3 + 4 * U()) * 0.9;
  }
  if (S_newsLeft > 0) {
    sigma *= 2.5;
    S_newsLeft--;
  }
  // volume legato alla volatilita': raffiche occasionali (breakout, stop run)
  double burst = 1.0;
  if (U() < 0.03) {
    burst = 2.0 + 2.0 * U();
    sigma *= 1.8;
  }
  if (S_newsLeft > 0) burst *= 2.0;
  int k = (int)((6 + 10 * sm * U()) * burst);
  double spread = 0.18 + (hu < 7 ? 0.08 : 0) + ((hu >= 20 && hu < 22) ? 0.25 : 0) + 0.04 * U() + (S_newsLeft > 25 ? 0.5 : 0);
  for (int i = 0; i < k; i++) {
    S_px += drift / k + sigma / std::sqrt((double)k) * N01();
    double b = std::round(S_px * 100) / 100;
    GenTick g{srv + (datetime)(i * 60 / k), b, std::round((b + spread) * 100) / 100};
    ticks.push_back(g);
  }
}

static double S_prevGold = 0;
static void genOthers(datetime utc, const std::vector<GenTick> &ticks);
static void finishM1() {
  if (!M1curOn) return;
  M1.push_back(M1cur);
  aggAdd(M1cur);
  M1curOn = false;
}
static void applyTick(const GenTick &g) {
  datetime mstart = g.srv - (g.srv % 60);
  if (M1curOn && M1cur.time != mstart) finishM1();
  S_now = g.srv;
  S_bid = g.bid;
  S_ask = g.ask;
  if (!M1curOn) {
    M1cur = MqlRates{mstart, g.bid, g.bid, g.bid, g.bid, 0, (int)std::lround((g.ask - g.bid) * 100), 0};
    M1curOn = true;
  }
  M1cur.high = std::max(M1cur.high, g.bid);
  M1cur.low = std::min(M1cur.low, g.bid);
  M1cur.close = g.bid;
  M1cur.tick_volume += 7;
}

static void genOthers(datetime utc, const std::vector<GenTick> &ticks) {
  if (ticks.empty() || OS.empty()) return;
  double gc = ticks.back().bid;
  double gr = (S_prevGold > 0) ? std::log(gc / S_prevGold) : 0.0;
  S_prevGold = gc;
  double u = -0.3 * gr + 0.00012 * N01();  // dollaro: in parte opposto all'oro
  datetime srv = ticks.front().srv - (ticks.front().srv % 60);
  for (auto &o : OS) {
    double r = o.beta * u + o.goldBeta * gr + o.noise * N01();
    double op = o.px;
    o.px *= std::exp(r);
    double hi = std::max(op, o.px) * (1 + std::fabs(N01()) * o.noise * 0.5);
    double lo = std::min(op, o.px) * (1 - std::fabs(N01()) * o.noise * 0.5);
    MqlRates b{srv, op, hi, lo, o.px, 10, 1, 0};
    o.M1.push_back(b);
    otherAgg(o, b);
  }
}

int main(int argc, char **argv) {
  int days = 60, seed = 1;
  string mode = "tester";
  std::vector<std::pair<string, string>> ov;
  for (int i = 1; i < argc; i++) {
    string a = argv[i];
    size_t eq = a.find('=');
    if (eq == string::npos) continue;
    string k = a.substr(0, eq), v = a.substr(eq + 1);
    if (k == "days") days = atoi(v.c_str());
    else if (k == "seed") seed = atoi(v.c_str());
    else if (k == "mode") mode = v;
    else if (k == "balance") S_balance = atof(v.c_str());
    else if (k == "verbose") g_shimQuiet = (v != "1");
    else if (k == "rw") S_rw = (v == "1");
    else if (k == "fx") S_fx = (v == "1");
    else if (k == "flow") S_flow = atof(v.c_str());
    else if (k == "reinitvc") S_reinitVC = atof(v.c_str());
    else if (k == "gvbug") S_gvbug = (v == "1");
    else if (k == "mh") S_mh = (v == "1");
    else ov.push_back({k, v});
  }
  S_tester = (mode == "tester");
  RNG.seed((unsigned long)seed);
  srand(seed);
  for (auto &o : ov) ApplyInput(o.first, o.second);
  if (system("mkdir -p simfiles") != 0) return 4;
  otherInit();
  remove("simfiles/macro_history.csv");
  if (S_mh) {
    std::ofstream f("simfiles/macro_history.csv");
    f << "date,bias,confidence\n";
    double b = 0;
    for (datetime d = 1764547200; d < 1798761600; d += 86400) {  // dic 2025 - dic 2026
      b = std::max(-1.0, std::min(1.0, 0.97 * b + 0.12 * N01()));
      MqlDateTime x;
      TimeToStruct(d, x);
      char line[64];
      snprintf(line, sizeof line, "%04d-%02d-%02d,%.4f,%.4f\n", x.year, x.mon, x.day, b, 0.4 + 0.3 * U());
      f << line;
    }
  }
  datetime start = 1767225600;  // 2026-01-01 00:00 UTC
  int warm = 260;
  std::vector<GenTick> ticks;
  datetime utc = start;
  // storico iniziale (senza EA)
  for (; utc < start + warm * 86400; utc += 60) {
    genMinute(utc, ticks);
    for (auto &g : ticks) applyTick(g);
    genOthers(utc, ticks);
  }
  if (S_gvbug) {
    string p = "XC.123456.260800.";
    GV[p + "vCap"] = 500; GV[p + "vStartBal"] = S_balance * 2; GV[p + "vStartEq"] = S_balance * 2;
    GV[p + "capMode"] = 500; GV[p + "peak"] = 500; GV[p + "flowTo"] = (double)(S_now - 3 * 86400);
  }
  if (OnInit() != INIT_SUCCEEDED) {
    printf("OnInit fallito\n");
    return 3;
  }
  double bal0 = S_balance;
  long nticks = 0;
  datetime end = utc + (datetime)days * 86400;
  datetime lastTimer = 0;
  if (mode == "probe") {
    // ingressi casuali: misura P(+1.5R prima di -1R) del generatore, senza EA
    struct Pr { int dir; double open, R; };
    std::vector<Pr> pr;
    int up = 0, dn = 0;
    double Rp = 4.5;
    for (; utc < end; utc += 60) {
      genMinute(utc, ticks);
      for (size_t i = 0; i < ticks.size(); i++) {
        applyTick(ticks[i]);
        for (int j = (int)pr.size() - 1; j >= 0; j--) {
          double fav = pr[j].dir > 0 ? S_bid - pr[j].open : pr[j].open - S_ask;
          if (fav >= 1.5 * pr[j].R) { up++; pr.erase(pr.begin() + j); }
          else if (fav <= -pr[j].R) { dn++; pr.erase(pr.begin() + j); }
        }
        if (i == 0 && U() < 0.05) pr.push_back({U() < 0.5 ? 1 : -1, 0, Rp}), pr.back().open = pr.back().dir > 0 ? S_ask : S_bid;
      }
    }
    printf("PROBE: +1.5R prima %d, -1R prima %d -> %.1f%%\n", up, dn, 100.0 * up / std::max(1, up + dn));
    return 0;
  }
  datetime flowAt = utc + (datetime)days * 86400 / 2;
  bool flowDone = (S_flow == 0);
  for (; utc < end; utc += 60) {
    if (!flowDone && utc >= flowAt && P.empty()) {
      flowDone = true;
      SimDeal d{nextDeal++, 0, S_now, DEAL_TYPE_BALANCE, DEAL_ENTRY_IN, 0, 0, 0, 0, 0, 0, S_flow, 0, "balance"};
      D.push_back(d);
      S_balance += S_flow;
      queueTx(d.ticket, 0);
      dispatchTx();
      printf("SIM: movimento di cassa %.2f\n", S_flow);
    }
    if (S_reinitVC >= 0 && utc >= flowAt && P.empty() && O.empty()) {
      OnDeinit(0);
      InpVirtualCapital = S_reinitVC;
      S_reinitVC = -1;
      if (OnInit() != INIT_SUCCEEDED) { printf("reinit fallito\n"); return 5; }
      printf("SIM: EA riavviato con capitale virtuale %.0f\n", InpVirtualCapital);
    }
    genMinute(utc, ticks);
    genOthers(utc, ticks);
    for (auto &g : ticks) {
      applyTick(g);
      ghostStep(S_ghost, S_gUp, S_gDn);
      ghostStep(S_ghostEA, S_gUpEA, S_gDnEA);
      brokerTick();
      dispatchTx();
      OnTick();
      dispatchTx();
      nticks++;
    }
    if (S_timer && !ticks.empty() && S_now - lastTimer >= 60) {
      lastTimer = S_now;
      OnTimer();
      dispatchTx();
    }
  }
  {
    int n = (int)S_exc.size(), be = 0, sl = 0, both = 0;
    for (auto &e : S_exc) {
      if (e.first >= 1.5) be++;
      if (e.second >= 0.95) sl++;
    }
    printf("DIAG fantasmi: stop fisso 4.5 -> %.1f%% | stop EA -> %.1f%% (teoria ~38%%)\n", 100.0 * S_gUp / std::max(1, S_gUp + S_gDn), 100.0 * S_gUpEA / std::max(1, S_gUpEA + S_gDnEA));
    if (n) printf("DIAG escursioni: %d trade | MFE>=1.5R %.1f%% | MAE>=0.95R %.1f%%\n", n, 100.0 * be / n, 100.0 * sl / n);
  }
  double crit = OnTester();
  OnDeinit(0);
  int opened = 0, closed = 0, errors = 0;
  for (auto &l : g_shimLog) {
    if (l.find("APERTO") != string::npos) opened++;
    if (l.find("CHIUSO [") != string::npos) closed++;
  }
  printf("SIM %s seed=%d giorni=%d tick=%ld | saldo %.2f -> %.2f EUR | DD max %.1f%% | aperti %d chiusi %d | posizioni ancora aperte %zu | OnTester %.3f | push %d\n",
         mode.c_str(), seed, days, nticks, bal0, S_balance, S_maxDDpct, opened, closed, P.size(), crit, S_push);
  return 0;
}
