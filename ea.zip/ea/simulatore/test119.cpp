#define main sim_main
#include "sim.cpp"
#undef main
#include <fstream>
#include <sstream>
static datetime U(int y,int mo,int d,int h,int mi){ MqlDateTime t; t.year=y; t.mon=mo; t.day=d; t.hour=h; t.min=mi; t.sec=0; return StructToTime(t); }
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-66s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
int main(int argc,char**argv){
  g_isTester=true; g_gmtOffset=0;
  int H=(int)CALENDAR_IMPORTANCE_HIGH, M=(int)CALENDAR_IMPORTANCE_MODERATE;
  chk("IPC m/m (MT5 in italiano) -> tier 1", TierOf("consumer-price-index-mm | IPC m/m", H)==1);
  chk("IPC m/m anche senza codice evento -> tier 1", TierOf(" | Indice dei Prezzi al Consumo (IPC) m/m", H)==1);
  chk("Libri Paga Non Agricoli -> tier 1", TierOf(" | Libri Paga Non Agricoli", H)==1);
  chk("Decisione sui Tassi di Interesse della Fed -> tier 1", TierOf(" | Decisione sui Tassi di Interesse della Federal Reserve System (Fed)", H)==1);
  chk("Decisione del Tasso di Interesse della Fed -> tier 1", TierOf(" | Decisione del Tasso di Interesse della Fed", H)==1);
  chk("codice fed-interest-rate-decision -> tier 1", TierOf("fed-interest-rate-decision | xyz", H)==1);
  chk("Conferenza Stampa del FOMC -> tier 1", TierOf(" | Conferenza Stampa del FOMC", H)==1);
  chk("FomcKind: decisione in italiano = 1", FomcKind("Decisione sui Tassi di Interesse della Federal Reserve System (Fed)")==1);
  chk("FomcKind: conferenza stampa FOMC in italiano = 2", FomcKind("Conferenza Stampa del FOMC [fomc-press-conference]")==2);
  chk("FomcKind: verbali FOMC = 0", FomcKind("Verbali del FOMC")==0);
  chk("FomcKind: codice fomc-press-conference = 2", FomcKind("xyz [fomc-press-conference]")==2);
  chk("Discorso di un membro Fed (moderato) -> tier 3", TierOf(" | Discorso del membro del FOMC Waller", M)==3);
  chk("Discorso del Presidente della Fed -> tier 1", TierOf(" | Discorso del Presidente della Fed", H)==1);
  chk("Richieste di sussidi (moderato) -> tier 3", TierOf(" | Richieste Iniziali di Sussidi di Disoccupazione", M)==3);
  chk("CPI m/m in inglese -> tier 1", TierOf(" | CPI m/m", H)==1);
  chk("Core PCE Price Index -> tier 1", TierOf(" | Core PCE Price Index m/m", H)==1);
  chk("ISM (alto, non tier1) -> tier 2", TierOf(" | ISM Manufacturing PMI", H)==2);
  // scenario del 9/11: MT5 da' il CPI come "IPC m/m" (tier 2 col vecchio codice) + GitHub
  g_newsN=0;
  NewsMerge(U(2026,11,10,13,30), 2, "IPC m/m");       // come lo vedeva la 1.18
  std::ifstream f(argv[1]); std::stringstream b; b<<f.rdbuf(); string js=b.str();
  ParseNewsCalendar(js);
  int k=NextTier1Index(U(2026,11,9,16,47));
  chk("dopo GitHub: il CPI del 10/11 13:30 UTC diventa tier 1", k>=0 && g_news[k].utc==U(2026,11,10,13,30));
  if(k>=0) printf("   -> %s %s\n", g_news[k].title.c_str(), TimeToString(g_news[k].utc).c_str());
  // date ufficiali da sole (MT5 e GitHub muti)
  g_newsN=0; BuiltinNewsAdd(DayKey(U(2026,11,9,16,47)));
  k=NextTier1Index(U(2026,11,9,16,47));
  chk("solo date ufficiali: CPI 10/11 13:30 UTC tier 1", k>=0 && g_news[k].utc==U(2026,11,10,13,30));
  string why;
  chk("blocco intraday alle 13:05 UTC del 10/11 (-25 min)", NewsBlocked(ENG_INTRA, U(2026,11,10,13,5), 0, why)); printf("   -> %s\n", why.c_str());
  chk("blocco swing alle 12:05 UTC (-85 min)", NewsBlocked(ENG_SWING, U(2026,11,10,12,5), 0, why));
  chk("libero intraday alle 13:50 UTC (+20 min)", !NewsBlocked(ENG_INTRA, U(2026,11,10,13,50), 0, why));
  // FOMC dicembre 2026 dalle date ufficiali
  g_newsN=0; BuiltinNewsAdd(DayKey(U(2026,12,8,12,0)));
  chk("FOMC 9/12/2026 bloccato fino a +90 min (20:25 UTC)", NewsBlocked(ENG_INTRA, U(2026,12,9,20,25), ST_IN_NEWS, why)); printf("   -> %s\n", why.c_str());
  printf("\nRISULTATO: %d falliti\n", fails);
  return fails?1:0;
}
