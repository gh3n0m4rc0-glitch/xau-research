// test128.cpp - XAU Committee EA 1.28: il mercato come asta (cinque letture dal profilo dei giorni prima)
#include <array>
#include <random>
#include <algorithm>
#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-96s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
static bool has(const std::string&a,const char*b){ return a.find(b)!=std::string::npos; }
static void mkTf(TfData&d,int n,datetime t0,int sec,double px,double range){
  d.n=n; ArrayResize(d.r,n); ArrayResize(d.ema20,n); ArrayResize(d.ema50,n); ArrayResize(d.atr,n);
  for(int i=0;i<n;i++){ d.r[i].time=t0+(datetime)i*sec; d.r[i].open=px; d.r[i].close=px; d.r[i].high=px+range/2; d.r[i].low=px-range/2; d.ema20[i]=px; d.ema50[i]=px; d.atr[i]=range; }
}
static void mkTfE(TfData&d,int n,datetime t0,int sec,double px,double range,int emaDir){ mkTf(d,n,t0,sec,px,range); for(int i=0;i<n;i++) d.ema20[i]=px+emaDir; }
static void zzSet(int sc,int type2,double p2,datetime conf2,double a2){
  g_zz[sc].ok=true; g_zz[sc].n=5; g_zz[sc].t0=380; g_zz[sc].p0=p2+(type2<0?-5:5); g_zz[sc].t1=390; g_zz[sc].p1=p2+(type2<0?25:-25); g_zz[sc].t2=396; g_zz[sc].p2=p2;
  g_zz[sc].type2=type2; g_zz[sc].c2=399; g_zz[sc].nbars=400; g_zz[sc].time2=conf2-3*OndaBarSec(sc); g_zz[sc].conf2=conf2; g_zz[sc].a2=a2; g_zz[sc].legDir=-type2; g_zz[sc].legExt=p2;
}
// area di valore di ieri e dell'altro ieri messe a mano
static void setVA(double val,double vah,double poc,int bars,double val2,double vah2,double poc2,int bars2){
  Profile &p=g_prof[1-g_profCur]; p.valid=true; p.val=val; p.vah=vah; p.poc=poc; p.bars=bars;
  g_ppOk=true; g_ppVal=val2; g_ppVah=vah2; g_ppPoc=poc2; g_ppBars=bars2;
}
// calcolo di riferimento, scritto in modo indipendente: profilo a fasce da una serie di barre
struct RefP{ double poc,vah,val; };
static RefP refProf(const std::vector<std::array<double,3>>&bars,double base,double bin){
  std::vector<double> v(4000,0.0); double tot=0;
  for(auto&b:bars){ int a=(int)floor((b[0]-base)/bin), c=(int)floor((b[1]-base)/bin); for(int i=a;i<=c;i++) v[i]+=b[2]/(c-a+1); tot+=b[2]; }
  int pi=0; for(int i=1;i<4000;i++) if(v[i]>v[pi]) pi=i;
  double acc=v[pi]; int lo=pi,hi=pi;
  while(acc<0.70*tot && (lo>0||hi<3999)){ double up=hi<3999?v[hi+1]:-1, dn=lo>0?v[lo-1]:-1; if(up>=dn){ hi++; acc+=v[hi]; } else { lo--; acc+=v[lo]; } }
  return { base+(pi+0.5)*bin, base+(hi+1)*bin, base+lo*bin };
}
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true; g_minLot=0.01; g_lotStep=0.01; g_lotDigits=2; g_sym="XAUUSD"; g_currency="EUR";
  InpVirtualCapital=0.0; S_balance=3000.0;
  datetime wd=1762214400;                       // martedi' 4 novembre 2025, 00:00
  chk("versione 1.28 o successiva", std::string(EA_VERSION)>="1.28");
  InpOndaTgtMode=0; InpMaxPos=4;   // dalla 1.29: target scelto sui livelli e 6 posizioni; qui restano le regole della 1.28 (test129.cpp prova le nuove)
  chk("regole fisse invariate: rischio base 1%, max 3% a trade, pareggio a 1,5R, R:R 2", fabs(InpRiskPercent-1.0)<1e-9 && fabs(InpMaxRiskPerTrade-3.0)<1e-9 && fabs(InpBE_R-1.5)<1e-9 && fabs(InpMinRR-2.0)<1e-9);
  chk("restano le scelte della 1.27: 20 strategie, quattro scale accese, lettura del mercato accesa", NSTRAT==20 && InpON_M5 && InpON_M15 && InpON_H1 && InpON_H4 && InpIN_TREND2 && InpReadOn && InpReadLearn);
  chk("le letture vecchie non cambiano: due contrarie dimezzano, rischio in piu' spento", InpReadCutN==2 && fabs(InpReadCutMult-0.5)<1e-9 && fabs(InpReadBoostMult-1.0)<1e-9);
  chk("21 letture: le 14 della 1.27 allo stesso posto, piu' le cinque dell'asta", NREAD==21 && RD_D1==0 && RD_FLOW==13 && g_rdName[RD_FLOW]=="volumi" && g_rdName[RD_BAL]=="equilibrio d'asta" &&
      g_rdName[RD_VMIG]=="spostamento del valore" && g_rdName[RD_VACC]=="accettazione fuori dal valore" && g_rdName[RD_VFAIL]=="rottura fallita del valore" && g_rdName[RD_IB]=="rottura del bilancio iniziale");
  chk("...e le due dopo la presa di liquidita'", RD_LCONF==19 && RD_EQL==20 && g_rdName[RD_LCONF]=="conferma dopo la presa di liquidita'" && g_rdName[RD_EQL]=="minimi o massimi allineati");
  chk("le etichette stanno in un intero (21 bit)", NREAD<=30);
  chk("target per scala: M5 2R (scalping), M15, H1 e H4 4R; direzione chiara x1 (spento)", fabs(InpOndaTargetR-2.0)<1e-9 && fabs(InpOndaTargetRM15-4.0)<1e-9 && fabs(InpOndaTargetRH1-4.0)<1e-9 && fabs(InpOndaTargetRH4-4.0)<1e-9 && fabs(InpOndaTargetClearX-1.0)<1e-9);
  chk("OndaTargetR: ogni scala il suo", fabs(OndaTargetR(0,false)-2.0)<1e-9 && fabs(OndaTargetR(1,false)-4.0)<1e-9 && fabs(OndaTargetR(2,true)-4.0)<1e-9 && fabs(OndaTargetR(3,false)-4.0)<1e-9);
  { InpOndaTargetR=1.0; InpOndaTargetRM15=0.5; chk("mai sotto l'R:R minimo (2), anche con un valore sbagliato", fabs(OndaTargetR(0,false)-2.0)<1e-9 && fabs(OndaTargetR(1,true)-2.0)<1e-9); InpOndaTargetR=2.0; InpOndaTargetRM15=4.0;
    InpOndaTargetRH4=50.0; chk("mai oltre 10R", fabs(OndaTargetR(3,false)-10.0)<1e-9); InpOndaTargetRH4=4.0;
    InpOndaTargetClearX=1.5; chk("direzione chiara x1,5: vale per M15, H1, H4 (4R -> 6R), non per M5 e non senza direzione chiara", fabs(OndaTargetR(1,true)-6.0)<1e-9 && fabs(OndaTargetR(2,true)-6.0)<1e-9 && fabs(OndaTargetR(0,true)-2.0)<1e-9 && fabs(OndaTargetR(2,false)-4.0)<1e-9); InpOndaTargetClearX=1.0; }
  chk("di serie: asta accesa, equilibrio da 50% di sovrapposizione, conta sul rischio solo quando e' provata", InpAstaOn && fabs(InpAstaOverlap-0.5)<1e-9 && InpAstaMode==1);
  chk("di serie: fuori dall'equilibrio x0,8, in equilibrio x1,2", fabs(InpAstaOutMult-0.8)<1e-9 && fabs(InpAstaInMult-1.2)<1e-9);
  // ---------- il segnale vero con i target nuovi: stesso caso della prova 1.27 (H1, minimo confermato a 3970, stop 3966, ingresso 4000,2)
  { mkTfE(g_d1,80,wd-80*86400,86400,4000.0,40.0,1); mkTfE(g_h4,300,wd-300*14400,14400,4000.0,20.0,1); mkTfE(g_h1,400,wd-400*3600,3600,4000.0,10.0,1);
    OndaInit(); OndaDayAtr();
    g_ctx.nowUtc=wd+14*3600+60; g_ctx.bid=4000.0; g_ctx.ask=4000.2; g_ctx.spread=0.2; g_ctx.dow=2; S_bid=4000.0; S_ask=4000.2; S_now=g_ctx.nowUtc;
    zzSet(2,-1,3970.0,wd+13*3600,40.0);
    TSignal s; bool ok=S_Onda(s,2);
    chk("H1: stesso ingresso e stesso stop della 1.27 (4000,20 e 3966,00)", ok && s.dir==1 && s.strat==ST_ON_H1 && fabs(s.entry-4000.2)<1e-9 && fabs(s.sl-3966.0)<0.011);
    chk("H1: target a 4R piu' tre tick (4137,03)", ok && fabs(s.tp-(4000.2+4*34.2+0.03))<0.011);
    chk("H1: il testo dell'idea dice 4.0R", ok && has(s.why,"4.0R"));
    InpOndaTargetRH1=2.0; ok=S_Onda(s,2); chk("H1 con il valore vecchio (2): target a 2R come nella 1.27", ok && fabs(s.tp-(4000.2+2*34.2+0.03))<0.011); InpOndaTargetRH1=4.0; }
  // ---------- il profilo: barre contate, e alla giornata nuova "ieri" diventa "l'altro ieri"
  { double bin=1.0; std::vector<std::array<double,3>> d1,d2,d3; std::mt19937 rng(7);
    auto gen=[&](std::vector<std::array<double,3>>&d,double c){ d.clear(); for(int i=0;i<200;i++){ double m=c+(double)((int)(rng()%21)-10); double h=m+(double)(rng()%4), l=m-(double)(rng()%4); d.push_back({l+0.25,h+0.25,(double)(50+rng()%200)}); } };
    gen(d1,4000.0); gen(d2,4010.0); gen(d3,4050.0);
    datetime a1=wd-2*86400, a2=wd-86400, a3=wd;
    g_profCur=0; ProfReset(g_prof[0],a1,4000.0,bin); ProfReset(g_prof[1],0,4000.0,bin); g_ppOk=false; g_ppBars=0;
    for(int i=0;i<200;i++) ProfileFeed(a1,a1+(datetime)i*300,d1[i][0],d1[i][1],d1[i][2]);
    chk("profilo: una barra contata per ogni M5", g_prof[g_profCur].bars==200);
    for(int i=0;i<200;i++) ProfileFeed(a2,a2+(datetime)i*300,d2[i][0],d2[i][1],d2[i][2]);
    RefP r1=refProf(d1,g_prof[1-g_profCur].base,bin);
    chk("giorno 2: 'ieri' e' il giorno 1, uguale al calcolo di riferimento", PrevProfileOk() && fabs(PrevPOC()-r1.poc)<1e-9 && fabs(PrevVAH()-r1.vah)<1e-9 && fabs(PrevVAL()-r1.val)<1e-9 && PrevProfBars()==200);
    chk("giorno 2: l'altro ieri non c'e' ancora", !g_ppOk);
    double v1h=PrevVAH(), v1l=PrevVAL(), p1=PrevPOC();
    for(int i=0;i<150;i++) ProfileFeed(a3,a3+(datetime)i*300,d3[i][0],d3[i][1],d3[i][2]);
    RefP r2=refProf(d2,g_prof[1-g_profCur].base,g_prof[1-g_profCur].bin);   // il giorno nuovo usa la fascia dell'EA (ProfileBin)
    chk("giorno 3: 'ieri' e' il giorno 2, uguale al calcolo di riferimento", fabs(PrevPOC()-r2.poc)<1e-9 && fabs(PrevVAH()-r2.vah)<1e-9 && fabs(PrevVAL()-r2.val)<1e-9);
    chk("giorno 3: 'l'altro ieri' e' il giorno 1, con le sue barre", g_ppOk && fabs(g_ppVah-v1h)<1e-9 && fabs(g_ppVal-v1l)<1e-9 && fabs(g_ppPoc-p1)<1e-9 && g_ppBars==200);
    chk("giorno 3: il profilo di oggi riparte da zero", g_prof[g_profCur].bars==150 && g_prof[g_profCur].anchor==a3); }
  // ---------- regime: equilibrio, transizione, squilibrio
  { RdInit(); InpAstaOn=true; InpAstaOverlap=0.5; g_ibDir=0; g_m15.n=0; S_now=wd+10*3600; g_ctx.nowUtc=S_now;
    double A=10.0;
    setVA(100,110,105,200, 102,112,107,200); RdAuction(A,105.0);
    chk("aree 100-110 e 102-112: sovrapposte 80% -> equilibrio", g_asReg==0 && fabs(g_asOv-0.8)<1e-9 && g_rdDir[RD_BAL]==1);
    chk("riga del pannello: equilibrio con la percentuale", has(g_asLine,"Asta: equilibrio (aree di valore sovrapposte 80%)"));
    setVA(100,110,105,200, 107,117,112,200); RdAuction(A,105.0);
    chk("aree 100-110 e 107-117: sovrapposte 30% -> transizione, fuori dall'equilibrio", g_asReg==1 && fabs(g_asOv-0.3)<1e-9 && g_rdDir[RD_BAL]==-1 && has(g_asLine,"transizione"));
    setVA(100,110,105,200, 120,130,125,200); RdAuction(A,105.0);
    chk("aree 100-110 e 120-130: staccate -> squilibrio", g_asReg==2 && g_asOv<0.0 && g_rdDir[RD_BAL]==-1 && has(g_asLine,"squilibrio") && has(g_asLine,"sovrapposte 0%"));
    setVA(100,110,105,200, 103,105,104,200); RdAuction(A,105.0);
    chk("area stretta dentro quella larga (103-105 dentro 100-110): sovrapposizione 100% -> equilibrio", g_asReg==0 && fabs(g_asOv-1.0)<1e-9);
    setVA(100,110,105,200, 105,115,110,200); RdAuction(A,105.0);
    chk("esattamente 50%: equilibrio (la soglia e' compresa)", g_asReg==0 && fabs(g_asOv-0.5)<1e-9);
    InpAstaOverlap=0.7; RdAuction(A,105.0); chk("soglia alzata a 70%: lo stesso caso diventa transizione", g_asReg==1 && g_rdDir[RD_BAL]==-1); InpAstaOverlap=0.5;
    setVA(100,110,105,99, 102,112,107,200); RdAuction(A,105.0);
    chk("ieri giornata corta (99 barre M5): il regime non si legge, lettura neutra", g_asReg==-1 && g_rdDir[RD_BAL]==0 && g_rdDir[RD_VMIG]==0 && has(g_asLine,"regime non leggibile"));
    setVA(100,110,105,200, 102,112,107,50); RdAuction(A,105.0);
    chk("altro ieri giornata corta: lo stesso", g_asReg==-1 && g_rdDir[RD_BAL]==0);
    setVA(100,110,105,200, 102,112,107,200); g_ppOk=false; RdAuction(A,105.0);
    chk("manca l'altro ieri: lo stesso", g_asReg==-1 && g_rdDir[RD_BAL]==0);
    setVA(100,110,105,200, 102,112,107,200); g_prof[1-g_profCur].valid=false; RdAuction(A,105.0);
    chk("manca il profilo di ieri: nessuna lettura d'asta e nessuna riga", g_asReg==-1 && g_rdDir[RD_BAL]==0 && g_asLine=="" && AstaPanel()=="");
    setVA(100,110,105,200, 102,112,107,200); InpAstaOn=false; RdAuction(A,105.0);
    chk("asta spenta: tutte neutre, nessuna riga", g_rdDir[RD_BAL]==0 && g_rdDir[RD_VMIG]==0 && g_rdDir[RD_VACC]==0 && g_rdDir[RD_VFAIL]==0 && g_rdDir[RD_IB]==0 && g_asLine==""); InpAstaOn=true;
    RdAuction(0.0,105.0); chk("senza escursione media: neutre", g_rdDir[RD_BAL]==0 && g_asLine=="");
    // spostamento del valore: il prezzo piu' scambiato di ieri contro quello dell'altro ieri, soglia 0,10 escursioni
    setVA(100,110,105,200, 98,108,103,200); RdAuction(A,105.0);
    chk("valore salito di 2 (0,2 escursioni): a favore dei rialzi", g_rdDir[RD_VMIG]==1 && has(g_asLine,"valore in salita"));
    setVA(100,110,105,200, 102,112,107,200); RdAuction(A,105.0);
    chk("valore sceso di 2: a favore dei ribassi", g_rdDir[RD_VMIG]==-1 && has(g_asLine,"valore in discesa"));
    setVA(100,110,105,200, 100,110,104.5,200); RdAuction(A,105.0);
    chk("valore spostato di 0,5 (0,05 escursioni): fermo, neutra", g_rdDir[RD_VMIG]==0 && has(g_asLine,"valore fermo"));
    setVA(100,110,105,200, 100,110,104.0,200); RdAuction(A,105.0);
    chk("esattamente 0,10 escursioni: conta", g_rdDir[RD_VMIG]==1); }
  // ---------- accettazione e rottura fallita rispetto all'area di valore di ieri (M15)
  { RdInit(); double A=10.0; S_now=wd+10*3600; g_ctx.nowUtc=S_now; g_ibDir=0;
    setVA(100,110,105,200, 102,112,107,200);
    // 40 barre M15 da mezzanotte: tutte dentro il valore
    auto day=[&](){ mkTf(g_m15,40,wd,900,105.0,1.0); };
    day(); RdAuction(A,105.0);
    chk("prezzo e chiusure dentro il valore: nessuna accettazione, nessuna rottura fallita", g_rdDir[RD_VACC]==0 && g_rdDir[RD_VFAIL]==0 && has(g_asLine,"prezzo dentro il valore di ieri (100.00-110.00)"));
    day(); g_m15.r[39].close=111.0; g_m15.r[39].high=111.5; RdAuction(A,111.2);
    chk("una sola chiusura M15 sopra: uscito ma non ancora accettato", g_rdDir[RD_VACC]==0 && has(g_asLine,"sopra il valore di ieri, non ancora accettato"));
    g_m15.r[38].close=110.5; g_m15.r[38].high=111.0; RdAuction(A,111.2);
    chk("due chiusure M15 sopra e prezzo sopra: accettato, a favore dei rialzi", g_rdDir[RD_VACC]==1 && has(g_asLine,"sopra il valore di ieri, accettato"));
    RdAuction(A,109.5); chk("due chiusure sopra ma il prezzo adesso e' rientrato: non accettato", g_rdDir[RD_VACC]==0);
    day(); g_m15.r[38].close=99.0; g_m15.r[39].close=98.5; g_m15.r[39].low=98.0; RdAuction(A,98.4);
    chk("due chiusure M15 sotto e prezzo sotto: accettato, a favore dei ribassi", g_rdDir[RD_VACC]==-1 && has(g_asLine,"sotto il valore di ieri, accettato"));
    // rottura fallita: oggi oltre l'area di almeno 0,10 escursioni (1,0), poi di nuovo dentro
    day(); g_m15.r[20].high=111.0; g_m15.r[20].close=110.6; RdAuction(A,105.0);
    chk("oggi massimo a 111 (1 sopra il valore) e ultima chiusura dentro: rottura fallita, a favore dei ribassi", g_rdDir[RD_VFAIL]==-1 && g_rdDir[RD_VACC]==0 && has(g_asLine,"uscita sopra il valore fallita"));
    day(); g_m15.r[20].high=110.9; RdAuction(A,105.0);
    chk("massimo a 110,9 (meno di 0,10 escursioni oltre): non conta", g_rdDir[RD_VFAIL]==0);
    day(); g_m15.r[20].low=99.0; RdAuction(A,105.0);
    chk("minimo a 99 e rientro: rottura fallita al ribasso, a favore dei rialzi", g_rdDir[RD_VFAIL]==1 && has(g_asLine,"uscita sotto il valore fallita"));
    day(); g_m15.r[10].low=99.0; g_m15.r[20].high=111.0; RdAuction(A,105.0);
    chk("uscito da tutte e due le parti: neutra", g_rdDir[RD_VFAIL]==0);
    day(); g_m15.r[20].high=111.0; RdAuction(A,110.5);
    chk("prezzo di nuovo fuori in questo momento: non e' (ancora) una rottura fallita", g_rdDir[RD_VFAIL]==0);
    // le barre di ieri non contano: stessa uscita ma il giorno prima
    mkTf(g_m15,40,wd-86400+14*3600,900,105.0,1.0); g_m15.r[5].high=111.0; RdAuction(A,105.0);
    chk("l'uscita di ieri sera non conta: si guarda solo oggi", g_rdDir[RD_VFAIL]==0); }
  // ---------- bilancio iniziale: prima mezz'ora di New York, chiusura M5 oltre
  { RdInit(); g_ctx.nyOpen=14.5; datetime op=wd+14*3600+1800;                     // apertura 14:30 UTC
    auto m5=[&](int nAfter){ mkTf(g_m5,40+nAfter,op-40*300,300,4000.0,1.0); for(int i=40;i<46 && i<g_m5.n;i++){ g_m5.r[i].high=4003.0; g_m5.r[i].low=3998.0; } };
    m5(8); g_m5.r[47].close=4003.5; g_m5.r[47].high=4003.6; g_ctx.nowUtc=op+8*300; RdIbOnM5();
    chk("chiusura M5 sopra il massimo della prima mezz'ora (4003): rotto al rialzo", g_ibDir==1 && fabs(g_ibHi-4003.0)<1e-9 && fabs(g_ibLo-3998.0)<1e-9);
    m5(8); g_m5.r[47].close=3997.5; g_m5.r[47].low=3997.0; RdIbOnM5(); chk("chiusura M5 sotto il minimo (3998): rotto al ribasso", g_ibDir==-1);
    m5(8); g_m5.r[47].high=4003.4; g_m5.r[47].close=4002.0; RdIbOnM5(); chk("solo l'ombra sopra, chiusura dentro: niente", g_ibDir==0);
    m5(8); g_m5.r[46].close=4004.0; g_m5.r[47].close=4001.0; RdIbOnM5(); chk("rotto e poi rientrato: adesso niente (conta l'ultima chiusura)", g_ibDir==0);
    m5(6); g_m5.r[45].close=4002.9; g_ctx.nowUtc=op+6*300; RdIbOnM5(); chk("a 30 minuti dall'apertura e' presto (si legge da 35)", g_ibDir==0);
    m5(8); g_m5.r[47].close=4003.5; g_ctx.nowUtc=op+4*3600+60; RdIbOnM5(); chk("dopo 4 ore dall'apertura non vale piu'", g_ibDir==0);
    mkTf(g_m5,40,op+1200,300,4005.0,1.0); g_ctx.nowUtc=op+1200+40*300; RdIbOnM5(); chk("niente barre all'apertura (dati mancanti): oggi non si legge", g_ibDir==0);
    // passa nelle letture
    m5(8); g_m5.r[47].close=4003.5; g_ctx.nowUtc=op+8*300; S_now=g_ctx.nowUtc; RdIbOnM5(); setVA(3990,4010,4000,200, 3992,4012,4001,200); g_m15.n=0; RdAuction(40.0,4003.5);
    chk("la rottura entra tra le letture e nella riga del pannello", g_rdDir[RD_IB]==1 && has(g_asLine,"bilancio iniziale rotto al rialzo")); }
  // ---------- conferma dopo la presa di liquidita' (M15)
  { RdInit(); g_ctx.atrM15=2.0; g_liqDir=1; g_lcDir=0;
    auto bar=[&](int sh,double o,double h,double l,double c){ int i=g_m15.n-1-sh; g_m15.r[i].open=o; g_m15.r[i].high=h; g_m15.r[i].low=l; g_m15.r[i].close=c; };
    auto flat=[&](){ mkTf(g_m15,20,wd,900,100.0,0.2); };
    flat(); RdLiqConfOnM15(); chk("candele piatte dopo la presa: nessuna conferma", g_lcDir==0);
    flat(); bar(1,101.0,101.2,99.8,100.0); bar(0,99.9,101.6,99.8,101.5); RdLiqConfOnM15();
    chk("engulfing al rialzo dopo un minimo preso: conferma", g_lcDir==1 && g_lcName=="engulfing");
    g_lcDir=0; flat(); bar(1,101.0,101.2,99.8,100.0); bar(0,100.2,100.9,100.1,100.8); RdLiqConfOnM15();
    chk("candela al rialzo che non copre il corpo della precedente: niente", g_lcDir==0);
    flat(); bar(1,100.0,101.0,99.0,100.1); bar(0,100.1,102.3,100.0,102.2); RdLiqConfOnM15();
    chk("doji e poi candela forte (corpo 91%, ampiezza 2,3 contro media 2,0): conferma", g_lcDir==1 && g_lcName=="doji e candela forte");
    g_lcDir=0; flat(); bar(1,100.0,101.0,99.0,100.1); bar(0,100.1,101.3,100.0,101.2); RdLiqConfOnM15();
    chk("doji e poi candela piccola (ampiezza 1,3 sotto la media): niente", g_lcDir==0);
    flat(); bar(2,102.0,102.2,100.5,100.8); bar(1,100.8,101.6,100.7,101.5); bar(0,101.5,102.6,101.4,102.5); RdLiqConfOnM15();
    chk("due candele al rialzo che insieme chiudono sopra il massimo della candela contraria: conferma", g_lcDir==1 && g_lcName=="due candele oltre la candela contraria");
    g_lcDir=0; flat(); bar(2,102.0,102.2,100.5,100.8); bar(1,100.8,101.6,100.7,101.5); bar(0,101.5,102.1,101.4,102.0); RdLiqConfOnM15();
    chk("due candele che non arrivano oltre il massimo (102,2): niente", g_lcDir==0);
    flat(); bar(1,101.0,101.2,99.8,100.0); bar(0,99.9,101.6,99.8,101.5); g_liqDir=-1; RdLiqConfOnM15();
    chk("stessa figura al rialzo ma la presa era di un massimo (verso ribasso): niente", g_lcDir==0);
    flat(); bar(1,100.0,101.2,99.8,101.0); bar(0,101.1,101.2,99.4,99.5); RdLiqConfOnM15();
    chk("engulfing al ribasso dopo un massimo preso: conferma al ribasso", g_lcDir==-1 && g_lcName=="engulfing");
    flat(); RdLiqConfOnM15(); chk("la conferma resta finche' la presa e' viva", g_lcDir==-1);
    g_liqDir=1; RdLiqConfOnM15(); chk("presa nuova nell'altro verso: la conferma vecchia cade", g_lcDir==0);
    g_lcDir=1; g_liqDir=0; RdLiqConfOnM15(); chk("presa scaduta: la conferma cade", g_lcDir==0 && g_lcName==""); }
  // ---------- minimi e massimi allineati (H1)
  { RdInit(); double A=100.0;                    // tolleranza 3,0
    auto h1=[&](){ mkTf(g_h1,80,wd-80*3600,3600,4000.0,10.0); };   // barre piatte: minimi 3995, massimi 4005, nessun punto di svolta
    h1(); RdEqualOnH1(A); chk("barre piatte: nessun gruppo", g_eqLo==0.0 && g_eqHi==0.0);
    h1(); g_h1.r[40].low=3980.0; g_h1.r[60].low=3981.5; RdEqualOnH1(A);
    chk("due minimi di svolta a 3980 e 3981,5 (entro 3): allineati, livello 3980", fabs(g_eqLo-3980.0)<1e-9 && g_eqHi==0.0);
    h1(); g_h1.r[40].low=3980.0; g_h1.r[60].low=3984.0; RdEqualOnH1(A); chk("minimi a 3980 e 3984 (4 di distanza): non allineati", g_eqLo==0.0);
    h1(); g_h1.r[40].low=3980.0; g_h1.r[60].low=3981.5; g_h1.r[70].low=3970.0; RdEqualOnH1(A);
    chk("gia' presi (una barra dopo e' scesa a 3970): non contano piu'", g_eqLo==0.0);
    h1(); g_h1.r[40].low=3980.0; g_h1.r[41].low=3981.0; RdEqualOnH1(A); chk("due barre vicine non sono due punti di svolta", g_eqLo==0.0);
    h1(); g_h1.r[10].low=3980.0; g_h1.r[60].low=3981.5; RdEqualOnH1(A); chk("un minimo piu' vecchio di 60 barre non conta", g_eqLo==0.0);
    h1(); g_h1.r[40].high=4020.0; g_h1.r[60].high=4021.0; RdEqualOnH1(A); chk("due massimi di svolta a 4020 e 4021: allineati, livello 4021", fabs(g_eqHi-4021.0)<1e-9 && g_eqLo==0.0);
    h1(); g_h1.r[30].low=3960.0; g_h1.r[36].low=3961.0; g_h1.r[50].low=3980.0; g_h1.r[60].low=3981.5; RdEqualOnH1(A);
    chk("due gruppi sotto il prezzo: vale il piu' vicino (3980)", fabs(g_eqLo-3980.0)<1e-9);
    // la lettura: gruppo entro 0,5 escursioni (50) dal prezzo
    for(int k=0;k<NREAD;k++) g_rdDir[k]=0; g_eqLo=3980.0; g_eqHi=0.0; g_liqDir=0; g_lcDir=0; g_prof[1-g_profCur].valid=false;
    auto rd=[&](double px){ g_ctx.bid=px; g_ctx.ask=px; g_rdReady=true; g_d1.n=0; mkTf(g_d1,40,wd-40*86400,86400,4000.0,100.0); RdUpdate(false,false,false); return g_rdDir[RD_EQL]; };
    bool atrOk=fabs(TdAtr()-100.0)<1e-6 || (rd(4000.0),fabs(TdAtr()-100.0)<1e-6);
    chk("(escursione media di prova = 100)", atrOk);
    chk("minimi allineati 20 sotto il prezzo: il prezzo puo' passare a prenderli -> a favore dei ribassi", rd(4000.0)==-1 && has(g_rdNote,"minimi allineati a 3980.00 sotto il prezzo"));
    chk("minimi allineati 60 sotto (oltre mezza escursione): troppo lontani, neutra", rd(4040.0)==0);
    chk("prezzo sceso sotto il gruppo: presi, neutra", rd(3979.0)==0);
    g_eqLo=0.0; g_eqHi=4021.0; chk("massimi allineati 21 sopra il prezzo: a favore dei rialzi", rd(4000.0)==1 && has(g_rdNote,"massimi allineati a 4021.00 sopra il prezzo"));
    g_eqLo=3980.0; chk("gruppi sia sopra sia sotto: neutra", rd(4000.0)==0);
    g_eqLo=0.0; g_eqHi=0.0; g_liqDir=1; g_lcDir=1; g_lcName="engulfing"; rd(4000.0);
    chk("presa confermata: entra tra le letture e nei dettagli del pannello", g_rdDir[RD_LCONF]==1 && has(g_rdNote,"presa confermata (engulfing M15)"));
    g_liqDir=0; rd(4000.0); chk("presa scaduta: la lettura torna neutra", g_rdDir[RD_LCONF]==0); }
  // ---------- etichette: l'equilibrio non ha verso
  { RdInit(); for(int k=0;k<NREAD;k++) g_rdDir[k]=0;
    g_rdDir[RD_BAL]=1; g_rdDir[RD_VMIG]=1; g_rdDir[RD_VFAIL]=-1;
    TSignal s; s.Reset(); s.strat=ST_ON_M15; s.dir=1; RdEval(s);
    chk("acquisto in equilibrio: equilibrio e spostamento a favore, rottura fallita contro", s.rdFav==((1<<RD_BAL)|(1<<RD_VMIG)) && s.rdAg==(1<<RD_VFAIL));
    s.dir=-1; RdEval(s);
    chk("vendita in equilibrio: l'equilibrio resta a favore, le altre si rovesciano", s.rdFav==((1<<RD_BAL)|(1<<RD_VFAIL)) && s.rdAg==(1<<RD_VMIG));
    g_rdDir[RD_BAL]=-1; s.dir=1; RdEval(s); chk("fuori dall'equilibrio: 'contro' per acquisti...", (s.rdAg&(1<<RD_BAL))!=0 && (s.rdFav&(1<<RD_BAL))==0);
    s.dir=-1; RdEval(s); chk("...e per vendite", (s.rdAg&(1<<RD_BAL))!=0 && (s.rdFav&(1<<RD_BAL))==0);
    chk("elenco per il diario con i nomi nuovi", RdList((1<<RD_BAL)|(1<<RD_IB))=="equilibrio d'asta, rottura del bilancio iniziale");
    // l'equilibrio provato non entra nel conto delle letture contrarie (ha il suo effetto a parte)
    for(int k=0;k<NREAD;k++) g_rdDir[k]=0; g_rdDir[RD_BAL]=-1; g_rdDir[RD_VMIG]=-1;
    g_rdState[FAM_ONDA*NREAD+RD_BAL]=RDS_USEFUL; s.dir=1; RdEval(s);
    chk("equilibrio provato e idea fuori: non conta tra le 'letture provate contrarie'", s.rdConf==0 && fabs(ReadRiskMult(s)-1.0)<1e-9);
    g_rdState[FAM_ONDA*NREAD+RD_VMIG]=RDS_USEFUL; RdEval(s); chk("le altre letture d'asta, se provate, contano come le vecchie", s.rdConf==-1);
    g_rdState[FAM_ONDA*NREAD+RD_VMIG]=RDS_INVERSE; RdEval(s); chk("provata al contrario: conta rovesciata", s.rdConf==1);
    // pannello: l'equilibrio non e' ne' rialzo ne' ribasso
    for(int k=0;k<NREAD;k++) g_rdDir[k]=0; g_rdDir[RD_BAL]=1; g_rdDir[RD_D1]=1; g_rdDir[RD_VACC]=-1;
    chk("pannello: 1 lettura al rialzo e 1 al ribasso (l'equilibrio non si conta)", has(RdPanelPart(0),"1 letture al rialzo, 1 al ribasso")); }
  // ---------- effetto sul rischio
  { RdInit(); TSignal in; in.Reset(); in.strat=ST_ON_M15; in.dir=1; in.rdFav=(1<<RD_BAL); TSignal out; out.Reset(); out.strat=ST_ON_M15; out.dir=1; out.rdAg=(1<<RD_BAL);
    TSignal none; none.Reset(); none.strat=ST_ON_M15; none.dir=1; TSignal mf; mf.Reset(); mf.strat=ST_IN_TREND; mf.dir=1; mf.rdAg=(1<<RD_BAL);
    InpAstaMode=1; InpAstaOutMult=0.8; InpAstaInMult=1.2;
    chk("di serie, lettura ancora in prova: il rischio non cambia", fabs(AstaRiskMult(in)-1.0)<1e-9 && fabs(AstaRiskMult(out)-1.0)<1e-9);
    g_rdState[FAM_ONDA*NREAD+RD_BAL]=RDS_USEFUL;
    chk("provata per i ritracciamenti: in equilibrio x1,2, fuori x0,8", fabs(AstaRiskMult(in)-1.2)<1e-9 && fabs(AstaRiskMult(out)-0.8)<1e-9);
    chk("regime non leggibile: x1", fabs(AstaRiskMult(none)-1.0)<1e-9);
    chk("provata per i ritracciamenti ma non per i movimenti forti: quelli restano x1", fabs(AstaRiskMult(mf)-1.0)<1e-9);
    g_rdState[FAM_ONDA*NREAD+RD_BAL]=RDS_INVERSE;
    chk("il bot misura il contrario: la regola si spegne da sola", fabs(AstaRiskMult(in)-1.0)<1e-9 && fabs(AstaRiskMult(out)-1.0)<1e-9);
    InpAstaMode=2; chk("da subito (2), ma misurata al contrario: resta spenta", fabs(AstaRiskMult(out)-1.0)<1e-9);
    g_rdState[FAM_ONDA*NREAD+RD_BAL]=RDS_TEST;
    chk("da subito (2), in prova: vale per tutte le famiglie", fabs(AstaRiskMult(in)-1.2)<1e-9 && fabs(AstaRiskMult(out)-0.8)<1e-9 && fabs(AstaRiskMult(mf)-0.8)<1e-9);
    InpAstaMode=0; g_rdState[FAM_ONDA*NREAD+RD_BAL]=RDS_USEFUL; chk("solo misura (0): mai, anche se provata", fabs(AstaRiskMult(in)-1.0)<1e-9 && fabs(AstaRiskMult(out)-1.0)<1e-9);
    InpAstaMode=2; InpAstaInMult=3.0; InpAstaOutMult=0.0; chk("valori fuori misura: in equilibrio mai oltre x1,5, fuori mai sotto x0,1", fabs(AstaRiskMult(in)-1.5)<1e-9 && fabs(AstaRiskMult(out)-0.1)<1e-9);
    InpAstaInMult=0.5; InpAstaOutMult=2.0; chk("valori rovesciati per errore: in equilibrio mai meno di x1, fuori mai piu' di x1", fabs(AstaRiskMult(in)-1.0)<1e-9 && fabs(AstaRiskMult(out)-1.0)<1e-9);
    InpAstaInMult=1.2; InpAstaOutMult=0.8; InpAstaOn=false; chk("asta spenta: x1", fabs(AstaRiskMult(out)-1.0)<1e-9); InpAstaOn=true;
    InpReadOn=false; chk("lettura del mercato spenta: x1", fabs(AstaRiskMult(out)-1.0)<1e-9); InpReadOn=true; InpAstaMode=1; }
  // ---------- misura: la stessa regola delle altre letture
  { RdInit();
    auto st=[&](int f,int k,int side,int p,double n,double mean,double sd){ g_rdN[RdIdx(f,k,side,p)]=n; g_rdS[RdIdx(f,k,side,p)]=n*mean; g_rdQ[RdIdx(f,k,side,p)]=n*(sd*sd+mean*mean); };
    // i numeri del replay 2022-2026: ritracciamenti, in equilibrio +0,29R (716), fuori +0,07R (975)
    double nf[4]={120,170,190,236}, mfv[4]={0.20,0.19,0.42,0.31}, na[4]={170,230,250,325}, mav[4]={0.10,-0.07,0.09,0.12};
    for(int p=0;p<NPER;p++){ st(FAM_ONDA,RD_BAL,0,p,nf[p],mfv[p],1.3); st(FAM_ONDA,RD_BAL,1,p,na[p],mav[p],1.3); }
    chk("con i numeri del replay 2022-2026 l'equilibrio risulta provato per i ritracciamenti", RdEvaluate(FAM_ONDA,RD_BAL)==RDS_USEFUL);
    for(int p=0;p<NPER;p++){ st(FAM_TREND,RD_BAL,0,p,380,-0.06,1.3); st(FAM_TREND,RD_BAL,1,p,370,-0.01,1.3); }
    chk("per le vecchie di tendenza (nessuna differenza) resta in prova", RdEvaluate(FAM_TREND,RD_BAL)==RDS_TEST);
    for(int p=0;p<NPER;p++){ st(FAM_ONDA,RD_BAL,0,p,20,0.5,1.3); st(FAM_ONDA,RD_BAL,1,p,0,0,0); } for(int p=1;p<NPER;p++) st(FAM_ONDA,RD_BAL,0,p,0,0,0); st(FAM_ONDA,RD_BAL,1,0,20,-0.5,1.3);
    chk("sul conto, pochi casi (20 per lato): in prova", RdEvaluate(FAM_ONDA,RD_BAL)==RDS_TEST);
    // conto di un'idea chiusa: finisce nella casella giusta
    RdInit(); RdAdd(ST_ON_M15,(1<<RD_BAL),(1<<RD_VMIG),wd,1.5,true); RdAdd(ST_ON_M15,0,(1<<RD_BAL),wd,-1.0,true);
    int p0=ObPeriod(wd);
    chk("idea chiusa in equilibrio: +1,5R tra le 'a favore'; fuori: -1R tra le 'contro'", fabs(g_rdN[RdIdx(FAM_ONDA,RD_BAL,0,p0)]-1.0)<1e-9 && fabs(g_rdS[RdIdx(FAM_ONDA,RD_BAL,0,p0)]-1.5)<1e-9 &&
        fabs(g_rdN[RdIdx(FAM_ONDA,RD_BAL,1,p0)]-1.0)<1e-9 && fabs(g_rdS[RdIdx(FAM_ONDA,RD_BAL,1,p0)]+1.0)<1e-9 && fabs(g_rdN[RdIdx(FAM_ONDA,RD_VMIG,1,p0)]-1.0)<1e-9 && fabs(g_rdTot-2.0)<1e-9); }
  // ---------- file: le letture nuove si salvano e si rileggono; un file della 1.27 si legge lo stesso
  { RdInit(); auto st=[&](int f,int k,int side,int p,double n,double mean,double sd){ g_rdN[RdIdx(f,k,side,p)]=n; g_rdS[RdIdx(f,k,side,p)]=n*mean; g_rdQ[RdIdx(f,k,side,p)]=n*(sd*sd+mean*mean); };
    for(int p=0;p<NPER;p++){ st(FAM_ONDA,RD_BAL,0,p,100,0.30,1.3); st(FAM_ONDA,RD_BAL,1,p,120,0.05,1.3); st(FAM_REV,RD_ZONE,0,p,50,0.40,1.2); st(FAM_REV,RD_ZONE,1,p,50,-0.20,1.2); st(FAM_MF,RD_IB,0,p,7,0.1,1.0); }
    g_rdTot=900; RdRefresh(false); g_isOptim=false; RdSave();
    double tot=RdReadFile(RdFile(true)); RdRefresh(false);
    chk("salvato e riletto: totale e conti dell'equilibrio uguali", fabs(tot-900)<1e-9 && fabs(g_rdN[RdIdx(FAM_ONDA,RD_BAL,0,2)]-100)<1e-9 && fabs(g_rdS[RdIdx(FAM_ONDA,RD_BAL,1,3)]-120*0.05)<1e-6 && fabs(g_rdN[RdIdx(FAM_MF,RD_IB,0,1)]-7)<1e-9);
    chk("riletto: l'equilibrio e' provato per i ritracciamenti, la zona per le vecchie di inversione", g_rdState[FAM_ONDA*NREAD+RD_BAL]==RDS_USEFUL && g_rdState[FAM_REV*NREAD+RD_ZONE]==RDS_USEFUL && g_rdState[FAM_MF*NREAD+RD_IB]==RDS_TEST);
    // file scritto dalla 1.27: stesse colonne, solo le 14 letture vecchie
    { std::string path="simfiles/"+RdFile(true); FILE*f=fopen(path.c_str(),"w");
      if(f){ fprintf(f,"tipo;famiglia_o_strategia;lettura;stato;casi_favore;R_medio_favore;casi_contro;R_medio_contro\r\n"); fprintf(f,"totale;-;-;-;500;0;0;0\r\n");
        fprintf(f,"lettura;vecchie di inversione;zona di domanda/offerta;in prova;200;0.400;200;-0.200");
        for(int p=0;p<4;p++) fprintf(f,";50;20.000;92.000;50;-10.000;74.000"); fprintf(f,"\r\n"); fclose(f); }
      double t2=RdReadFile(RdFile(true)); RdRefresh(false);
      chk("file della 1.27: si legge, le letture vecchie tornano", fabs(t2-500)<1e-9 && fabs(g_rdN[RdIdx(FAM_REV,RD_ZONE,0,0)]-50)<1e-9 && g_rdState[FAM_REV*NREAD+RD_ZONE]==RDS_USEFUL);
      bool zero=true; for(int f2=0;f2<NFAM;f2++) for(int k=RD_BAL;k<NREAD;k++) for(int sd=0;sd<2;sd++) for(int p=0;p<NPER;p++) if(g_rdN[RdIdx(f2,k,sd,p)]!=0.0) zero=false;
      chk("file della 1.27: le cinque letture nuove partono da zero, in prova", zero && g_rdState[FAM_ONDA*NREAD+RD_BAL]==RDS_TEST);
      remove(path.c_str()); } }
  // ---------- pannello
  { RdInit(); InpAstaOn=true; InpAstaMode=1; InpAstaOutMult=0.8; InpAstaInMult=1.2; double A=40.0; S_now=wd+10*3600; g_ctx.nowUtc=S_now; g_ibDir=1;
    setVA(4080.10,4102.30,4091.00,200, 4070.00,4095.00,4085.00,200); mkTf(g_m15,40,wd,900,4105.0,1.0); RdAuction(A,4105.0);
    std::string pn=AstaPanel();
    chk("riga completa: regime, valore, prezzo e area di ieri, bilancio iniziale", has(pn,"Asta: equilibrio") && has(pn,"valore in salita") && has(pn,"prezzo sopra il valore di ieri, accettato (4080.10-4102.30)") && has(pn,"bilancio iniziale rotto al rialzo"));
    chk("riga dell'asta: una riga sola, sotto i 230 caratteri", pn.size()<230 && pn.back()=='\n' && std::count(pn.begin(),pn.end(),'\n')==1);
    chk("lettura in prova: la riga non parla di rischio", !has(pn,"rischio"));
    g_rdState[FAM_ONDA*NREAD+RD_BAL]=RDS_USEFUL; g_rdState[FAM_MF*NREAD+RD_BAL]=RDS_USEFUL; pn=AstaPanel();
    chk("provata per due famiglie, in equilibrio: 'rischio x1.20 per ritracciamenti, movimenti forti'", has(pn,"-> rischio x1.20 per ritracciamenti, movimenti forti"));
    setVA(4080.10,4102.30,4091.00,200, 4130.00,4150.00,4140.00,200); RdAuction(A,4105.0); pn=AstaPanel();
    chk("provata, in squilibrio: 'rischio x0.80'", has(pn,"squilibrio") && has(pn,"-> rischio x0.80 per ritracciamenti, movimenti forti") && pn.size()<230);
    InpAstaMode=2; RdInit(); pn=AstaPanel(); chk("da subito (2): 'rischio x0.80' senza elenco delle famiglie", has(pn,"-> rischio x0.80") && !has(pn," per "));
    InpAstaMode=0; pn=AstaPanel(); chk("solo misura (0): la riga non parla di rischio", has(pn,"Asta:") && !has(pn,"rischio")); InpAstaMode=1;
    chk("RdPanel contiene la riga dell'asta dopo la riga delle letture", RdPanel().find("Lettura del mercato")<RdPanel().find("Asta:"));
    // la riga peggiore possibile sta nel limite
    g_rdState[FAM_ONDA*NREAD+RD_BAL]=RDS_USEFUL; g_rdState[FAM_MF*NREAD+RD_BAL]=RDS_USEFUL; g_rdState[FAM_TREND*NREAD+RD_BAL]=RDS_USEFUL; g_ibDir=-1;
    setVA(14080.10,14102.30,14091.00,200, 14070.00,14080.50,14075.00,200); mkTf(g_m15,40,wd,900,14110.0,1.0); g_m15.r[39].close=14101.0; RdAuction(A,14110.0); pn=AstaPanel();
    chk("riga piu' lunga possibile: tagliata a 220 caratteri piu' l'a capo", pn.size()<=221 && pn.back()=='\n'); }
  printf("FALLITI %d\n", fails); return fails?1:0;
}
