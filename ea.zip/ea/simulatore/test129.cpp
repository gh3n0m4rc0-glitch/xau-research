// test129.cpp - XAU Committee EA 1.29: target scelto dal bot trade per trade sui livelli del mercato, 6 posizioni
#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-100s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
static bool has(const std::string&a,const char*b){ return a.find(b)!=std::string::npos; }
static bool near(double a,double b,double e=1e-6){ return fabs(a-b)<=e; }
static void mkTf(TfData&d,int n,datetime t0,int sec,double px,double range,int emaDir){
  d.n=n; ArrayResize(d.r,n); ArrayResize(d.ema20,n); ArrayResize(d.ema50,n); ArrayResize(d.atr,n);
  for(int i=0;i<n;i++){ d.r[i].time=t0+(datetime)i*sec; d.r[i].open=px; d.r[i].close=px; d.r[i].high=px+range/2; d.r[i].low=px-range/2; d.ema20[i]=px+emaDir; d.ema50[i]=px; d.atr[i]=range; }
}
// onda: p0 inizio della gamba, p1 estremo da cui parte il ritracciamento, p2 fine del ritracciamento
static void zz(int sc,int type2,double p0,double p1,double p2,datetime conf2,double a2){
  g_zz[sc].ok=true; g_zz[sc].n=5; g_zz[sc].t0=380; g_zz[sc].p0=p0; g_zz[sc].t1=390; g_zz[sc].p1=p1; g_zz[sc].t2=396; g_zz[sc].p2=p2;
  g_zz[sc].type2=type2; g_zz[sc].c2=399; g_zz[sc].nbars=400; g_zz[sc].time2=conf2-3*OndaBarSec(sc); g_zz[sc].conf2=conf2; g_zz[sc].a2=a2; g_zz[sc].legDir=-type2; g_zz[sc].legExt=p2;
}
static void noLv(){ g_lvN=0; }
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true; g_minLot=0.01; g_lotStep=0.01; g_lotDigits=2; g_sym="XAUUSD"; g_currency="EUR";
  InpVirtualCapital=0.0; S_balance=3000.0;
  datetime wd=1762214400;                       // martedi' 4 novembre 2025, 00:00
  chk("versione 1.29", std::string(EA_VERSION)=="1.29");
  // ---------- cosa resta della 1.28
  chk("regole fisse invariate: rischio 1%, max 3% a trade, pareggio a 1,5R, R:R minimo 2, rischio aperto max 4%", near(InpRiskPercent,1.0) && near(InpMaxRiskPerTrade,3.0) && near(InpBE_R,1.5) && near(InpMinRR,2.0) && near(InpMaxOpenRiskPct,4.0));
  chk("target della scala come la 1.28: M5 2R, M15, H1, H4 4R", near(InpOndaTargetR,2.0) && near(InpOndaTargetRM15,4.0) && near(InpOndaTargetRH1,4.0) && near(InpOndaTargetRH4,4.0) && near(OndaTargetR(0,false),2.0) && near(OndaTargetR(3,true),4.0));
  chk("asta come la 1.28: accesa, 50%, conta quando provata, x0,8 fuori e x1,2 dentro", InpAstaOn && near(InpAstaOverlap,0.5) && InpAstaMode==1 && near(InpAstaOutMult,0.8) && near(InpAstaInMult,1.2));
  chk("21 letture, 20 strategie, quattro scale accese", NREAD==21 && NSTRAT==20 && InpON_M5 && InpON_M15 && InpON_H1 && InpON_H4);
  // ---------- di serie 1.29
  chk("di serie: target scelto dal bot (modo 1), allunga fino al livello (2), tre fonti (7)", InpOndaTgtMode==1 && InpOndaTgtWay==2 && InpOndaTgtSrc==7 && InpOndaTgtNone==0);
  chk("di serie: livelli di peso 0,8 o piu', target 0,10R prima del livello, massimo 6R", near(InpOndaTgtMinW,0.8) && near(InpOndaTgtFront,0.10) && near(InpOndaTgtMaxR,6.0));
  g_netting=false;
  chk("di serie: 6 posizioni contemporanee (nome nuovo InpMaxPos, il vecchio 4 salvato sul grafico non torna)", InpMaxPos==6 && MaxPositionsEff()==6);
  g_netting=true; chk("conto netting: sempre una posizione", MaxPositionsEff()==1); g_netting=false;
  // ---------- OndaTargetDyn: acquisto da 4000, stop 10 $ (1R = 10 $); onda lontana per non disturbare
  zz(0,-1,3900.0,3960.0,3990.0,wd,10.0);       // p1 3960 sotto l'ingresso, misura 3990+60=4050 -> la si prova a parte
  InpOndaTgtSrc=4; noLv();
  chk("nessun livello: target della scala (2R)", near(OndaTargetDyn(0,1,4000.0,10.0,2.0),2.0) && has(g_ondaTgtWhy,"fisso della scala"));
  LvAdd(4045.0,LV_PDH,1.0);
  chk("massimo di ieri a 4045: target 4,4R (1 $ prima del livello)", near(OndaTargetDyn(0,1,4000.0,10.0,2.0),4.4) && has(g_ondaTgtWhy,"prima di PDH 4045.00"));
  LvAdd(4030.0,LV_PWH,1.0);
  chk("due livelli oltre il target: prende il primo (massimo della settimana a 4030 -> 2,9R)", near(OndaTargetDyn(0,1,4000.0,10.0,2.0),2.9) && has(g_ondaTgtWhy,"PWH"));
  noLv(); LvAdd(4015.0,LV_PDH,1.0);
  chk("livello prima del target della scala (1,4R): non accorcia, resta 2R", near(OndaTargetDyn(0,1,4000.0,10.0,2.0),2.0));
  noLv(); LvAdd(4025.0,LV_PDH,1.0);
  chk("scala a 4R e livello a 2,4R: non accorcia (resta 4R)", near(OndaTargetDyn(1,1,4000.0,10.0,4.0),4.0));
  InpOndaTgtWay=1;
  chk("modo 'accorcia' (InpOndaTgtWay 1): 2,4R", near(OndaTargetDyn(1,1,4000.0,10.0,4.0),2.4) && has(g_ondaTgtWhy,"PDH"));
  InpOndaTgtWay=2;
  noLv(); LvAdd(4080.0,LV_PDH,1.0);
  chk("livello oltre il massimo (7,9R): target della scala", near(OndaTargetDyn(0,1,4000.0,10.0,2.0),2.0) && has(g_ondaTgtWhy,"nessun livello"));
  InpOndaTgtNone=1; chk("con InpOndaTgtNone 1: target massimo 6R", near(OndaTargetDyn(0,1,4000.0,10.0,2.0),6.0)); InpOndaTgtNone=0;
  InpOndaTgtMaxR=8.0; chk("massimo 8R: il livello a 7,9R diventa il target", near(OndaTargetDyn(0,1,4000.0,10.0,2.0),7.9)); InpOndaTgtMaxR=6.0;
  noLv(); LvAdd(4045.0,LV_SWING,0.7);
  chk("swing H1 (peso 0,7) non conta di serie", near(OndaTargetDyn(0,1,4000.0,10.0,2.0),2.0));
  InpOndaTgtMinW=0.7; chk("con peso minimo 0,7 si'", near(OndaTargetDyn(0,1,4000.0,10.0,2.0),4.4)); InpOndaTgtMinW=0.8;
  noLv(); LvAdd(3955.0,LV_PDL,1.0); LvAdd(4045.0,LV_PDH,1.0);
  chk("vendita da 4000: guarda solo sotto (minimo di ieri 3955 -> 4,4R)", near(OndaTargetDyn(0,-1,4000.0,10.0,2.0),4.4) && has(g_ondaTgtWhy,"PDL"));
  noLv();
  // estremo precedente e misura dell'onda
  InpOndaTgtSrc=1; zz(1,-1,3900.0,4050.0,3980.0,wd,10.0);
  chk("estremo da cui parte il ritracciamento (4050): 4,9R", near(OndaTargetDyn(1,1,4000.0,10.0,4.0),4.9) && has(g_ondaTgtWhy,"estremo precedente 4050.00"));
  InpOndaTgtSrc=2; zz(1,-1,4000.0,4030.0,3990.0,wd,10.0);
  chk("misura dell'onda: 3990 + (4030-4000) = 4020 -> 1,9R, sotto il 4R della scala: resta 4R", near(OndaTargetDyn(1,1,4000.0,10.0,4.0),4.0));
  zz(1,-1,3960.0,4030.0,3990.0,wd,10.0);
  chk("misura dell'onda: 3990 + 70 = 4060 -> 5,9R", near(OndaTargetDyn(1,1,4000.0,10.0,4.0),5.9) && has(g_ondaTgtWhy,"misura dell'onda 4060.00"));
  InpOndaTgtSrc=0; chk("nessuna fonte: target della scala", near(OndaTargetDyn(1,1,4000.0,10.0,4.0),4.0));
  InpOndaTgtSrc=7;
  InpOndaTgtMode=0; LvAdd(4045.0,LV_PDH,1.0);
  chk("modo 0: target fisso anche con un livello vicino (come la 1.28)", near(OndaTargetDyn(0,1,4000.0,10.0,2.0),2.0) && has(g_ondaTgtWhy,"fisso"));
  InpOndaTgtMode=1; noLv();
  { bool ok=true; std::mt19937 rng(7);
    for(int i=0;i<3000;i++){ noLv(); int n=rng()%6; for(int k=0;k<n;k++) LvAdd(3900.0+(rng()%2000)/10.0,(int)(rng()%21),(rng()%10)/10.0+0.1);
      zz(i%4,(i%2)?1:-1,3900.0+(rng()%2000)/10.0,3900.0+(rng()%2000)/10.0,3900.0+(rng()%2000)/10.0,wd,10.0);
      int d=(rng()%2)?1:-1; double S=1.0+(rng()%300)/10.0, fx=(i%4==0)?2.0:4.0; double r=OndaTargetDyn(i%4,d,4000.0,S,fx);
      if(!(r>=fx-1e-9 && r<=6.0+1e-9) && !(near(r,fx))) ok=false; if(r<2.0-1e-9) ok=false; }
    chk("3000 casi a caso: target sempre tra quello della scala e 6R, mai sotto 2R", ok); noLv(); }
  // ---------- il segnale vero: H1, minimo confermato a 3970, ingresso 4000,20, stop 3966 (stesso caso della 1.27 e 1.28)
  { mkTf(g_d1,80,wd-80*86400,86400,4000.0,40.0,1); mkTf(g_h4,300,wd-300*14400,14400,4000.0,20.0,1); mkTf(g_h1,400,wd-400*3600,3600,4000.0,10.0,1);
    g_ctx.nowUtc=wd+14*3600+60; g_ctx.bid=4000.0; g_ctx.ask=4000.2; g_ctx.spread=0.2; g_ctx.dow=2; S_bid=4000.0; S_ask=4000.2; S_now=g_ctx.nowUtc;
    auto go=[&](TSignal&s){ OndaInit(); OndaDayAtr(); zz(2,-1,3965.0,3995.0,3970.0,wd+13*3600,40.0); return S_Onda(s,2); };
    noLv(); TSignal a; bool okA=go(a); double S=a.entry-a.sl;
    chk("senza livelli: stesso ingresso e stop di prima, target 4R", okA && near(a.entry,4000.2,1e-9) && near(a.sl,3966.0,0.011) && near(a.tp,a.entry+4.0*S+0.03,0.011));
    chk("il motivo dice come e' nato il target", has(a.why,"target 4.0R (nessun livello vicino: fisso della scala)"));
    LvAdd(4170.0,LV_PDH,1.0); LvAdd(4100.0,LV_ROUND,0.5);
    TSignal b; bool okB=go(b);
    double rr=(4170.0-b.entry-0.1*S)/S;
    chk("massimo di ieri a 4170: target appena prima (4166,6), oltre il 4R; il tondo debole a 4100 non conta", okB && near(b.tp,b.entry+rr*S+0.03,0.011) && b.tp>a.tp && b.tp<4170.0);
    chk("...e il motivo lo dice", has(b.why,"prima di PDH 4170.00"));
    chk("stesso stop, stesso ingresso: cambia solo il target", near(b.sl,a.sl,1e-9) && near(b.entry,a.entry,1e-9));
    noLv(); }
  // ---------- 6 posizioni: la settima idea si ferma, la sesta entra
  { P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); g_netting=false; g_lossesInRowToday=0; InpOnlyStrategy=PICK_ALL;
    for(int e=0;e<3;e++) g_tradesToday[e]=0;
    auto pos=[&](ulong tk,int eng,int strat,int dir,double open,double sl){ SimPos q; q.ticket=tk; q.id=(long)tk; q.type=(dir>0)?0:1; q.vol=0.01; q.open=open; q.sl=sl; q.tp=0; q.time=wd; q.magic=(ulong)MagicOfEngine(eng); q.comment="XC"; P.push_back(q);
      int k=MetaFree(); g_meta[k].Reset(); g_meta[k].active=true; g_meta[k].id=(long)tk; g_meta[k].strat=strat; g_meta[k].engine=eng; g_meta[k].dir=dir; };
    auto sig=[&](int strat,int dir){ TSignal s; s.Reset(); s.strat=strat; s.engine=g_stratEngine[strat]; s.dir=dir; PortfolioChecks(s); return s; };
    pos(9001,ENG_INTRA,ST_ON_M15,1,4000,3990); pos(9002,ENG_INTRA,ST_ON_M15,1,4001,3991); pos(9003,ENG_SCALP,ST_ON_M5,1,4002,3995); pos(9004,ENG_SWING,ST_ON_H1,1,4000,3960);
    { TSignal s=sig(ST_ON_M15,1); chk("quattro posizioni aperte: dalla 1.29 c'e' ancora posto (prima era il tetto)", !s.veto || !has(s.vetoWhy,"posizioni massime")); }
    pos(9005,ENG_INTRA,ST_ON_M15,1,4003,3993);
    { TSignal s=sig(ST_ON_M15,1); chk("cinque aperte: la sesta entra", !s.veto || !has(s.vetoWhy,"posizioni massime")); }
    pos(9006,ENG_SWING,ST_ON_H4,1,4000,3900);
    { TSignal s=sig(ST_ON_M15,1), t=sig(ST_IN_TREND2,1); chk("sei aperte: tetto, non entra nessuno", s.veto && has(s.vetoWhy,"posizioni massime") && t.veto && has(t.vetoWhy,"posizioni massime")); }
    InpMaxPos=4; P.pop_back(); P.pop_back();
    { TSignal s=sig(ST_ON_M15,1); chk("con InpMaxPos 4 torna il tetto della 1.28", s.veto && has(s.vetoWhy,"posizioni massime")); }
    InpMaxPos=6; P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); }
  printf("\n%s: %d falliti\n", fails?"QUALCOSA NON VA":"TUTTO OK", fails);
  return fails?1:0;
}
