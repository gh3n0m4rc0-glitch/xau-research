#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-66s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
static void ctx(int phase,double retr){
  CtxReset(g_cxH4); CtxReset(g_cxD1);
  g_cxH4.valid=true; g_cxH4.dir=1; g_cxH4.structure=1; g_cxH4.phase=phase; g_cxH4.retr=retr; g_cxH4.extAtr=0.5;
  g_cxD1=g_cxH4; g_ctxBias=0.0;
}
static double desk(){ TSignal s; s.strat=ST_IN_PULLBACK; s.engine=ENG_INTRA; s.stype=STYPE_TREND; s.dir=1; return DeskContext(s); }
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true;
  chk("versione 1.24 o successiva", std::string(EA_VERSION)>="1.24");
  chk("SW-WYCKOFF spento di default (W1)", !InpSW_WYCKOFF);
  chk("T5 acceso, 5 giorni", InpT5NoShortAfterCrash && InpT5Days==5);
  chk("T2, T3, T4 accesi di default", InpT2NoDiscountBonus && InpT3NoRangeEdgeObj && InpT4RoundNotMajor);
  // T2
  ctx(PH_RITRACCIAMENTO,0.5); double zona=desk(); ctx(PH_IMPULSO,0.1); double imp=desk(); ctx(PH_LATERALE,0.5); double base=desk();
  chk("T2 acceso: zona di sconto = neutro (nessun +0,12)", fabs(zona-base)<1e-9);
  chk("T2 acceso: impulso = neutro (nessun -0,08)", fabs(imp-base)<1e-9);
  InpT2NoDiscountBonus=false;
  ctx(PH_RITRACCIAMENTO,0.5); double zona0=desk(); ctx(PH_IMPULSO,0.1); double imp0=desk();
  chk("T2 spento: zona di sconto +0,12 come la 1.20", fabs(zona0-base-0.12)<1e-9);
  chk("T2 spento: impulso -0,08 come la 1.20", fabs(imp0-base+0.08)<1e-9);
  InpT2NoDiscountBonus=true;
  ctx(PH_RITRACCIAMENTO,0.85); double deep=desk();
  chk("oltre 78,6% resta la riduzione del contesto (confermata)", deep<=zona+1e-9);
  ctx(PH_ESAURIMENTO,0.1); g_cxH4.extAtr=3.0; g_cxD1=g_cxH4; double ex=desk();
  chk("movimento esausto: resta il -0,15 (confermato)", fabs(ex-(base-0.15))<1e-9);
  // T4
  chk("T4 acceso: tondo forte non e' livello forte", !IsMajorLevel(LV_ROUNDM));
  chk("T4 acceso: PDH resta livello forte", IsMajorLevel(LV_PDH));
  InpT4RoundNotMajor=false;
  chk("T4 spento: tondo forte torna livello forte (1.20)", IsMajorLevel(LV_ROUNDM));
  InpT4RoundNotMajor=true;
  g_lvN=0; LvAdd(4100.0, LV_ROUNDM, 1.0);
  chk("T4: stop sul 4100 non penalizzato come livello forte", !PriceOnMajorLevel(4100.0, 0.5));
  g_lvN=0; LvAdd(4100.0, LV_PDH, 1.0);
  chk("stop sul PDH resta penalizzato", PriceOnMajorLevel(4100.0, 0.5));
  // T3
  ctx(PH_LATERALE,0.5); g_cxD1.rangePos=0.95;
  { TSignal s; s.strat=ST_IN_PULLBACK; s.engine=ENG_INTRA; s.stype=STYPE_TREND; s.dir=1; std::string l; DevilsAdvocate(s,l);
    chk("T3 acceso: nessuna obiezione 'estremi del range' con prezzo al 95%", l.find("estremi del range")==std::string::npos); }
  InpT3NoRangeEdgeObj=false;
  { TSignal s; s.strat=ST_IN_PULLBACK; s.engine=ENG_INTRA; s.stype=STYPE_TREND; s.dir=1; std::string l; DevilsAdvocate(s,l);
    chk("T3 spento: obiezione come la 1.20", l.find("estremi del range")!=std::string::npos); }
  InpT3NoRangeEdgeObj=true;
  // T5
  { datetime d0=1762300800; // 2025-11-05 00:00 UTC (mercoledi)
    g_t5CrashDay=0; chk("T5: nessun crollo -> non attivo", !T5Active(d0));
    g_t5CrashDay=d0; chk("T5: stesso giorno -> attivo", T5Active(d0));
    chk("T5: 5 giorni di borsa dopo (lun 10/11+2) -> attivo", T5Active(d0+7*86400));
    chk("T5: 9 giorni di calendario dopo -> spento", !T5Active(d0+10*86400));
    InpT5NoShortAfterCrash=false; chk("T5 spento: mai attivo", !T5Active(d0)); InpT5NoShortAfterCrash=true;
    ctx(PH_LATERALE,0.5); g_d1.n=0;
    TSignal s; s.strat=ST_IN_BREAKOUT; s.engine=ENG_INTRA; s.stype=STYPE_BREAKOUT; s.dir=-1; s.veto=false;
    ArrayResize(g_d1.r,1); g_d1.r[0].time=d0+86400; g_d1.n=1;
    g_t5CrashDay=0; DeskContext(s); chk("T5: short senza crollo -> nessun veto T5", !s.veto);
    g_t5CrashDay=d0; s.veto=false; DeskContext(s); chk("T5: short di breakout il giorno dopo il crollo -> veto", s.veto && s.vetoWhy.find("T5")!=std::string::npos);
    TSignal l=s; l.dir=1; l.veto=false; DeskContext(l); chk("T5: long dopo il crollo -> nessun veto T5", !l.veto || l.vetoWhy.find("T5")==std::string::npos);
    TSignal m=s; m.stype=STYPE_MEANREV; m.veto=false; DeskContext(m); chk("T5: short di ritorno alla media -> nessun veto T5", !m.veto || m.vetoWhy.find("T5")==std::string::npos);
    g_t5CrashDay=0;
  }
  printf("FALLITI %d\n", fails); return fails?1:0;
}
