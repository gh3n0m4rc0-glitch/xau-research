#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-78s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
static bool has(const std::string&a,const char*b){ return a.find(b)!=std::string::npos; }
// barre M1 (server = UTC) da t0, una al minuto, con i prezzi di chiusura dati
static void bars(datetime t0,const std::vector<double>&c){
  int n=(int)c.size(); ArrayResize(g_m1.r,n); g_m1.n=n;
  for(int i=0;i<n;i++){ g_m1.r[i].time=t0+i*60; g_m1.r[i].open=i?c[i-1]:c[0]; g_m1.r[i].close=c[i]; g_m1.r[i].high=std::max(g_m1.r[i].open,c[i])+0.1; g_m1.r[i].low=std::min(g_m1.r[i].open,c[i])-0.1; }
}
static void stats(int k,int p,double n,double mean,double sd){ g_stN[k*NPER+p]=n; g_stS[k*NPER+p]=n*mean; g_stQ[k*NPER+p]=n*(sd*sd+mean*mean); }
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true;
  chk("versione 1.26 o successiva", std::string(EA_VERSION)>="1.26");
  chk("restano le scelte di 1.24 e 1.25 (Wyckoff spento, T5, OF1, OF2, costi, diario)", !InpSW_WYCKOFF && InpT5NoShortAfterCrash && InpOF1FixNoChase && InpOF2VolumeNeutral && InpCostTrack && InpDecisionLog);
  chk("regole fisse invariate: rischio base 1%, max 3% a trade, pareggio a 1,5R, R:R 2", fabs(InpRiskPercent-1.0)<1e-9 && fabs(InpMaxRiskPerTrade-3.0)<1e-9 && fabs(InpBE_R-1.5)<1e-9 && fabs(InpMinRR-2.0)<1e-9);
  // ---------- movimenti forti: parametri
  chk("IN-TREND acceso: soglia 0,8, stop 0,4 (min 0,25), tenuta 1 giorno, niente trailing", InpIN_TREND && fabs(InpTDThreshAtr-0.8)<1e-9 && fabs(InpTDStopAtr-0.4)<1e-9 && fabs(InpTDStopMinAtr-0.25)<1e-9 && InpTDHoldDays==1 && !InpTDTrail && InpTDProven);
  chk("rischio: IN-TREND x1,5, IN-DATO x0,5, IN-NOTTE x1", fabs(TmRiskMult(ST_IN_TREND)-1.5)<1e-9 && fabs(TmRiskMult(ST_IN_DATA)-0.5)<1e-9 && fabs(TmRiskMult(ST_IN_NIGHT)-1.0)<1e-9);
  chk("rischio dei movimenti forti mai oltre il massimo per trade", InpRiskPercent*TmRiskMult(ST_IN_TREND)<=InpMaxRiskPerTrade+1e-9);
  chk("famiglia movimenti forti: IN-TREND, IN-DATO, IN-NOTTE e nessun'altra", IsTrendMove(ST_IN_TREND) && IsTrendMove(ST_IN_DATA) && IsTrendMove(ST_IN_NIGHT) && !IsTrendMove(ST_SC_VWAP) && !IsTrendMove(ST_SW_TREND));
  chk("nomi delle nuove strategie", g_stratName[ST_IN_TREND]=="IN-TREND" && g_stratName[ST_IN_DATA]=="IN-DATO" && g_stratName[ST_IN_NIGHT]=="IN-NOTTE");
  { TSignal p; p.Reset(); p.strat=ST_IN_TREND; p.proven=true; TSignal q; q.Reset(); q.strat=ST_SC_VWAP;
    chk("lotto minimo: tetto 3% per i movimenti forti, 2,5% per gli altri", fabs(MinLotCapFor(p)-3.0)<1e-9 && fabs(MinLotCapFor(q)-InpMinLotMaxRiskPct)<1e-9); }
  // ---------- orari (inverno: mar 2025-11-04; estate: mar 2025-07-01)
  datetime wd=1762214400, sd=1751328000;
  chk("date di prova: martedi' d'inverno e d'estate", DowOf(wd)==2 && DowOf(sd)==2 && Ymd(wd)==20251104 && Ymd(sd)==20250701);
  chk("8:00 di New York = 13:00 UTC d'inverno, 12:00 d'estate", Ny8Utc(wd+5*3600)==wd+13*3600 && Ny8Utc(sd+5*3600)==sd+12*3600);
  chk("venerdi' sera: 20 UTC d'inverno, 19 UTC d'estate", fabs(FridayEveUTC(wd)-20.0)<1e-9 && fabs(FridayEveUTC(sd)-19.0)<1e-9);
  { datetime fw=wd+3*86400, fs=sd+3*86400;
    chk("venerdi' d'inverno: 19:59 no, 20:00 si'", DowOf(fw)==5 && !FridayEvening(fw+19*3600+59*60) && FridayEvening(fw+20*3600));
    chk("venerdi' d'estate: 18:59 no, 19:00 si' (prima chiudeva solo dalle 20, a mercato chiuso)", !FridayEvening(fs+18*3600+59*60) && FridayEvening(fs+19*3600));
    chk("gli altri giorni non sono venerdi' sera", !FridayEvening(wd+21*3600));
    chk("aperto di venerdi' mattina: fine della tenuta il venerdi' sera", TmExitUtc(fw+14*3600)==fw+20*3600 && TmExitUtc(fs+13*3600)==fs+19*3600); }
  chk("chiusura serale: 20 UTC d'inverno, 19:45 d'estate (prima della pausa del broker)", fabs(EveCloseUTC(wd)-20.0)<1e-9 && fabs(EveCloseUTC(sd)-19.75)<1e-9);
  chk("tenuta 1 giorno: aperto martedi' alle 14 -> mercoledi' alle 20 UTC", TmExitUtc(wd+14*3600)==wd+86400+20*3600);
  chk("tenuta 1 giorno d'estate: mercoledi' alle 19:45 UTC", TmExitUtc(sd+13*3600)==sd+86400+19*3600+45*60);
  chk("aperto giovedi' -> venerdi' sera", TmExitUtc(wd+2*86400+14*3600)==wd+3*86400+20*3600);
  chk("aperto di notte (dopo la chiusura serale): conta come il giorno dopo", TmExitUtc(wd+23*3600)==wd+2*86400+20*3600);
  InpTDHoldDays=0; chk("tenuta 0: chiude la sera stessa", TmExitUtc(wd+14*3600)==wd+20*3600 && has(TmHoldText(),"stasera")); InpTDHoldDays=1;
  chk("testo della tenuta nel messaggio di apertura", has(TmHoldText(),"giorno di borsa dopo"));
  // ---------- primo superamento (TmScan)
  { datetime a=wd+13*3600; std::vector<double> c; for(int i=0;i<20;i++) c.push_back(4000.0);      // 12:40-12:59
    for(int i=0;i<30;i++) c.push_back(4000.0+i*0.5);                                                // 13:00.. sale di 0,5 al minuto
    bars(a-20*60,c); double an=0; int dr=0; datetime cu=0;
    bool ok=TmScan(g_m1,60,a,a+5*60,a+180*60,10.0,an,dr,cu);
    chk("partenza = ultima chiusura prima delle 8:00 NY", ok && fabs(an-4000.0)<1e-9);
    chk("superamento al rialzo alla prima chiusura oltre la soglia (13:20, noto alle 13:21)", dr==1 && cu==a+21*60);
    ok=TmScan(g_m1,60,a,a+5*60,a+180*60,20.0,an,dr,cu); chk("soglia non raggiunta: nessun verso", ok && dr==0 && cu==0);
    ok=TmScan(g_m1,60,a,a+25*60,a+180*60,10.0,an,dr,cu); chk("la finestra parte dopo: vale la prima chiusura dentro la finestra", ok && dr==1 && cu==a+26*60);
    ok=TmScan(g_m1,60,a,a+5*60,a+15*60,10.0,an,dr,cu); chk("superamento dopo la fine della finestra: non conta", ok && dr==0);
    for(auto &x:c) x=8000.0-x; bars(a-20*60,c); ok=TmScan(g_m1,60,a,a+5*60,a+180*60,10.0,an,dr,cu);
    chk("superamento al ribasso", ok && dr==-1 && cu==a+21*60);
    std::vector<double> late(30,4000.0); bars(a+40*60,late); ok=TmScan(g_m1,60,a,a+5*60,a+180*60,10.0,an,dr,cu);
    chk("niente prezzi intorno all'ora di partenza: oggi non si guarda", !ok); }
  // ---------- dati: che numero e', verdetto
  { int h=0;
    chk("CPI m/m in italiano (IPC m/m) = inflazione", DataKindOf("consumer-price-index-mm | IPC m/m",h)==1 && h==1);
    chk("CPI core m/m = inflazione", DataKindOf("core-cpi-mm | IPC core m/m",h)==1);
    chk("CPI annuo non conta (si guarda il mensile)", DataKindOf("cpi-yy | IPC a/a",h)==0);
    chk("PCE core m/m = solo avviso (tipo 3)", DataKindOf("core-pce-price-index-mm | Indice dei prezzi PCE core m/m",h)==3);
    chk("NFP = lavoro", DataKindOf("nonfarm-payrolls | Buste paga del settore non agricolo",h)==2 && h==1);
    chk("disoccupazione = lavoro, al contrario (piu' alta = oro su)", DataKindOf("unemployment-rate | Tasso di disoccupazione",h)==2 && h==-1);
    chk("PPI e vendite al dettaglio non sono letti", DataKindOf("ppi-mm | IPP m/m",h)==0 && DataKindOf("retail-sales-mm | Vendite al dettaglio m/m",h)==0); }
  chk("verdetto: caldo -> ribasso", has(DataVerdict(1,2,2),"CALDO") && has(DataVerdict(1,2,2),"RIBASSO") && !has(DataVerdict(1,2,2),"misti"));
  chk("verdetto: freddo -> rialzo", has(DataVerdict(1,-2,2),"FREDDO") && has(DataVerdict(1,-2,2),"RIALZO"));
  chk("verdetto: totale e core discordi = numeri misti / in linea", has(DataVerdict(1,1,2),"misti") && has(DataVerdict(1,0,2),"in linea"));
  chk("verdetto lavoro: forte -> ribasso, debole -> rialzo", has(DataVerdict(2,1,1),"FORTE") && has(DataVerdict(2,-1,1),"DEBOLE"));
  chk("verdetto senza numeri: vuoto", DataVerdict(1,0,0)=="");
  { int n=ArraySize(g_cpiSurpDate); bool asc=true; for(int i=1;i<n;i++) if(g_cpiSurpDate[i]<=g_cpiSurpDate[i-1]) asc=false;
    chk("tabella CPI del Tester: 57 uscite in ordine, da gennaio 2022 a novembre 2026", n==57 && ArraySize(g_cpiSurpVal)==57 && asc && g_cpiSurpDate[0]==20220112 && g_cpiSurpDate[n-1]==20261110);
    chk("CPI del 10 novembre 2026: caldo (totale e core sopra le attese)", g_cpiSurpVal[n-1]==2); }
  // ---------- strategie in osservazione
  chk("osservazione accesa, giudizio automatico, 60 idee minime", InpObserveOn && InpObserveAuto && InpObserveMinN==60);
  StInit();
  chk("partono in osservazione: scalping e vecchi intraday, IN-NOTTE", StListed(ST_SC_VWAP) && StListed(ST_SC_SWEEP) && StListed(ST_IN_SWEEP) && StListed(ST_IN_NIGHT));
  chk("partono attive: IN-TREND, IN-DATO, SW-TREND", !StListed(ST_IN_TREND) && !StListed(ST_IN_DATA) && !StListed(ST_SW_TREND));
  chk("senza numeri: chi e' in elenco resta in osservazione, gli altri attivi", StEvaluate(ST_SC_VWAP)==1 && StEvaluate(ST_IN_TREND)==0);
  for(int p=0;p<NPER;p++) stats(ST_SC_VWAP,p,100,0.30,1.2);
  chk("promossa: 400 idee, +0,30R, 4 periodi positivi", StEvaluate(ST_SC_VWAP)==0);
  for(int p=0;p<NPER;p++) stats(ST_SC_VWAP,p,100,0.05,1.2);
  chk("non promossa: +0,05R e' sotto +0,10R", StEvaluate(ST_SC_VWAP)==1);
  for(int p=0;p<NPER;p++) stats(ST_SC_VWAP,p,100,0.12,1.2);
  chk("non promossa: +0,12R ma non lontano dal caso (2 errori standard)", StEvaluate(ST_SC_VWAP)==1);
  stats(ST_SC_VWAP,0,100,-0.2,1.2); stats(ST_SC_VWAP,1,100,-0.2,1.2); stats(ST_SC_VWAP,2,100,1.0,1.2); stats(ST_SC_VWAP,3,100,1.0,1.2);
  chk("non promossa: guadagna solo in 2 periodi su 4", StEvaluate(ST_SC_VWAP)==1);
  for(int p=0;p<NPER;p++) stats(ST_SC_VWAP,p,10,1.0,0.5);
  chk("non promossa: 40 idee sono poche", StEvaluate(ST_SC_VWAP)==1);
  for(int p=0;p<NPER;p++) stats(ST_SC_VWAP,p,0,0,0); stats(ST_SC_VWAP,3,80,0.5,1.0);
  chk("conto vero (un periodo solo): 80 idee non bastano, ne servono 120", StEvaluate(ST_SC_VWAP)==1);
  stats(ST_SC_VWAP,3,130,0.5,1.0); chk("conto vero: 130 idee a +0,5R -> promossa", StEvaluate(ST_SC_VWAP)==0);
  for(int p=0;p<NPER;p++) stats(ST_IN_TREND,p,50,-0.30,1.0);
  chk("una attiva che perde in modo chiaro torna in osservazione", StEvaluate(ST_IN_TREND)==1);
  for(int p=0;p<NPER;p++) stats(ST_IN_TREND,p,50,-0.03,1.0);
  chk("una attiva che perde poco resta attiva", StEvaluate(ST_IN_TREND)==0);
  for(int p=0;p<NPER;p++) stats(ST_IN_TREND,p,50,0.35,1.2);
  chk("una attiva che guadagna resta attiva", StEvaluate(ST_IN_TREND)==0);
  { double n,sm,q; StSums(ST_IN_TREND,n,sm,q); chk("conti per strategia: 200 idee, media 0,35, errore standard 0,085", fabs(n-200)<1e-9 && fabs(sm/n-0.35)<1e-9 && fabs(StSe(ST_IN_TREND)-1.2/sqrt(200.0))<0.002); }
  StInit(); for(int p=0;p<NPER;p++) stats(ST_SC_SWEEP,p,100,0.30,1.2);
  InpObserveAuto=false; chk("giudizio automatico spento: decide solo l'elenco", StEvaluate(ST_SC_SWEEP)==1); InpObserveAuto=true;
  InpObserveOn=false; StRefresh(false); chk("osservazione spenta: tutte attive", StEvaluate(ST_SC_VWAP)==0 && !StratObserved(ST_SC_VWAP)); InpObserveOn=true;
  StRefresh(false);
  chk("dopo il ricalcolo: SC-SWEEP promossa, SC-VWAP in osservazione", !StratObserved(ST_SC_SWEEP) && StratObserved(ST_SC_VWAP));
  InpOnlyStrategy=PICK_SC_VWAP; chk("nel Tester con una strategia sola l'osservazione non la ferma", !StratObserved(ST_SC_VWAP)); InpOnlyStrategy=PICK_ALL;
  { std::string pn=StPanel(); chk("pannello: elenco di chi apre ordini e di chi e' sulla carta", has(pn,"aprono ordini") && has(pn,"in osservazione") && has(pn,"IN-TREND")); }
  // ---------- file dei conti per strategia: scrittura e rilettura
  { remove("simfiles/XauCommittee_tester_strategie.csv");
    StInit(); for(int p=0;p<NPER;p++) stats(ST_SC_SWEEP,p,100,0.30,1.2); stats(ST_IN_DATA,3,7,0.6,1.5);
    g_isTester=true; StSave();
    FILE*f=fopen("simfiles/XauCommittee_tester_strategie.csv","r"); chk("il Tester scrive XauCommittee_tester_strategie.csv", f!=NULL); if(f) fclose(f);
    StLoad(); { double n,sm,q; StSums(ST_SC_SWEEP,n,sm,q); chk("nel Tester si riparte da zero", n==0.0); }
    g_isTester=false; S_tester=false; remove(("simfiles/"+StFile(false)).c_str());
    StLoad(); { double n,sm,q; StSums(ST_SC_SWEEP,n,sm,q); double n2,s2,q2; StSums(ST_IN_DATA,n2,s2,q2);
      chk("il conto parte dai conti del Tester (400 idee SC-SWEEP, 7 IN-DATO)", fabs(n-400)<1e-6 && fabs(sm-120)<1e-3 && fabs(n2-7)<1e-6);
      chk("e con quei conti SC-SWEEP e' promossa da subito", !StratObserved(ST_SC_SWEEP) && StratObserved(ST_SC_VWAP)); }
    InpObjFromTester=false; StLoad(); { double n,sm,q; StSums(ST_SC_SWEEP,n,sm,q); chk("InpObjFromTester spento: il conto parte da zero", n==0.0); } InpObjFromTester=true;
    g_isTester=true; S_tester=true; remove("simfiles/XauCommittee_tester_strategie.csv"); }
  printf("FALLITI %d\n", fails); return fails?1:0;
}
