// test132.cpp - XAU Committee EA 1.32: lotto minimo scelto dall'utente (0,03) entro il rischio massimo per trade
#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-100s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
int main(){
  chk("versione 1.32 o successiva", std::string(EA_VERSION)>="1.32");
  chk("di serie: lotto minimo scelto 0,03, poi 0,02, accettato fino al 2% (rischio massimo per trade 3%)", fabs(InpUserMinLots-0.03)<1e-9 && fabs(InpUserMinLots2-0.02)<1e-9 && fabs(InpUserMinLotMaxPct-2.0)<1e-9 && fabs(InpMaxRiskPerTrade-3.0)<1e-9);
  chk("restano i limiti: rischio aperto 4%, stesso verso 3%, rischio base 1%", fabs(InpMaxOpenRiskPct-4.0)<1e-9 && fabs(InpMaxDirRiskPct-3.0)<1e-9 && fabs(InpRiskPercent-1.0)<1e-9);
  printf("FALLITI %d\n", fails); return fails?1:0;
}
