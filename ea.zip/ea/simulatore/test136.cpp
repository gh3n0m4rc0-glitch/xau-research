// test136.cpp - XAU Committee EA 1.36: SPINTA-TREND e IN-FED con posto e rischio propri, assorbimento con minimo 0,02
//  - le strategie a parte non contano nelle 6 posizioni, nel rischio aperto e nelle posizioni opposte delle altre (e viceversa)
//  - le loro perdite non fermano e non rimpiccioliscono le altre; non consumano i trade del giorno delle altre
//  - assorbimento: lotto minimo 0,02 se il rischio resta entro il 2%, sopra cresce col conto (1% a trade)
#define main sim_main
#include "sim.cpp"
#undef main
static int fails=0;
static void chk(const char*lab, bool ok){ printf("%-100s %s\n", lab, ok?"ok":"FALLITO"); if(!ok) fails++; }
static bool has(const std::string&a,const char*b){ return a.find(b)!=std::string::npos; }
static bool near(double a,double b,double e=1e-6){ return fabs(a-b)<=e; }
int main(){
  g_tick=0.01; g_digits=2; g_point=0.01; g_gmtOffset=0; g_isTester=true; S_tester=true; g_minLot=0.01; g_maxLot=100.0; g_lotStep=0.01; g_lotDigits=2; g_sym="XAUUSD"; g_currency="EUR";
  InpVirtualCapital=0.0; S_balance=3700.0; if(system("mkdir -p simfiles")!=0) return 2;
  S_bid=4000.0; S_ask=4000.2;
  // ---------- di serie
  chk("versione 1.36", std::string(EA_VERSION)=="1.36");
  chk("SPINTA-TREND acceso: 72 ore, spinta 1,5 escursioni, stop 1, target 3R, tenuta 240 ore, pausa 48 ore, una alla volta",
      InpSPINTA && InpSpHours==72 && near(InpSpMove,1.5) && near(InpSpStopAtr,1.0) && near(InpSpTargetR,3.0) && InpSpHoldHours==240 && InpSpCoolHours==48 && InpSpOnePos);
  chk("IN-FED acceso: entra alle 15:00 NY, stop 0,3, target 2R, esce alle 16:00 NY del giorno dopo, meta' rischio, anche in hedging",
      InpIN_FED && InpFedEntryMin==900 && near(InpFedStopAtr,0.30) && near(InpFedTargetR,2.0) && InpFedExitMin==960 && near(InpFedRiskMult,0.5) && InpFedHedgeOk);
  chk("posto e rischio propri accesi, tetto 2% per le due insieme", InpOwnBudget && near(InpOwnMaxRiskPct,2.0));
  chk("assorbimento: rischio 1% a trade, minimo 0,02 lotti se il rischio resta entro il 2%", near(InpAbsRiskPerTrade,1.0) && near(InpAbsUserMinLots,0.02) && near(InpAbsMinLotMaxRisk,2.0));
  chk("resto del bot come la 1.35: rischio 1%, 0,03 poi 0,02, 6 posizioni, rischio aperto 4%", near(InpRiskPercent,1.0) && near(InpUserMinLots,0.03) && near(InpUserMinLots2,0.02) && InpMaxPos==6 && near(InpMaxOpenRiskPct,4.0));
  chk("menu 'solo una strategia': SPINTA-TREND e IN-FED hanno la loro voce", (int)PICK_SPINTA==ST_SPINTA && (int)PICK_IN_FED==ST_IN_FED && NSTRAT==24);
  chk("nomi", std::string(g_stratName[ST_SPINTA])=="SPINTA-TREND" && std::string(g_stratName[ST_IN_FED])=="IN-FED");
  chk("a parte solo SPINTA-TREND e IN-FED", OwnBudget(ST_SPINTA) && OwnBudget(ST_IN_FED) && !OwnBudget(ST_ON_H1) && !OwnBudget(ST_ON_M15) && !OwnBudget(ST_IN_TREND) && !OwnBudget(ST_IN_ARG));
  InpOwnBudget=false; chk("con InpOwnBudget spento tornano nel conto comune", !OwnBudget(ST_SPINTA) && !OwnBudget(ST_IN_FED)); InpOwnBudget=true;
  chk("giorni della Fed: 10 dic 2025 si', 11 dic no, 28 gen 2026 si'", IsFomcDay(1765393200) && !IsFomcDay(1765479600) && IsFomcDay(1769626800));
  // ---------- posto proprio: posizioni e rischio
  { P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); g_netting=false; g_lossesInRowToday=0; g_lossStreak=0; InpOnlyStrategy=PICK_ALL; for(int e=0;e<3;e++) g_tradesToday[e]=0;
    datetime wd=1762214400;
    auto pos=[&](ulong tk,int eng,int strat,int dir,double open,double sl){ SimPos q; q.ticket=tk; q.id=(long)tk; q.type=(dir>0)?0:1; q.vol=0.01; q.open=open; q.sl=sl; q.tp=0; q.time=wd; q.magic=(ulong)MagicOfEngine(eng); q.comment="XC"; P.push_back(q);
      int k=MetaFree(); g_meta[k].Reset(); g_meta[k].active=true; g_meta[k].id=(long)tk; g_meta[k].strat=strat; g_meta[k].engine=eng; g_meta[k].dir=dir; };
    auto sig=[&](int strat,int dir){ TSignal s; s.Reset(); s.strat=strat; s.engine=g_stratEngine[strat]; s.dir=dir; PortfolioChecks(s); return s; };
    pos(9001,ENG_SWING,ST_SPINTA,1,4000,3960);
    PortfolioScan();
    chk("SPINTA aperta: non conta nelle posizioni e nel rischio delle altre", g_cntAll==0 && g_cntOnda==0 && near(g_openRiskMoney,0.0) && g_cntDir[0]==0);
    chk("ma ha il suo conto: 1 posizione, rischio 40 $ x 0,01 lotti", g_ownCnt==1 && near(g_ownRiskMoney,40.0*0.01*ValuePerPriceUnit(),0.01));
    { TSignal a=sig(ST_ON_M15,-1); chk("SPINTA in acquisto: un ritracciamento in vendita non e' fermato da 'posizione opposta'", !a.veto); }
    for(int i=0;i<6;i++) pos(9100+i,ENG_INTRA,ST_ON_M15,1,4000,3990);
    PortfolioScan();
    chk("6 ritracciamenti + 1 SPINTA: le altre vedono 6 posizioni", g_cntAll==6 && g_ownCnt==1);
    { TSignal a=sig(ST_ON_H1,1), b=sig(ST_SPINTA,1), c=sig(ST_IN_FED,-1);
      chk("6 posizioni: ONDA-H1 fermata (posizioni massime)", a.veto && has(a.vetoWhy,"posizioni massime"));
      chk("SPINTA-TREND entra lo stesso (posto proprio)", !b.veto);
      chk("IN-FED in vendita contro 6 acquisti: entra lo stesso", !c.veto); }
    g_lossesInRowToday=5;
    { TSignal a=sig(ST_ON_H1,1), b=sig(ST_SPINTA,1); P.resize(1);
      TSignal c=sig(ST_ON_H1,1), d=sig(ST_SPINTA,1);
      chk("5 perdite di fila oggi: ONDA ferma, SPINTA no", c.veto && has(c.vetoWhy,"perdite di fila") && !d.veto); (void)a; (void)b; }
    g_lossesInRowToday=0;
    P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset();
    g_tradesToday[ENG_INTRA]=InpIntraMaxTradesDay;
    { TSignal a=sig(ST_IN_FED,1), b=sig(ST_IN_PULLBACK,1);
      chk("trade del giorno dell'intraday finiti: IN-FED entra, IN-PULLBACK no", !a.veto && b.veto && has(b.vetoWhy,"trade massimi")); }
    g_tradesToday[ENG_INTRA]=0;
    InpOwnBudget=false; pos(9001,ENG_SWING,ST_SPINTA,1,4000,3960); PortfolioScan();
    chk("InpOwnBudget spento: SPINTA torna a contare con le altre", g_cntAll==1 && g_ownCnt==0); InpOwnBudget=true;
    P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); }
  // ---------- rischio a parte nel calcolo dei lotti
  { P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); datetime wd=1762214400;
    auto pos=[&](ulong tk,int eng,int strat,int dir,double open,double sl,double vol){ SimPos q; q.ticket=tk; q.id=(long)tk; q.type=(dir>0)?0:1; q.vol=vol; q.open=open; q.sl=sl; q.tp=0; q.time=wd; q.magic=(ulong)MagicOfEngine(eng); q.comment="XC"; P.push_back(q);
      int k=MetaFree(); g_meta[k].Reset(); g_meta[k].active=true; g_meta[k].id=(long)tk; g_meta[k].strat=strat; g_meta[k].engine=eng; g_meta[k].dir=dir; };
    // rischio aperto delle altre al 4% (tetto pieno)
    double vpu=ValuePerPriceUnit(); double base=BaseCapital(); double d4=base*0.04/(0.03*vpu);   // 0,03 lotti con stop largo: rischio 4%, margine piccolo
    pos(9201,ENG_INTRA,ST_ON_M15,1,4000,4000-d4,0.03);
    PortfolioScan();
    chk("le altre hanno il rischio aperto quasi pieno", g_openRiskMoney>base*0.035);
    TSignal s; s.Reset(); s.strat=ST_SPINTA; s.engine=ENG_SWING; s.dir=1; s.entry=4000.2; s.sl=3990.2; s.proven=true; s.riskX=1.0;
    double rm=0; std::string why; double l=LotsFor(s,rm,why);
    chk("SPINTA: trova spazio nel suo 2% anche col rischio delle altre pieno", l>=g_minLot && rm<=base*0.02+1e-6);
    TSignal o; o.Reset(); o.strat=ST_ON_H1; o.engine=ENG_INTRA; o.dir=1; o.entry=4000.2; o.sl=3990.2; o.proven=true; o.riskX=1.0;
    double rm2=0; std::string why2; double l2=LotsFor(o,rm2,why2);
    chk("ONDA-H1 invece trova poco o niente (tetto del 4%)", l2<l || l2==0.0);
    P.clear(); for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); }
  // ---------- le perdite delle strategie a parte non toccano le altre
  { for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); g_lossStreak=0; g_lossesInRowToday=0; g_recoveryArmed=false; for(int e=0;e<3;e++) g_reArmed[e]=false;
    int mi=0; g_meta[mi].active=true; g_meta[mi].id=1; g_meta[mi].strat=ST_SPINTA; g_meta[mi].engine=ENG_SWING; g_meta[mi].dir=1; g_meta[mi].riskMoney=30.0; g_meta[mi].openTime=S_now-3600;
    FinalizeTrade(mi,-30.0);
    chk("SPINTA perde 1R: perdite di fila e recupero non cambiano", g_lossStreak==0 && g_lossesInRowToday==0 && !g_recoveryArmed);
    g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].id=2; g_meta[mi].strat=ST_IN_FED; g_meta[mi].engine=ENG_INTRA; g_meta[mi].dir=-1; g_meta[mi].riskMoney=15.0; g_meta[mi].openTime=S_now-3600;
    FinalizeTrade(mi,-15.0);
    chk("IN-FED perde 1R: idem", g_lossStreak==0 && g_lossesInRowToday==0);
    g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].id=3; g_meta[mi].strat=ST_ON_M15; g_meta[mi].engine=ENG_INTRA; g_meta[mi].dir=1; g_meta[mi].riskMoney=30.0; g_meta[mi].openTime=S_now-3600;
    FinalizeTrade(mi,-30.0);
    chk("un ritracciamento che perde invece conta come prima", g_lossStreak==1 && g_lossesInRowToday==1);
    g_meta[mi].Reset(); g_meta[mi].active=true; g_meta[mi].id=4; g_meta[mi].strat=ST_SPINTA; g_meta[mi].engine=ENG_SWING; g_meta[mi].dir=1; g_meta[mi].riskMoney=30.0; g_meta[mi].openTime=S_now-3600;
    FinalizeTrade(mi,90.0);
    chk("SPINTA vince 3R: non azzera le perdite di fila delle altre", g_lossStreak==1 && g_lossesInRowToday==1);
    chk("ma il suo conto per strategia si' (statistiche)", g_ss[ST_SPINTA].n>=2);
    g_lossStreak=0; g_lossesInRowToday=0; for(int i=0;i<MAX_META;i++) g_meta[i].Reset(); }
  // ---------- assorbimento: lotti
  { P.clear(); S_balance=3700.0; g_absPart=0; g_absClosed=0;
    double tv=SymbolInfoDouble(g_sym,SYMBOL_TRADE_TICK_VALUE), ts=SymbolInfoDouble(g_sym,SYMBOL_TRADE_TICK_SIZE);
    double lpl20=20.0/ts*tv, lpl50=50.0/ts*tv;
    chk("conto 3700, stop 20 $: l'1% darebbe 0,01 -> sale a 0,02 (rischio 1% circa, entro il 2%)", near(AbsLots(lpl20),0.02));
    chk("stop 50 $: 0,02 rischierebbe oltre il 2% -> 0,01 (il minimo del broker resta entro il 2%)", near(AbsLots(lpl50),0.01));
    S_balance=10000.0;
    chk("conto 10.000, stop 20 $: lotto calcolato dal rischio 0,05 (cresce col conto)", near(AbsLots(lpl20),0.05));
    S_balance=20000.0;
    chk("conto 20.000, stop 20 $: 0,10", near(AbsLots(lpl20),0.10));
    S_balance=3700.0; InpAbsUserMinLots=0.0;
    chk("minimo scelto spento: torna al calcolo (0,01)", near(AbsLots(lpl20),0.01));
    InpAbsUserMinLots=0.02; InpAbsRiskPerTrade=0.5;
    chk("con rischio 0,5%: 0,02 lo stesso a 3700", near(AbsLots(lpl20),0.02));
    S_balance=10000.0;
    chk("con rischio 0,5% a 10.000: 0,02 (0,027 arrotondato)", near(AbsLots(lpl20),0.02));
    InpAbsRiskPerTrade=1.0; S_balance=3700.0; }
  printf("\n%s: %d controlli falliti\n", fails?"FALLITO":"TUTTO OK", fails);
  return fails?1:0;
}
