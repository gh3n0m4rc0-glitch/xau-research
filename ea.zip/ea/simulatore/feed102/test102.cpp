// prova di GCDeltaFeed 1.02 (scelta del contratto, righe del file) con uno shim minimo
#include "shim.h"
#include <map>
#define COPY_TICKS_TRADE 2
#define TICK_FLAG_BUY 32
#define TICK_FLAG_SELL 64
struct Sym { datetime exp; std::vector<MqlRates> d1; std::vector<MqlTick> ticks; };
static std::map<std::string, Sym> SY; static std::vector<std::string> ORDER;
static datetime S_now = 0; static bool S_conn = true; string g_shimComment, g_shimCommentLongest; size_t g_shimCommentMax = 0; bool g_shimQuiet = false; std::vector<string> g_shimLog;
string _Symbol = "GCEG27";
datetime TimeTradeServer() { return S_now; }
datetime TimeGMT() { return S_now; }
datetime TimeCurrent() { return S_now; }
bool SymbolSelect(const string &s, bool) { return SY.count(s) > 0; }
long SymbolInfoInteger(const string &s, ENUM_SYMBOL_INFO_INTEGER p) { if(p == SYMBOL_EXPIRATION_TIME && SY.count(s)) return (long)SY[s].exp; return 0; }
int SymbolsTotal(bool) { return (int)ORDER.size(); }
string SymbolName(int i, bool) { return ORDER[i]; }
int CopyRates(const string &s, ENUM_TIMEFRAMES tf, int start, int count, DynArr<MqlRates> &out) {
  if(tf != PERIOD_D1 || !SY.count(s)) return -1;
  std::vector<MqlRates> all; for(auto &r : SY[s].d1) if(r.time <= S_now) all.push_back(r);   // come MT5: shift 0 = ultima barra esistente
  if(all.empty()) return -1;
  int n = (int)all.size(); int last = n - 1 - start; int first = last - count + 1; if(first < 0) first = 0; if(last < 0) return 0;
  out.v.assign(all.begin() + first, all.begin() + last + 1); return (int)out.v.size(); }
int CopyRates(const string &, ENUM_TIMEFRAMES, datetime, datetime, DynArr<MqlRates> &) { return -1; }
int CopyTicksRange(const string &s, DynArr<MqlTick> &out, uint, ulong from, ulong to) {
  out.v.clear(); if(!SY.count(s)) return -1; for(auto &t : SY[s].ticks) if((ulong)t.time_msc >= from && (ulong)t.time_msc <= to) out.v.push_back(t); return (int)out.v.size(); }
bool EventSetTimer(int) { return true; }
void EventKillTimer() {}
int TerminalInfoInteger(ENUM_TERMINAL_INFO_INTEGER) { return S_conn ? 1 : 0; }
static std::map<int, FILE*> FH; static int FHN = 1;
int FileOpen(const string &name, int, short, uint) { FILE *f = fopen(("simfiles/" + name).c_str(), "a+"); if(!f) return -1; FH[FHN] = f; return FHN++; }
uint FileWriteString(int h, const string &s, int) { fseek(FH[h], 0, SEEK_END); fputs(s.c_str(), FH[h]); return (uint)s.size(); }
void FileClose(int h) { fclose(FH[h]); FH.erase(h); }
ulong FileSize(int h) { long p = ftell(FH[h]); fseek(FH[h], 0, SEEK_END); long n = ftell(FH[h]); fseek(FH[h], p, SEEK_SET); return (ulong)n; }
bool FileSeek(int h, long off, ENUM_FILE_POSITION o) { return fseek(FH[h], off, o == SEEK_SET ? SEEK_SET : SEEK_END) == 0; }
string RootOf(string s); bool IsMonthCode(string s, int pos); void ChooseContract(); void WritePending(); void CloseMinute(); long LastDayVolume(string s); int ServerOffsetSec();
#include "feed.inc"
static int fails = 0;
static void chk(const char *l, bool ok) { printf("%-95s %s\n", l, ok ? "ok" : "FALLITO"); if(!ok) fails++; }
static MqlRates bar(datetime t, long v) { MqlRates r{}; r.time = t; r.real_volume = v; r.tick_volume = v / 2; return r; }
static void tick(const char *s, datetime t, int ms, ulong vol, uint fl) { MqlTick k{}; k.time = t; k.time_msc = (long)t * 1000 + ms; k.volume = vol; k.flags = fl; k.last = 3650; SY[s].ticks.push_back(k); }
static std::string slurp() { FILE *f = fopen("simfiles/GC_delta.csv", "r"); std::string s; char b[4096]; size_t n; while(f && (n = fread(b, 1, sizeof b, f)) > 0) s.append(b, n); if(f) fclose(f); return s; }
int main() {
  if(system("mkdir -p simfiles && rm -f simfiles/GC_delta.csv") != 0) return 2;
  const datetime D = 1795478400;   // mar 24 nov 2026 00:00 UTC
  const datetime DAY = 86400;
  ORDER = {"MGCEZ26", "GCEZ26", "GCEG27", "GCEJ27", "GCEM27", "GCEQ25", "GCEZ26X", "@GCE", "GCEZ2A"};
  SY["MGCEZ26"].exp = D + 35 * DAY; SY["GCEZ26"].exp = D + 35 * DAY; SY["GCEG27"].exp = D + 92 * DAY; SY["GCEJ27"].exp = D + 150 * DAY;
  SY["GCEM27"].exp = D + 210 * DAY; SY["GCEQ25"].exp = D - 100 * DAY; SY["GCEZ26X"].exp = D + 35 * DAY; SY["@GCE"].exp = 0; SY["GCEZ2A"].exp = D + 35 * DAY;
  // volumi giornalieri: ven 20, dom 22 (pochi), lun 23; oggi mar 24
  SY["MGCEZ26"].d1 = {bar(D - 4 * DAY, 900000), bar(D - 2 * DAY, 900000), bar(D - DAY, 900000)};
  SY["GCEZ26"].d1 = {bar(D - 4 * DAY, 200000), bar(D - 2 * DAY, 100), bar(D - DAY, 150000), bar(D, 5000)};
  SY["GCEG27"].d1 = {bar(D - 4 * DAY, 60000), bar(D - 2 * DAY, 900), bar(D - DAY, 90000), bar(D, 3000)};
  SY["GCEJ27"].d1 = {bar(D - 4 * DAY, 500), bar(D - DAY, 800)};
  SY["GCEM27"].d1 = {bar(D - DAY, 999999)};          // quarto per scadenza: non va considerato
  chk("radice: GCEG27 -> GCE, @GCE -> GCE, XAUUSD -> niente", RootOf("GCEG27") == "GCE" && RootOf("@GCE") == "GCE" && RootOf("XAUUSD") == "" && RootOf("GC") == "");
  chk("lunedi' (domenica saltata): ultima giornata completa = lunedi' 23", (S_now = D + 14 * 3600 + 42 * 60, LastDayVolume("GCEZ26") == 150000));
  S_now = D + 14 * 3600 + 42 * 60;
  chk("avvio sul grafico GCEG27", OnInit() == INIT_SUCCEEDED);
  chk("sceglie dicembre (150.000 ieri contro 90.000): GCEZ26", g_sym == "GCEZ26");
  chk("esclusi micro (MGC), scaduti, nomi strani e il quarto per scadenza (GCEM27)", g_rollInfo.find("MGC") == std::string::npos && g_rollInfo.find("GCEQ25") == std::string::npos && g_rollInfo.find("GCEM27") == std::string::npos && g_rollInfo.find("GCEZ26X") == std::string::npos);
  chk("pannello con i volumi dei 3 contratti", g_rollInfo.find("GCEZ26 150000") != std::string::npos && g_rollInfo.find("GCEG27 90000") != std::string::npos && g_rollInfo.find("GCEJ27 800") != std::string::npos);
  // scambi: dicembre conta, febbraio no
  tick("GCEZ26", S_now + 10, 0, 3, TICK_FLAG_BUY); tick("GCEZ26", S_now + 20, 0, 2, TICK_FLAG_SELL); tick("GCEG27", S_now + 15, 0, 50, TICK_FLAG_BUY);
  S_now += 30; OnTimer(); S_now += 60; OnTimer();
  std::string f = slurp();
  chk("riga del minuto 14:42 con buy 3 sell 2 e il contratto", f.find("2026.11.24 14:42;3;2;0;2;3650.00;GCEZ26") != std::string::npos);
  chk("intestazione nuova con la colonna contratto", f.rfind("utc;buy;sell;none;ticks;last;contratto", 0) == 0);
  chk("pannello: contratto scelto da solo", g_shimComment.find("contratto scelto da solo") != std::string::npos);
  // il giorno dopo febbraio supera dicembre
  SY["GCEZ26"].d1.back().real_volume = 70000; SY["GCEG27"].d1.back().real_volume = 160000;
  S_now = D + DAY + 3600; OnTimer();
  chk("mercoledi': passa a febbraio GCEG27", g_sym == "GCEG27");
  tick("GCEZ26", S_now + 5, 0, 7, TICK_FLAG_BUY); tick("GCEG27", S_now + 6, 0, 4, TICK_FLAG_SELL);
  S_now += 80; OnTimer();
  f = slurp();
  chk("dopo il cambio conta solo febbraio (sell 4, niente buy 7 di dicembre)", f.find(";0;4;0;1;3650.00;GCEG27") != std::string::npos && f.find(";7;") == std::string::npos);
  long n0 = 0; for(char c : f) if(c == '\n') n0++;
  // dati del giorno non ancora arrivati (CopyRates fallisce): resta dov'e'
  S_now += 700; std::string keep = g_sym; SY["GCEG27"].d1.clear(); OnTimer();
  chk("se mancano le barre giornaliere del contratto in uso aspetta (resta su febbraio)", g_sym == keep && keep == "GCEG27");
  // contratto in uso scaduto (sparisce dai candidati): passa al piu' scambiato
  SY["GCEG27"].d1 = {bar(D, 160000)}; SY["GCEG27"].exp = S_now - 1; SY["GCEM27"].d1 = {bar(D, 10)}; S_now += 700; OnTimer();
  chk("contratto in uso scaduto: passa al piu' scambiato tra quelli rimasti", g_sym == "GCEZ26");
  // simbolo fisso
  chk("con un simbolo fisso (InpSymbol) non sceglie: radice vuota", RootOf("XAUUSD") == "");
  printf("FALLITI %d\n", fails); return fails ? 1 : 0;
}
