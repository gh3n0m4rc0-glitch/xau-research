#define main sim_main
#include "sim.cpp"
#undef main
static void row(const char *lab, datetime t0, int eng, int strat) {
  printf("%-28s", lab);
  int ms[] = {-91, -31, -30, -1, 0, 4, 5, 14, 16, 29, 31, 45, 60, 61, 89, 90, 91, 121};
  for (int m : ms) { string why; bool b = NewsBlocked(eng, t0 + m * 60, strat, why); printf(" %+d:%s", m, b ? "B" : "."); }
  printf("\n");
}
int main() {
  datetime fomc = 1793210400;            // 2026-10-28 18:00 UTC (14:00 ET)
  datetime nfp = 1793971800;             // 2026-11-06 13:30 UTC
  // calendario del tester: deve creare FOMC alle 18:00 UTC del 28/10 e NFP alle 13:30 UTC del 6/11
  TesterNewsRefresh(fomc - 3 * 86400);
  for (int i = 0; i < g_newsN; i++) printf("tester: %s %s\n", TimeToString(g_news[i].utc).c_str(), g_news[i].title.c_str());
  g_newsN = 0; g_testerNewsDay = 0;
  TesterNewsRefresh(nfp - 2 * 86400);
  for (int i = 0; i < g_newsN; i++) printf("tester: %s %s\n", TimeToString(g_news[i].utc).c_str(), g_news[i].title.c_str());
  g_newsN = 0;
  NewsUpsert(fomc, 1, "Fed Interest Rate Decision");
  row("FOMC scalp", fomc, ENG_SCALP, ST_SC_VWAP);
  row("FOMC IN-NEWS", fomc, ENG_INTRA, ST_IN_NEWS);
  row("FOMC swing", fomc, ENG_SWING, ST_SW_TREND);
  NewsUpsert(fomc + 1800, 1, "FOMC Press Conference");
  row("FOMC+conferenza intraday", fomc, ENG_INTRA, ST_IN_PULLBACK);
  g_newsN = 0;
  NewsUpsert(fomc, 1, "FOMC Meeting Minutes");
  row("Verbali FOMC (normale)", fomc, ENG_SCALP, ST_SC_VWAP);
  g_newsN = 0;
  NewsUpsert(nfp, 1, "Nonfarm Payrolls");
  row("NFP scalp (normale)", nfp, ENG_SCALP, ST_SC_VWAP);
  row("NFP IN-NEWS (normale)", nfp, ENG_INTRA, ST_IN_NEWS);
  g_newsN = 0;
  InpNewsBlockFomcAfter = 0;
  NewsUpsert(fomc, 1, "Fed Interest Rate Decision");
  row("FOMC con parametro 0", fomc, ENG_SCALP, ST_SC_VWAP);
  row("FOMC IN-NEWS parametro 0", fomc, ENG_INTRA, ST_IN_NEWS);
  printf("FomcKind: %d %d %d %d %d %d\n", FomcKind("Federal Funds Rate"), FomcKind("FOMC Statement"), FomcKind("FOMC Press Conference"),
         FomcKind("FOMC Member Waller Speaks"), FomcKind("Fed Chairman Warsh Speaks"), FomcKind("ECB Interest Rate Decision"));
  return 0;
}
