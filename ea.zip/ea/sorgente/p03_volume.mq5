//+------------------------------------------------------------------+
//| Motore volumi: delta tick (tick rule), RVOL per orario, VWAP,    |
//| volume profile (POC/VAH/VAL), VSA, DOM                           |
//+------------------------------------------------------------------+
struct MicroBar
  {
   datetime          t;
   double            o;
   double            h;
   double            l;
   double            c;
   double            vol;
   double            delta;
  };

MicroBar g_micro[MICRO_N];
int      g_microHead = -1;
int      g_microCount = 0;

//--- accumulatori del delta tick della barra M1 in formazione
double   g_tkLastBid = 0.0;
int      g_tkLastDir = 0;
double   g_tkDelta = 0.0;
double   g_tkCount = 0.0;
datetime g_tkBarOpen = 0;

//--- spread medio (per riconoscere spread anomali)
double   g_spreadAvg = 0.0;

void MicroPush(datetime t, double o, double h, double l, double c, double vol, double delta)
  {
   g_microHead = (g_microHead + 1) % MICRO_N;
   g_micro[g_microHead].t = t;
   g_micro[g_microHead].o = o;
   g_micro[g_microHead].h = h;
   g_micro[g_microHead].l = l;
   g_micro[g_microHead].c = c;
   g_micro[g_microHead].vol = vol;
   g_micro[g_microHead].delta = delta;
   if(g_microCount < MICRO_N)
      g_microCount++;
  }

int MicroIdx(int sh)
  {
   if(sh < 0 || sh >= g_microCount || g_microHead < 0)
      return -1;
   return (g_microHead - sh + MICRO_N) % MICRO_N;
  }

double ClvDelta(double h, double l, double c, double vol)
  {
   double rg = h - l;
   if(rg <= 0.0)
      return 0.0;
   double clv = ((c - l) - (h - c)) / rg;
   return clv * vol;
  }

double MicroDelta(int sh)
  {
   int i = MicroIdx(sh);
   return (i < 0) ? 0.0 : g_micro[i].delta;
  }

double MicroCvd(int nBars)
  {
   double s = 0.0;
   for(int k = 0; k < nBars; k++)
     {
      int i = MicroIdx(k);
      if(i < 0)
         break;
      s += g_micro[i].delta;
     }
   return s;
  }

double MicroVolSum(int nBars)
  {
   double s = 0.0;
   for(int k = 0; k < nBars; k++)
     {
      int i = MicroIdx(k);
      if(i < 0)
         break;
      s += g_micro[i].vol;
     }
   return s;
  }

//--- CVD normalizzato (-1..+1) sulle ultime n barre M1
double MicroCvdRatio(int nBars)
  {
   double v = MicroVolSum(nBars);
   if(v <= 0.0)
      return 0.0;
   return MicroCvd(nBars) / v;
  }

void TickDelta(double bid)
  {
   if(g_tkLastBid > 0.0)
     {
      if(bid > g_tkLastBid)
         g_tkLastDir = 1;
      else
         if(bid < g_tkLastBid)
            g_tkLastDir = -1;
      g_tkDelta += g_tkLastDir;
      g_tkCount += 1.0;
     }
   g_tkLastBid = bid;
  }

void SpreadTrack(double sp)
  {
   if(sp <= 0.0)
      return;
   if(g_spreadAvg <= 0.0)
      g_spreadAvg = sp;
   else
      g_spreadAvg += (sp - g_spreadAvg) * 0.002;
  }

bool SpreadAbnormal()
  {
   double sp = PxAsk() - PxBid();
   return (g_spreadAvg > 0.0 && sp > 2.5 * g_spreadAvg && sp > 3.0 * g_tick);
  }

//--- chiude la barra M1 appena finita nel buffer micro
void MicroFinalize()
  {
   MqlRates b[];
   if(CopyRates(g_sym, PERIOD_M1, 1, 1, b) != 1)
      return;
   if(g_microHead >= 0 && g_micro[g_microHead].t >= b[0].time)
      return;
   double vol = (double)b[0].tick_volume;
   double delta;
   if(g_tkBarOpen == b[0].time && g_tkCount >= 3.0)
      delta = (g_tkDelta / g_tkCount) * vol;
   else
      delta = ClvDelta(b[0].high, b[0].low, b[0].close, vol);
   MicroPush(b[0].time, b[0].open, b[0].high, b[0].low, b[0].close, vol, delta);
  }

void MicroInit()
  {
   MqlRates b[];
   int got = CopyRates(g_sym, PERIOD_M1, 1, 600, b);
   g_microHead = -1;
   g_microCount = 0;
   for(int i = 0; i < got; i++)
      MicroPush(b[i].time, b[i].open, b[i].high, b[i].low, b[i].close, (double)b[i].tick_volume,
                ClvDelta(b[i].high, b[i].low, b[i].close, (double)b[i].tick_volume));
  }

//+------------------------------------------------------------------+
//| RVOL: volume rispetto alla media della stessa fascia oraria      |
//+------------------------------------------------------------------+
double g_rvolAvg[288];
int    g_rvolCnt[288];

int SlotOf(datetime serverTime)
  {
   datetime u = ToUTC(serverTime);
   int sec = (int)(u % 86400);
   if(sec < 0)
      sec += 86400;
   return (sec / 300) % 288;
  }

void RvolAdd(datetime barTime, double vol)
  {
   int s = SlotOf(barTime);
   if(g_rvolCnt[s] < 20)
     {
      g_rvolAvg[s] = (g_rvolAvg[s] * g_rvolCnt[s] + vol) / (g_rvolCnt[s] + 1);
      g_rvolCnt[s]++;
     }
   else
      g_rvolAvg[s] += (vol - g_rvolAvg[s]) / 20.0;
  }

void RvolInit()
  {
   ArrayInitialize(g_rvolAvg, 0.0);
   ArrayInitialize(g_rvolCnt, 0);
   MqlRates b[];
   int got = CopyRates(g_sym, PERIOD_M5, 1, 6000, b);
   for(int i = 0; i < got; i++)
      RvolAdd(b[i].time, (double)b[i].tick_volume);
  }

//--- volume atteso per una barra di timeframe tf che inizia a barTime
double RvolExpected(datetime barTime, ENUM_TIMEFRAMES tf)
  {
   int secs = PeriodSeconds(tf);
   int s0 = SlotOf(barTime);
   if(secs < 300)
      return g_rvolAvg[s0] * secs / 300.0;
   int m = secs / 300;
   if(m > 288)
      m = 288;
   double e = 0.0;
   for(int k = 0; k < m; k++)
      e += g_rvolAvg[(s0 + k) % 288];
   return e;
  }

double RvolBar(const TfData &d, int sh)
  {
   int i = TfIdx(d, sh);
   if(i < 0)
      return 1.0;
   double e = RvolExpected(d.r[i].time, d.tf);
   if(e <= 0.0)
      return 1.0;
   return (double)d.r[i].tick_volume / e;
  }

//+------------------------------------------------------------------+
//| VWAP giornaliera (barre M1) e settimanale (barre M5)             |
//+------------------------------------------------------------------+
struct VwapAcc
  {
   datetime          anchor;
   double            sv;
   double            spv;
   double            sp2v;
  };
VwapAcc g_vwD;
VwapAcc g_vwW;

void VwapReset(VwapAcc &a, datetime anchor)
  {
   a.anchor = anchor;
   a.sv = 0.0;
   a.spv = 0.0;
   a.sp2v = 0.0;
  }

void VwapAdd(VwapAcc &a, double tp, double v)
  {
   if(v <= 0.0)
      v = 1.0;
   a.sv += v;
   a.spv += tp * v;
   a.sp2v += tp * tp * v;
  }

double VwapVal(const VwapAcc &a)
  {
   if(a.sv <= 0.0)
      return 0.0;
   return a.spv / a.sv;
  }

double VwapSigma(const VwapAcc &a)
  {
   if(a.sv <= 0.0)
      return 0.0;
   double m = a.spv / a.sv;
   double var = a.sp2v / a.sv - m * m;
   return (var > 0.0) ? MathSqrt(var) : 0.0;
  }

//--- aggiunge una barra chiusa all'accumulatore ancorato a 'anchorNow'
void VwapFeed(VwapAcc &a, datetime anchorNow, datetime barTime, double h, double l, double c, double v)
  {
   if(barTime >= anchorNow && a.anchor != anchorNow)
      VwapReset(a, anchorNow);
   VwapAdd(a, (h + l + c) / 3.0, v);
  }

void VwapInit()
  {
   datetime dAnchor = iTime(g_sym, PERIOD_D1, 0);
   datetime wAnchor = iTime(g_sym, PERIOD_W1, 0);
   VwapReset(g_vwD, dAnchor);
   VwapReset(g_vwW, wAnchor);
   MqlRates b[];
   datetime curM1 = iTime(g_sym, PERIOD_M1, 0);
   int got = CopyRates(g_sym, PERIOD_M1, dAnchor, curM1, b);
   for(int i = 0; i < got; i++)
     {
      if(b[i].time >= curM1)
         continue;
      VwapAdd(g_vwD, (b[i].high + b[i].low + b[i].close) / 3.0, (double)b[i].tick_volume);
     }
   MqlRates w[];
   datetime curM5 = iTime(g_sym, PERIOD_M5, 0);
   int gw = CopyRates(g_sym, PERIOD_M5, wAnchor, curM5, w);
   for(int i = 0; i < gw; i++)
     {
      if(w[i].time >= curM5)
         continue;
      VwapAdd(g_vwW, (w[i].high + w[i].low + w[i].close) / 3.0, (double)w[i].tick_volume);
     }
  }

//+------------------------------------------------------------------+
//| Volume profile giornaliero (barre M5)                            |
//+------------------------------------------------------------------+
struct Profile
  {
   datetime          anchor;
   double            base;
   double            bin;
   double            vol[];
   double            total;
   double            poc;
   double            vah;
   double            val;
   bool              valid;
   int               bars;        // 1.28: barre M5 dentro il profilo (un giorno corto non basta per giudicare l'asta)
  };
Profile g_prof[2];
int     g_profCur = 0;
//--- 1.28: l'area di valore dell'altro ieri (per capire se il mercato e' in equilibrio)
bool    g_ppOk = false;
double  g_ppVah = 0.0, g_ppVal = 0.0, g_ppPoc = 0.0;
int     g_ppBars = 0;

void ProfReset(Profile &p, datetime anchor, double refPrice, double bin)
  {
   p.anchor = anchor;
   p.bin = MathMax(bin, g_tick);
   p.base = refPrice - 100.0 * p.bin;
   ArrayResize(p.vol, 200);
   ArrayInitialize(p.vol, 0.0);
   p.total = 0.0;
   p.poc = 0.0;
   p.vah = 0.0;
   p.val = 0.0;
   p.valid = false;
   p.bars = 0;
  }

int ProfIndex(Profile &p, double price)
  {
   int n = ArraySize(p.vol);
   int idx = (int)MathFloor((price - p.base) / p.bin);
   if(idx < 0)
     {
      int k = -idx + 20;
      if(n + k > 3000)
         return 0;
      ArrayResize(p.vol, n + k);
      for(int i = n - 1; i >= 0; i--)
         p.vol[i + k] = p.vol[i];
      for(int i = 0; i < k; i++)
         p.vol[i] = 0.0;
      p.base -= k * p.bin;
      idx += k;
      n += k;
     }
   if(idx >= n)
     {
      int nn = idx + 20;
      if(nn > 3000)
         return n - 1;
      ArrayResize(p.vol, nn);
      for(int i = n; i < nn; i++)
         p.vol[i] = 0.0;
     }
   return idx;
  }

void ProfAddBar(Profile &p, double lo, double hi, double v)
  {
   if(p.bin <= 0.0 || v <= 0.0)
      return;
   int a = ProfIndex(p, lo);
   int b = ProfIndex(p, hi);
   a = ProfIndex(p, lo);   // l'indice basso puo' spostarsi dopo un'estensione
   if(b < a)
     {
      int t = a;
      a = b;
      b = t;
     }
   int cnt = b - a + 1;
   double each = v / cnt;
   for(int i = a; i <= b; i++)
      p.vol[i] += each;
   p.total += v;
   p.bars++;
  }

void ProfCompute(Profile &p)
  {
   int n = ArraySize(p.vol);
   p.valid = false;
   if(n <= 0 || p.total <= 0.0)
      return;
   int pi = 0;
   for(int i = 1; i < n; i++)
      if(p.vol[i] > p.vol[pi])
         pi = i;
   double target = p.total * 0.70;
   double acc = p.vol[pi];
   int lo = pi, hi = pi;
   while(acc < target && (lo > 0 || hi < n - 1))
     {
      double up = (hi < n - 1) ? p.vol[hi + 1] : -1.0;
      double dn = (lo > 0) ? p.vol[lo - 1] : -1.0;
      if(up >= dn)
        {
         hi++;
         acc += p.vol[hi];
        }
      else
        {
         lo--;
         acc += p.vol[lo];
        }
     }
   p.poc = p.base + (pi + 0.5) * p.bin;
   p.val = p.base + lo * p.bin;
   p.vah = p.base + (hi + 1) * p.bin;
   p.valid = true;
  }

double ProfileBin()
  {
   double a = AtrOf(g_d1);
   double b = (a > 0.0) ? a / 60.0 : 50.0 * g_tick;
   return MathMax(10.0 * g_tick, NormPrice(b));
  }

//--- barra M5 chiusa -> profilo del giorno del broker
void ProfileFeed(datetime dayAnchorNow, datetime barTime, double lo, double hi, double v)
  {
   if(barTime >= dayAnchorNow && g_prof[g_profCur].anchor != dayAnchorNow)
     {
      //--- 1.28: il profilo che era "ieri" diventa "l'altro ieri" (prima di essere riusato per il giorno nuovo)
      g_ppOk = g_prof[1 - g_profCur].valid;
      g_ppVah = g_prof[1 - g_profCur].vah;
      g_ppVal = g_prof[1 - g_profCur].val;
      g_ppPoc = g_prof[1 - g_profCur].poc;
      g_ppBars = g_prof[1 - g_profCur].bars;
      ProfCompute(g_prof[g_profCur]);
      g_profCur = 1 - g_profCur;
      ProfReset(g_prof[g_profCur], dayAnchorNow, (lo + hi) / 2.0, ProfileBin());
     }
   ProfAddBar(g_prof[g_profCur], lo, hi, v);
  }

void ProfileInit()
  {
   datetime today = iTime(g_sym, PERIOD_D1, 0);
   datetime yday = iTime(g_sym, PERIOD_D1, 1);
   double bin = ProfileBin();
   double ref = PxBid();
   g_profCur = 0;
   ProfReset(g_prof[1], yday, ref, bin);
   ProfReset(g_prof[0], today, ref, bin);
   MqlRates b[];
   datetime curM5 = iTime(g_sym, PERIOD_M5, 0);
   int got = CopyRates(g_sym, PERIOD_M5, yday, curM5, b);
   for(int i = 0; i < got; i++)
     {
      if(b[i].time >= curM5)
         continue;
      if(b[i].time < today)
         ProfAddBar(g_prof[1], b[i].low, b[i].high, (double)b[i].tick_volume);
      else
         ProfAddBar(g_prof[0], b[i].low, b[i].high, (double)b[i].tick_volume);
     }
   ProfCompute(g_prof[1]);
   ProfCompute(g_prof[0]);
   //--- 1.28: l'altro ieri, per sapere da subito se il mercato e' in equilibrio
   g_ppOk = false;
   g_ppVah = 0.0;
   g_ppVal = 0.0;
   g_ppPoc = 0.0;
   g_ppBars = 0;
   datetime d2 = iTime(g_sym, PERIOD_D1, 2);
   if(d2 > 0 && d2 < yday)
     {
      Profile t;
      ProfReset(t, d2, ref, bin);
      MqlRates c[];
      int g2 = CopyRates(g_sym, PERIOD_M5, d2, yday, c);
      for(int i = 0; i < g2; i++)
         if(c[i].time >= d2 && c[i].time < yday)
            ProfAddBar(t, c[i].low, c[i].high, (double)c[i].tick_volume);
      ProfCompute(t);
      g_ppOk = t.valid;
      g_ppVah = t.vah;
      g_ppVal = t.val;
      g_ppPoc = t.poc;
      g_ppBars = t.bars;
     }
  }

bool PrevProfileOk() { return g_prof[1 - g_profCur].valid; }
double PrevVAH() { return g_prof[1 - g_profCur].vah; }
double PrevVAL() { return g_prof[1 - g_profCur].val; }
double PrevPOC() { return g_prof[1 - g_profCur].poc; }
int    PrevProfBars() { return g_prof[1 - g_profCur].bars; }

//+------------------------------------------------------------------+
//| VSA: climax e assorbimento                                       |
//+------------------------------------------------------------------+
//--- barra di climax nella direzione 'dir' (volume molto alto, barra ampia, chiusura all'estremo)
bool IsClimax(const TfData &d, int sh, int dir)
  {
   double a = Ind(d.atr, sh + 1);
   if(a <= 0.0)
      return false;
   double rg = BarH(d, sh) - BarL(d, sh);
   if(RvolBar(d, sh) < 2.2 || rg < 1.5 * a)
      return false;
   double cp = ClosePos(d, sh);
   if(dir > 0)
      return (BarC(d, sh) > BarO(d, sh) && cp > 0.7);
   return (BarC(d, sh) < BarO(d, sh) && cp < 0.3);
  }

//--- assorbimento: molto volume ma poco movimento
bool IsAbsorption(const TfData &d, int sh)
  {
   double a = Ind(d.atr, sh + 1);
   if(a <= 0.0)
      return false;
   double rg = BarH(d, sh) - BarL(d, sh);
   return (RvolBar(d, sh) >= 1.8 && rg <= 0.6 * a);
  }

//+------------------------------------------------------------------+
//| DOM (book) - solo se il broker lo fornisce                       |
//+------------------------------------------------------------------+
bool     g_domOn = false;
double   g_domImb = 0.0;
datetime g_domTime = 0;

bool DomFresh() { return (g_domOn && TimeCurrent() - g_domTime <= 10); }

void DomUpdate()
  {
   MqlBookInfo book[];
   if(!MarketBookGet(g_sym, book))
      return;
   int n = ArraySize(book);
   double bv = 0.0, av = 0.0;
   for(int i = 0; i < n; i++)
     {
      double v = (book[i].volume_real > 0.0) ? book[i].volume_real : (double)book[i].volume;
      if(book[i].type == BOOK_TYPE_BUY || book[i].type == BOOK_TYPE_BUY_MARKET)
         bv += v;
      else
         if(book[i].type == BOOK_TYPE_SELL || book[i].type == BOOK_TYPE_SELL_MARKET)
            av += v;
     }
   if(bv + av <= 0.0)
      return;
   g_domImb = (bv - av) / (bv + av);
   g_domTime = TimeCurrent();
  }
