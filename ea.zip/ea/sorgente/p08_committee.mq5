//--- C3 (1.20): spinta agli stop run quando Asia e' stretta
bool TightAsiaBonus(const TSignal &s)
  {
   if(!InpC3TightAsia)
      return false;
   if(s.strat != ST_SC_SWEEP && s.strat != ST_IN_SWEEP)
      return false;
   return TightAsia();
  }

//+------------------------------------------------------------------+
//| Comitato: ogni desk vota 0..1 (e puo' mettere il veto),          |
//| poi avvocato del diavolo, quorum e punteggio pesato per motore   |
//+------------------------------------------------------------------+
double DeskWeight(int engine, int desk)
  {
   if(engine == ENG_SCALP)
     {
      switch(desk)
        {
         case D_STRAT:   return 0.15;
         case D_TREND:   return 0.08;
         case D_VOLUME:  return 0.16;
         case D_LIQ:     return 0.10;
         case D_MACRO:   return 0.08;
         case D_NEWS:    return 0.05;
         case D_SESSION: return 0.09;
         case D_COST:    return 0.13;
         case D_STATS:   return 0.06;
         case D_CONTEXT: return 0.10;
        }
      return 0.0;
     }
   if(engine == ENG_INTRA)
     {
      switch(desk)
        {
         case D_STRAT:   return 0.16;
         case D_TREND:   return 0.10;
         case D_VOLUME:  return 0.12;
         case D_LIQ:     return 0.10;
         case D_MACRO:   return 0.14;
         case D_NEWS:    return 0.04;
         case D_SESSION: return 0.05;
         case D_COST:    return 0.07;
         case D_STATS:   return 0.08;
         case D_CONTEXT: return 0.14;
        }
      return 0.0;
     }
   switch(desk)
     {
      case D_STRAT:   return 0.14;
      case D_TREND:   return 0.10;
      case D_VOLUME:  return 0.08;
      case D_LIQ:     return 0.08;
      case D_MACRO:   return 0.20;
      case D_NEWS:    return 0.03;
      case D_SESSION: return 0.02;
      case D_COST:    return 0.03;
      case D_STATS:   return 0.10;
      case D_CONTEXT: return 0.22;
     }
   return 0.0;
  }

double MinScoreFor(int engine)
  {
   if(engine == ENG_SCALP)
      return InpMinScoreScalp;
   if(engine == ENG_INTRA)
      return InpMinScoreIntra;
   return InpMinScoreSwing;
  }

//--- OF1 (1.25): prezzo M1 a un orario UTC (apertura della prima barra M1 da quell'orario in poi)
double M1PriceAtUtc(datetime tUtc)
  {
   int lim = MathMin(g_m1.n, 240);
   for(int sh = 0; sh < lim; sh++)
     {
      datetime t = ToUTC(BarT(g_m1, sh));
      if(t <= 0)
         return 0.0;
      if(t < tUtc)
        {
         if(sh == 0)
            return 0.0;
         if(ToUTC(BarT(g_m1, sh - 1)) > tUtc + 300)
            return 0.0;                      // buco nei dati: meglio non decidere
         return BarO(g_m1, sh - 1);
        }
     }
   return 0.0;
  }

//--- ora UTC del fixing LBMA del mattino (10:30 di Londra) nel giorno di 'utc'
datetime FixAmUtc(datetime utc)
  {
   datetime day = utc - (utc % 86400);
   return day + (IsUKDST(utc) ? 9 * 3600 + 1800 : 10 * 3600 + 1800);
  }

//--- OF1 (1.25): nei 15 minuti dopo il fixing delle 10:30 il movimento dei 15 minuti prima si gira
//    (M1 del demo 2022-2026: fade +1,2/+2,2 bp con movimento medio/grande in tutti e 4 i periodi; t -4,4,
//     unico quarto d'ora su 41 della giornata di Londra con questo comportamento)
bool FixChase(const TSignal &s, string &why)
  {
   if(!InpOF1FixNoChase || s.engine == ENG_SWING)
      return false;
   datetime now = g_ctx.nowUtc;
   datetime fx = FixAmUtc(now);
   if(now < fx || now >= fx + 900)
      return false;
   double a = M1PriceAtUtc(fx - 900);
   double b = M1PriceAtUtc(fx);
   if(a <= 0.0 || b <= 0.0)
      return false;
   double mv = (b / a - 1.0) * 10000.0;
   if(MathAbs(mv) < InpOF1MinBp || mv * s.dir <= 0.0)
      return false;
   why = "OF1 fixing di Londra: movimento 10:15-10:30 di " + DoubleToString(mv, 1) + " bp, nei 15 minuti dopo di solito si gira";
   return true;
  }

void Veto(TSignal &s, string why)
  {
   if(!s.veto)
     {
      s.veto = true;
      s.vetoWhy = why;
     }
   else
      if(StringLen(s.vetoWhy) < 120)
         s.vetoWhy += "; " + why;
  }

//+------------------------------------------------------------------+
//| MENO REGOLE (1.25)                                               |
//| - obiezioni obbligatorie (rischio, news, costi, prove vere) e    |
//|   obiezioni secondarie (trend, livelli, macro, contesto,         |
//|   avvocato del diavolo: mai provate contro il caso)              |
//| - conferme forti (7/8 desk, punteggio alto) scavalcano fino a 2  |
//|   obiezioni secondarie, con rischio ridotto                      |
//| - idee fantasma: ogni buona idea, presa o no, viene seguita fino |
//|   a stop/target; per ogni obiezione il bot confronta le idee con |
//|   e senza. Provata (fa perdere) -> blocca da sola; inutile ->    |
//|   non conta piu'. Stessa regola degli studi: 3 periodi su 4.     |
//+------------------------------------------------------------------+
#define NOBJ        16
#define NPER        4
#define OB_TREND2   0
#define OB_LEVEL    1
#define OB_MACROV   2
#define OB_CTXV     3
#define OB_RSIX     4
#define OB_RSIDIV   5
#define OB_LVL1R    6
#define OB_MACRO    7
#define OB_CTX      8
#define OB_EXH      9
#define OB_RANGE    10
#define OB_DELTA    11
#define OB_SESS     12
#define OB_LOST2    13
#define OB_VOLAT    14
#define OB_PRENEWS  15
#define OBS_TEST    0
#define OBS_USEFUL  1
#define OBS_USELESS 2
#define MAX_GHOST   48

string g_obName[NOBJ] = {"contro il trend su due timeframe", "livello forte vicino", "macro contraria forte", "contesto HTF contrario forte",
                         "RSI estremo", "divergenza RSI", "livello prima di 1R", "macro contraria", "contesto HTF contrario", "movimento esausto",
                         "prezzo agli estremi del range", "delta contrario", "sessione debole", "ultime 2 perse", "mercato volatile",
                         "vista pre-news contraria"};
double g_obN[NOBJ * NPER];      // idee fantasma chiuse CON l'obiezione, per periodo (2022, 2023, 2024, 2025-26)
double g_obS[NOBJ * NPER];      // somma dei loro R dopo i costi
double g_obQ[NOBJ * NPER];      // somma dei quadrati (per sapere quanto e' sicuro il confronto)
double g_obTotN[NPER];          // tutte le idee fantasma chiuse
double g_obTotS[NPER];
double g_obTotQ[NPER];
int    g_obState[NOBJ];
string g_devilProven = "";      // obiezioni dell'avvocato del diavolo provate (bloccano da sole)
int    g_overCount = 0;         // idee aperte scavalcando obiezioni secondarie (da quando parte l'EA)

struct TGhost
  {
   bool              active;
   int               strat;
   int               dir;
   int               engine;
   int               mask;
   double            entry;
   double            sl;
   double            tp;
   double            risk;
   double            costR;
   datetime          t0;
   datetime          tEnd;
  };
TGhost g_gh[MAX_GHOST];

void GhostInit()
  {
   for(int i = 0; i < MAX_GHOST; i++)
     {
      g_gh[i].active = false;
      g_gh[i].strat = 0;
      g_gh[i].dir = 0;
      g_gh[i].engine = 0;
      g_gh[i].mask = 0;
      g_gh[i].entry = 0.0;
      g_gh[i].sl = 0.0;
      g_gh[i].tp = 0.0;
      g_gh[i].risk = 0.0;
      g_gh[i].costR = 0.0;
      g_gh[i].t0 = 0;
      g_gh[i].tEnd = 0;
     }
  }

void ObjInit()
  {
   for(int i = 0; i < NOBJ * NPER; i++)
     {
      g_obN[i] = 0.0;
      g_obS[i] = 0.0;
      g_obQ[i] = 0.0;
     }
   for(int p = 0; p < NPER; p++)
     {
      g_obTotN[p] = 0.0;
      g_obTotS[p] = 0.0;
      g_obTotQ[p] = 0.0;
     }
   for(int k = 0; k < NOBJ; k++)
      g_obState[k] = OBS_TEST;
  }

int ObPeriod(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   int p = d.year - 2022;
   return (p < 0) ? 0 : ((p > NPER - 1) ? NPER - 1 : p);
  }

//--- casi e somme con e senza l'obiezione k (p < 0 = tutti i periodi)
void ObSums(int k, int p, double &nw, double &sw, double &no, double &so)
  {
   nw = 0.0;
   sw = 0.0;
   double nt = 0.0, st = 0.0;
   for(int q = 0; q < NPER; q++)
     {
      if(p >= 0 && q != p)
         continue;
      nw += g_obN[k * NPER + q];
      sw += g_obS[k * NPER + q];
      nt += g_obTotN[q];
      st += g_obTotS[q];
     }
   no = nt - nw;
   so = st - sw;
  }

//--- errore standard della differenza tra le medie con e senza l'obiezione
double ObSe(int k)
  {
   double nw = 0.0, sw = 0.0, qw = 0.0, nt = 0.0, st = 0.0, qt = 0.0;
   for(int q = 0; q < NPER; q++)
     {
      nw += g_obN[k * NPER + q];
      sw += g_obS[k * NPER + q];
      qw += g_obQ[k * NPER + q];
      nt += g_obTotN[q];
      st += g_obTotS[q];
      qt += g_obTotQ[q];
     }
   double no = nt - nw, so = st - sw, qo = qt - qw;
   if(nw < 2.0 || no < 2.0)
      return 99.0;
   double vw = MathMax((qw - sw * sw / nw) / (nw - 1.0), 0.0);
   double vo = MathMax((qo - so * so / no) / (no - 1.0), 0.0);
   return MathSqrt(vw / nw + vo / no);
  }

//--- giudizio su un'obiezione: provata, inutile o ancora da provare
//    provata: con l'obiezione si perde, almeno 0,10R peggio che senza, lontano dal caso (t <= -2,5: idee vicine nel tempo e controlli ripetuti), 3 periodi su 4
//    inutile: con l'obiezione si guadagna come senza e il danno possibile e' piccolo (diff - 1 errore >= -0,15R)
int ObjEvaluate(int k)
  {
   double nw, sw, no, so;
   ObSums(k, -1, nw, sw, no, so);
   if(nw < InpObjMinN || no < InpObjMinN)
      return OBS_TEST;
   double rw = sw / nw;
   double diff = rw - so / no;
   double se = ObSe(k);
   int perOk = 0, perWorse = 0, perHarmless = 0;
   for(int p = 0; p < NPER; p++)
     {
      double a, b, c, d;
      ObSums(k, p, a, b, c, d);
      if(a < 8.0 || c < 8.0)
         continue;
      perOk++;
      double dp = b / a - d / c;
      if(dp < 0.0)
         perWorse++;
      if(dp >= -0.05)
         perHarmless++;
     }
   //--- con meno di 3 periodi misurabili (conto vero, un anno solo) servono il doppio dei casi
   if(perOk < 3 && nw < 2.0 * InpObjMinN)
      return OBS_TEST;
   if(diff <= -0.10 && rw < 0.0 && diff <= -2.5 * se && (perOk < 3 || perWorse >= 3))
      return OBS_USEFUL;
   if(diff >= -0.02 && rw >= 0.0 && diff - se >= -0.15 && (perOk < 3 || perHarmless >= 3))
      return OBS_USELESS;
   return OBS_TEST;
  }

int ObjState(int k)
  {
   if(!InpObjLearn || k < 0 || k >= NOBJ)
      return OBS_TEST;
   return g_obState[k];
  }

string ObjStateName(int st)
  {
   if(st == OBS_USEFUL)
      return "provata (blocca da sola)";
   if(st == OBS_USELESS)
      return "inutile (non conta)";
   return "da provare";
  }

string ObjNumbers(int k)
  {
   double nw, sw, no, so;
   ObSums(k, -1, nw, sw, no, so);
   if(nw <= 0.0)
      return "nessun caso";
   return DoubleToString(sw / nw, 2) + "R con, " + (no > 0.0 ? DoubleToString(so / no, 2) : "-") + "R senza, " + DoubleToString(nw, 0) + " casi";
  }

void ObjRefresh(bool tell)
  {
   for(int k = 0; k < NOBJ; k++)
     {
      int st = InpObjLearn ? ObjEvaluate(k) : OBS_TEST;
      if(st != g_obState[k] && tell)
        {
         string m = "Meno regole: obiezione '" + g_obName[k] + "' ora " + ObjStateName(st) + " (" + ObjNumbers(k) + ")";
         if(g_isTester)
            Logf(m);
         else
            Notify(m);
        }
      g_obState[k] = st;
     }
  }

string ObjFile(bool tester) { return tester ? "XauCommittee_tester_obiezioni.csv" : "XauCommittee_" + IntegerToString(g_login) + "_obiezioni.csv"; }

void ObjSave()
  {
   if(g_isOptim || !InpObjLearn || g_obTotN[0] + g_obTotN[1] + g_obTotN[2] + g_obTotN[3] <= 0.0)
      return;
   int h = FileOpen(ObjFile(g_isTester), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   string hd = "obiezione;stato;casi_con;R_medio_con;R_medio_senza;n_2022;somma_R_2022;quad_2022;n_2023;somma_R_2023;quad_2023;";
   hd += "n_2024;somma_R_2024;quad_2024;n_2025_26;somma_R_2025_26;quad_2025_26\r\n";
   FileWriteString(h, hd);
   double nt = 0.0, st = 0.0;
   string per = "";
   for(int p = 0; p < NPER; p++)
     {
      nt += g_obTotN[p];
      st += g_obTotS[p];
      per += ";" + DoubleToString(g_obTotN[p], 0) + ";" + DoubleToString(g_obTotS[p], 3) + ";" + DoubleToString(g_obTotQ[p], 3);
     }
   FileWriteString(h, "tutte le idee;-;" + DoubleToString(nt, 0) + ";" + (nt > 0.0 ? DoubleToString(st / nt, 3) : "0") + ";-" + per + "\r\n");
   for(int k = 0; k < NOBJ; k++)
     {
      double nw, sw, no, so;
      ObSums(k, -1, nw, sw, no, so);
      string l = g_obName[k] + ";" + ObjStateName(g_obState[k]) + ";" + DoubleToString(nw, 0) + ";" + (nw > 0.0 ? DoubleToString(sw / nw, 3) : "0") + ";" +
                 (no > 0.0 ? DoubleToString(so / no, 3) : "0");
      for(int p = 0; p < NPER; p++)
         l += ";" + DoubleToString(g_obN[k * NPER + p], 0) + ";" + DoubleToString(g_obS[k * NPER + p], 3) + ";" + DoubleToString(g_obQ[k * NPER + p], 3);
      FileWriteString(h, l + "\r\n");
     }
   FileClose(h);
  }

//--- legge un file delle obiezioni; restituisce le idee fantasma che contiene
double ObjReadFile(string f)
  {
   ObjInit();
   if(!FileIsExist(f, FILE_COMMON))
      return 0.0;
   int h = FileOpen(f, FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return 0.0;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      int np = StringSplit(l, ';', p);
      if(np < 5 + 3 * NPER)
         continue;
      int k = -2;
      if(p[0] == "tutte le idee")
         k = -1;
      else
         for(int j = 0; j < NOBJ; j++)
            if(p[0] == g_obName[j])
               k = j;
      if(k == -2)
         continue;
      for(int q = 0; q < NPER; q++)
        {
         double n = MathMax(StringToDouble(p[5 + 3 * q]), 0.0);
         double s = StringToDouble(p[6 + 3 * q]);
         double qq = MathMax(StringToDouble(p[7 + 3 * q]), 0.0);
         if(k == -1)
           {
            g_obTotN[q] = n;
            g_obTotS[q] = s;
            g_obTotQ[q] = qq;
           }
         else
           {
            g_obN[k * NPER + q] = n;
            g_obS[k * NPER + q] = s;
            g_obQ[k * NPER + q] = qq;
           }
        }
     }
   FileClose(h);
   //--- un file rovinato non deve far credere al bot di sapere: i casi con l'obiezione mai piu' del totale
   for(int k = 0; k < NOBJ; k++)
      for(int q = 0; q < NPER; q++)
         if(g_obN[k * NPER + q] > g_obTotN[q])
           {
            g_obN[k * NPER + q] = 0.0;
            g_obS[k * NPER + q] = 0.0;
            g_obQ[k * NPER + q] = 0.0;
           }
   return g_obTotN[0] + g_obTotN[1] + g_obTotN[2] + g_obTotN[3];
  }

//--- carica quello che e' gia' stato imparato (conto: il suo file, altrimenti quello del Tester)
void ObjLoad()
  {
   ObjInit();
   if(g_isTester || !InpObjLearn)
      return;                                   // nel Tester si impara da zero, come in una prova vera
   double nt = ObjReadFile(ObjFile(false));
   if(nt <= 0.0 && InpObjFromTester)
     {
      nt = ObjReadFile(ObjFile(true));
      if(nt > 0.0)
         Notify("Meno regole: parto da quello che ha imparato il Tester (" + DoubleToString(nt, 0) + " idee fantasma)");
     }
   ObjRefresh(false);
  }

//--- una buona idea (punteggio e quorum sufficienti), presa o no, diventa un'idea fantasma
void GhostAdd(const TSignal &s)
  {
   if(!InpObjLearn || g_isOptim)
      return;
   double risk = RiskPx(s);
   if(risk <= 0.0 || s.tp == 0.0 || s.score < MinScoreFor(s.engine) || s.quorum < InpQuorum)
      return;
   int fr = -1;
   for(int i = 0; i < MAX_GHOST; i++)
     {
      if(g_gh[i].active)
        {
         if(g_gh[i].strat == s.strat && g_gh[i].dir == s.dir)
            return;                             // la stessa idea ripetuta conta una volta sola
        }
      else
         if(fr < 0)
            fr = i;
     }
   if(fr < 0)
      return;
   datetime now = TimeCurrent();
   int life = (s.engine == ENG_SCALP) ? 240 : ((s.engine == ENG_INTRA) ? 1440 : 7200);
   g_gh[fr].active = true;
   g_gh[fr].strat = s.strat;
   g_gh[fr].dir = s.dir;
   g_gh[fr].engine = s.engine;
   g_gh[fr].mask = s.objMask;
   g_gh[fr].entry = s.entry;
   g_gh[fr].sl = s.sl;
   g_gh[fr].tp = s.tp;
   g_gh[fr].risk = risk;
   g_gh[fr].costR = (g_ctx.spread + CommissionPx() + SlipEstPx(g_ctx.spread)) / risk;
   g_gh[fr].t0 = (datetime)((long)now - (long)now % 60);
   g_gh[fr].tEnd = now + life * 60;
  }

void GhostClose(int i, double r)
  {
   int p = ObPeriod(g_gh[i].t0);
   g_obTotN[p] += 1.0;
   g_obTotS[p] += r;
   g_obTotQ[p] += r * r;
   for(int k = 0; k < NOBJ; k++)
      if((g_gh[i].mask & (1 << k)) != 0)
        {
         g_obN[k * NPER + p] += 1.0;
         g_obS[k * NPER + p] += r;
         g_obQ[k * NPER + p] += r * r;
        }
   g_gh[i].active = false;
  }

//--- a ogni nuova M1: le idee fantasma toccano stop (prima, se nella stessa barra) o target, o scadono
void GhostUpdate()
  {
   if(!InpObjLearn)
      return;
   datetime bt = BarT(g_m1, 1);
   if(bt <= 0)
      return;
   double hi = BarH(g_m1, 1), lo = BarL(g_m1, 1), cl = BarC(g_m1, 1);
   bool changed = false;
   for(int i = 0; i < MAX_GHOST; i++)
     {
      if(!g_gh[i].active || bt <= g_gh[i].t0)
         continue;                              // la barra in cui e' nata l'idea non conta
      int d = g_gh[i].dir;
      bool hitSl = (d > 0) ? (lo <= g_gh[i].sl) : (hi >= g_gh[i].sl);
      bool hitTp = (d > 0) ? (hi >= g_gh[i].tp) : (lo <= g_gh[i].tp);
      double r = 0.0;
      bool done = false;
      if(hitSl)
        {
         r = -1.0;
         done = true;
        }
      else
         if(hitTp)
           {
            r = (g_gh[i].tp - g_gh[i].entry) * d / g_gh[i].risk;
            done = true;
           }
         else
            if(bt + 60 >= g_gh[i].tEnd)
              {
               r = (cl - g_gh[i].entry) * d / g_gh[i].risk;
               done = true;
              }
      if(!done)
         continue;
      GhostClose(i, Clamp(r, -1.5, 10.0) - g_gh[i].costR);
      changed = true;
     }
   if(changed)
     {
      ObjRefresh(true);
      if(!g_isTester)
         ObjSave();
     }
  }

int GhostOpen()
  {
   int c = 0;
   for(int i = 0; i < MAX_GHOST; i++)
      if(g_gh[i].active)
         c++;
   return c;
  }

//--- obiezione secondaria: blocca solo se non ci sono conferme forti (deciso alla fine del comitato)
void SoftVeto(TSignal &s, int k, string why)
  {
   s.objMask |= (1 << k);
   int st = ObjState(k);
   if(st == OBS_USELESS)
      return;                                   // misurata: non serve, non blocca
   if(st == OBS_USEFUL)
     {
      Veto(s, why + " (obiezione provata)");
      return;
     }
   s.softN++;
   s.softWhy += (s.softWhy == "" ? "" : "; ") + why;
  }

//--- elenco leggibile delle obiezioni presenti (per il diario)
string ObjList(int mask)
  {
   string t = "";
   for(int k = 0; k < NOBJ; k++)
      if((mask & (1 << k)) != 0)
        {
         int st = ObjState(k);
         t += (t == "" ? "" : ", ") + g_obName[k] + (st == OBS_USEFUL ? " (provata)" : (st == OBS_USELESS ? " (inutile)" : ""));
        }
   return t;
  }

string ObjPanel()
  {
   int u = 0, z = 0, t = 0;
   for(int k = 0; k < NOBJ; k++)
     {
      int st = ObjState(k);
      if(st == OBS_USEFUL)
         u++;
      else
         if(st == OBS_USELESS)
            z++;
         else
            t++;
     }
   double nt = g_obTotN[0] + g_obTotN[1] + g_obTotN[2] + g_obTotN[3];
   return "Meno regole: obiezioni provate " + IntegerToString(u) + ", inutili " + IntegerToString(z) + ", da provare " + IntegerToString(t) +
          " | idee fantasma chiuse " + DoubleToString(nt, 0) + ", in corso " + IntegerToString(GhostOpen()) +
          " | scavalcate " + IntegerToString(g_overCount);
  }

void ObjReport()
  {
   if(!InpObjLearn)
      return;
   double nt = g_obTotN[0] + g_obTotN[1] + g_obTotN[2] + g_obTotN[3];
   double st = g_obTotS[0] + g_obTotS[1] + g_obTotS[2] + g_obTotS[3];
   Logf("Meno regole: " + DoubleToString(nt, 0) + " idee fantasma, R medio " + (nt > 0.0 ? DoubleToString(st / nt, 3) : "-") + " dopo i costi");
   for(int k = 0; k < NOBJ; k++)
     {
      double nw, sw, no, so;
      ObSums(k, -1, nw, sw, no, so);
      if(nw > 0.0)
         Logf("  " + g_obName[k] + ": " + ObjStateName(g_obState[k]) + " | " + ObjNumbers(k));
     }
  }

//--- trend del timeframe di contesto (which=1 vicino, 2 superiore) per ogni motore
int CtxTrend(int engine, int which)
  {
   if(engine == ENG_SCALP)
      return (which == 1) ? TrendDir(g_m15) : TrendDir(g_h1);
   if(engine == ENG_INTRA)
      return (which == 1) ? TrendDir(g_h1) : TrendDir(g_h4);
   return (which == 1) ? TrendDir(g_h4) : EmaDir(g_d1);
  }

double CtxAdx(int engine)
  {
   if(engine == ENG_SCALP)
      return AdxOf(g_m15);
   if(engine == ENG_INTRA)
      return AdxOf(g_h1);
   return AdxOf(g_h4);
  }

double CtxRsi(int engine)
  {
   if(engine == ENG_SCALP)
      return Ind(g_m15.rsi, 0);
   if(engine == ENG_INTRA)
      return Ind(g_h1.rsi, 0);
   return Ind(g_h4.rsi, 0);
  }

double ExecRvol(int engine)
  {
   if(engine == ENG_SCALP)
      return RvolBar(g_m1, 0);
   if(engine == ENG_INTRA)
      return RvolBar(g_m5, 0);
   return RvolBar(g_h1, 0);
  }

int CvdWindow(int engine)
  {
   if(engine == ENG_SCALP)
      return 20;
   if(engine == ENG_INTRA)
      return 60;
   return 240;
  }

bool IsTrendLike(int stype) { return (stype == STYPE_TREND || stype == STYPE_BREAKOUT || stype == STYPE_NEWS); }

//--- climax contrario nelle ultime 3 barre del timeframe di esecuzione
bool ClimaxAgainst(int engine, int dir)
  {
   for(int sh = 0; sh < 3; sh++)
     {
      if(engine == ENG_SCALP && IsClimax(g_m1, sh, -dir))
         return true;
      if(engine == ENG_INTRA && IsClimax(g_m5, sh, -dir))
         return true;
      if(engine == ENG_SWING && IsClimax(g_h1, sh, -dir))
         return true;
     }
   return false;
  }

//--- DESK TREND
double DeskTrend(TSignal &s)
  {
   int a1 = CtxTrend(s.engine, 1) * s.dir;
   int a2 = CtxTrend(s.engine, 2) * s.dir;
   double adx = CtxAdx(s.engine);
   double sc;
   if(IsTrendLike(s.stype))
     {
      sc = 0.5 + 0.2 * a1 + 0.15 * a2;
      if(a1 > 0 && adx > 25.0)
         sc += 0.1;
      if(a1 < 0 && a2 < 0)
         SoftVeto(s, OB_TREND2, "contro il trend su due timeframe");
     }
   else
     {
      sc = 0.55;
      if(adx < 20.0)
         sc += 0.1;
      if(a1 < 0 && adx > 30.0)
         sc -= 0.25;
      if(a2 > 0)
         sc += 0.15;
      if(a2 < 0 && a1 < 0)
         sc -= 0.1;
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK VOLUMI (delta, VWAP, RVOL, VSA, DOM, order flow GC)
double DeskVolume(TSignal &s)
  {
   double sc = 0.5;
   double cr = MicroCvdRatio(CvdWindow(s.engine));
   s.cvdRatio = cr;
   if(InpOF2VolumeNeutral)
     {
      //--- OF2 (1.25): sul demo il volume tick non segue il volume vero del COMEX (correlazione 0,03 a parita' di ora)
      //    e delta, VWAP, climax e profilo non battono il caso: resta solo l'attivita' (RVOL), che prevede la volatilita'
      double rvn = ExecRvol(s.engine);
      if(rvn >= 1.2)
         sc += 0.1;
      else
         if(rvn < 0.6)
            sc -= 0.1;
      if(GcFresh() && MathAbs(g_gcDeltaTrend) > 0.2)
         sc += (g_gcDeltaTrend * s.dir > 0.0) ? 0.05 : -0.05;   // dati veri CME (solo con Databento)
      return Clamp(sc, 0.0, 1.0);
     }
   if(IsTrendLike(s.stype))
     {
      if(cr * s.dir > 0.05)
         sc += 0.15;
      else
         if(cr * s.dir < -0.05)
            sc -= 0.15;
     }
   else
     {
      double crs = MicroCvdRatio(5);
      if(crs * s.dir > 0.1)
         sc += 0.15;
      else
         if(crs * s.dir < -0.1)
            sc -= 0.1;
     }
   double vw = g_ctx.vwap, sg = g_ctx.vwSig;
   if(vw > 0.0)
     {
      if(IsTrendLike(s.stype))
         sc += ((s.entry - vw) * s.dir > 0.0) ? 0.1 : -0.1;
      else
         if(sg > 0.0 && (vw - s.entry) * s.dir >= sg)
            sc += 0.1;
     }
   double rv = ExecRvol(s.engine);
   if(rv >= 1.2)
      sc += 0.1;
   else
      if(rv < 0.6)
         sc -= 0.1;
   if(ClimaxAgainst(s.engine, s.dir))
      sc += IsTrendLike(s.stype) ? -0.15 : 0.1;
   //--- profilo di ieri: comprare vicino a VAL/POC (o vendere vicino a VAH/POC) e' un supporto
   if(PrevProfileOk())
     {
      double tol = 0.3 * g_ctx.atrM15;
      if(s.dir > 0 && (MathAbs(s.entry - PrevVAL()) < tol || MathAbs(s.entry - PrevPOC()) < tol))
         sc += 0.05;
      if(s.dir < 0 && (MathAbs(s.entry - PrevVAH()) < tol || MathAbs(s.entry - PrevPOC()) < tol))
         sc += 0.05;
     }
   if(s.engine == ENG_SCALP && DomFresh())
     {
      if(g_domImb * s.dir > 0.2)
         sc += 0.05;
      else
         if(g_domImb * s.dir < -0.2)
            sc -= 0.05;
     }
   if(GcFresh() && MathAbs(g_gcDeltaTrend) > 0.2)
      sc += (g_gcDeltaTrend * s.dir > 0.0) ? 0.05 : -0.05;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK LIQUIDITA' (strada libera verso il target, stop protetto)
double DeskLiquidity(TSignal &s)
  {
   double risk = RiskPx(s);
   double reward = (s.tp - s.entry) * s.dir;
   double sc = 0.5;
   int t = -1;
   double d = NearestLevelDist(s.entry, s.dir, 0.25 * risk, t);
   //--- ritorno alla media: il target E' un livello (VWAP/value area), i livelli intermedi fanno parte del percorso
   if(s.stype == STYPE_MEANREV)
     {
      s.obstacleR = 99.0;
      sc = 0.6;
      int tm = -1;
      double dm = NearestLevelDist(s.entry, -s.dir, 0.0, tm);
      if(dm > 0.0 && dm < risk * 0.95)
         sc += 0.1;
      return Clamp(sc, 0.0, 1.0);
     }
   if(d < 0.0)
     {
      sc += 0.2;
      s.obstacleR = 99.0;
     }
   else
     {
      double dR = d / risk;
      s.obstacleR = dR;
      if(dR >= reward / risk)
         sc += 0.2;
      else
         if(dR >= 1.5)
            sc += 0.1;
         else
            if(dR < 1.0)
              {
               sc -= 0.2;
               if(IsMajorLevel(t) && dR < 0.7)
                  SoftVeto(s, OB_LEVEL, "livello forte (" + g_lvName[t] + ") a " + DoubleToString(dR, 2) + "R");
              }
     }
   int t2 = -1;
   double ds = NearestLevelDist(s.entry, -s.dir, 0.0, t2);
   if(ds > 0.0 && ds < risk * 0.95)
      sc += 0.1;
   if(PriceOnMajorLevel(s.sl, 0.05 * g_ctx.atrM15))
      sc -= 0.1;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK MACRO (servizio GitHub + storico + intermarket dai simboli del broker)
double DeskMacro(TSignal &s)
  {
   if(MacroFresh() && g_macroHalt)
     {
      Veto(s, "servizio macro: stop (" + g_macroHaltReason + ")");
      return 0.0;
     }
   if(g_mConf <= 0.0)
      return 0.5;
   double al = g_mBias * s.dir;
   double sc = 0.5 + 0.45 * al * Clamp(g_mConf * 1.4, 0.0, 1.0);
   //--- il dollaro di oggi conta per chi lavora intraday
   if(s.engine != ENG_SWING && g_imOk)
      sc -= 0.08 * g_dollarFast * s.dir;
   if(AiFresh())
     {
      if(g_aiStance == "long")
         sc += 0.1 * g_aiConv * s.dir;
      else
         if(g_aiStance == "short")
            sc -= 0.1 * g_aiConv * s.dir;
         else
            if(g_aiStance == "stand_aside")
               sc -= 0.05;
     }
   //--- macro forte e contraria: niente trade di trend intraday/swing contro
   if(s.engine != ENG_SCALP && al <= -InpMacroVetoLevel && g_mConf >= 0.45)
     {
      if(IsTrendLike(s.stype) || s.engine == ENG_SWING)
         SoftVeto(s, OB_MACROV, "macro contraria (" + DoubleToString(g_mBias, 2) + ", " + g_mSource + ")");
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK CONTESTO HTF (struttura, ritracciamento, compressione/espansione)
double DeskContext(TSignal &s)
  {
   if(!g_cxD1.valid && !g_cxH4.valid)
      return 0.5;
   if(s.dir < 0 && IsTrendLike(s.stype) && T5Active(BarT(g_d1, 0)))
      Veto(s, "T5: crollo esausto sul D1, niente short di trend per " + IntegerToString(InpT5Days) + " giorni");
   double al = g_ctxBias * s.dir;
   int ph = PhaseFor(s.engine);
   int pdir = PhaseDirFor(s.engine);
   double retr = PhaseRetrFor(s.engine);
   double ext = PhaseExtFor(s.engine);
   double sc = 0.5;
   if(s.stype == STYPE_TREND || s.stype == STYPE_NEWS)
     {
      sc += 0.3 * al;
      if(!InpT2NoDiscountBonus && pdir == s.dir && ph == PH_RITRACCIAMENTO && retr >= 0.382 && retr <= 0.786)
         sc += 0.12;                                    // compra lo sconto dentro il trend (spento da T2)
      if(!InpT2NoDiscountBonus && pdir == s.dir && (ph == PH_IMPULSO || ph == PH_ESPANSIONE) && retr < 0.236)
         sc -= 0.08;                                    // inseguire l'estensione (spento da T2)
      if(ph == PH_ESAURIMENTO && ext * s.dir > 0.0)
         sc -= 0.15;                                    // entrare nel verso di un movimento esausto
      if(s.engine != ENG_SCALP && al <= -InpContextVetoLevel)
         SoftVeto(s, OB_CTXV, "contesto dei timeframe alti contrario (" + DoubleToString(g_ctxBias, 2) + ")");
     }
   else
      if(s.stype == STYPE_BREAKOUT)
        {
         sc += 0.2 * al;
         if(ph == PH_COMPRESSIONE || g_cxD1.phase == PH_COMPRESSIONE)
            sc += 0.15;                                 // energia accumulata: la rottura ha piu' benzina
         if(ph == PH_ESAURIMENTO)
            sc -= 0.15;
         if(s.engine != ENG_SCALP && al <= -InpContextVetoLevel)
            SoftVeto(s, OB_CTXV, "contesto dei timeframe alti contrario (" + DoubleToString(g_ctxBias, 2) + ")");
        }
      else
        {
         sc += 0.1 * al;
         if(ph == PH_ESAURIMENTO && ext * s.dir < 0.0)
            sc += 0.15;                                 // inversione contro un movimento esausto
         if((ph == PH_IMPULSO || ph == PH_ESPANSIONE) && pdir == -s.dir)
            sc -= 0.15;                                 // contro un impulso fresco
         if(ph == PH_LATERALE || ph == PH_COMPRESSIONE)
            sc += 0.05;
        }
   //--- premium / discount del range giornaliero
   double rp = g_cxD1.rangePos;
   if(g_cxD1.valid)
     {
      if((s.dir > 0 && rp < 0.35) || (s.dir < 0 && rp > 0.65))
         sc += 0.06;
      else
         if((s.dir > 0 && rp > 0.85) || (s.dir < 0 && rp < 0.15))
            sc -= 0.08;
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK NEWS
double DeskNews(TSignal &s)
  {
   string why = "";
   if(NewsBlocked(s.engine, g_ctx.nowUtc, s.strat, why))
     {
      Veto(s, why);
      return 0.0;
     }
   if(s.strat == ST_IN_NEWS)
      return 0.75;
   double sc = 0.6;
   int mins = MinutesToNextTier1(g_ctx.nowUtc);
   int horizon = (s.engine == ENG_SWING) ? 720 : 120;
   if(mins >= 0 && mins < horizon)
      sc = 0.4;
   int v = NextEventView(g_ctx.nowUtc, 600);
   if(v != 0)
      sc += (v == s.dir) ? 0.1 : -0.15;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK SESSIONE
double DeskSession(TSignal &s)
  {
   double h = g_ctx.hUtc;
   double lo = g_ctx.lonOpen, nyd = g_ctx.nyData, nyo = g_ctx.nyOpen, nyc = g_ctx.nyClose;
   double sc = 0.6;
   if(s.engine == ENG_SCALP)
     {
      if(h >= nyd - 0.25 && h < nyo + 2.5)
         sc = 0.8;
      else
         if(h >= lo && h < lo + 3.0)
            sc = 0.75;
         else
            if(h >= lo && h < nyd)
               sc = 0.55;
            else
               if(h < lo)
                  sc = 0.25;
               else
                  sc = 0.4;
     }
   else
      if(s.engine == ENG_INTRA)
        {
         if(h >= lo && h < nyc - 2.0)
            sc = 0.7;
         else
            if(h < lo)
               sc = 0.35;
            else
               sc = 0.4;
        }
   if(g_ctx.dow == 5 && h >= 16.0)
      sc -= 0.2;
   if(g_ctx.dow == 1 && h < lo)
      sc -= 0.1;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK COSTI (spread + commissione rispetto allo stop)
double DeskCost(TSignal &s)
  {
   double risk = RiskPx(s);
   if(risk <= 0.0)
      return 0.0;
   double cost = g_ctx.spread + CommissionPx() + SlipEstPx(g_ctx.spread);   // K (1.25): slittamento e commissioni misurati
   double cr = cost / risk;
   if(cr > InpMaxCostR)
      Veto(s, "costi " + DoubleToString(cr * 100.0, 0) + "% di R");
   if(SpreadAbnormal())
      Veto(s, "spread anomalo");
   return Clamp(1.0 - cr * 4.0, 0.0, 1.0);
  }

//--- DESK STATISTICA (risultati reali della strategia + adattamento al regime)
double DeskStats(TSignal &s)
  {
   double sc = 0.5;
   int k = s.strat;
   if(g_ss[k].n >= 10)
      sc += Clamp(g_ss[k].Expectancy(), -0.5, 0.5) * 0.6;
   int rl = g_ss[k].RecentLosses(5);
   if(rl >= 4)
      sc -= 0.15;
   else
      if(rl >= 3)
         sc -= 0.1;
   sc += RegimeFit(s.stype);
   if(InpUseBench && InpOnlyStrategy == PICK_ALL && g_ss[k].benchUntil > TimeCurrent())
      Veto(s, "strategia in panchina fino al " + TimeToString(g_ss[k].benchUntil, TIME_DATE));
   return Clamp(sc, 0.0, 1.0);
  }

//--- controlli di portafoglio (slot, direzione, limiti giornalieri)
void PortfolioChecks(TSignal &s)
  {
   PortfolioScan();
   if(g_cntAll >= MaxPositionsEff())
      Veto(s, "posizioni massime (" + IntegerToString(MaxPositionsEff()) + ")");
   if(g_cntEng[s.engine] >= EngineMaxPos(s.engine))
      Veto(s, "slot del motore " + g_engName[s.engine] + " pieni");
   int opp = (s.dir > 0) ? g_cntDir[1] : g_cntDir[0];
   if(opp > 0)
      Veto(s, "c'e' una posizione opposta a rischio");
   int maxDay = (s.engine == ENG_SCALP) ? InpScalpMaxTradesDay : ((s.engine == ENG_INTRA) ? InpIntraMaxTradesDay : InpSwingMaxTradesDay);
   if(g_tradesToday[s.engine] >= maxDay)
      Veto(s, "trade massimi di oggi per " + g_engName[s.engine]);
   if(g_lossesInRowToday >= InpMaxLossesInRowDay)
      Veto(s, IntegerToString(g_lossesInRowToday) + " perdite di fila oggi");
  }

//--- AVVOCATO DEL DIAVOLO: conta gli argomenti contrari
//    MR (1.25): un argomento misurato come inutile non conta; uno provato blocca da solo
void DevilItem(TSignal &s, int k, int &c, string &list)
  {
   s.objMask |= (1 << k);
   int st = ObjState(k);
   if(st == OBS_USELESS)
      return;
   if(st == OBS_USEFUL)
      g_devilProven += (g_devilProven == "" ? "" : ", ") + g_obName[k];
   c++;
   list += g_obName[k] + "; ";
  }

int DevilsAdvocate(TSignal &s, string &list)
  {
   int c = 0;
   list = "";
   g_devilProven = "";
   double rsi = CtxRsi(s.engine);
   if(IsTrendLike(s.stype) && ((s.dir > 0 && rsi > 75.0) || (s.dir < 0 && rsi < 25.0)))
      DevilItem(s, OB_RSIX, c, list);
   bool div = false;
   if(s.engine == ENG_SCALP)
      div = RsiDivergenceAgainst(g_m5, s.dir, 20);
   else
      if(s.engine == ENG_INTRA)
         div = RsiDivergenceAgainst(g_m15, s.dir, 20);
      else
         div = RsiDivergenceAgainst(g_h4, s.dir, 20);
   if(IsTrendLike(s.stype) && div)
      DevilItem(s, OB_RSIDIV, c, list);
   if(s.obstacleR >= 0.0 && s.obstacleR < 1.0)
      DevilItem(s, OB_LVL1R, c, list);
   if(g_mBias * s.dir < -0.3 && g_mConf >= 0.4)
      DevilItem(s, OB_MACRO, c, list);
   if(g_ctxBias * s.dir < -0.3)
      DevilItem(s, OB_CTX, c, list);
   if(IsTrendLike(s.stype) && PhaseFor(s.engine) == PH_ESAURIMENTO && PhaseExtFor(s.engine) * s.dir > 0.0)
      DevilItem(s, OB_EXH, c, list);
   if(!InpT3NoRangeEdgeObj && IsTrendLike(s.stype) && g_cxD1.valid && ((s.dir > 0 && g_cxD1.rangePos > 0.9) || (s.dir < 0 && g_cxD1.rangePos < 0.1)))
      DevilItem(s, OB_RANGE, c, list);
   if(!InpOF2VolumeNeutral && s.cvdRatio * s.dir < -0.1)
      DevilItem(s, OB_DELTA, c, list);
   if(s.desk[D_SESSION] < 0.4)
      DevilItem(s, OB_SESS, c, list);
   if(g_ss[s.strat].RecentLosses(2) >= 2)
      DevilItem(s, OB_LOST2, c, list);
   if(g_regime == REG_VOLATILE)
      DevilItem(s, OB_VOLAT, c, list);
   int v = NextEventView(g_ctx.nowUtc, 600);
   if(v != 0 && v != s.dir)
      DevilItem(s, OB_PRENEWS, c, list);
   return c;
  }

//--- P5 (1.17): nelle ore asiatiche lo stop non resta appoggiato su un livello ovvio
bool ObviousLevel(int type)
  {
   return (type == LV_PDH || type == LV_PDL || type == LV_PWH || type == LV_PWL || type == LV_ASIAH || type == LV_ASIAL ||
           type == LV_ROUND || type == LV_ROUNDM);
  }

void AsiaStopAdjust(TSignal &s)
  {
   if(!InpP5AsiaStopBuffer)
      return;
   double h = g_ctx.hUtc;
   if(!(h >= 21.0 || h < g_ctx.lonOpen))
      return;
   double buf = InpP5BufferAtrH1 * g_ctx.atrH1;
   double risk = RiskPx(s);
   if(buf <= 0.0 || risk <= 0.0)
      return;
   double rr = (s.tp - s.entry) * s.dir / risk;
   double sl = s.sl;
   string moved = "";
   for(int pass = 0; pass < 3; pass++)
     {
      bool any = false;
      for(int i = 0; i < g_lvN; i++)
        {
         if(!ObviousLevel(g_lv[i].type))
            continue;
         double L = g_lv[i].price;
         if((s.entry - L) * s.dir <= 0.0)
            continue;                       // il livello deve stare dalla parte dello stop
         if(MathAbs(sl - L) > buf)
            continue;
         double target = (s.dir > 0) ? L - buf : L + buf + g_ctx.spread;
         if((sl - target) * s.dir > 0.0)
           {
            sl = target;
            any = true;
            moved = g_lvName[g_lv[i].type];
           }
        }
      if(!any)
         break;
     }
   if(moved == "")
      return;
   s.sl = NormPrice(sl);
   double nrisk = RiskPx(s);
   s.tp = NormPrice(s.entry + s.dir * nrisk * rr);
   s.why += " | P5 stop oltre " + moved + " (ore asiatiche)";
  }

//--- P6 (1.17): alla scadenza opzioni COMEX e il giorno dopo i breakout hanno meno strada
void ExpiryTargetAdjust(TSignal &s)
  {
   if(!InpP6ExpiryTargets || s.stype != STYPE_BREAKOUT)
      return;
   if(!IsExpiryWindow(EtYmd(g_ctx.nowUtc)))
      return;
   double risk = RiskPx(s);
   if(risk <= 0.0)
      return;
   double rr = (s.tp - s.entry) * s.dir / risk;
   double nr = MathMax(InpMinRR, rr * Clamp(InpP6TargetMult, 0.5, 1.0));
   if(nr >= rr)
      return;
   s.tp = NormPrice(s.entry + s.dir * risk * nr);
   s.why += " | P6 scadenza opzioni: target " + DoubleToString(nr, 2) + "R";
  }

//--- ritocchi del segnale prima del voto (P5, P6)
void SignalAdjust(TSignal &s)
  {
   AsiaStopAdjust(s);
   ExpiryTargetAdjust(s);
  }

//--- MR (1.25): le obiezioni secondarie bloccano, a meno di conferme forti
//    (nessun veto obbligatorio, 7/8 desk, punteggio sopra la soglia, strategia buona, al massimo 2 obiezioni)
bool StrongConfirm(const TSignal &s, double score)
  {
   return (InpOverrideOn && !s.veto && s.softN <= InpOverrideMaxSoft && s.quorum >= InpOverrideQuorum &&
           score >= MinScoreFor(s.engine) + InpOverrideExtraScore - 0.000001 && s.desk[D_STRAT] >= 0.6 && s.devil <= InpDevilMax + 1);
  }

void ResolveSoft(TSignal &s, double score)
  {
   s.overrideOk = false;
   if(s.softN <= 0)
      return;
   if(StrongConfirm(s, score))
      s.overrideOk = true;
   else
      Veto(s, s.softWhy);
  }

//--- il comitato vota il segnale
void Committee(TSignal &s)
  {
   double risk = RiskPx(s);
   double reward = (s.tp - s.entry) * s.dir;
   if(risk <= 0.0 || reward < InpMinRR * risk - g_tick)
      Veto(s, "R:R sotto 1:" + DoubleToString(InpMinRR, 1));
   //--- motori del prezzo (1.17)
   string thin = "";
   if(ThinLiquidity(g_ctx.nowUtc, g_ctx.hUtc, g_ctx.lonOpen, thin))
      Veto(s, thin);
   if(g_runBrake && s.dir > 0 && s.stype == STYPE_BREAKOUT)
      Veto(s, "P1 corsa verticale (" + DoubleToString(g_runZ, 1) + " sigma, distanza dalla media 200 " + DoubleToString(g_ma200Dist, 0) + "%): niente long in rottura");
   string fixWhy = "";
   if(FixChase(s, fixWhy))
      Veto(s, fixWhy);
   s.desk[D_STRAT] = s.quality;
   s.desk[D_TREND] = DeskTrend(s);
   s.desk[D_VOLUME] = DeskVolume(s);
   s.desk[D_LIQ] = DeskLiquidity(s);
   s.desk[D_MACRO] = DeskMacro(s);
   s.desk[D_NEWS] = DeskNews(s);
   s.desk[D_SESSION] = DeskSession(s);
   s.desk[D_COST] = DeskCost(s);
   s.desk[D_STATS] = DeskStats(s);
   s.desk[D_CONTEXT] = DeskContext(s);
   PortfolioChecks(s);
   string objections = "";
   s.devil = DevilsAdvocate(s, objections);
   if(g_devilProven != "")
      Veto(s, "obiezione provata: " + g_devilProven);
   if(s.devil >= InpDevilMax)
     {
      s.softN++;                            // MR (1.25): l'avvocato del diavolo e' un'obiezione secondaria
      if(s.softWhy != "")
         s.softWhy += "; ";
      s.softWhy += "avvocato del diavolo: " + objections;
     }
   //--- quorum sugli 8 desk principali
   s.quorum = 0;
   if(s.desk[D_CONTEXT] >= 0.5)
      s.quorum++;
   if(s.desk[D_MACRO] >= 0.5)
      s.quorum++;
   if(s.desk[D_STRAT] >= 0.5)
      s.quorum++;
   if(s.desk[D_TREND] >= 0.5)
      s.quorum++;
   if(s.desk[D_VOLUME] >= 0.5)
      s.quorum++;
   if(s.desk[D_LIQ] >= 0.5)
      s.quorum++;
   if(s.desk[D_NEWS] >= 0.5)
      s.quorum++;
   if(s.desk[D_COST] >= 0.5)
      s.quorum++;
   double score = 0.0;
   bool unanimous = true;
   for(int d = 0; d < NDESK; d++)
     {
      score += DeskWeight(s.engine, d) * s.desk[d];
      if(s.desk[d] < 0.55)
         unanimous = false;
     }
   if(unanimous)
      score += 0.03;
   if(InpP4FirstDayLong && s.dir > 0 && IsFirstTradingDay(EtYmd(g_ctx.nowUtc)))
      score += InpP4Bonus;                  // P4 (1.17): primo giorno di borsa del mese
   if(TightAsiaBonus(s))
      score += InpC3Bonus;                  // C3 (1.20): Asia stretta, piu' probabile la spazzata dei due lati
   s.score = score;
   ResolveSoft(s, score);
   //--- coda (1.17): con altre posizioni o ordini aperti, la nuova idea deve essere piu' sicura
   //    (solo per le idee che passerebbero da sole: le altre restano respinte con il loro motivo)
   if(InpQueueOn && !s.veto && g_cntAll > 0 && score >= MinScoreFor(s.engine) && s.quorum >= InpQuorum &&
      (score < MinScoreFor(s.engine) + InpQueueExtraScore || s.quorum < InpQuorum + 1))
      Veto(s, "coda: c'e' gia' una posizione aperta, servono punteggio " + DoubleToString(MinScoreFor(s.engine) + InpQueueExtraScore, 2) +
           " e quorum " + IntegerToString(InpQuorum + 1) + "/8");
   s.strong = (!s.veto && !s.overrideOk && score >= InpStrongScore && s.quorum >= 7);
   s.passed = (!s.veto && s.quorum >= InpQuorum && score >= MinScoreFor(s.engine));
  }

string DeskLine(const TSignal &s)
  {
   string t = "";
   for(int d = 0; d < NDESK; d++)
      t += g_deskShort[d] + " " + DoubleToString(s.desk[d], 2) + (d < NDESK - 1 ? " | " : "");
   return t;
  }
