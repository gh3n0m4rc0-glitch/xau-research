//--- C3 (1.20): spinta agli stop run quando Asia e' stretta
bool TightAsiaBonus(const TSignal &s)
  {
   if(!InpC3TightAsia)
      return false;
   if(s.strat != ST_SC_SWEEP && s.strat != ST_IN_SWEEP)
      return false;
   return TightAsia();
  }

//+------------------------------------------------------------------+
//| Comitato: ogni desk vota 0..1 (e puo' mettere il veto),          |
//| poi avvocato del diavolo, quorum e punteggio pesato per motore   |
//+------------------------------------------------------------------+
double DeskWeight(int engine, int desk)
  {
   if(engine == ENG_SCALP)
     {
      switch(desk)
        {
         case D_STRAT:   return 0.15;
         case D_TREND:   return 0.08;
         case D_VOLUME:  return 0.16;
         case D_LIQ:     return 0.10;
         case D_MACRO:   return 0.08;
         case D_NEWS:    return 0.05;
         case D_SESSION: return 0.09;
         case D_COST:    return 0.13;
         case D_STATS:   return 0.06;
         case D_CONTEXT: return 0.10;
        }
      return 0.0;
     }
   if(engine == ENG_INTRA)
     {
      switch(desk)
        {
         case D_STRAT:   return 0.16;
         case D_TREND:   return 0.10;
         case D_VOLUME:  return 0.12;
         case D_LIQ:     return 0.10;
         case D_MACRO:   return 0.14;
         case D_NEWS:    return 0.04;
         case D_SESSION: return 0.05;
         case D_COST:    return 0.07;
         case D_STATS:   return 0.08;
         case D_CONTEXT: return 0.14;
        }
      return 0.0;
     }
   switch(desk)
     {
      case D_STRAT:   return 0.14;
      case D_TREND:   return 0.10;
      case D_VOLUME:  return 0.08;
      case D_LIQ:     return 0.08;
      case D_MACRO:   return 0.20;
      case D_NEWS:    return 0.03;
      case D_SESSION: return 0.02;
      case D_COST:    return 0.03;
      case D_STATS:   return 0.10;
      case D_CONTEXT: return 0.22;
     }
   return 0.0;
  }

double MinScoreFor(int engine)
  {
   if(engine == ENG_SCALP)
      return InpMinScoreScalp;
   if(engine == ENG_INTRA)
      return InpMinScoreIntra;
   return InpMinScoreSwing;
  }

void Veto(TSignal &s, string why)
  {
   if(!s.veto)
     {
      s.veto = true;
      s.vetoWhy = why;
     }
   else
      if(StringLen(s.vetoWhy) < 120)
         s.vetoWhy += "; " + why;
  }

//--- trend del timeframe di contesto (which=1 vicino, 2 superiore) per ogni motore
int CtxTrend(int engine, int which)
  {
   if(engine == ENG_SCALP)
      return (which == 1) ? TrendDir(g_m15) : TrendDir(g_h1);
   if(engine == ENG_INTRA)
      return (which == 1) ? TrendDir(g_h1) : TrendDir(g_h4);
   return (which == 1) ? TrendDir(g_h4) : EmaDir(g_d1);
  }

double CtxAdx(int engine)
  {
   if(engine == ENG_SCALP)
      return AdxOf(g_m15);
   if(engine == ENG_INTRA)
      return AdxOf(g_h1);
   return AdxOf(g_h4);
  }

double CtxRsi(int engine)
  {
   if(engine == ENG_SCALP)
      return Ind(g_m15.rsi, 0);
   if(engine == ENG_INTRA)
      return Ind(g_h1.rsi, 0);
   return Ind(g_h4.rsi, 0);
  }

double ExecRvol(int engine)
  {
   if(engine == ENG_SCALP)
      return RvolBar(g_m1, 0);
   if(engine == ENG_INTRA)
      return RvolBar(g_m5, 0);
   return RvolBar(g_h1, 0);
  }

int CvdWindow(int engine)
  {
   if(engine == ENG_SCALP)
      return 20;
   if(engine == ENG_INTRA)
      return 60;
   return 240;
  }

bool IsTrendLike(int stype) { return (stype == STYPE_TREND || stype == STYPE_BREAKOUT || stype == STYPE_NEWS); }

//--- climax contrario nelle ultime 3 barre del timeframe di esecuzione
bool ClimaxAgainst(int engine, int dir)
  {
   for(int sh = 0; sh < 3; sh++)
     {
      if(engine == ENG_SCALP && IsClimax(g_m1, sh, -dir))
         return true;
      if(engine == ENG_INTRA && IsClimax(g_m5, sh, -dir))
         return true;
      if(engine == ENG_SWING && IsClimax(g_h1, sh, -dir))
         return true;
     }
   return false;
  }

//--- DESK TREND
double DeskTrend(TSignal &s)
  {
   int a1 = CtxTrend(s.engine, 1) * s.dir;
   int a2 = CtxTrend(s.engine, 2) * s.dir;
   double adx = CtxAdx(s.engine);
   double sc;
   if(IsTrendLike(s.stype))
     {
      sc = 0.5 + 0.2 * a1 + 0.15 * a2;
      if(a1 > 0 && adx > 25.0)
         sc += 0.1;
      if(a1 < 0 && a2 < 0)
         Veto(s, "contro il trend su due timeframe");
     }
   else
     {
      sc = 0.55;
      if(adx < 20.0)
         sc += 0.1;
      if(a1 < 0 && adx > 30.0)
         sc -= 0.25;
      if(a2 > 0)
         sc += 0.15;
      if(a2 < 0 && a1 < 0)
         sc -= 0.1;
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK VOLUMI (delta, VWAP, RVOL, VSA, DOM, order flow GC)
double DeskVolume(TSignal &s)
  {
   double sc = 0.5;
   double cr = MicroCvdRatio(CvdWindow(s.engine));
   s.cvdRatio = cr;
   if(IsTrendLike(s.stype))
     {
      if(cr * s.dir > 0.05)
         sc += 0.15;
      else
         if(cr * s.dir < -0.05)
            sc -= 0.15;
     }
   else
     {
      double crs = MicroCvdRatio(5);
      if(crs * s.dir > 0.1)
         sc += 0.15;
      else
         if(crs * s.dir < -0.1)
            sc -= 0.1;
     }
   double vw = g_ctx.vwap, sg = g_ctx.vwSig;
   if(vw > 0.0)
     {
      if(IsTrendLike(s.stype))
         sc += ((s.entry - vw) * s.dir > 0.0) ? 0.1 : -0.1;
      else
         if(sg > 0.0 && (vw - s.entry) * s.dir >= sg)
            sc += 0.1;
     }
   double rv = ExecRvol(s.engine);
   if(rv >= 1.2)
      sc += 0.1;
   else
      if(rv < 0.6)
         sc -= 0.1;
   if(ClimaxAgainst(s.engine, s.dir))
      sc += IsTrendLike(s.stype) ? -0.15 : 0.1;
   //--- profilo di ieri: comprare vicino a VAL/POC (o vendere vicino a VAH/POC) e' un supporto
   if(PrevProfileOk())
     {
      double tol = 0.3 * g_ctx.atrM15;
      if(s.dir > 0 && (MathAbs(s.entry - PrevVAL()) < tol || MathAbs(s.entry - PrevPOC()) < tol))
         sc += 0.05;
      if(s.dir < 0 && (MathAbs(s.entry - PrevVAH()) < tol || MathAbs(s.entry - PrevPOC()) < tol))
         sc += 0.05;
     }
   if(s.engine == ENG_SCALP && DomFresh())
     {
      if(g_domImb * s.dir > 0.2)
         sc += 0.05;
      else
         if(g_domImb * s.dir < -0.2)
            sc -= 0.05;
     }
   if(GcFresh() && MathAbs(g_gcDeltaTrend) > 0.2)
      sc += (g_gcDeltaTrend * s.dir > 0.0) ? 0.05 : -0.05;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK LIQUIDITA' (strada libera verso il target, stop protetto)
double DeskLiquidity(TSignal &s)
  {
   double risk = RiskPx(s);
   double reward = (s.tp - s.entry) * s.dir;
   double sc = 0.5;
   int t = -1;
   double d = NearestLevelDist(s.entry, s.dir, 0.25 * risk, t);
   //--- ritorno alla media: il target E' un livello (VWAP/value area), i livelli intermedi fanno parte del percorso
   if(s.stype == STYPE_MEANREV)
     {
      s.obstacleR = 99.0;
      sc = 0.6;
      int tm = -1;
      double dm = NearestLevelDist(s.entry, -s.dir, 0.0, tm);
      if(dm > 0.0 && dm < risk * 0.95)
         sc += 0.1;
      return Clamp(sc, 0.0, 1.0);
     }
   if(d < 0.0)
     {
      sc += 0.2;
      s.obstacleR = 99.0;
     }
   else
     {
      double dR = d / risk;
      s.obstacleR = dR;
      if(dR >= reward / risk)
         sc += 0.2;
      else
         if(dR >= 1.5)
            sc += 0.1;
         else
            if(dR < 1.0)
              {
               sc -= 0.2;
               if(IsMajorLevel(t) && dR < 0.7)
                  Veto(s, "livello forte (" + g_lvName[t] + ") a " + DoubleToString(dR, 2) + "R");
              }
     }
   int t2 = -1;
   double ds = NearestLevelDist(s.entry, -s.dir, 0.0, t2);
   if(ds > 0.0 && ds < risk * 0.95)
      sc += 0.1;
   if(PriceOnMajorLevel(s.sl, 0.05 * g_ctx.atrM15))
      sc -= 0.1;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK MACRO (servizio GitHub + storico + intermarket dai simboli del broker)
double DeskMacro(TSignal &s)
  {
   if(MacroFresh() && g_macroHalt)
     {
      Veto(s, "servizio macro: stop (" + g_macroHaltReason + ")");
      return 0.0;
     }
   if(g_mConf <= 0.0)
      return 0.5;
   double al = g_mBias * s.dir;
   double sc = 0.5 + 0.45 * al * Clamp(g_mConf * 1.4, 0.0, 1.0);
   //--- il dollaro di oggi conta per chi lavora intraday
   if(s.engine != ENG_SWING && g_imOk)
      sc -= 0.08 * g_dollarFast * s.dir;
   if(AiFresh())
     {
      if(g_aiStance == "long")
         sc += 0.1 * g_aiConv * s.dir;
      else
         if(g_aiStance == "short")
            sc -= 0.1 * g_aiConv * s.dir;
         else
            if(g_aiStance == "stand_aside")
               sc -= 0.05;
     }
   //--- macro forte e contraria: niente trade di trend intraday/swing contro
   if(s.engine != ENG_SCALP && al <= -InpMacroVetoLevel && g_mConf >= 0.45)
     {
      if(IsTrendLike(s.stype) || s.engine == ENG_SWING)
         Veto(s, "macro contraria (" + DoubleToString(g_mBias, 2) + ", " + g_mSource + ")");
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK CONTESTO HTF (struttura, ritracciamento, compressione/espansione)
double DeskContext(TSignal &s)
  {
   if(!g_cxD1.valid && !g_cxH4.valid)
      return 0.5;
   if(s.dir < 0 && IsTrendLike(s.stype) && T5Active(BarT(g_d1, 0)))
      Veto(s, "T5: crollo esausto sul D1, niente short di trend per " + IntegerToString(InpT5Days) + " giorni");
   double al = g_ctxBias * s.dir;
   int ph = PhaseFor(s.engine);
   int pdir = PhaseDirFor(s.engine);
   double retr = PhaseRetrFor(s.engine);
   double ext = PhaseExtFor(s.engine);
   double sc = 0.5;
   if(s.stype == STYPE_TREND || s.stype == STYPE_NEWS)
     {
      sc += 0.3 * al;
      if(!InpT2NoDiscountBonus && pdir == s.dir && ph == PH_RITRACCIAMENTO && retr >= 0.382 && retr <= 0.786)
         sc += 0.12;                                    // compra lo sconto dentro il trend (spento da T2)
      if(!InpT2NoDiscountBonus && pdir == s.dir && (ph == PH_IMPULSO || ph == PH_ESPANSIONE) && retr < 0.236)
         sc -= 0.08;                                    // inseguire l'estensione (spento da T2)
      if(ph == PH_ESAURIMENTO && ext * s.dir > 0.0)
         sc -= 0.15;                                    // entrare nel verso di un movimento esausto
      if(s.engine != ENG_SCALP && al <= -InpContextVetoLevel)
         Veto(s, "contesto dei timeframe alti contrario (" + DoubleToString(g_ctxBias, 2) + ")");
     }
   else
      if(s.stype == STYPE_BREAKOUT)
        {
         sc += 0.2 * al;
         if(ph == PH_COMPRESSIONE || g_cxD1.phase == PH_COMPRESSIONE)
            sc += 0.15;                                 // energia accumulata: la rottura ha piu' benzina
         if(ph == PH_ESAURIMENTO)
            sc -= 0.15;
         if(s.engine != ENG_SCALP && al <= -InpContextVetoLevel)
            Veto(s, "contesto dei timeframe alti contrario (" + DoubleToString(g_ctxBias, 2) + ")");
        }
      else
        {
         sc += 0.1 * al;
         if(ph == PH_ESAURIMENTO && ext * s.dir < 0.0)
            sc += 0.15;                                 // inversione contro un movimento esausto
         if((ph == PH_IMPULSO || ph == PH_ESPANSIONE) && pdir == -s.dir)
            sc -= 0.15;                                 // contro un impulso fresco
         if(ph == PH_LATERALE || ph == PH_COMPRESSIONE)
            sc += 0.05;
        }
   //--- premium / discount del range giornaliero
   double rp = g_cxD1.rangePos;
   if(g_cxD1.valid)
     {
      if((s.dir > 0 && rp < 0.35) || (s.dir < 0 && rp > 0.65))
         sc += 0.06;
      else
         if((s.dir > 0 && rp > 0.85) || (s.dir < 0 && rp < 0.15))
            sc -= 0.08;
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK NEWS
double DeskNews(TSignal &s)
  {
   string why = "";
   if(NewsBlocked(s.engine, g_ctx.nowUtc, s.strat, why))
     {
      Veto(s, why);
      return 0.0;
     }
   if(s.strat == ST_IN_NEWS)
      return 0.75;
   double sc = 0.6;
   int mins = MinutesToNextTier1(g_ctx.nowUtc);
   int horizon = (s.engine == ENG_SWING) ? 720 : 120;
   if(mins >= 0 && mins < horizon)
      sc = 0.4;
   int v = NextEventView(g_ctx.nowUtc, 600);
   if(v != 0)
      sc += (v == s.dir) ? 0.1 : -0.15;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK SESSIONE
double DeskSession(TSignal &s)
  {
   double h = g_ctx.hUtc;
   double lo = g_ctx.lonOpen, nyd = g_ctx.nyData, nyo = g_ctx.nyOpen, nyc = g_ctx.nyClose;
   double sc = 0.6;
   if(s.engine == ENG_SCALP)
     {
      if(h >= nyd - 0.25 && h < nyo + 2.5)
         sc = 0.8;
      else
         if(h >= lo && h < lo + 3.0)
            sc = 0.75;
         else
            if(h >= lo && h < nyd)
               sc = 0.55;
            else
               if(h < lo)
                  sc = 0.25;
               else
                  sc = 0.4;
     }
   else
      if(s.engine == ENG_INTRA)
        {
         if(h >= lo && h < nyc - 2.0)
            sc = 0.7;
         else
            if(h < lo)
               sc = 0.35;
            else
               sc = 0.4;
        }
   if(g_ctx.dow == 5 && h >= 16.0)
      sc -= 0.2;
   if(g_ctx.dow == 1 && h < lo)
      sc -= 0.1;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK COSTI (spread + commissione rispetto allo stop)
double DeskCost(TSignal &s)
  {
   double risk = RiskPx(s);
   if(risk <= 0.0)
      return 0.0;
   double cost = g_ctx.spread + CommissionPx() + 0.1 * g_ctx.spread;
   double cr = cost / risk;
   if(cr > InpMaxCostR)
      Veto(s, "costi " + DoubleToString(cr * 100.0, 0) + "% di R");
   if(SpreadAbnormal())
      Veto(s, "spread anomalo");
   return Clamp(1.0 - cr * 4.0, 0.0, 1.0);
  }

//--- DESK STATISTICA (risultati reali della strategia + adattamento al regime)
double DeskStats(TSignal &s)
  {
   double sc = 0.5;
   int k = s.strat;
   if(g_ss[k].n >= 10)
      sc += Clamp(g_ss[k].Expectancy(), -0.5, 0.5) * 0.6;
   int rl = g_ss[k].RecentLosses(5);
   if(rl >= 4)
      sc -= 0.15;
   else
      if(rl >= 3)
         sc -= 0.1;
   sc += RegimeFit(s.stype);
   if(InpUseBench && InpOnlyStrategy == PICK_ALL && g_ss[k].benchUntil > TimeCurrent())
      Veto(s, "strategia in panchina fino al " + TimeToString(g_ss[k].benchUntil, TIME_DATE));
   return Clamp(sc, 0.0, 1.0);
  }

//--- controlli di portafoglio (slot, direzione, limiti giornalieri)
void PortfolioChecks(TSignal &s)
  {
   PortfolioScan();
   if(g_cntAll >= MaxPositionsEff())
      Veto(s, "posizioni massime (" + IntegerToString(MaxPositionsEff()) + ")");
   if(g_cntEng[s.engine] >= EngineMaxPos(s.engine))
      Veto(s, "slot del motore " + g_engName[s.engine] + " pieni");
   int opp = (s.dir > 0) ? g_cntDir[1] : g_cntDir[0];
   if(opp > 0)
      Veto(s, "c'e' una posizione opposta a rischio");
   int maxDay = (s.engine == ENG_SCALP) ? InpScalpMaxTradesDay : ((s.engine == ENG_INTRA) ? InpIntraMaxTradesDay : InpSwingMaxTradesDay);
   if(g_tradesToday[s.engine] >= maxDay)
      Veto(s, "trade massimi di oggi per " + g_engName[s.engine]);
   if(g_lossesInRowToday >= InpMaxLossesInRowDay)
      Veto(s, IntegerToString(g_lossesInRowToday) + " perdite di fila oggi");
  }

//--- AVVOCATO DEL DIAVOLO: conta gli argomenti contrari
int DevilsAdvocate(TSignal &s, string &list)
  {
   int c = 0;
   list = "";
   double rsi = CtxRsi(s.engine);
   if(IsTrendLike(s.stype) && ((s.dir > 0 && rsi > 75.0) || (s.dir < 0 && rsi < 25.0)))
     {
      c++;
      list += "RSI estremo; ";
     }
   bool div = false;
   if(s.engine == ENG_SCALP)
      div = RsiDivergenceAgainst(g_m5, s.dir, 20);
   else
      if(s.engine == ENG_INTRA)
         div = RsiDivergenceAgainst(g_m15, s.dir, 20);
      else
         div = RsiDivergenceAgainst(g_h4, s.dir, 20);
   if(IsTrendLike(s.stype) && div)
     {
      c++;
      list += "divergenza RSI; ";
     }
   if(s.obstacleR >= 0.0 && s.obstacleR < 1.0)
     {
      c++;
      list += "livello prima di 1R; ";
     }
   if(g_mBias * s.dir < -0.3 && g_mConf >= 0.4)
     {
      c++;
      list += "macro contraria; ";
     }
   if(g_ctxBias * s.dir < -0.3)
     {
      c++;
      list += "contesto HTF contrario; ";
     }
   if(IsTrendLike(s.stype) && PhaseFor(s.engine) == PH_ESAURIMENTO && PhaseExtFor(s.engine) * s.dir > 0.0)
     {
      c++;
      list += "movimento esausto; ";
     }
   if(!InpT3NoRangeEdgeObj && IsTrendLike(s.stype) && g_cxD1.valid && ((s.dir > 0 && g_cxD1.rangePos > 0.9) || (s.dir < 0 && g_cxD1.rangePos < 0.1)))
     {
      c++;
      list += "prezzo agli estremi del range; ";
     }
   if(s.cvdRatio * s.dir < -0.1)
     {
      c++;
      list += "delta contrario; ";
     }
   if(s.desk[D_SESSION] < 0.4)
     {
      c++;
      list += "sessione debole; ";
     }
   if(g_ss[s.strat].RecentLosses(2) >= 2)
     {
      c++;
      list += "ultime 2 perse; ";
     }
   if(g_regime == REG_VOLATILE)
     {
      c++;
      list += "mercato volatile; ";
     }
   int v = NextEventView(g_ctx.nowUtc, 600);
   if(v != 0 && v != s.dir)
     {
      c++;
      list += "vista pre-news contraria; ";
     }
   return c;
  }

//--- P5 (1.17): nelle ore asiatiche lo stop non resta appoggiato su un livello ovvio
bool ObviousLevel(int type)
  {
   return (type == LV_PDH || type == LV_PDL || type == LV_PWH || type == LV_PWL || type == LV_ASIAH || type == LV_ASIAL ||
           type == LV_ROUND || type == LV_ROUNDM);
  }

void AsiaStopAdjust(TSignal &s)
  {
   if(!InpP5AsiaStopBuffer)
      return;
   double h = g_ctx.hUtc;
   if(!(h >= 21.0 || h < g_ctx.lonOpen))
      return;
   double buf = InpP5BufferAtrH1 * g_ctx.atrH1;
   double risk = RiskPx(s);
   if(buf <= 0.0 || risk <= 0.0)
      return;
   double rr = (s.tp - s.entry) * s.dir / risk;
   double sl = s.sl;
   string moved = "";
   for(int pass = 0; pass < 3; pass++)
     {
      bool any = false;
      for(int i = 0; i < g_lvN; i++)
        {
         if(!ObviousLevel(g_lv[i].type))
            continue;
         double L = g_lv[i].price;
         if((s.entry - L) * s.dir <= 0.0)
            continue;                       // il livello deve stare dalla parte dello stop
         if(MathAbs(sl - L) > buf)
            continue;
         double target = (s.dir > 0) ? L - buf : L + buf + g_ctx.spread;
         if((sl - target) * s.dir > 0.0)
           {
            sl = target;
            any = true;
            moved = g_lvName[g_lv[i].type];
           }
        }
      if(!any)
         break;
     }
   if(moved == "")
      return;
   s.sl = NormPrice(sl);
   double nrisk = RiskPx(s);
   s.tp = NormPrice(s.entry + s.dir * nrisk * rr);
   s.why += " | P5 stop oltre " + moved + " (ore asiatiche)";
  }

//--- P6 (1.17): alla scadenza opzioni COMEX e il giorno dopo i breakout hanno meno strada
void ExpiryTargetAdjust(TSignal &s)
  {
   if(!InpP6ExpiryTargets || s.stype != STYPE_BREAKOUT)
      return;
   if(!IsExpiryWindow(EtYmd(g_ctx.nowUtc)))
      return;
   double risk = RiskPx(s);
   if(risk <= 0.0)
      return;
   double rr = (s.tp - s.entry) * s.dir / risk;
   double nr = MathMax(InpMinRR, rr * Clamp(InpP6TargetMult, 0.5, 1.0));
   if(nr >= rr)
      return;
   s.tp = NormPrice(s.entry + s.dir * risk * nr);
   s.why += " | P6 scadenza opzioni: target " + DoubleToString(nr, 2) + "R";
  }

//--- ritocchi del segnale prima del voto (P5, P6)
void SignalAdjust(TSignal &s)
  {
   AsiaStopAdjust(s);
   ExpiryTargetAdjust(s);
  }

//--- il comitato vota il segnale
void Committee(TSignal &s)
  {
   double risk = RiskPx(s);
   double reward = (s.tp - s.entry) * s.dir;
   if(risk <= 0.0 || reward < InpMinRR * risk - g_tick)
      Veto(s, "R:R sotto 1:" + DoubleToString(InpMinRR, 1));
   //--- motori del prezzo (1.17)
   string thin = "";
   if(ThinLiquidity(g_ctx.nowUtc, g_ctx.hUtc, g_ctx.lonOpen, thin))
      Veto(s, thin);
   if(g_runBrake && s.dir > 0 && s.stype == STYPE_BREAKOUT)
      Veto(s, "P1 corsa verticale (" + DoubleToString(g_runZ, 1) + " sigma, distanza dalla media 200 " + DoubleToString(g_ma200Dist, 0) + "%): niente long in rottura");
   s.desk[D_STRAT] = s.quality;
   s.desk[D_TREND] = DeskTrend(s);
   s.desk[D_VOLUME] = DeskVolume(s);
   s.desk[D_LIQ] = DeskLiquidity(s);
   s.desk[D_MACRO] = DeskMacro(s);
   s.desk[D_NEWS] = DeskNews(s);
   s.desk[D_SESSION] = DeskSession(s);
   s.desk[D_COST] = DeskCost(s);
   s.desk[D_STATS] = DeskStats(s);
   s.desk[D_CONTEXT] = DeskContext(s);
   PortfolioChecks(s);
   string objections = "";
   s.devil = DevilsAdvocate(s, objections);
   if(s.devil >= InpDevilMax)
      Veto(s, "avvocato del diavolo: " + objections);
   //--- quorum sugli 8 desk principali
   s.quorum = 0;
   if(s.desk[D_CONTEXT] >= 0.5)
      s.quorum++;
   if(s.desk[D_MACRO] >= 0.5)
      s.quorum++;
   if(s.desk[D_STRAT] >= 0.5)
      s.quorum++;
   if(s.desk[D_TREND] >= 0.5)
      s.quorum++;
   if(s.desk[D_VOLUME] >= 0.5)
      s.quorum++;
   if(s.desk[D_LIQ] >= 0.5)
      s.quorum++;
   if(s.desk[D_NEWS] >= 0.5)
      s.quorum++;
   if(s.desk[D_COST] >= 0.5)
      s.quorum++;
   double score = 0.0;
   bool unanimous = true;
   for(int d = 0; d < NDESK; d++)
     {
      score += DeskWeight(s.engine, d) * s.desk[d];
      if(s.desk[d] < 0.55)
         unanimous = false;
     }
   if(unanimous)
      score += 0.03;
   if(InpP4FirstDayLong && s.dir > 0 && IsFirstTradingDay(EtYmd(g_ctx.nowUtc)))
      score += InpP4Bonus;                  // P4 (1.17): primo giorno di borsa del mese
   if(TightAsiaBonus(s))
      score += InpC3Bonus;                  // C3 (1.20): Asia stretta, piu' probabile la spazzata dei due lati
   s.score = score;
   //--- coda (1.17): con altre posizioni o ordini aperti, la nuova idea deve essere piu' sicura
   //    (solo per le idee che passerebbero da sole: le altre restano respinte con il loro motivo)
   if(InpQueueOn && !s.veto && g_cntAll > 0 && score >= MinScoreFor(s.engine) && s.quorum >= InpQuorum &&
      (score < MinScoreFor(s.engine) + InpQueueExtraScore || s.quorum < InpQuorum + 1))
      Veto(s, "coda: c'e' gia' una posizione aperta, servono punteggio " + DoubleToString(MinScoreFor(s.engine) + InpQueueExtraScore, 2) +
           " e quorum " + IntegerToString(InpQuorum + 1) + "/8");
   s.strong = (!s.veto && score >= InpStrongScore && s.quorum >= 7);
   s.passed = (!s.veto && s.quorum >= InpQuorum && score >= MinScoreFor(s.engine));
  }

string DeskLine(const TSignal &s)
  {
   string t = "";
   for(int d = 0; d < NDESK; d++)
      t += g_deskShort[d] + " " + DoubleToString(s.desk[d], 2) + (d < NDESK - 1 ? " | " : "");
   return t;
  }
