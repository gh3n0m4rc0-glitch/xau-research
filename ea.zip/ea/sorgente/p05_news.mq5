//+------------------------------------------------------------------+
//| News: calendario MT5 (live), calendario di riserva nel tester,   |
//| vista pre-news, dati macro/AI/GC da GitHub (WebRequest)          |
//+------------------------------------------------------------------+
struct NewsEvent
  {
   datetime          utc;
   int               tier;
   string            title;
   int               preDir;
   double            preConf;
   bool              viewTaken;
   int               viewDir;
   double            preClose;
   double            preAtr;
   double            extreme;
   bool              eUsed;
  };
NewsEvent g_news[MAX_NEWS];
int       g_newsN = 0;
datetime  g_newsRefreshedAt = 0;
int       g_testerNewsDay = 0;

void NewsClearSlot(int i)
  {
   g_news[i].utc = 0;
   g_news[i].tier = 4;
   g_news[i].title = "";
   g_news[i].preDir = 0;
   g_news[i].preConf = 0.0;
   g_news[i].viewTaken = false;
   g_news[i].viewDir = 0;
   g_news[i].preClose = 0.0;
   g_news[i].preAtr = 0.0;
   g_news[i].extreme = 0.0;
   g_news[i].eUsed = false;
  }

void NewsCopy(int dst, int src)
  {
   g_news[dst].utc = g_news[src].utc;
   g_news[dst].tier = g_news[src].tier;
   g_news[dst].title = g_news[src].title;
   g_news[dst].preDir = g_news[src].preDir;
   g_news[dst].preConf = g_news[src].preConf;
   g_news[dst].viewTaken = g_news[src].viewTaken;
   g_news[dst].viewDir = g_news[src].viewDir;
   g_news[dst].preClose = g_news[src].preClose;
   g_news[dst].preAtr = g_news[src].preAtr;
   g_news[dst].extreme = g_news[src].extreme;
   g_news[dst].eUsed = g_news[src].eUsed;
  }

//--- toglie gli eventi piu' vecchi di 'keepHours'
void NewsPrune(datetime nowUtc, int keepHours)
  {
   int w = 0;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].utc < nowUtc - keepHours * 3600)
         continue;
      if(w != i)
         NewsCopy(w, i);
      w++;
     }
   for(int i = w; i < g_newsN; i++)
      NewsClearSlot(i);
   g_newsN = w;
  }

int NewsFind(datetime utc, string title, int tolSec)
  {
   for(int i = 0; i < g_newsN; i++)
     {
      long d = (long)(g_news[i].utc - utc);
      if(d < 0)
         d = -d;
      if(d <= tolSec && (title == "" || g_news[i].title == title))
         return i;
     }
   return -1;
  }

int NewsUpsert(datetime utc, int tier, string title)
  {
   int i = NewsFind(utc, title, 120);
   if(i >= 0)
     {
      if(tier < g_news[i].tier)
         g_news[i].tier = tier;
      return i;
     }
   if(g_newsN >= MAX_NEWS)
      return -1;
   i = g_newsN;
   NewsClearSlot(i);
   g_news[i].utc = utc;
   g_news[i].tier = tier;
   g_news[i].title = title;
   g_newsN++;
   return i;
  }

//--- classificazione (come nel servizio Python)
int TierOf(string name, int importance)
  {
   string t = name;
   StringToLower(t);
   if(importance < (int)CALENDAR_IMPORTANCE_MODERATE)
      return 4;
   bool high = (importance >= (int)CALENDAR_IMPORTANCE_HIGH);
   bool speech = (StringFind(t, "speech") >= 0 || StringFind(t, "speaks") >= 0 || StringFind(t, "testimony") >= 0);
   if(speech && StringFind(t, "chair") < 0)
      return high ? 2 : 3;
   if(StringFind(t, "nonfarm") >= 0 || StringFind(t, "non-farm") >= 0 || StringFind(t, "fomc") >= 0 ||
      StringFind(t, "interest rate decision") >= 0 || StringFind(t, "federal funds") >= 0 ||
      StringFind(t, "cpi") >= 0 || StringFind(t, "consumer price index") >= 0 || StringFind(t, "pce") >= 0 ||
      StringFind(t, "chair") >= 0 || StringFind(t, "jackson hole") >= 0)
      return 1;
   return high ? 2 : 3;
  }

//+------------------------------------------------------------------+
//| Calendario di riserva per il tester (il calendario MT5 non       |
//| funziona nel tester): NFP (primo venerdi'), FOMC e CPI noti      |
//+------------------------------------------------------------------+
int g_fomcDates[32] = {20230201, 20230322, 20230503, 20230614, 20230726, 20230920, 20231101, 20231213,
                       20240131, 20240320, 20240501, 20240612, 20240731, 20240918, 20241107, 20241218,
                       20250129, 20250319, 20250507, 20250618, 20250730, 20250917, 20251029, 20251210,
                       20260128, 20260318, 20260429, 20260617, 20260729, 20260916, 20261028, 20261209
                      };
int g_cpiDates[21] = {20240111, 20240213, 20240312, 20240410, 20240515, 20240612, 20240711, 20240814, 20240911, 20241010, 20241113, 20241211,
                      20250115, 20250212, 20250312, 20250410, 20250513, 20250611, 20250715, 20250812, 20250911
                     };

bool InIntList(const int &arr[], int v)
  {
   int n = ArraySize(arr);
   for(int i = 0; i < n; i++)
      if(arr[i] == v)
         return true;
   return false;
  }

//--- ora ET -> UTC per una data (giorno UTC a mezzanotte)
datetime EtToUtc(datetime dayUtc, int hh, int mm)
  {
   datetime t = dayUtc + hh * 3600 + mm * 60 + 5 * 3600;
   if(IsUSDST(t))
      t -= 3600;
   return t;
  }

void TesterNewsRefresh(datetime nowUtc)
  {
   int dk = DayKey(nowUtc);
   if(dk == g_testerNewsDay)
      return;
   g_testerNewsDay = dk;
   NewsPrune(nowUtc, 12);
   for(int k = 0; k <= 7; k++)
     {
      datetime day = (datetime)(dk + k) * 86400;
      int ymd = Ymd(day);
      MqlDateTime d;
      TimeToStruct(day, d);
      if(d.day_of_week == 5 && d.day <= 7)
         NewsUpsert(EtToUtc(day, 8, 30), 1, "Nonfarm Payrolls");
      if(InIntList(g_fomcDates, ymd))
         NewsUpsert(EtToUtc(day, 14, 0), 1, "Fed Interest Rate Decision");
      if(InIntList(g_cpiDates, ymd))
         NewsUpsert(EtToUtc(day, 8, 30), 1, "CPI m/m");
     }
  }

//+------------------------------------------------------------------+
//| Calendario MT5 (solo live/demo)                                  |
//+------------------------------------------------------------------+
void CalendarRefresh()
  {
   datetime srv = TimeTradeServer();
   g_newsRefreshedAt = TimeCurrent();
   MqlCalendarValue vals[];
   int n = CalendarValueHistory(vals, srv - 6 * 3600, srv + 36 * 3600, "US", "USD");
   NewsPrune(ToUTC(srv), 12);
   if(n <= 0)
      return;
   for(int i = 0; i < n; i++)
     {
      MqlCalendarEvent ev;
      if(!CalendarEventById(vals[i].event_id, ev))
         continue;
      int tier = TierOf(ev.name, (int)ev.importance);
      if(tier > 2)
         continue;
      NewsUpsert(ToUTC(vals[i].time), tier, ev.name);
     }
  }

//--- minuti alla prossima news tier1 (-1 se nessuna nelle prossime 36 ore)
int MinutesToNextTier1(datetime nowUtc)
  {
   int best = -1;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier != 1)
         continue;
      long d = (long)(g_news[i].utc - nowUtc);
      if(d < 0)
         continue;
      int m = (int)(d / 60);
      if(best < 0 || m < best)
         best = m;
     }
   return best;
  }

int NextTier1Index(datetime nowUtc)
  {
   int bi = -1;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier != 1 || g_news[i].utc < nowUtc)
         continue;
      if(bi < 0 || g_news[i].utc < g_news[bi].utc)
         bi = i;
     }
   return bi;
  }

//--- blocco ingressi per news. strat = strategia che chiede (IN-NEWS puo' entrare dopo +5 min)
bool NewsBlocked(int engine, datetime nowUtc, int strat, string &why)
  {
   for(int i = 0; i < g_newsN; i++)
     {
      double dt = (double)(nowUtc - g_news[i].utc) / 60.0;
      double before = 0.0, after = 0.0;
      if(g_news[i].tier == 1)
        {
         before = (engine == ENG_SWING) ? InpNewsBlockSwingBefore : InpNewsBlockBefore;
         after = (engine == ENG_SWING) ? InpNewsBlockSwingAfter : InpNewsBlockAfter;
        }
      else
         if(g_news[i].tier == 2)
           {
            before = (engine == ENG_SWING) ? 30.0 : 15.0;
            after = (engine == ENG_SWING) ? 30.0 : 10.0;
           }
         else
            continue;
      if(dt >= -before && dt <= after)
        {
         if(strat == ST_IN_NEWS && dt >= 5.0)
            continue;
         why = "news " + g_news[i].title + (dt < 0 ? " tra " : " uscita da ") + IntegerToString((int)MathAbs(dt)) + " min";
         return true;
        }
     }
   return false;
  }

//+------------------------------------------------------------------+
//| JSON minimo (solo quello che serve)                              |
//+------------------------------------------------------------------+
ushort JsCh(const string &s, int i) { return StringGetCharacter(s, i); }

int JsSkipSpace(const string &s, int i)
  {
   int n = StringLen(s);
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c != ' ' && c != '\n' && c != '\r' && c != '\t')
         break;
      i++;
     }
   return i;
  }

//--- fine di una stringa che inizia con " in posizione i (ritorna indice del " di chiusura)
int JsStringEnd(const string &s, int i)
  {
   int n = StringLen(s);
   i++;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '\\')
        {
         i += 2;
         continue;
        }
      if(c == '"')
         return i;
      i++;
     }
   return n - 1;
  }

//--- posizione del valore della chiave 'key' al primo livello dell'oggetto in s (-1 se manca)
int JsonTopKey(const string &s, string key)
  {
   int n = StringLen(s);
   int depth = 0;
   int i = 0;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '"')
        {
         int e = JsStringEnd(s, i);
         if(depth == 1)
           {
            int j = JsSkipSpace(s, e + 1);
            if(j < n && JsCh(s, j) == ':')
              {
               if(StringSubstr(s, i + 1, e - i - 1) == key)
                  return JsSkipSpace(s, j + 1);
              }
           }
         i = e + 1;
         continue;
        }
      if(c == '{' || c == '[')
         depth++;
      else
         if(c == '}' || c == ']')
            depth--;
      i++;
     }
   return -1;
  }

double JsonNum(const string &s, string key, double def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0)
      return def;
   int n = StringLen(s);
   int e = p;
   while(e < n)
     {
      ushort c = JsCh(s, e);
      if((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E')
         e++;
      else
         break;
     }
   if(e == p)
      return def;
   return StringToDouble(StringSubstr(s, p, e - p));
  }

bool JsonBool(const string &s, string key, bool def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0)
      return def;
   if(StringSubstr(s, p, 4) == "true")
      return true;
   if(StringSubstr(s, p, 5) == "false")
      return false;
   return def;
  }

string JsonStr(const string &s, string key, string def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0 || JsCh(s, p) != '"')
      return def;
   int e = JsStringEnd(s, p);
   return StringSubstr(s, p + 1, e - p - 1);
  }

//--- oggetti di un array: a partire dalla '[' in posizione p
int JsonArrayObjects(const string &s, int p, string &objs[])
  {
   ArrayResize(objs, 0);
   int n = StringLen(s);
   if(p < 0 || p >= n || JsCh(s, p) != '[')
      return 0;
   int depth = 0;
   int start = -1;
   int cnt = 0;
   int i = p + 1;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '"')
        {
         i = JsStringEnd(s, i) + 1;
         continue;
        }
      if(c == '{')
        {
         if(depth == 0)
            start = i;
         depth++;
        }
      else
         if(c == '}')
           {
            depth--;
            if(depth == 0 && start >= 0)
              {
               ArrayResize(objs, cnt + 1);
               objs[cnt] = StringSubstr(s, start, i - start + 1);
               cnt++;
               start = -1;
              }
           }
         else
            if(c == ']' && depth == 0)
               break;
      i++;
     }
   return cnt;
  }

datetime ParseIsoUtc(string s)
  {
   string t = s;
   StringReplace(t, "-", ".");
   StringReplace(t, "T", " ");
   StringReplace(t, "Z", "");
   return StringToTime(t);
  }

//+------------------------------------------------------------------+
//| Dati esterni da GitHub                                           |
//+------------------------------------------------------------------+
double   g_macroBias = 0.0, g_macroConf = 0.0, g_macroRiskMult = 1.0;
bool     g_macroHalt = false;
string   g_macroHaltReason = "";
datetime g_macroTime = 0;
string   g_aiStance = "";
double   g_aiConv = 0.0;
datetime g_aiTime = 0;
datetime g_webLastTry = 0;
double   g_mBias = 0.0;       // macro combinata usata dal comitato (GitHub + storico + intermarket)
double   g_mConf = 0.0;
string   g_mSource = "";
bool     g_webWarned = false;

bool MacroFresh() { return (g_macroTime > 0 && ToUTC(TimeCurrent()) - g_macroTime <= 6 * 3600); }
bool AiFresh()    { return (g_aiTime > 0 && ToUTC(TimeCurrent()) - g_aiTime <= 8 * 3600); }

bool HttpGet(string url, string &body)
  {
   char data[];
   char res[];
   string hdr;
   ResetLastError();
   int code = WebRequest("GET", url, "", 5000, data, res, hdr);
   if(code == -1)
     {
      int err = GetLastError();
      if(!g_webWarned)
        {
         g_webWarned = true;
         Notify("Dati esterni non leggibili (errore " + IntegerToString(err) + "). In MT5: Strumenti > Opzioni > Expert Advisors > spunta 'Consenti WebRequest' e aggiungi https://raw.githubusercontent.com");
        }
      return false;
     }
   if(code != 200)
      return false;
   body = CharArrayToString(res, 0, WHOLE_ARRAY, CP_UTF8);
   return (StringLen(body) > 2);
  }

void ParseMacro(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   g_macroTime = ParseIsoUtc(ts);
   g_macroBias = Clamp(JsonNum(js, "bias", 0.0), -1.0, 1.0);
   g_macroConf = Clamp(JsonNum(js, "confidence", 0.0), 0.0, 1.0);
   g_macroRiskMult = Clamp(JsonNum(js, "risk_multiplier", 1.0), 0.3, 1.5);
   g_macroHalt = JsonBool(js, "halt_trading", false);
   g_macroHaltReason = JsonStr(js, "halt_reason", "");
   //--- viste pre-news del servizio di ricerca
   string objs[];
   int n = JsonArrayObjects(js, JsonTopKey(js, "pre_news"), objs);
   for(int i = 0; i < n; i++)
     {
      string t = JsonStr(objs[i], "time_utc", "");
      if(t == "")
         continue;
      datetime u = ParseIsoUtc(t);
      int tier = (int)JsonNum(objs[i], "tier", 1.0);
      string title = JsonStr(objs[i], "event", "evento");
      int k = NewsFind(u, "", 600);
      if(k < 0)
         k = NewsUpsert(u, IMax(1, IMin(tier, 2)), title);
      if(k < 0)
         continue;
      g_news[k].preDir = (int)MathRound(Clamp(JsonNum(objs[i], "gold_direction", 0.0), -1.0, 1.0));
      g_news[k].preConf = Clamp(JsonNum(objs[i], "confidence", 0.0), 0.0, 1.0);
     }
  }

void ParseCommittee(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   g_aiTime = ParseIsoUtc(ts);
   g_aiStance = JsonStr(js, "stance", "flat");
   g_aiConv = Clamp(JsonNum(js, "conviction", 0.0), 0.0, 1.0);
  }

void ParseVolumeLevels(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   double last = JsonNum(js, "gc_last", 0.0);
   int p = JsonTopKey(js, "composite");
   if(p < 0 || last <= 0.0)
      return;
   //--- l'oggetto composite: lo isolo e leggo poc/vah/val
   int n = StringLen(js);
   int depth = 0, e = p;
   for(int i = p; i < n; i++)
     {
      ushort c = JsCh(js, i);
      if(c == '"')
        {
         i = JsStringEnd(js, i);
         continue;
        }
      if(c == '{')
         depth++;
      if(c == '}')
        {
         depth--;
         if(depth == 0)
           {
            e = i;
            break;
           }
        }
     }
   string comp = StringSubstr(js, p, e - p + 1);
   g_gcPoc = JsonNum(comp, "poc", 0.0);
   g_gcVah = JsonNum(comp, "vah", 0.0);
   g_gcVal = JsonNum(comp, "val", 0.0);
   g_gcLast = last;
   g_gcDeltaTrend = Clamp(JsonNum(js, "delta_trend", 0.0), -1.0, 1.0);
   g_gcTime = ParseIsoUtc(ts);
  }

//--- calendario di riserva dal JSON (se il calendario MT5 e' vuoto)
void ParseNewsCalendar(const string &js)
  {
   string objs[];
   int n = JsonArrayObjects(js, JsSkipSpace(js, 0), objs);
   for(int i = 0; i < n; i++)
     {
      string t = JsonStr(objs[i], "time_utc", "");
      int tier = (int)JsonNum(objs[i], "tier", 4.0);
      if(t == "" || tier > 2)
         continue;
      NewsUpsert(ParseIsoUtc(t), tier, JsonStr(objs[i], "title", "news"));
     }
  }

void WebRefresh()
  {
   if(!InpUseWebData || g_isTester)
      return;
   g_webLastTry = TimeCurrent();
   string body;
   if(InpMacroUrl != "" && HttpGet(InpMacroUrl, body))
      ParseMacro(body);
   if(InpCommitteeUrl != "" && HttpGet(InpCommitteeUrl, body))
      ParseCommittee(body);
   if(InpVolumeUrl != "" && HttpGet(InpVolumeUrl, body))
      ParseVolumeLevels(body);
   if(InpNewsUrl != "" && g_newsN == 0 && HttpGet(InpNewsUrl, body))
      ParseNewsCalendar(body);
  }

//+------------------------------------------------------------------+
//| Vista pre-news: 30 minuti prima della news il desk news fissa    |
//| la direzione attesa; dopo la news si entra SOLO se conferma      |
//+------------------------------------------------------------------+
void NewsTrack()
  {
   datetime nowU = g_ctx.nowUtc;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier > 2)
         continue;
      long dt = (long)(nowU - g_news[i].utc);
      if(!g_news[i].viewTaken && dt >= -30 * 60 && dt < 0)
        {
         int trend = TrendDir(g_h1);
         int vw = (g_ctx.vwap > 0.0) ? ((BarC(g_m5, 0) > g_ctx.vwap) ? 1 : -1) : 0;
         int macro = 0;
         if(g_mConf >= 0.3 && MathAbs(g_mBias) >= 0.15)
            macro = (g_mBias > 0.0) ? 1 : -1;
         int dir = 0;
         if(g_news[i].preConf >= 0.5 && g_news[i].preDir != 0)
            dir = g_news[i].preDir;
         else
            if(trend != 0 && trend == vw && (macro == 0 || macro == trend))
               dir = trend;
         g_news[i].viewDir = dir;
         g_news[i].preClose = BarC(g_m5, 0);
         g_news[i].preAtr = MathMax(AtrOf(g_m15), g_tick * 10);
         g_news[i].extreme = g_news[i].preClose;
         g_news[i].viewTaken = true;
         string vtxt = (dir > 0) ? "rialzo" : ((dir < 0) ? "ribasso" : "neutra");
         Logf("Vista pre-news su " + g_news[i].title + ": " + vtxt);
        }
      if(g_news[i].viewTaken && g_news[i].viewDir != 0 && dt >= 0 && dt <= 120 * 60)
        {
         if(g_news[i].viewDir > 0)
            g_news[i].extreme = MathMax(g_news[i].extreme, BarH(g_m5, 0));
         else
            g_news[i].extreme = MathMin(g_news[i].extreme, BarL(g_m5, 0));
        }
     }
  }

//--- vista per la prossima news tier1 entro 'horizonMin' (dal servizio di ricerca o dalla vista fissata)
int NextEventView(datetime nowUtc, int horizonMin)
  {
   int k = NextTier1Index(nowUtc);
   if(k < 0)
      return 0;
   if((g_news[k].utc - nowUtc) / 60 > horizonMin)
      return 0;
   if(g_news[k].viewTaken)
      return g_news[k].viewDir;
   if(g_news[k].preConf >= 0.5)
      return g_news[k].preDir;
   return 0;
  }
