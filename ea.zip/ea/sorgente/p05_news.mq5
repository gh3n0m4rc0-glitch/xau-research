//+------------------------------------------------------------------+
//| News: calendario MT5 (live), calendario di riserva nel tester,   |
//| vista pre-news, dati macro/AI/GC da GitHub (WebRequest)          |
//+------------------------------------------------------------------+
struct NewsEvent
  {
   datetime          utc;
   int               tier;
   string            title;
   int               preDir;
   double            preConf;
   bool              viewTaken;
   int               viewDir;
   double            preClose;
   double            preAtr;
   double            extreme;
   bool              eUsed;
   int               kind;        // 1.26: 0 = non letto, 1 = inflazione CPI, 2 = lavoro, 3 = inflazione PCE
   int               surp;        // somma dei segni: positivo = dato "caldo" (sopra le attese, pesa sull'oro), negativo = "freddo"
   int               surpN;       // numeri con previsione letti
   datetime          surpAt;      // quando il bot l'ha saputo (UTC)
   string            surpText;
   bool              surpTold;
  };
NewsEvent g_news[MAX_NEWS];
int       g_newsN = 0;
datetime  g_newsRefreshedAt = 0;
int       g_testerNewsDay = 0;

void NewsClearSlot(int i)
  {
   g_news[i].utc = 0;
   g_news[i].tier = 4;
   g_news[i].title = "";
   g_news[i].preDir = 0;
   g_news[i].preConf = 0.0;
   g_news[i].viewTaken = false;
   g_news[i].viewDir = 0;
   g_news[i].preClose = 0.0;
   g_news[i].preAtr = 0.0;
   g_news[i].extreme = 0.0;
   g_news[i].eUsed = false;
   g_news[i].kind = 0;
   g_news[i].surp = 0;
   g_news[i].surpN = 0;
   g_news[i].surpAt = 0;
   g_news[i].surpText = "";
   g_news[i].surpTold = false;
  }

void NewsCopy(int dst, int src)
  {
   g_news[dst].utc = g_news[src].utc;
   g_news[dst].tier = g_news[src].tier;
   g_news[dst].title = g_news[src].title;
   g_news[dst].preDir = g_news[src].preDir;
   g_news[dst].preConf = g_news[src].preConf;
   g_news[dst].viewTaken = g_news[src].viewTaken;
   g_news[dst].viewDir = g_news[src].viewDir;
   g_news[dst].preClose = g_news[src].preClose;
   g_news[dst].preAtr = g_news[src].preAtr;
   g_news[dst].extreme = g_news[src].extreme;
   g_news[dst].eUsed = g_news[src].eUsed;
   g_news[dst].kind = g_news[src].kind;
   g_news[dst].surp = g_news[src].surp;
   g_news[dst].surpN = g_news[src].surpN;
   g_news[dst].surpAt = g_news[src].surpAt;
   g_news[dst].surpText = g_news[src].surpText;
   g_news[dst].surpTold = g_news[src].surpTold;
  }

//--- toglie gli eventi piu' vecchi di 'keepHours'
void NewsPrune(datetime nowUtc, int keepHours)
  {
   int w = 0;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].utc < nowUtc - keepHours * 3600)
         continue;
      if(w != i)
         NewsCopy(w, i);
      w++;
     }
   for(int i = w; i < g_newsN; i++)
      NewsClearSlot(i);
   g_newsN = w;
  }

int NewsFind(datetime utc, string title, int tolSec)
  {
   for(int i = 0; i < g_newsN; i++)
     {
      long d = (long)(g_news[i].utc - utc);
      if(d < 0)
         d = -d;
      if(d <= tolSec && (title == "" || g_news[i].title == title))
         return i;
     }
   return -1;
  }

int NewsUpsert(datetime utc, int tier, string title)
  {
   int i = NewsFind(utc, title, 120);
   if(i >= 0)
     {
      if(tier < g_news[i].tier)
         g_news[i].tier = tier;
      return i;
     }
   if(g_newsN >= MAX_NEWS)
      return -1;
   i = g_newsN;
   NewsClearSlot(i);
   g_news[i].utc = utc;
   g_news[i].tier = tier;
   g_news[i].title = title;
   g_newsN++;
   return i;
  }

//--- 1.19: unisce per orario (+-2 min) le news che arrivano da fonti diverse (MT5, GitHub, date ufficiali):
//--- resta il tier piu' alto; il titolo diventa quello della fonte che alza il tier
int NewsMerge(datetime utc, int tier, string title)
  {
   int i = NewsFind(utc, "", 120);
   if(i >= 0)
     {
      if(tier < g_news[i].tier)
        {
         g_news[i].tier = tier;
         g_news[i].title = title;
        }
      return i;
     }
   return NewsUpsert(utc, tier, title);
  }

//--- testo normalizzato per riconoscere le news: minuscolo, trattini e trattini bassi come spazi
string NewsNorm(string s)
  {
   string t = " " + s + " ";
   StringToLower(t);
   StringReplace(t, "-", " ");
   StringReplace(t, "_", " ");
   return t;
  }

//--- classificazione (come nel servizio Python). 1.19: il terminale in italiano chiama il CPI "IPC m/m",
//--- quindi si guarda anche il codice evento di MT5 (in inglese) e le parole italiane
int TierOf(string name, int importance)
  {
   string t = NewsNorm(name);
   if(importance < (int)CALENDAR_IMPORTANCE_MODERATE)
      return 4;
   bool high = (importance >= (int)CALENDAR_IMPORTANCE_HIGH);
   bool chair = (StringFind(t, "chair") >= 0 || StringFind(t, "presidente") >= 0);
   bool speech = (StringFind(t, "speech") >= 0 || StringFind(t, "speaks") >= 0 || StringFind(t, "testimony") >= 0 ||
                  StringFind(t, "discorso") >= 0 || StringFind(t, "testimonianza") >= 0 || StringFind(t, "interviene") >= 0);
   if(speech && !chair)
      return high ? 2 : 3;
   if(StringFind(t, "nonfarm") >= 0 || StringFind(t, "non farm") >= 0 || StringFind(t, "non agricol") >= 0 ||
      StringFind(t, "fomc") >= 0 || StringFind(t, "interest rate decision") >= 0 || StringFind(t, "federal funds") >= 0 ||
      StringFind(t, "fed interest rate") >= 0 || StringFind(t, "tassi d'interesse della fed") >= 0 ||
      StringFind(t, "tassi di interesse della fed") >= 0 || StringFind(t, "decisione sui tassi") >= 0 ||
      StringFind(t, "tasso di interesse della fed") >= 0 || StringFind(t, "tasso d'interesse della fed") >= 0 ||
      StringFind(t, " cpi ") >= 0 || StringFind(t, "(cpi)") >= 0 || StringFind(t, " ipc ") >= 0 || StringFind(t, "(ipc)") >= 0 ||
      StringFind(t, "consumer price index") >= 0 || StringFind(t, "prezzi al consumo") >= 0 ||
      StringFind(t, " pce ") >= 0 || StringFind(t, "(pce)") >= 0 || chair || StringFind(t, "jackson hole") >= 0)
      return 1;
   return high ? 2 : 3;
  }

//+------------------------------------------------------------------+
//| Calendario di riserva per il tester (il calendario MT5 non       |
//| funziona nel tester): NFP, FOMC e CPI con le date vere 2023-2027 |
//+------------------------------------------------------------------+
int g_fomcDates[41] = {20230201, 20230322, 20230503, 20230614, 20230726, 20230920, 20231101, 20231213,
                       20240131, 20240320, 20240501, 20240612, 20240731, 20240918, 20241107, 20241218,
                       20250129, 20250319, 20250507, 20250618, 20250730, 20250917, 20251029, 20251210,
                       20260128, 20260318, 20260429, 20260617, 20260729, 20260916, 20261028, 20261209,
                       20270127, 20270317, 20270428, 20270609, 20270728, 20270915, 20271027, 20271208,
                       20280126
                      };
//--- CPI: date vere di uscita (ForexFactory e BLS). Nel 2025 lo shutdown ha spostato settembre al 24/10,
//--- ottobre non e' uscito e novembre e' uscito il 18/12
int g_cpiDates[59] = {20230112, 20230214, 20230314, 20230412, 20230510, 20230613, 20230712, 20230810, 20230913, 20231012, 20231114, 20231212,
                      20240111, 20240213, 20240312, 20240410, 20240515, 20240612, 20240711, 20240814, 20240911, 20241010, 20241113, 20241211,
                      20250115, 20250212, 20250312, 20250410, 20250513, 20250611, 20250715, 20250812, 20250911, 20251024, 20251218,
                      20260113, 20260213, 20260311, 20260410, 20260512, 20260610, 20260714, 20260812, 20260911, 20261014, 20261110, 20261210,
                      20270113, 20270211, 20270310, 20270413, 20270512, 20270610, 20270714, 20270811, 20270914, 20271014, 20271110, 20271210
                     };
//--- NFP: date vere di uscita 2023-2027 (fuori da questo intervallo vale la regola del primo venerdi')
int g_nfpDates[59] = {20230106, 20230203, 20230310, 20230407, 20230505, 20230602, 20230707, 20230804, 20230901, 20231006, 20231103, 20231208,
                      20240105, 20240202, 20240308, 20240405, 20240503, 20240607, 20240705, 20240802, 20240906, 20241004, 20241101, 20241206,
                      20250110, 20250207, 20250307, 20250404, 20250502, 20250606, 20250703, 20250801, 20250905, 20251120, 20251216,
                      20260109, 20260211, 20260306, 20260403, 20260508, 20260605, 20260702, 20260807, 20260904, 20261002, 20261106, 20261204,
                      20270108, 20270205, 20270305, 20270402, 20270507, 20270604, 20270702, 20270806, 20270903, 20271008, 20271105, 20271203
                     };

//--- 1.26: sorpresa del CPI (totale m/m + core m/m contro le previsioni, ForexFactory): +2 = tutti e due sopra le attese
//--- (dato caldo), -2 = tutti e due sotto (freddo), 0 = in linea o misti che si annullano. Serve al Tester, dove il
//--- calendario MT5 non funziona; dal vivo il dato e la previsione si leggono dal calendario.
int g_cpiSurpDate[57] = {20220112, 20220210, 20220310, 20220412, 20220511, 20220610, 20220713, 20220810, 20220913, 20221013, 20221110, 20221213,
                         20230112, 20230214, 20230314, 20230412, 20230510, 20230613, 20230712, 20230810, 20230913, 20231012, 20231114, 20231212,
                         20240111, 20240213, 20240312, 20240410, 20240515, 20240612, 20240711, 20240814, 20240911, 20241010, 20241113, 20241211,
                         20250115, 20250212, 20250312, 20250410, 20250513, 20250611, 20250715, 20250812, 20250911, 20251024,
                         20260113, 20260213, 20260311, 20260410, 20260512, 20260610, 20260714, 20260812, 20260911, 20261014, 20261110
                        };
int g_cpiSurpVal[57]  = {2, 2, 0, -1, 2, 2, 2, -2, 2, 2, -2, -2,
                         0, 0, 1, -1, 1, -1, -2, 0, 1, 1, -2, 1,
                         1, 2, 1, 2, -1, -2, -2, 0, 1, 2, 0, 0,
                         -1, 2, -2, -2, -2, -2, -1, 0, 1, -2,
                         -1, -1, 0, -2, 1, -1, -2, 0, 1, 1, 2
                        };

bool InIntList(const int &arr[], int v)
  {
   int n = ArraySize(arr);
   for(int i = 0; i < n; i++)
      if(arr[i] == v)
         return true;
   return false;
  }

//--- ora ET -> UTC per una data (giorno UTC a mezzanotte)
datetime EtToUtc(datetime dayUtc, int hh, int mm)
  {
   datetime t = dayUtc + hh * 3600 + mm * 60 + 5 * 3600;
   if(IsUSDST(t))
      t -= 3600;
   return t;
  }

void BuiltinNewsAdd(int dk)
  {
   for(int k = 0; k <= 7; k++)
     {
      datetime day = (datetime)(dk + k) * 86400;
      int ymd = Ymd(day);
      MqlDateTime d;
      TimeToStruct(day, d);
      bool nfp = (ymd >= 20230101 && ymd <= 20271231) ? InIntList(g_nfpDates, ymd) : (d.day_of_week == 5 && d.day <= 7);
      if(nfp)
         NewsMerge(EtToUtc(day, 8, 30), 1, "Nonfarm Payrolls");
      if(InIntList(g_fomcDates, ymd))
         NewsMerge(EtToUtc(day, 14, 0), 1, "Fed Interest Rate Decision");
      if(InIntList(g_cpiDates, ymd))
         NewsMerge(EtToUtc(day, 8, 30), 1, "CPI m/m");
      //--- 1.26: nel Tester la sorpresa del CPI arriva dalla tabella storica, un minuto dopo l'uscita
      if(g_isTester)
         for(int j = 0; j < ArraySize(g_cpiSurpDate); j++)
            if(g_cpiSurpDate[j] == ymd)
              {
               int kx = NewsMerge(EtToUtc(day, 8, 30), 1, "CPI m/m");
               if(kx >= 0 && g_news[kx].surpN == 0)
                 {
                  g_news[kx].kind = 1;
                  g_news[kx].surp = g_cpiSurpVal[j];
                  g_news[kx].surpN = 2;
                  g_news[kx].surpAt = g_news[kx].utc + 60;
                  g_news[kx].surpText = "CPI totale e core (tabella storica)";
                 }
              }
     }
  }

void TesterNewsRefresh(datetime nowUtc)
  {
   int dk = DayKey(nowUtc);
   if(dk == g_testerNewsDay)
      return;
   g_testerNewsDay = dk;
   NewsPrune(nowUtc, 12);
   BuiltinNewsAdd(dk);
  }

int NextTier1Index(datetime nowUtc);
string g_newsNextLog = "";

//--- 1.19: scrive nel Diario quando cambia la prossima news forte (per controllare il calendario dal vivo)
void NewsLogNext(datetime nowUtc, string src)
  {
   int k = NextTier1Index(nowUtc);
   string s = (k >= 0) ? (g_news[k].title + " " + TimeToString(g_news[k].utc, TIME_DATE | TIME_MINUTES) + " UTC") : "nessuna";
   if(s == g_newsNextLog)
      return;
   g_newsNextLog = s;
   Logf("Calendario news (" + src + ", " + IntegerToString(g_newsN) + " eventi): prossima news forte " + s);
  }

//+------------------------------------------------------------------+
//| 1.26: IL DATO CONTRO LA PREVISIONE                               |
//| Il bot legge dal calendario MT5 il dato uscito e la previsione   |
//| e ne ricava il segno: "caldo" (inflazione o lavoro sopra le      |
//| attese: tassi piu' alti, pesa sull'oro) o "freddo". Sui dati     |
//| 2022-2026 (60 uscite) dopo un CPI caldo l'oro scende nel primo   |
//| minuto 8 volte su 10, dopo uno freddo sale 10 su 10: il verso e' |
//| giusto, ma il grosso del movimento arriva subito.                |
//+------------------------------------------------------------------+
//--- che numero e'? 1 = inflazione CPI mensile (totale e core), 2 = lavoro, 3 = inflazione PCE mensile; hawk = +1 se "sopra le attese" pesa sull'oro
int DataKindOf(string name, int &hawk)
  {
   string t = NewsNorm(name);
   hawk = 1;
   bool monthly = (StringFind(t, "m/m") >= 0 || StringFind(t, " mm ") >= 0 || StringFind(t, "mensile") >= 0);
   bool cpi = (StringFind(t, " cpi ") >= 0 || StringFind(t, "(cpi)") >= 0 || StringFind(t, " ipc ") >= 0 || StringFind(t, "(ipc)") >= 0 ||
               StringFind(t, "consumer price") >= 0 || StringFind(t, "prezzi al consumo") >= 0);
   bool pce = (StringFind(t, " pce ") >= 0 || StringFind(t, "(pce)") >= 0);
   if(cpi && monthly)
      return 1;
   if(StringFind(t, "nonfarm") >= 0 || StringFind(t, "non farm") >= 0 || StringFind(t, "non agricol") >= 0)
      return 2;
   if(StringFind(t, "unemployment rate") >= 0 || StringFind(t, "tasso di disoccupazione") >= 0)
     {
      hawk = -1;
      return 2;
     }
   if(monthly && (StringFind(t, "hourly earnings") >= 0 || StringFind(t, "retribuzion") >= 0 || StringFind(t, "salari") >= 0))
      return 2;
   if(pce && monthly)
      return 3;                                // inflazione PCE: solo avviso (sui dati l'oro reagisce poco)
   return 0;
  }

string DataVerdict(int kind, int surp, int n)
  {
   if(n <= 0)
      return "";
   if(surp == 0)
      return "in linea con le attese: nessuna spinta dal dato";
   bool clear = (MathAbs(surp) >= n);
   string strength = clear ? "" : " (numeri misti)";
   if(kind == 2)
     {
      if(surp > 0)
         return "lavoro FORTE, meglio delle attese" + strength + ": tassi piu' alti, pressione al RIBASSO sull'oro";
      return "lavoro DEBOLE, peggio delle attese" + strength + ": tassi piu' bassi, spinta al RIALZO sull'oro";
     }
   if(surp > 0)
      return "dato CALDO, sopra le attese" + strength + ": tassi piu' alti, pressione al RIBASSO sull'oro";
   return "dato FREDDO, sotto le attese" + strength + ": tassi piu' bassi, spinta al RIALZO sull'oro";
  }

//--- legge dato e previsione dei numeri appena usciti e li somma sull'evento con lo stesso orario
void DataSurpriseRead(MqlCalendarValue &vals[], int n, datetime nowUtc)
  {
   for(int k = 0; k < g_newsN; k++)
     {
      if(g_news[k].utc > nowUtc || nowUtc - g_news[k].utc > 6 * 3600)
         continue;
      //--- i numeri dello stesso dato (totale e core) possono arrivare a pochi secondi l'uno dall'altro:
      //    nel primo minuto dopo la prima lettura si rilegge, e vale la lettura con piu' numeri
      if(g_news[k].surpN > 0 && (g_isTester || g_news[k].surpTold || nowUtc - g_news[k].surpAt > 60))
         continue;
      int sum = 0, cnt = 0, kind = 0;
      string txt = "";
      for(int i = 0; i < n; i++)
        {
         long d = (long)(ToUTC(vals[i].time) - g_news[k].utc);
         if(d < -120 || d > 120)
            continue;
         if(vals[i].actual_value == LONG_MIN || vals[i].forecast_value == LONG_MIN)
            continue;
         MqlCalendarEvent ev;
         if(!CalendarEventById(vals[i].event_id, ev))
            continue;
         int hawk = 1;
         int kd = DataKindOf(ev.event_code + " | " + ev.name, hawk);
         if(kd == 0)
            continue;
         if(kind == 0 || kd < kind)
            kind = kd;
         double a = (double)vals[i].actual_value / 1000000.0, f = (double)vals[i].forecast_value / 1000000.0;
         if(a > f + 0.0000001)
            sum += hawk;
         if(a < f - 0.0000001)
            sum -= hawk;
         cnt++;
         if(StringLen(txt) < 150)
           {
            if(txt != "")
               txt += ", ";
            txt += ev.name + " " + DoubleToString(a, 1) + " (attese " + DoubleToString(f, 1) + ")";
           }
        }
      if(cnt == 0 || cnt <= g_news[k].surpN)
         continue;
      datetime first = (g_news[k].surpN > 0) ? g_news[k].surpAt : nowUtc;
      g_news[k].kind = kind;
      g_news[k].surp = sum;
      g_news[k].surpN = cnt;
      g_news[k].surpAt = first;
      g_news[k].surpText = txt;
     }
  }

//--- ultimo dato letto (per pannello e avvisi): indice dell'evento, -1 se nessuno nelle ultime 'hours' ore
int DataLastIndex(datetime nowUtc, int hours)
  {
   int best = -1;
   for(int k = 0; k < g_newsN; k++)
      if(g_news[k].surpN > 0 && g_news[k].surpAt <= nowUtc && nowUtc - g_news[k].utc <= hours * 3600)
         if(best < 0 || g_news[k].utc > g_news[best].utc)
            best = k;
   return best;
  }

string DataText(int k)
  {
   if(k < 0)
      return "";
   return g_news[k].surpText + ": " + DataVerdict(g_news[k].kind, g_news[k].surp, g_news[k].surpN);
  }

//--- avviso (una volta) quando il dato e' noto
void DataTell(datetime nowUtc)
  {
   if(!InpDataAlerts)
      return;
   for(int k = 0; k < g_newsN; k++)
     {
      if(g_news[k].surpN <= 0 || g_news[k].surpTold || g_news[k].surpAt > nowUtc)
         continue;
      if(!g_isTester && nowUtc - g_news[k].surpAt < 20)
         continue;                              // aspetta gli altri numeri dello stesso dato: l'avviso li porta tutti
      g_news[k].surpTold = true;
      string m = "DATO " + DataText(k);
      if(g_isTester)
         Logf(m);
      else
         Notify(m);
     }
  }

//--- c'e' un dato forte appena uscito che il bot non ha ancora letto? (rilettura veloce del calendario)
bool DataAwaited(datetime nowUtc)
  {
   for(int k = 0; k < g_newsN; k++)
      if(g_news[k].tier == 1 && g_news[k].surpN == 0 && nowUtc >= g_news[k].utc && nowUtc - g_news[k].utc <= 600)
         return true;
   return false;
  }

//+------------------------------------------------------------------+
//| Calendario MT5 (solo live/demo)                                  |
//+------------------------------------------------------------------+
void CalendarRefresh()
  {
   datetime srv = TimeTradeServer();
   g_newsRefreshedAt = TimeCurrent();
   MqlCalendarValue vals[];
   int n = CalendarValueHistory(vals, srv - 6 * 3600, srv + 36 * 3600, "US", "USD");
   NewsPrune(ToUTC(srv), 12);
   for(int i = 0; i < n; i++)
     {
      MqlCalendarEvent ev;
      if(!CalendarEventById(vals[i].event_id, ev))
         continue;
      int tier = TierOf(ev.event_code + " | " + ev.name, (int)ev.importance);
      if(tier > 2)
         continue;
      string title = ev.name;
      if(ev.event_code != "")
         title += " [" + ev.event_code + "]";
      NewsMerge(ToUTC(vals[i].time), tier, title);
     }
   if(InpDataAlerts || InpIN_DATA)
      DataSurpriseRead(vals, n, ToUTC(srv));
   BuiltinNewsAdd(DayKey(ToUTC(srv)));     // 1.19: NFP, CPI e FOMC dalle date ufficiali anche dal vivo
   NewsLogNext(ToUTC(srv), "MT5 + date ufficiali");
  }

//--- minuti alla prossima news tier1 (-1 se nessuna nelle prossime 36 ore)
int MinutesToNextTier1(datetime nowUtc)
  {
   int best = -1;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier != 1)
         continue;
      long d = (long)(g_news[i].utc - nowUtc);
      if(d < 0)
         continue;
      int m = (int)(d / 60);
      if(best < 0 || m < best)
         best = m;
     }
   return best;
  }

int NextTier1Index(datetime nowUtc)
  {
   int bi = -1;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier != 1 || g_news[i].utc < nowUtc)
         continue;
      if(bi < 0 || g_news[i].utc < g_news[bi].utc)
         bi = i;
     }
   return bi;
  }

//--- tipo di evento FOMC: 0 = no, 1 = decisione/comunicato/proiezioni, 2 = conferenza stampa
int FomcKind(string title)
  {
   string t = NewsNorm(title);
   if(StringFind(t, "minutes") >= 0 || StringFind(t, "speak") >= 0 || StringFind(t, "speech") >= 0 ||
      StringFind(t, "testimony") >= 0 || StringFind(t, "member") >= 0 || StringFind(t, "verbal") >= 0 ||
      StringFind(t, "discorso") >= 0 || StringFind(t, "membro") >= 0 || StringFind(t, "testimonianza") >= 0)
      return 0;
   if(StringFind(t, "press conference") >= 0 || StringFind(t, "conferenza stampa") >= 0)
      return (StringFind(t, "fomc") >= 0 || StringFind(t, "fed") >= 0) ? 2 : 0;
   if(StringFind(t, "fomc") >= 0 || StringFind(t, "federal funds") >= 0 || StringFind(t, "fed interest rate") >= 0 ||
      StringFind(t, "tassi d'interesse della fed") >= 0 || StringFind(t, "tassi di interesse della fed") >= 0 ||
      StringFind(t, "tasso di interesse della fed") >= 0 || StringFind(t, "tasso d'interesse della fed") >= 0)
      return 1;
   return 0;
  }

//--- blocco ingressi per news. strat = strategia che chiede (IN-NEWS puo' entrare dopo +5 min).
//--- FOMC (studio banche centrali, 9 nov 2026): la conferenza parte a +30 e raddoppia o ribalta la mossa,
//--- quindi niente ingressi, IN-NEWS compreso, fino a +InpNewsBlockFomcAfter minuti dalla decisione
bool NewsBlocked(int engine, datetime nowUtc, int strat, string &why)
  {
   for(int i = 0; i < g_newsN; i++)
     {
      double dt = (double)(nowUtc - g_news[i].utc) / 60.0;
      double before = 0.0, after = 0.0;
      int fk = (InpNewsBlockFomcAfter > 0) ? FomcKind(g_news[i].title) : 0;
      if(g_news[i].tier == 1 || fk > 0)
        {
         before = (engine == ENG_SWING) ? InpNewsBlockSwingBefore : InpNewsBlockBefore;
         after = (engine == ENG_SWING) ? InpNewsBlockSwingAfter : InpNewsBlockAfter;
         if(fk == 1)
            after = MathMax(after, (double)InpNewsBlockFomcAfter);
         if(fk == 2)
            after = MathMax(after, (double)InpNewsBlockFomcAfter - 30.0);
        }
      else
         if(g_news[i].tier == 2)
           {
            if(IsProvenFam(strat))
               continue;                      // 1.26: i movimenti forti (e dalla 1.27 i ritracciamenti) sono misurati senza questo blocco (resta quello delle news forti)
            before = (engine == ENG_SWING) ? 30.0 : 15.0;
            after = (engine == ENG_SWING) ? 30.0 : 10.0;
           }
         else
            continue;
      if(dt >= -before && dt <= after)
        {
         if(strat == ST_IN_NEWS && dt >= 5.0 && fk == 0)
            continue;
         if(strat == ST_IN_DATA && dt >= 0.0 && fk == 0)
            continue;                         // 1.26: IN-DATO entra proprio dopo il dato
         why = "news " + g_news[i].title + (dt < 0 ? " tra " : " uscita da ") + IntegerToString((int)MathAbs(dt)) + " min";
         return true;
        }
     }
   return false;
  }

//+------------------------------------------------------------------+
//| JSON minimo (solo quello che serve)                              |
//+------------------------------------------------------------------+
ushort JsCh(const string &s, int i) { return StringGetCharacter(s, i); }

int JsSkipSpace(const string &s, int i)
  {
   int n = StringLen(s);
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c != ' ' && c != '\n' && c != '\r' && c != '\t')
         break;
      i++;
     }
   return i;
  }

//--- fine di una stringa che inizia con " in posizione i (ritorna indice del " di chiusura)
int JsStringEnd(const string &s, int i)
  {
   int n = StringLen(s);
   i++;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '\\')
        {
         i += 2;
         continue;
        }
      if(c == '"')
         return i;
      i++;
     }
   return n - 1;
  }

//--- posizione del valore della chiave 'key' al primo livello dell'oggetto in s (-1 se manca)
int JsonTopKey(const string &s, string key)
  {
   int n = StringLen(s);
   int depth = 0;
   int i = 0;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '"')
        {
         int e = JsStringEnd(s, i);
         if(depth == 1)
           {
            int j = JsSkipSpace(s, e + 1);
            if(j < n && JsCh(s, j) == ':')
              {
               if(StringSubstr(s, i + 1, e - i - 1) == key)
                  return JsSkipSpace(s, j + 1);
              }
           }
         i = e + 1;
         continue;
        }
      if(c == '{' || c == '[')
         depth++;
      else
         if(c == '}' || c == ']')
            depth--;
      i++;
     }
   return -1;
  }

double JsonNum(const string &s, string key, double def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0)
      return def;
   int n = StringLen(s);
   int e = p;
   while(e < n)
     {
      ushort c = JsCh(s, e);
      if((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E')
         e++;
      else
         break;
     }
   if(e == p)
      return def;
   return StringToDouble(StringSubstr(s, p, e - p));
  }

bool JsonBool(const string &s, string key, bool def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0)
      return def;
   if(StringSubstr(s, p, 4) == "true")
      return true;
   if(StringSubstr(s, p, 5) == "false")
      return false;
   return def;
  }

string JsonStr(const string &s, string key, string def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0 || JsCh(s, p) != '"')
      return def;
   int e = JsStringEnd(s, p);
   return StringSubstr(s, p + 1, e - p - 1);
  }

//--- oggetti di un array: a partire dalla '[' in posizione p
int JsonArrayObjects(const string &s, int p, string &objs[])
  {
   ArrayResize(objs, 0);
   int n = StringLen(s);
   if(p < 0 || p >= n || JsCh(s, p) != '[')
      return 0;
   int depth = 0;
   int start = -1;
   int cnt = 0;
   int i = p + 1;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '"')
        {
         i = JsStringEnd(s, i) + 1;
         continue;
        }
      if(c == '{')
        {
         if(depth == 0)
            start = i;
         depth++;
        }
      else
         if(c == '}')
           {
            depth--;
            if(depth == 0 && start >= 0)
              {
               ArrayResize(objs, cnt + 1);
               objs[cnt] = StringSubstr(s, start, i - start + 1);
               cnt++;
               start = -1;
              }
           }
         else
            if(c == ']' && depth == 0)
               break;
      i++;
     }
   return cnt;
  }

datetime ParseIsoUtc(string s)
  {
   string t = s;
   StringReplace(t, "-", ".");
   StringReplace(t, "T", " ");
   StringReplace(t, "Z", "");
   return StringToTime(t);
  }

//+------------------------------------------------------------------+
//| Dati esterni da GitHub                                           |
//+------------------------------------------------------------------+
double   g_macroBias = 0.0, g_macroConf = 0.0, g_macroRiskMult = 1.0;
bool     g_macroHalt = false;
string   g_macroHaltReason = "";
//--- macro piu' ricca: stato delle fonti e informazioni extra del servizio (solo da leggere: non cambiano le decisioni)
bool     g_macroIncomplete = false;
string   g_macroMissing = "";
string   g_extraText = "";
string   g_lastDataText = "";
datetime g_lastDataTime = 0;
datetime g_macroTime = 0;
string   g_aiStance = "";
double   g_aiConv = 0.0;
datetime g_aiTime = 0;
datetime g_webLastTry = 0;
double   g_mBias = 0.0;       // macro combinata usata dal comitato (GitHub + storico + intermarket)
double   g_mConf = 0.0;
string   g_mSource = "";
bool     g_webWarned = false;

bool MacroFresh() { return (g_macroTime > 0 && ToUTC(TimeCurrent()) - g_macroTime <= 6 * 3600); }
bool AiFresh()    { return (g_aiTime > 0 && ToUTC(TimeCurrent()) - g_aiTime <= 8 * 3600); }

bool HttpGet(string url, string &body)
  {
   char data[];
   char res[];
   string hdr;
   ResetLastError();
   int code = WebRequest("GET", url, "", 5000, data, res, hdr);
   if(code == -1)
     {
      int err = GetLastError();
      if(!g_webWarned)
        {
         g_webWarned = true;
         Notify("Dati esterni non leggibili (errore " + IntegerToString(err) + "). In MT5: Strumenti > Opzioni > Expert Advisors > spunta 'Consenti WebRequest' e aggiungi https://raw.githubusercontent.com");
        }
      return false;
     }
   if(code != 200)
      return false;
   body = CharArrayToString(res, 0, WHOLE_ARRAY, CP_UTF8);
   return (StringLen(body) > 2);
  }

void ParseMacro(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   g_macroTime = ParseIsoUtc(ts);
   g_macroBias = Clamp(JsonNum(js, "bias", 0.0), -1.0, 1.0);
   g_macroConf = Clamp(JsonNum(js, "confidence", 0.0), 0.0, 1.0);
   g_macroRiskMult = Clamp(JsonNum(js, "risk_multiplier", 1.0), 0.3, 1.5);
   g_macroHalt = JsonBool(js, "halt_trading", false);
   g_macroHaltReason = JsonStr(js, "halt_reason", "");
   g_macroIncomplete = JsonBool(js, "macro_incompleta", false);
   g_macroMissing = JsonStr(js, "fonti_mancanti_testo", "");
   g_extraText = JsonStr(js, "extra_sintesi", "");
   g_lastDataText = JsonStr(js, "ultimo_dato", "");
   string ldt = JsonStr(js, "ultimo_dato_ora_utc", "");
   g_lastDataTime = (ldt != "") ? ParseIsoUtc(ldt) : 0;
   //--- viste pre-news del servizio di ricerca
   string objs[];
   int n = JsonArrayObjects(js, JsonTopKey(js, "pre_news"), objs);
   for(int i = 0; i < n; i++)
     {
      string t = JsonStr(objs[i], "time_utc", "");
      if(t == "")
         continue;
      datetime u = ParseIsoUtc(t);
      int tier = (int)JsonNum(objs[i], "tier", 1.0);
      string title = JsonStr(objs[i], "event", "evento");
      int k = NewsFind(u, "", 600);
      if(k < 0)
         k = NewsUpsert(u, IMax(1, IMin(tier, 2)), title);
      if(k < 0)
         continue;
      g_news[k].preDir = (int)MathRound(Clamp(JsonNum(objs[i], "gold_direction", 0.0), -1.0, 1.0));
      g_news[k].preConf = Clamp(JsonNum(objs[i], "confidence", 0.0), 0.0, 1.0);
     }
  }

void ParseCommittee(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   g_aiTime = ParseIsoUtc(ts);
   g_aiStance = JsonStr(js, "stance", "flat");
   g_aiConv = Clamp(JsonNum(js, "conviction", 0.0), 0.0, 1.0);
  }

void ParseVolumeLevels(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   double last = JsonNum(js, "gc_last", 0.0);
   int p = JsonTopKey(js, "composite");
   if(p < 0 || last <= 0.0)
      return;
   //--- l'oggetto composite: lo isolo e leggo poc/vah/val
   int n = StringLen(js);
   int depth = 0, e = p;
   for(int i = p; i < n; i++)
     {
      ushort c = JsCh(js, i);
      if(c == '"')
        {
         i = JsStringEnd(js, i);
         continue;
        }
      if(c == '{')
         depth++;
      if(c == '}')
        {
         depth--;
         if(depth == 0)
           {
            e = i;
            break;
           }
        }
     }
   string comp = StringSubstr(js, p, e - p + 1);
   g_gcPoc = JsonNum(comp, "poc", 0.0);
   g_gcVah = JsonNum(comp, "vah", 0.0);
   g_gcVal = JsonNum(comp, "val", 0.0);
   g_gcLast = last;
   g_gcDeltaTrend = Clamp(JsonNum(js, "delta_trend", 0.0), -1.0, 1.0);
   g_gcTime = ParseIsoUtc(ts);
  }

//--- calendario di riserva dal JSON (se il calendario MT5 e' vuoto)
void ParseNewsCalendar(const string &js)
  {
   string objs[];
   int n = JsonArrayObjects(js, JsSkipSpace(js, 0), objs);
   for(int i = 0; i < n; i++)
     {
      string t = JsonStr(objs[i], "time_utc", "");
      int tier = (int)JsonNum(objs[i], "tier", 4.0);
      if(t == "" || tier > 2)
         continue;
      NewsMerge(ParseIsoUtc(t), tier, JsonStr(objs[i], "title", "news"));
     }
  }

void WebRefresh()
  {
   if(!InpUseWebData || g_isTester)
      return;
   g_webLastTry = TimeCurrent();
   string body;
   if(InpMacroUrl != "" && HttpGet(InpMacroUrl, body))
      ParseMacro(body);
   if(InpCommitteeUrl != "" && HttpGet(InpCommitteeUrl, body))
      ParseCommittee(body);
   if(InpVolumeUrl != "" && HttpGet(InpVolumeUrl, body))
      ParseVolumeLevels(body);
   if(InpNewsUrl != "" && HttpGet(InpNewsUrl, body))   // 1.19: sempre, anche se MT5 ha gia' dato eventi
     {
      ParseNewsCalendar(body);
      NewsLogNext(ToUTC(TimeCurrent()), "MT5 + GitHub + date ufficiali");
     }
  }

//+------------------------------------------------------------------+
//| Vista pre-news: 30 minuti prima della news il desk news fissa    |
//| la direzione attesa; dopo la news si entra SOLO se conferma      |
//+------------------------------------------------------------------+
void NewsTrack()
  {
   datetime nowU = g_ctx.nowUtc;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier > 2)
         continue;
      long dt = (long)(nowU - g_news[i].utc);
      if(!g_news[i].viewTaken && dt >= -30 * 60 && dt < 0)
        {
         int trend = TrendDir(g_h1);
         int vw = (g_ctx.vwap > 0.0) ? ((BarC(g_m5, 0) > g_ctx.vwap) ? 1 : -1) : 0;
         int macro = 0;
         if(g_mConf >= 0.3 && MathAbs(g_mBias) >= 0.15)
            macro = (g_mBias > 0.0) ? 1 : -1;
         int dir = 0;
         if(g_news[i].preConf >= 0.5 && g_news[i].preDir != 0)
            dir = g_news[i].preDir;
         else
            if(trend != 0 && trend == vw && (macro == 0 || macro == trend))
               dir = trend;
         g_news[i].viewDir = dir;
         g_news[i].preClose = BarC(g_m5, 0);
         g_news[i].preAtr = MathMax(AtrOf(g_m15), g_tick * 10);
         g_news[i].extreme = g_news[i].preClose;
         g_news[i].viewTaken = true;
         string vtxt = (dir > 0) ? "rialzo" : ((dir < 0) ? "ribasso" : "neutra");
         Logf("Vista pre-news su " + g_news[i].title + ": " + vtxt);
        }
      if(g_news[i].viewTaken && g_news[i].viewDir != 0 && dt >= 0 && dt <= 120 * 60)
        {
         if(g_news[i].viewDir > 0)
            g_news[i].extreme = MathMax(g_news[i].extreme, BarH(g_m5, 0));
         else
            g_news[i].extreme = MathMin(g_news[i].extreme, BarL(g_m5, 0));
        }
     }
  }

//--- vista per la prossima news tier1 entro 'horizonMin' (dal servizio di ricerca o dalla vista fissata)
int NextEventView(datetime nowUtc, int horizonMin)
  {
   int k = NextTier1Index(nowUtc);
   if(k < 0)
      return 0;
   if((g_news[k].utc - nowUtc) / 60 > horizonMin)
      return 0;
   if(g_news[k].viewTaken)
      return g_news[k].viewDir;
   if(g_news[k].preConf >= 0.5)
      return g_news[k].preDir;
   return 0;
  }
