//+------------------------------------------------------------------+
//| Risk manager: limiti del conto, lotti dinamici, profit cushion,  |
//| recupero, scaglioni, esecuzione                                  |
//+------------------------------------------------------------------+
bool TradingHalted(string &why)
  {
   if(g_ddHalt)
     {
      why = "STOP per drawdown massimo: per ripartire imposta 'Sblocca' = true";
      return true;
     }
   if(g_weekHalt)
     {
      why = "stop settimanale raggiunto (-" + DoubleToString(InpWeeklyLossPct, 1) + "%)";
      return true;
     }
   if(g_dayHalt)
     {
      why = "stop giornaliero raggiunto (-" + DoubleToString(InpDailyLossPct, 1) + "%)";
      return true;
     }
   if(!g_isTester && (!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED)))
     {
      why = "trading automatico disattivato (pulsante Algo Trading)";
      return true;
     }
   return false;
  }

void CloseAll(string why)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym || !IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      g_trade.PositionClose(tk);
     }
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong tk = OrderGetTicket(i);
      if(tk == 0)
         continue;
      if(OrderGetString(ORDER_SYMBOL) != g_sym || !IsOurMagic(OrderGetInteger(ORDER_MAGIC)))
         continue;
      g_trade.OrderDelete(tk);
     }
   g_needSweep = true;
   Notify("CHIUSO TUTTO: " + why);
  }

//--- nuovo giorno / nuova settimana del broker
void RiskPeriodCheck()
  {
   datetime dA = iTime(g_sym, PERIOD_D1, 0);
   datetime wA = iTime(g_sym, PERIOD_W1, 0);
   bool changed = false;
   if(dA != 0 && dA != g_dayAnchor)
     {
      g_dayAnchor = dA;
      g_dayStartEq = AccEquity();
      g_dayHalt = false;
      g_tradesToday[0] = 0;
      g_tradesToday[1] = 0;
      g_tradesToday[2] = 0;
      g_lossesInRowToday = 0;
      changed = true;
     }
   if(wA != 0 && wA != g_weekAnchor)
     {
      g_weekAnchor = wA;
      g_weekStartEq = AccEquity();
      g_weekStartBal = AccBalance();
      g_weekHalt = false;
      changed = true;
     }
   if(changed)
      GvSave();
  }

//+------------------------------------------------------------------+
//| Depositi e prelievi: il bot si adatta al nuovo saldo ma NON li   |
//| scambia per guadagni o perdite (niente falsi stop giornalieri)   |
//+------------------------------------------------------------------+
datetime g_flowCheckedTo = 0;
double   g_lastRealBal = 0.0;

void ApplyCashFlow(double amount, datetime when)
  {
   if(amount == 0.0)
      return;
   if(InpVirtualCapital > 0.0)
     {
      //--- con il capitale virtuale i movimenti del conto vero non lo cambiano
      g_vStartBal += amount;
      g_vStartEq += amount;
      GlobalVariableSet(GvName("vStartBal"), g_vStartBal);
      GlobalVariableSet(GvName("vStartEq"), g_vStartEq);
     }
   else
     {
      //--- conto vero: i riferimenti si spostano insieme al saldo (non e' un guadagno ne' una perdita)
      g_dayStartEq += amount;
      g_weekStartEq += amount;
      g_weekStartBal += amount;
      g_peakEq = MathMax(g_peakEq + amount, AccEquity());
     }
   GvSave();
   string what = (amount > 0.0) ? "Deposito" : "Prelievo";
   Notify(what + " di " + Money(MathAbs(amount)) + ": lotti e limiti ricalcolati sul nuovo saldo (" + Money(AccEquity()) + ")");
  }

//--- cerca depositi/prelievi nello storico dall'ultimo controllo
void CashFlowScan()
  {
   if(g_isTester)
      return;
   datetime now = ServerNow();
   datetime from = g_flowCheckedTo;
   if(from <= 0)
     {
      from = (datetime)GvGet("flowTo", 0.0);
      if(from <= 0)
        {
         g_flowCheckedTo = now;
         GlobalVariableSet(GvName("flowTo"), (double)now);
         return;
        }
     }
   if(!HistorySelect(from + 1, now + 60))
      return;
   int n = HistoryDealsTotal();
   for(int i = 0; i < n; i++)
     {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0)
         continue;
      if(HistoryDealGetInteger(d, DEAL_TYPE) != DEAL_TYPE_BALANCE)
         continue;
      ApplyCashFlow(HistoryDealGetDouble(d, DEAL_PROFIT), (datetime)HistoryDealGetInteger(d, DEAL_TIME));
     }
   g_flowCheckedTo = now;
   GlobalVariableSet(GvName("flowTo"), (double)now);
  }

//--- il saldo vero e' cambiato: prima di tutto controllo se e' un deposito/prelievo
void FlowCheck()
  {
   if(g_isTester)
      return;
   double rb = AccountInfoDouble(ACCOUNT_BALANCE);
   if(rb != g_lastRealBal)
     {
      g_lastRealBal = rb;
      CashFlowScan();
     }
  }

//--- controllato a ogni tick
void RiskCheckLimits()
  {
   FlowCheck();
   double eq = AccEquity();
   if(eq <= 0.0)
      return;
   if(eq > g_peakEq)
     {
      g_peakEq = eq;
      if(!g_isTester && MathRand() % 50 == 0)
         GlobalVariableSet(GvName("peak"), g_peakEq);
     }
   if(!g_ddHalt && g_peakEq > 0.0 && eq <= g_peakEq * (1.0 - InpMaxDrawdownPct / 100.0))
     {
      g_ddHalt = true;
      CloseAll("drawdown " + Pct(InpMaxDrawdownPct) + " dal picco. L'EA si ferma.");
      GvSave();
      return;
     }
   if(!g_weekHalt && g_weekStartEq > 0.0 && eq <= g_weekStartEq * (1.0 - InpWeeklyLossPct / 100.0))
     {
      g_weekHalt = true;
      CloseAll("stop settimanale -" + Pct(InpWeeklyLossPct));
      GvSave();
      return;
     }
   if(!g_dayHalt && g_dayStartEq > 0.0 && eq <= g_dayStartEq * (1.0 - InpDailyLossPct / 100.0))
     {
      g_dayHalt = true;
      CloseAll("stop giornaliero -" + Pct(InpDailyLossPct));
      GvSave();
     }
  }

//--- perdita per 1 lotto fino allo stop, commissione inclusa (valuta del conto)
double LossPerLot(int dir, double entry, double sl)
  {
   double p = 0.0;
   ENUM_ORDER_TYPE t = (dir > 0) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   if(!OrderCalcProfit(t, g_sym, 1.0, entry, sl, p) || p == 0.0)
      p = -(entry - sl) * dir * ValuePerPriceUnit();
   return MathAbs(p) + CommPerLotEff();   // K (1.25): commissione misurata se disponibile
  }

//--- V (1.25): volatilita' prevista per le prossime ore rispetto al normale.
//    ATR H1 rispetto alla sua mediana, corretto con l'attivita' dell'ultima ora (studio order flow: piu' tick del
//    solito -> ora dopo piu' ampia, elasticita' circa 0,3 in tutti i periodi 2022-2026)
double VolForecast()
  {
   double a = (g_atrRatioH1 > 0.0) ? g_atrRatioH1 : 1.0;
   double rv = RvolBar(g_h1, 1);
   if(rv <= 0.0)
      rv = 1.0;                              // senza dati di volume: nessuna correzione
   rv = Clamp(rv, 0.5, 3.0);
   return Clamp(a * MathPow(rv, 0.3), 0.3, 5.0);
  }

//--- V (1.25): moltiplicatore del rischio (Moreira-Muir: esposizione inversa alla volatilita' prevista),
//    solo verso il basso: sotto 1,2 volte il normale non cambia nulla
double VolTargetMult()
  {
   if(!InpVolTarget)
      return 1.0;
   double fc = VolForecast();
   if(fc <= 1.2)
      return 1.0;
   return Clamp(1.2 / fc, Clamp(InpVolMinMult, 0.1, 1.0), 1.0);
  }

double BaseCapital()
  {
   return MathMin(AccEquity(), AccBalance());
  }

//--- recupero: una sola volta dopo una perdita, solo con idee di altissima qualita'
bool RecoveryEligible(const TSignal &s)
  {
   if(!InpRecoveryEnabled || !g_recoveryArmed)
      return false;
   if(TimeCurrent() - g_recoveryArmedT > 24 * 3600)
      return false;
   if(!(s.strat == ST_SC_VWAP || s.strat == ST_IN_PULLBACK || s.strat == ST_SW_TREND))
      return false;
   if(s.score < InpRecoveryMinScore || s.desk[D_VOLUME] < 0.6 || s.desk[D_MACRO] < 0.5 || s.desk[D_CONTEXT] < 0.55)
      return false;
   int conf = 0;
   if(s.desk[D_TREND] >= 0.6)
      conf++;
   if(s.desk[D_VOLUME] >= 0.6)
      conf++;
   if(s.desk[D_LIQ] >= 0.6)
      conf++;
   if(s.desk[D_SESSION] >= 0.6)
      conf++;
   if(conf < 3)
      return false;
   int m = MinutesToNextTier1(g_ctx.nowUtc);
   int need = (s.engine == ENG_SWING) ? 720 : 240;
   if(m >= 0 && m < need)
      return false;
   if(g_regime == REG_VOLATILE)
      return false;
   return true;
  }

//--- rientro (1.17): il trade di prima e' tornato a pareggio e le conferme ci sono ancora
bool ReentryEligible(const TSignal &s)
  {
   int e = s.engine;
   if(!InpReentryOn || s.recovery || e < 0 || e > 2 || !g_reArmed[e] || s.dir != g_reDir[e])
      return false;
   int win = (e == ENG_SCALP) ? 60 : ((e == ENG_INTRA) ? 240 : 1440);
   if(TimeCurrent() - g_reT[e] > win * 60)
      return false;
   if(s.score < MinScoreFor(e) + 0.03 || s.quorum < InpQuorum + 1 || s.devil > 1)
      return false;
   if(s.desk[D_CONTEXT] < 0.55 || s.desk[D_MACRO] < 0.5)
      return false;
   return true;
  }

//--- idea A+ (1.18): tutte le conferme insieme -> rischio piu' alto, lotti fino a InpAplusMaxLots
bool AplusEligible(const TSignal &s, int against)
  {
   if(!InpAplusOn || s.recovery || against > 0 || g_regime == REG_VOLATILE || g_runBrake || g_lossStreak >= 2)
      return false;
   double need = MathMax(InpAplusMinScore, MinScoreFor(s.engine) + 0.05);
   if(s.score < need - 0.000001 || s.quorum < 7 || s.devil > 1)
      return false;
   if(s.desk[D_CONTEXT] < 0.55 || s.desk[D_MACRO] < 0.5)
      return false;
   return true;
  }

//--- riduce i lotti finche' il margine resta sopra il livello minimo
double FitMargin(int dir, double entry, double lots, string &why)
  {
   double m1 = 0.0;
   ENUM_ORDER_TYPE t = (dir > 0) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   if(!OrderCalcMargin(t, g_sym, 1.0, entry, m1) || m1 <= 0.0)
      return lots;
   double eq = AccEquity();
   double used = AccountInfoDouble(ACCOUNT_MARGIN);
   double allow = eq * 100.0 / MathMax(InpMinMarginLevel, 100.0) - used;
   double maxLots = FloorLot(allow / m1);
   if(maxLots < lots)
     {
      lots = maxLots;
      if(lots < g_minLot)
         why = "margine insufficiente: con questa leva 0.01 lotti richiedono " + Money(m1 * g_minLot);
     }
   return lots;
  }

//--- lotti per il segnale: rischio % -> denaro -> lotti, con tutti i limiti
//--- 1.26: rischio massimo accettato con il lotto minimo (i movimenti forti hanno stop larghi: tetto proprio, mai oltre il massimo per trade)
double OndaMinLotCap();
double ReadRiskMult(const TSignal &s);
double AstaRiskMult(const TSignal &s);

double MinLotCapFor(const TSignal &s)
  {
   if(IsOnda(s.strat))
      return OndaMinLotCap();                   // 1.27: tetto proprio dei ritracciamenti
   if(s.proven)
      return MathMax(MathMin(InpTDMinLotRiskPct, InpMaxRiskPerTrade), InpMinLotMaxRiskPct);
   return InpMinLotMaxRiskPct;
  }

double LotsFor(TSignal &s, double &riskMoneyOut, string &why)
  {
   riskMoneyOut = 0.0;
   double base = BaseCapital();
   if(base <= 0.0)
     {
      why = "conto senza capitale";
      return 0.0;
     }
   double pct = InpRiskPercent;
   if(s.engine == ENG_SCALP)
      pct *= InpScalpRiskMult;
   else
      if(s.engine == ENG_SWING)
         pct *= InpSwingRiskMult;
   //--- regime volatile (x0,5) e C1 giornata larga (1.20) sono gia' tagli per volatilita':
   //    V (1.25) prende il taglio piu' forte tra quelli e la volatilita' prevista, senza sommarli
   double c1f = (g_bigDay && s.engine != ENG_SWING) ? Clamp(InpC1RiskMult, 0.0, 1.0) : 1.0;
   double oldVol = ((g_regime == REG_VOLATILE) ? 0.5 : 1.0) * c1f;
   double vmult = VolTargetMult();
   pct *= MathMin(oldVol, vmult);
   if(g_runBrake)
      pct *= Clamp(InpP1RiskMult, 0.0, 1.0);   // P1 (1.17): corsa verticale, rischio ridotto
   if(MacroFresh())
      pct *= Clamp(g_macroRiskMult, 0.5, 1.2);
   //--- macro o contesto contrari (ma non abbastanza per il veto): posizione piu' piccola
   int against = 0;
   if(g_mConf >= 0.3 && g_mBias * s.dir < -0.2)
      against++;
   if(g_ctxBias * s.dir < -0.2)
      against++;
   pct *= (1.0 - 0.25 * against);
   s.recovery = RecoveryEligible(s);
   if(s.recovery)
      pct *= InpRecoveryMult;
   else
      if(g_lossStreak >= 3)
         pct *= 0.5;
      else
         if(g_lossStreak == 2)
            pct *= 0.75;
   s.reentry = ReentryEligible(s);
   if(s.reentry)
      pct *= Clamp(InpReentryMult, 1.0, 2.0);
   if(s.overrideOk)
      pct *= Clamp(InpOverrideRiskMult, 0.2, 1.0);   // MR (1.25): passa scavalcando obiezioni secondarie, rischio ridotto
   s.aplus = !s.overrideOk && AplusEligible(s, against);
   if(s.aplus)
      pct = MathMax(pct, Clamp(InpAplusRiskPct, 0.0, InpMaxRiskPerTrade) * (s.reentry ? Clamp(InpReentryMult, 1.0, 2.0) : 1.0) *
                    MathMin(c1f, vmult));   // C1 e V valgono anche per le A+
   if(s.proven)
     {
      //--- 1.26: movimenti forti: rischio base x moltiplicatore, ridotto solo dopo le perdite di fila.
      //    Macro, contesto e volatilita' non lo cambiano (sui dati non spostano il risultato); niente recupero, rientro o A+.
      pct = InpRiskPercent * TmRiskMult(s.strat) * Clamp(s.riskX, 0.25, 2.0);
      if(g_lossStreak >= 3)
         pct *= 0.5;
      else
         if(g_lossStreak == 2)
            pct *= 0.75;
      s.recovery = false;
      s.reentry = false;
      s.aplus = false;
     }
   pct *= ReadRiskMult(s);                      // 1.27: letture del mercato provate (contrarie: meno rischio)
   pct *= AstaRiskMult(s);                      // 1.28: idee nate fuori dall'equilibrio d'asta (se acceso)
   pct = MathMin(pct, InpMaxRiskPerTrade);
   double money = base * pct / 100.0;
   //--- profit cushion: le idee forti possono rischiare in piu' SOLO profitti gia' incassati in settimana
   double extra = 0.0;
   if(InpUseProfitCushion && s.strong && !s.recovery && !s.aplus)
     {
      double cushion = AccBalance() - g_weekStartBal;
      if(cushion > 0.0)
         extra = MathMin(cushion * InpCushionUse, money * InpCushionMaxMult);
     }
   s.cushion = extra;
   money += extra;
   PortfolioScan();
   double room = base * InpMaxOpenRiskPct / 100.0 + extra - g_openRiskMoney;
   if(room <= 0.0)
     {
      why = "rischio aperto gia' al massimo (" + Pct(InpMaxOpenRiskPct) + ")";
      return 0.0;
     }
   money = MathMin(money, room);
   //--- S (1.25): le posizioni sono tutte oro, quindi lo stesso verso e' una scommessa sola
   double roomDir = base * InpMaxDirRiskPct / 100.0 + extra - g_openRiskDir[(s.dir > 0) ? 0 : 1];
   if(InpMaxDirRiskPct > 0.0 && roomDir <= 0.0)
     {
      why = "rischio aperto nello stesso verso gia' al massimo (" + Pct(InpMaxDirRiskPct) + ")";
      return 0.0;
     }
   if(InpMaxDirRiskPct > 0.0)
     {
      money = MathMin(money, roomDir);
      room = MathMin(room, roomDir);
     }
   double lpl = LossPerLot(s.dir, s.entry, s.sl);
   if(InpCostTrack)
      lpl += SlipEstPx(g_ctx.spread) * ValuePerPriceUnit();   // K (1.25): lo slittamento medio fa parte del rischio vero
   if(lpl <= 0.0)
     {
      why = "calcolo della perdita per lotto fallito";
      return 0.0;
     }
   double lots = FloorLot(money / lpl);
   if(lots < g_minLot)
     {
      double minRisk = lpl * g_minLot;
      double minPct = 100.0 * minRisk / base;
      double capMin = MinLotCapFor(s);
      if(minPct <= capMin && minRisk <= room + base * 0.005)
         lots = g_minLot;
      else
        {
         why = "conto piccolo per questo stop: " + DoubleToString(g_minLot, g_lotDigits) + " lotti = " + Pct(minPct) +
               " di rischio (max " + Pct(capMin) + ", servono circa " + DoubleToString(minRisk * 100.0 / MathMax(capMin, 0.1), 0) + " " + g_currency + ")";
         return 0.0;
        }
     }
   lots = MathMin(lots, MathMin(InpMaxLots, g_maxLot));
   if(s.aplus && InpAplusMaxLots > 0.0)
      lots = MathMin(lots, MathMax(FloorLot(InpAplusMaxLots), g_minLot));
   lots = FitMargin(s.dir, s.entry, lots, why);
   if(lots < g_minLot)
     {
      if(why == "")
         why = "lotti sotto il minimo";
      return 0.0;
     }
   riskMoneyOut = lots * lpl;
   return lots;
  }

//--- distanza minima dello stop dal prezzo imposta dal broker
double StopsMinDist()
  {
   long lvl = SymbolInfoInteger(g_sym, SYMBOL_TRADE_STOPS_LEVEL);
   long frz = SymbolInfoInteger(g_sym, SYMBOL_TRADE_FREEZE_LEVEL);
   long m = (lvl > frz) ? lvl : frz;
   return (double)m * g_point + g_tick;
  }

double g_sendReqPx = 0.0, g_sendSpread = 0.0;
string g_execWhy = "";

bool RetOk(uint rc) { return (rc == TRADE_RETCODE_DONE || rc == TRADE_RETCODE_PLACED || rc == TRADE_RETCODE_DONE_PARTIAL); }

int MetaRecord(const TSignal &s, long id, int tranche, double lots, double entry, bool pending, int expiryMin)
  {
   int k = MetaFree();
   if(k < 0)
      return -1;
   g_meta[k].Reset();
   g_meta[k].active = true;
   g_meta[k].id = id;
   g_meta[k].strat = s.strat;
   g_meta[k].engine = s.engine;
   g_meta[k].dir = s.dir;
   g_meta[k].tranche = tranche;
   g_meta[k].idea = g_ideaSeq;
   g_meta[k].entry = entry;
   g_meta[k].sl0 = s.sl;
   g_meta[k].tp = s.tp;
   g_meta[k].riskPx = (entry - s.sl) * s.dir;
   g_meta[k].riskMoney = lots * LossPerLot(s.dir, entry, s.sl);
   g_meta[k].lots0 = lots;
   g_meta[k].score = s.score;
   g_meta[k].cushion = s.cushion;
   g_meta[k].recovery = s.recovery;
   g_meta[k].reentry = s.reentry;
   g_meta[k].aplus = s.aplus;
   g_meta[k].isPending = pending;
   g_meta[k].openTime = TimeCurrent();
   g_meta[k].expiryMin = expiryMin;
   g_meta[k].deadline = s.deadline;
   return k;
  }

bool SendMarket(const TSignal &s, double lots, long &idOut)
  {
   double sl = NormPrice(s.sl), tp = NormPrice(s.tp);
   double px = (s.dir > 0) ? PxAsk() : PxBid();
   double md = StopsMinDist();
   if((px - sl) * s.dir < md || (tp - px) * s.dir < md)
     {
      Logf("Ordine saltato: stop o target troppo vicini al prezzo per il broker");
      return false;
     }
   g_trade.SetExpertMagicNumber((ulong)MagicOfEngine(s.engine));
   g_sendReqPx = px;                       // K (1.25): prezzo visto all'invio e spread pagato
   g_sendSpread = PxAsk() - PxBid();
   string cmt = "XC " + g_stratName[s.strat];
   bool ok = (s.dir > 0) ? g_trade.Buy(lots, g_sym, 0.0, sl, tp, cmt) : g_trade.Sell(lots, g_sym, 0.0, sl, tp, cmt);
   uint rc = g_trade.ResultRetcode();
   if(!ok || !RetOk(rc))
     {
      Logf("Ordine rifiutato: " + IntegerToString((int)rc) + " " + g_trade.ResultRetcodeDescription());
      return false;
     }
   idOut = (long)g_trade.ResultOrder();
   ulong deal = g_trade.ResultDeal();
   if(deal > 0 && HistoryDealSelect(deal))
     {
      long pid = HistoryDealGetInteger(deal, DEAL_POSITION_ID);
      if(pid > 0)
         idOut = pid;
     }
   return true;
  }

bool SendLimit(const TSignal &s, double lots, double price, long &idOut)
  {
   price = NormPrice(price);
   double sl = NormPrice(s.sl), tp = NormPrice(s.tp);
   double px = (s.dir > 0) ? PxAsk() : PxBid();
   double md = StopsMinDist();
   if((px - price) * s.dir < md || (price - sl) * s.dir < md)
      return false;
   g_trade.SetExpertMagicNumber((ulong)MagicOfEngine(s.engine));
   string cmt = "XC " + g_stratName[s.strat] + " T";
   bool ok = (s.dir > 0) ? g_trade.BuyLimit(lots, price, g_sym, sl, tp, ORDER_TIME_GTC, 0, cmt)
             : g_trade.SellLimit(lots, price, g_sym, sl, tp, ORDER_TIME_GTC, 0, cmt);
   if(!ok || !RetOk(g_trade.ResultRetcode()))
      return false;
   idOut = (long)g_trade.ResultOrder();
   return true;
  }

int ExpiryFor(int engine)
  {
   if(engine == ENG_SCALP)
      return 10;
   if(engine == ENG_INTRA)
      return 60;
   return 480;
  }

string TmHoldText();

//--- esegue un segnale approvato (con eventuali ingressi scaglionati)
int CloseOppOnda(int dir, string why);

bool Execute(TSignal &s)
  {
   double riskMoney = 0.0;
   string why = "";
   g_execWhy = "";
   //--- 1.27: movimento forte contro ritracciamenti ancora a rischio: prima li chiude (liberano posto e rischio)
   if(s.flip)
     {
      int nc = CloseOppOnda(s.dir, "movimento forte " + DirName(s.dir) + " contro il ritracciamento");
      if(nc > 0)
         Notify(g_stratName[s.strat] + " " + DirName(s.dir) + ": chiusi " + IntegerToString(nc) + " ritracciamenti aperti nel verso opposto prima di entrare");
     }
   double lots = LotsFor(s, riskMoney, why);
   if(lots <= 0.0)
     {
      g_execWhy = why;
      string line = "[" + g_engName[s.engine] + "] " + g_stratName[s.strat] + " " + DirName(s.dir) + " approvato ma NON eseguito: " + why;
      Logf(line);
      RememberDecision(line);
      return false;
     }
   g_ideaSeq++;
   double w[3];
   w[0] = 1.0;
   w[1] = 0.0;
   w[2] = 0.0;
   double depth[3];
   depth[0] = 0.0;
   depth[1] = 0.25;
   depth[2] = 0.5;
   int nTr = 1;
   PortfolioScan();
   int slots = MaxPositionsEff() - g_cntAll;
   //--- coda (1.17): gli ingressi scaglionati lasciano un posto a ogni altro motore attivo e vuoto
   if(InpQueueOn)
     {
      if(s.engine != ENG_SCALP && InpEnableScalping && g_cntEng[ENG_SCALP] == 0)
         slots--;
      if(s.engine != ENG_INTRA && InpEnableIntraday && g_cntEng[ENG_INTRA] == 0)
         slots--;
      if(s.engine != ENG_SWING && InpEnableSwing && g_cntEng[ENG_SWING] == 0)
         slots--;
     }
   if(InpAllowTranches && s.strong && s.engine != ENG_SCALP && !g_netting && !s.recovery && !s.aplus)
     {
      if(slots >= 3 && FloorLot(lots * 0.3) >= g_minLot)
        {
         nTr = 3;
         w[0] = 0.4;
         w[1] = 0.3;
         w[2] = 0.3;
        }
      else
         if(slots >= 2 && FloorLot(lots * 0.4) >= g_minLot)
           {
            nTr = 2;
            w[0] = 0.6;
            w[1] = 0.4;
           }
     }
   double risk = RiskPx(s);
   int opened = 0;
   double total = 0.0;
   for(int k = 0; k < nTr; k++)
     {
      double lk = (nTr == 1) ? lots : FloorLot(lots * w[k]);
      if(lk < g_minLot)
         continue;
      long id = 0;
      if(k == 0)
        {
         if(!SendMarket(s, lk, id))
            break;
         double fill = g_trade.ResultPrice();
         if(fill <= 0.0)
            fill = s.entry;
         int mk = MetaRecord(s, id, 0, lk, fill, false, 0);
         //--- K (1.25): slittamento e spread di questo ingresso
         double slip = (g_sendReqPx > 0.0) ? (fill - g_sendReqPx) * s.dir : 0.0;
         if(mk >= 0)
           {
            g_meta[mk].spreadPx = g_sendSpread;
            g_meta[mk].slipPx = slip;
           }
         if(InpCostTrack && g_sendReqPx > 0.0)
           {
            g_costSlipPx = CostAvg(g_costSlipPx, g_costSlipN, slip);
            g_costSlipN++;
            g_costSpreadPx = CostAvg(g_costSpreadPx, g_costSpreadN, g_sendSpread);
            g_costSpreadN++;
           }
        }
      else
        {
         double price = s.entry - s.dir * depth[k] * risk;
         if(!SendLimit(s, lk, price, id))
            continue;
         MetaRecord(s, id, k, lk, price, true, ExpiryFor(s.engine));
        }
      opened++;
      total += lk;
     }
   if(opened == 0)
     {
      g_execWhy = "ordine non eseguito dal broker";
      return false;
     }
   g_execWhy = "aperto";
   if(!(IsOnda(s.strat) && InpOndaNoDayLimit))
      g_tradesToday[s.engine]++;
   if(s.recovery)
      g_recoveryArmed = false;
   if(s.reentry)
      g_reArmed[s.engine] = false;
   string extra = "";
   if(s.recovery)
      extra += " | RECUPERO x" + DoubleToString(InpRecoveryMult, 2);
   if(s.reentry)
      extra += " | RIENTRO dopo pareggio x" + DoubleToString(InpReentryMult, 2);
   if(s.aplus)
      extra += " | A+ tutte le conferme";
   if(s.cushion > 0.0)
      extra += " | extra dai profitti " + Money(s.cushion);
   if(s.overrideOk)
      extra += " | conferme forti, scavalca: " + StringSubstr(s.softWhy, 0, 90) + " (rischio x" + DoubleToString(InpOverrideRiskMult, 2) + ")";
   if(opened > 1)
      extra += " | " + IntegerToString(opened) + " ingressi scaglionati";
   if(s.proven && IsOnda(s.strat))
      extra += " | ritracciamento nel trend, tempo massimo fino al " + TimeToString(s.deadline, TIME_DATE | TIME_MINUTES) + " UTC";
   else
      if(s.proven)
         extra += " | movimento forte: " + TmHoldText();
   if(ReadRiskMult(s) != 1.0)
     {
      string rdw = (s.rdConf < 0) ? "contrarie" : "a favore";
      extra += " | letture provate " + rdw + ": rischio x" + DoubleToString(ReadRiskMult(s), 2);
     }
   if(AstaRiskMult(s) != 1.0)
     {
      string asw = (AstaRiskMult(s) < 1.0) ? "fuori dall'equilibrio d'asta" : "in equilibrio d'asta";
      extra += " | " + asw + ": rischio x" + DoubleToString(AstaRiskMult(s), 2);
     }
   if(!s.proven && VolTargetMult() < 0.999)
      extra += " | volatilita' prevista x" + DoubleToString(VolForecast(), 1) + ": rischio x" + DoubleToString(VolTargetMult(), 2);
   double base = BaseCapital();
   string msg = "APERTO [" + g_engName[s.engine] + "] " + g_stratName[s.strat] + " " + DirName(s.dir) + " " +
                DoubleToString(total, g_lotDigits) + " lotti @ " + DoubleToString(s.entry, g_digits) +
                " SL " + DoubleToString(s.sl, g_digits) + " TP " + DoubleToString(s.tp, g_digits) +
                " | rischio " + Money(riskMoney) + " (" + Pct(100.0 * riskMoney / MathMax(base, 0.01)) + ")" +
                " | score " + DoubleToString(s.score, 2) + extra;
   Notify(msg);
   RememberDecision(msg);
   return true;
  }
