//+------------------------------------------------------------------+
//| Sessioni (UTC con ora legale), mappa della liquidita', regime    |
//+------------------------------------------------------------------+
struct OrState
  {
   double            h;
   double            l;
   bool              started;
   bool              done;
   int               brk;
   datetime          brkT;
   bool              used;
  };

struct SessionState
  {
   int               dayKey;
   double            asiaH;
   double            asiaL;
   bool              asiaOn;
   bool              asiaDone;
   double            lonH;
   double            lonL;
   bool              lonOn;
   bool              lonDone;
   double            dayH;
   double            dayL;
   OrState           orLon;
   OrState           orNy;
  };
SessionState g_sess;

void OrReset(OrState &o)
  {
   o.h = 0.0;
   o.l = 0.0;
   o.started = false;
   o.done = false;
   o.brk = 0;
   o.brkT = 0;
   o.used = false;
  }

void SessReset(int dayKey)
  {
   g_sess.dayKey = dayKey;
   g_sess.asiaH = 0.0;
   g_sess.asiaL = 0.0;
   g_sess.asiaOn = false;
   g_sess.asiaDone = false;
   g_sess.lonH = 0.0;
   g_sess.lonL = 0.0;
   g_sess.lonOn = false;
   g_sess.lonDone = false;
   g_sess.dayH = 0.0;
   g_sess.dayL = 0.0;
   OrReset(g_sess.orLon);
   OrReset(g_sess.orNy);
  }

void OrFeed(OrState &o, double hu, double openH, double hi, double lo)
  {
   if(hu >= openH && hu < openH + 0.25)
     {
      if(!o.started)
        {
         o.h = hi;
         o.l = lo;
         o.started = true;
        }
      else
        {
         o.h = MathMax(o.h, hi);
         o.l = MathMin(o.l, lo);
        }
     }
   if(hu >= openH + 0.25 && o.started)
      o.done = true;
  }

//--- barra M1 chiusa (tempo server) -> stato delle sessioni del giorno UTC
void SessFeed(datetime barSrv, double hi, double lo)
  {
   datetime u = ToUTC(barSrv);
   int dk = DayKey(u);
   if(dk != g_sess.dayKey)
      SessReset(dk);
   double hu = HourOf(u);
   double lon = LondonOpenUTC(u);
   double nyd = NYDataUTC(u);
   double nyo = NYOpenUTC(u);
   if(g_sess.dayH == 0.0 || hi > g_sess.dayH)
      g_sess.dayH = hi;
   if(g_sess.dayL == 0.0 || lo < g_sess.dayL)
      g_sess.dayL = lo;
   if(hu < lon)
     {
      if(!g_sess.asiaOn)
        {
         g_sess.asiaH = hi;
         g_sess.asiaL = lo;
         g_sess.asiaOn = true;
        }
      else
        {
         g_sess.asiaH = MathMax(g_sess.asiaH, hi);
         g_sess.asiaL = MathMin(g_sess.asiaL, lo);
        }
     }
   else
      if(g_sess.asiaOn)
         g_sess.asiaDone = true;
   if(hu >= lon && hu < nyd)
     {
      if(!g_sess.lonOn)
        {
         g_sess.lonH = hi;
         g_sess.lonL = lo;
         g_sess.lonOn = true;
        }
      else
        {
         g_sess.lonH = MathMax(g_sess.lonH, hi);
         g_sess.lonL = MathMin(g_sess.lonL, lo);
        }
     }
   if(hu >= nyd && g_sess.lonOn)
      g_sess.lonDone = true;
   OrFeed(g_sess.orLon, hu, lon, hi, lo);
   OrFeed(g_sess.orNy, hu, nyo, hi, lo);
  }

void SessInit()
  {
   datetime nowU = ToUTC(TimeCurrent());
   SessReset(DayKey(nowU));
   datetime startSrv = ToServer((datetime)(DayKey(nowU)) * 86400);
   MqlRates b[];
   datetime curM1 = iTime(g_sym, PERIOD_M1, 0);
   int got = CopyRates(g_sym, PERIOD_M1, startSrv, curM1, b);
   for(int i = 0; i < got; i++)
     {
      if(b[i].time >= curM1)
         continue;
      SessFeed(b[i].time, b[i].high, b[i].low);
     }
   //--- gli OR gia' passati non vanno piu' tradati dopo un riavvio
   if(g_sess.orLon.done)
      g_sess.orLon.used = true;
   if(g_sess.orNy.done)
      g_sess.orNy.used = true;
  }

//+------------------------------------------------------------------+
//| Mappa dei livelli di liquidita'                                  |
//+------------------------------------------------------------------+
#define LV_PDH     0
#define LV_PDL     1
#define LV_PDC     2
#define LV_PWH     3
#define LV_PWL     4
#define LV_ASIAH   5
#define LV_ASIAL   6
#define LV_LONH    7
#define LV_LONL    8
#define LV_VAH     9
#define LV_VAL     10
#define LV_POC     11
#define LV_VWAP    12
#define LV_VWAPB1  13
#define LV_VWAPB2  14
#define LV_WVWAP   15
#define LV_SWING   16
#define LV_ROUND   17
#define LV_ROUNDM  18
#define LV_GC      19
#define LV_DAYHL   20

string g_lvName[21] = {"PDH", "PDL", "PDC", "PWH", "PWL", "Asia H", "Asia L", "Londra H", "Londra L", "VAH ieri", "VAL ieri", "POC ieri", "VWAP", "VWAP 1s", "VWAP 2s", "VWAP sett", "swing H1", "tondo", "tondo forte", "livello GC", "max/min oggi"};

struct TLevel
  {
   double            price;
   int               type;
   double            weight;
  };
TLevel g_lv[MAX_LEVELS];
int    g_lvN = 0;
double g_pwH = 0.0;
double g_pwL = 0.0;

void LvAdd(double price, int type, double weight)
  {
   if(price <= 0.0 || g_lvN >= MAX_LEVELS)
      return;
   g_lv[g_lvN].price = price;
   g_lv[g_lvN].type = type;
   g_lv[g_lvN].weight = weight;
   g_lvN++;
  }

bool IsMajorLevel(int type)
  {
   return (type == LV_PDH || type == LV_PDL || type == LV_PWH || type == LV_PWL || type == LV_ROUNDM ||
           type == LV_VAH || type == LV_VAL || type == LV_POC || type == LV_GC);
  }

void UpdateWeekly()
  {
   MqlRates w[];
   if(CopyRates(g_sym, PERIOD_W1, 1, 1, w) == 1)
     {
      g_pwH = w[0].high;
      g_pwL = w[0].low;
     }
  }

//--- livelli GC (futures CME) mappati sul prezzo spot: riempiti dal modulo web
double   g_gcPoc = 0.0, g_gcVah = 0.0, g_gcVal = 0.0, g_gcLast = 0.0, g_gcDeltaTrend = 0.0;
datetime g_gcTime = 0;
bool GcFresh() { return (g_gcLast > 0.0 && ToUTC(TimeCurrent()) - g_gcTime <= 4 * 3600); }

void BuildLevels()
  {
   g_lvN = 0;
   if(g_d1.n >= 2)
     {
      LvAdd(BarH(g_d1, 0), LV_PDH, 1.0);
      LvAdd(BarL(g_d1, 0), LV_PDL, 1.0);
      LvAdd(BarC(g_d1, 0), LV_PDC, 0.6);
     }
   LvAdd(g_pwH, LV_PWH, 1.0);
   LvAdd(g_pwL, LV_PWL, 1.0);
   if(g_sess.asiaDone)
     {
      LvAdd(g_sess.asiaH, LV_ASIAH, 0.8);
      LvAdd(g_sess.asiaL, LV_ASIAL, 0.8);
     }
   if(g_sess.lonDone)
     {
      LvAdd(g_sess.lonH, LV_LONH, 0.8);
      LvAdd(g_sess.lonL, LV_LONL, 0.8);
     }
   if(PrevProfileOk())
     {
      LvAdd(PrevVAH(), LV_VAH, 0.9);
      LvAdd(PrevVAL(), LV_VAL, 0.9);
      LvAdd(PrevPOC(), LV_POC, 0.9);
     }
   double vw = VwapVal(g_vwD), sg = VwapSigma(g_vwD);
   if(vw > 0.0)
     {
      LvAdd(vw, LV_VWAP, 0.7);
      if(sg > 0.0)
        {
         LvAdd(vw + sg, LV_VWAPB1, 0.5);
         LvAdd(vw - sg, LV_VWAPB1, 0.5);
         LvAdd(vw + 2.0 * sg, LV_VWAPB2, 0.6);
         LvAdd(vw - 2.0 * sg, LV_VWAPB2, 0.6);
        }
     }
   double wv = VwapVal(g_vwW);
   if(wv > 0.0)
      LvAdd(wv, LV_WVWAP, 0.8);
   //--- swing H1 (frattali a 2 barre) delle ultime 48 ore
   int foundH = 0, foundL = 0;
   for(int sh = 2; sh < 48 && sh + 2 < g_h1.n; sh++)
     {
      double h = BarH(g_h1, sh), l = BarL(g_h1, sh);
      if(foundH < 4 && h > BarH(g_h1, sh - 1) && h > BarH(g_h1, sh - 2) && h > BarH(g_h1, sh + 1) && h > BarH(g_h1, sh + 2))
        {
         LvAdd(h, LV_SWING, 0.7);
         foundH++;
        }
      if(foundL < 4 && l < BarL(g_h1, sh - 1) && l < BarL(g_h1, sh - 2) && l < BarL(g_h1, sh + 1) && l < BarL(g_h1, sh + 2))
        {
         LvAdd(l, LV_SWING, 0.7);
         foundL++;
        }
     }
   //--- numeri tondi (oro a 4000: ogni 10 e forti ogni 50)
   double px = PxBid();
   if(px > 0.0)
     {
      double mag = MathPow(10.0, MathFloor(MathLog10(px)) - 2.0);
      double major = 5.0 * mag;
      double base = MathFloor(px / mag) * mag;
      for(int k = -3; k <= 4; k++)
        {
         double rp = base + k * mag;
         double rem = MathAbs(rp / major - MathRound(rp / major));
         if(rem < 0.0001)
            LvAdd(rp, LV_ROUNDM, 1.0);
         else
            LvAdd(rp, LV_ROUND, 0.5);
        }
     }
   if(GcFresh())
     {
      double basis = PxBid() - g_gcLast;
      if(g_gcPoc > 0.0)
         LvAdd(g_gcPoc + basis, LV_GC, 1.0);
      if(g_gcVah > 0.0)
         LvAdd(g_gcVah + basis, LV_GC, 0.9);
      if(g_gcVal > 0.0)
         LvAdd(g_gcVal + basis, LV_GC, 0.9);
     }
  }

//--- distanza dal primo livello oltre 'from' nella direzione dir (piu' lontano di minDist). -1 se nessuno
double NearestLevelDist(double from, int dir, double minDist, int &typeOut)
  {
   double best = -1.0;
   typeOut = -1;
   for(int i = 0; i < g_lvN; i++)
     {
      double d = (g_lv[i].price - from) * dir;
      if(d <= minDist)
         continue;
      if(best < 0.0 || d < best)
        {
         best = d;
         typeOut = g_lv[i].type;
        }
     }
   return best;
  }

//--- un livello forte molto vicino a un prezzo (es. lo stop messo proprio sul livello)
bool PriceOnMajorLevel(double price, double tol)
  {
   for(int i = 0; i < g_lvN; i++)
      if(IsMajorLevel(g_lv[i].type) && MathAbs(g_lv[i].price - price) <= tol)
         return true;
   return false;
  }

//+------------------------------------------------------------------+
//| Regime di mercato (H1)                                           |
//+------------------------------------------------------------------+
int    g_regime = REG_RANGE;
double g_atrRatioH1 = 1.0;

void UpdateRegime()
  {
   if(g_h1.n < 120)
      return;
   double a = AtrOf(g_h1);
   //--- mediana dell'ATR delle ultime 100 ore
   double tmp[100];
   int m = 0;
   for(int k = 0; k < 100; k++)
     {
      int i = ArraySize(g_h1.atr) - 1 - k;
      if(i < 0)
         break;
      tmp[m] = g_h1.atr[i];
      m++;
     }
   for(int i = 1; i < m; i++)
     {
      double v = tmp[i];
      int j = i - 1;
      while(j >= 0 && tmp[j] > v)
        {
         tmp[j + 1] = tmp[j];
         j--;
        }
      tmp[j + 1] = v;
     }
   double med = (m > 0) ? tmp[m / 2] : a;
   g_atrRatioH1 = (med > 0.0) ? a / med : 1.0;
   double adx = AdxOf(g_h1);
   double e20 = Ind(g_h1.ema20, 0), e50 = Ind(g_h1.ema50, 0), c = BarC(g_h1, 0);
   double slope = (a > 0.0) ? (Ind(g_h1.ema50, 0) - Ind(g_h1.ema50, 5)) / a : 0.0;
   if(g_atrRatioH1 > 1.8)
      g_regime = REG_VOLATILE;
   else
      if(adx >= 22.0 && e20 > e50 && c > e50 && slope > 0.1)
         g_regime = REG_UP;
      else
         if(adx >= 22.0 && e20 < e50 && c < e50 && slope < -0.1)
            g_regime = REG_DOWN;
         else
            if(g_atrRatioH1 < 0.6)
               g_regime = REG_QUIET;
            else
               g_regime = REG_RANGE;
  }

//--- quanto la strategia si adatta al regime
double RegimeFit(int stype)
  {
   bool trend = (g_regime == REG_UP || g_regime == REG_DOWN);
   if(trend)
     {
      if(stype == STYPE_TREND)
         return 0.15;
      if(stype == STYPE_BREAKOUT)
         return 0.10;
      if(stype == STYPE_REVERSAL)
         return -0.10;
      if(stype == STYPE_MEANREV)
         return -0.15;
      return 0.05;
     }
   if(g_regime == REG_RANGE)
     {
      if(stype == STYPE_TREND)
         return -0.10;
      if(stype == STYPE_REVERSAL)
         return 0.10;
      if(stype == STYPE_MEANREV)
         return 0.15;
      return 0.0;
     }
   if(g_regime == REG_VOLATILE)
     {
      if(stype == STYPE_MEANREV)
         return -0.15;
      if(stype == STYPE_BREAKOUT)
         return 0.05;
      if(stype == STYPE_REVERSAL)
         return -0.05;
      return 0.0;
     }
   //--- calmo
   if(stype == STYPE_BREAKOUT)
      return -0.10;
   if(stype == STYPE_MEANREV)
      return 0.10;
   if(stype == STYPE_REVERSAL)
      return 0.05;
   return -0.05;
  }
