//+------------------------------------------------------------------+
//| BOT CHE SI PARLANO (1.30)                                        |
//| Ogni bot (oro, indici) scrive ogni minuto il suo stato in un     |
//| file della cartella comune di MT5 e legge quello degli altri:    |
//| posizioni aperte, rischio aperto e risultato di oggi.            |
//| Serve a sapere quanto rischiano tutti insieme. Nessun blocco e   |
//| nessun lotto piu' piccolo: se il rischio aperto di tutti i bot   |
//| supera InpBusCarefulRisk le nuove posizioni hanno la gestione    |
//| attenta (pareggio a InpBusCarefulBE_R, se impostato) e il bot    |
//| avvisa una volta.                                                |
//| File: BotComuni_<conto o gruppo>_<nome>.txt (una riga:           |
//| nome;simbolo;ora server;posizioni;rischio %;oggi %)              |
//+------------------------------------------------------------------+
#define BUS_MAX 8
string   g_busName[BUS_MAX];
string   g_busSym[BUS_MAX];
int      g_busPos[BUS_MAX];
double   g_busRisk[BUS_MAX];
double   g_busDay[BUS_MAX];
int      g_busN = 0;
double   g_busOwnRisk = 0.0;
double   g_busTotRisk = 0.0;
datetime g_busLast = 0;
bool     g_busWasCareful = false;

string BusFile(string name) { return "BotComuni_" + ((InpBusGroup != "") ? InpBusGroup : IntegerToString(g_login)) + "_" + name + ".txt"; }

void BusWrite()
  {
   PortfolioScan();
   double base = BaseCapital();
   g_busOwnRisk = (base > 0.0) ? 100.0 * g_openRiskMoney / base : 0.0;
   double dayPct = (g_dayStartEq > 0.0) ? 100.0 * (AccEquity() / g_dayStartEq - 1.0) : 0.0;
   int h = FileOpen(BusFile(InpBusName), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return;
   FileWriteString(h, InpBusName + ";" + g_sym + ";" + IntegerToString((long)TimeCurrent()) + ";" + IntegerToString(g_cntAll) + ";" +
                   DoubleToString(g_busOwnRisk, 2) + ";" + DoubleToString(dayPct, 2) + "\r\n");
   FileClose(h);
  }

void BusRead()
  {
   g_busN = 0;
   g_busTotRisk = g_busOwnRisk;
   string peers[];
   int np = StringSplit(InpBusPeers, ',', peers);
   for(int i = 0; i < np && g_busN < BUS_MAX; i++)
     {
      string nm = peers[i];
      StringTrimLeft(nm);
      StringTrimRight(nm);
      if(nm == "" || nm == InpBusName || !FileIsExist(BusFile(nm), FILE_COMMON))
         continue;
      int h = FileOpen(BusFile(nm), FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ | FILE_SHARE_WRITE);
      if(h == INVALID_HANDLE)
         continue;
      string l = FileReadString(h);
      FileClose(h);
      string q[];
      if(StringSplit(l, ';', q) < 6)
         continue;
      datetime t = (datetime)StringToInteger(q[2]);
      if(TimeCurrent() - t > 600)
         continue;                               // fermo da piu' di 10 minuti (grafico chiuso o mercato chiuso): non conta
      g_busName[g_busN] = q[0];
      g_busSym[g_busN] = q[1];
      g_busPos[g_busN] = (int)StringToInteger(q[3]);
      g_busRisk[g_busN] = StringToDouble(q[4]);
      g_busDay[g_busN] = StringToDouble(q[5]);
      g_busTotRisk += g_busRisk[g_busN];
      g_busN++;
     }
  }

bool BusCareful()
  {
   return (InpBusOn && !g_isTester && InpBusCarefulRisk > 0.0 && g_busN > 0 && g_busTotRisk >= InpBusCarefulRisk);
  }

string BusShort()
  {
   return "rischio aperto di tutti i bot " + DoubleToString(g_busTotRisk, 1) + "% (oltre " + DoubleToString(InpBusCarefulRisk, 1) + "%): gestione attenta";
  }

//--- una volta al minuto: scrive il proprio stato e legge gli altri
void BusTick()
  {
   if(!InpBusOn || g_isTester || g_isOptim)
      return;
   if(TimeCurrent() - g_busLast < 60)
      return;
   g_busLast = TimeCurrent();
   BusWrite();
   BusRead();
   bool c = BusCareful();
   if(c && !g_busWasCareful)
      Notify("Bot insieme: " + BusShort() + ". Nessun blocco: le nuove posizioni hanno solo la gestione attenta.");
   g_busWasCareful = c;
  }

string BusPanel()
  {
   if(!InpBusOn || g_isTester)
      return "";
   if(g_busN == 0)
      return "Altri bot: nessuno attivo adesso\n";
   string t = "Altri bot:";
   for(int i = 0; i < g_busN; i++)
      t += " " + g_busName[i] + " " + IntegerToString(g_busPos[i]) + " pos, rischio " + DoubleToString(g_busRisk[i], 1) + "%, oggi " +
           DoubleToString(g_busDay[i], 2) + "% |";
   t += " tutti insieme " + DoubleToString(g_busTotRisk, 1) + "%" + (BusCareful() ? " -> gestione attenta" : "");
   return StringSubstr(t, 0, 200) + "\n";
  }
