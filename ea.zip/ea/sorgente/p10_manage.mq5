//+------------------------------------------------------------------+
//| Gestione: pareggio a +1.5R con parziale, trailing, uscite a      |
//| tempo, news, venerdi', ordini scaglionati, chiusure e statistica |
//+------------------------------------------------------------------+
double BeOffsetPx() { return CommissionPx() + g_tick; }

bool ModifySL(ulong tk, double sl, double tp)
  {
   sl = NormPrice(sl);
   if(!g_trade.PositionModify(tk, sl, tp))
      return false;
   return RetOk(g_trade.ResultRetcode());
  }

bool CloseTicket(ulong tk, string why)
  {
   bool ok = g_trade.PositionClose(tk);
   if(ok && RetOk(g_trade.ResultRetcode()))
     {
      Logf("Chiusura: " + why);
      g_needSweep = true;
      return true;
     }
   return false;
  }

//--- 1.27: chiude i ritracciamenti (ONDA) ancora a rischio aperti nel verso opposto a 'dir'
int CloseOppOnda(int dir, string why)
  {
   int c = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym || !IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      int pd = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      if(pd == dir)
         continue;
      double op = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      if(sl > 0.0 && (op - sl) * pd <= 0.0)
         continue;                              // gia' a pareggio: non e' a rischio, resta
      int mi = MetaFind(PositionGetInteger(POSITION_IDENTIFIER));
      if(mi < 0 || !IsOnda(g_meta[mi].strat))
         continue;
      if(CloseTicket(tk, g_stratName[g_meta[mi].strat] + ": " + why))
         c++;
     }
   return c;
  }

double TrailLevel(int eng, int dir)
  {
   if(eng == ENG_SCALP)
     {
      double ext = (dir > 0) ? HighestH(g_m1, 0, 10) : LowestL(g_m1, 0, 10);
      return ext - dir * 2.0 * g_ctx.atrM1;
     }
   if(eng == ENG_INTRA)
     {
      double ext = (dir > 0) ? HighestH(g_m15, 0, 8) : LowestL(g_m15, 0, 8);
      return ext - dir * 2.0 * g_ctx.atrM15;
     }
   double ext = (dir > 0) ? HighestH(g_h4, 0, 6) : LowestL(g_h4, 0, 6);
   return ext - dir * 2.5 * g_ctx.atrH4;
  }

//--- uscite obbligate (tempo, fine giornata, venerdi', news)
bool ForcedExit(int mi, string &why)
  {
   int eng = g_meta[mi].engine;
   bool be = g_meta[mi].beDone;
   int ageMin = (int)((TimeCurrent() - g_meta[mi].openTime) / 60);
   double h = HourOf(ToUTC(TimeCurrent()));
   int dow = DowOf(ToUTC(TimeCurrent()));
   //--- 1.26: i movimenti forti sono misurati tenendoli fino alla fine della tenuta (la sera stessa o del giorno dopo):
   //    niente uscita a tempo senza pareggio e niente chiusura prima delle news; il venerdi' sera chiudono come gli altri
   //--- 1.27: i ritracciamenti nel trend hanno il loro tempo massimo (3 volte la durata dell'onda); niente uscita prima
   //    delle news. Venerdi' sera: M5 e M15 chiudono, H1 e H4 secondo InpOndaWeekend (0 tiene, 1 dimezza, 2 chiude)
   if(IsOnda(g_meta[mi].strat))
     {
      datetime nowU = ToUTC(TimeCurrent());
      datetime dl = g_meta[mi].deadline;
      if(dl <= 0)                                // posizione adottata dopo un riavvio senza il suo file: tempo massimo di riserva (150 barre della scala)
         dl = ToUTC(g_meta[mi].openTime) + 150 * OndaBarSec(OndaScale(g_meta[mi].strat));
      if(nowU >= dl)
        {
         why = "ritracciamento: tempo massimo";
         return true;
        }
      if(FridayEvening(nowU))
        {
         if(OndaScale(g_meta[mi].strat) <= 1 || InpOndaWeekend >= 2)
           {
            why = "venerdi' sera";
            return true;
           }
         if(InpOndaWeekend == 1 && InpOndaFriCloseMinLot && !g_meta[mi].wkDone &&
            PositionGetDouble(POSITION_VOLUME) < 2.0 * g_minLot - 0.0000001)
           {
            why = "venerdi' sera: un solo lotto minimo, non si puo' dimezzare";
            return true;
           }
        }
      return false;
     }
   bool tm = IsTrendMove(g_meta[mi].strat);
   if(tm)
     {
      if(ToUTC(TimeCurrent()) >= TmExitUtc(ToUTC(g_meta[mi].openTime)))
        {
         why = "movimento forte: fine della tenuta";
         return true;
        }
      if(FridayEvening(ToUTC(TimeCurrent())))
        {
         why = "venerdi' sera";
         return true;
        }
      return false;
     }
   if(eng == ENG_SCALP)
     {
      if(ageMin >= InpScalpMaxMinutes && !be)
        {
         why = "scalp: tempo scaduto senza pareggio";
         return true;
        }
      if(ageMin >= 3 * InpScalpMaxMinutes)
        {
         why = "scalp: tempo massimo";
         return true;
        }
     }
   if(eng == ENG_INTRA && ageMin >= InpIntraMaxHours * 60 && !be)
     {
      why = "intraday: tempo scaduto senza pareggio";
      return true;
     }
   if(eng != ENG_SWING && h >= EveCloseUTC(ToUTC(TimeCurrent())))
     {
      why = "fine sessione intraday";
      return true;
     }
   if(eng == ENG_SWING)
     {
      int bars = ageMin / 240;
      if(bars >= InpSwingMaxBarsH4 && !be)
        {
         why = "swing: " + IntegerToString(bars) + " barre H4 senza pareggio";
         return true;
        }
      if(bars >= 2 * InpSwingMaxBarsH4)
        {
         why = "swing: tempo massimo";
         return true;
        }
      if(FridayEvening(ToUTC(TimeCurrent())) && !be && !InpSwingHoldWeekend)
        {
         why = "swing non a pareggio prima del weekend";
         return true;
        }
     }
   if(FridayEvening(ToUTC(TimeCurrent())) && eng != ENG_SWING)
     {
      why = "venerdi' sera";
      return true;
     }
   if(InpCloseBeforeNews)
     {
      int m = MinutesToNextTier1(ToUTC(TimeCurrent()));
      if(m >= 0 && m <= 5 && (eng == ENG_SCALP || (eng == ENG_INTRA && !be)))
        {
         why = "news tier1 tra " + IntegerToString(m) + " minuti";
         return true;
        }
     }
   return false;
  }

//--- posizione dell'EA senza metadati (riavvio, file perso): la adotto
int MetaAdopt(ulong tk)
  {
   int k = MetaFree();
   if(k < 0)
      return -1;
   long mg = PositionGetInteger(POSITION_MAGIC);
   int dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
   double op = PositionGetDouble(POSITION_PRICE_OPEN);
   double sl = PositionGetDouble(POSITION_SL);
   double vol = PositionGetDouble(POSITION_VOLUME);
   string cmt = PositionGetString(POSITION_COMMENT);
   g_meta[k].Reset();
   g_meta[k].active = true;
   g_meta[k].id = PositionGetInteger(POSITION_IDENTIFIER);
   g_meta[k].engine = IMax(0, IMin(2, EngineOfMagic(mg)));
   g_meta[k].dir = dir;
   g_meta[k].entry = op;
   g_meta[k].sl0 = sl;
   g_meta[k].tp = PositionGetDouble(POSITION_TP);
   g_meta[k].lots0 = vol;
   g_meta[k].openTime = (datetime)PositionGetInteger(POSITION_TIME);
   if(StringFind(cmt, "XC ") == 0)
     {
      string nm = StringSubstr(cmt, 3);
      int sp = StringFind(nm, " ");
      if(sp > 0)
         nm = StringSubstr(nm, 0, sp);
      g_meta[k].strat = StratByName(nm);
     }
   double r = (sl > 0.0) ? (op - sl) * dir : 0.0;
   if(r <= 0.0)
     {
      g_meta[k].beDone = (sl > 0.0);
      r = MathMax(AtrOf(g_m15), 10.0 * g_tick);
     }
   g_meta[k].riskPx = r;
   g_meta[k].riskMoney = vol * (r * ValuePerPriceUnit() + MathMax(InpCommissionPerLot, 0.0));
   return k;
  }

void MetaSave();

void ManageOne(ulong tk, int mi)
  {
   int dir = g_meta[mi].dir;
   double open = PositionGetDouble(POSITION_PRICE_OPEN);
   double sl = PositionGetDouble(POSITION_SL);
   double tp = PositionGetDouble(POSITION_TP);
   double vol = PositionGetDouble(POSITION_VOLUME);
   double px = (dir > 0) ? PxBid() : PxAsk();
   double r = g_meta[mi].riskPx;
   if(r <= 0.0)
      return;
   string why = "";
   if(ForcedExit(mi, why))
     {
      CloseTicket(tk, why);
      return;
     }
   double pr = (px - open) * dir / r;
   double md = StopsMinDist();
   //--- S (1.25): il venerdi' sera (FridayEvening) uno swing non ancora a pareggio si dimezza (il gap del weekend salta lo stop)
   if(InpWeekendHalfSwing && g_meta[mi].engine == ENG_SWING && !IsOnda(g_meta[mi].strat) && !g_meta[mi].beDone && FridayEvening(g_ctx.nowUtc) &&
      vol >= g_meta[mi].lots0 - g_minLot * 0.5)
     {
      double half = FloorLot(vol * 0.5);
      if(half >= g_minLot && vol - half >= g_minLot - 0.0000001)
        {
         if(g_trade.PositionClosePartial(tk, half))
           {
            vol -= half;
            Notify(g_stratName[g_meta[mi].strat] + ": swing dimezzato prima del weekend (" + DoubleToString(half, g_lotDigits) + " lotti chiusi a " +
                   DoubleToString(pr, 2) + "R)");
           }
        }
     }
   //--- 1.27: ritracciamenti lunghi (H1, H4): il venerdi' sera si dimezzano, una volta sola; se resta un solo lotto
   //    minimo non si puo' dividere: resta aperto e il bot avvisa di quanto rischio passa il weekend
   if(IsOnda(g_meta[mi].strat) && OndaScale(g_meta[mi].strat) >= 2 && InpOndaWeekend == 1 && !g_meta[mi].wkDone && FridayEvening(g_ctx.nowUtc))
     {
      g_meta[mi].wkDone = true;
      double half = FloorLot(vol * 0.5);
      bool cut = false;
      if(half >= g_minLot && vol - half >= g_minLot - 0.0000001)
         if(g_trade.PositionClosePartial(tk, half))
           {
            vol -= half;
            cut = true;
           }
      double left = (sl > 0.0) ? MathMax((open - sl) * dir, 0.0) * vol * ValuePerPriceUnit() : 0.0;
      Notify(g_stratName[g_meta[mi].strat] + (cut ? ": dimezzato prima del weekend (" + DoubleToString(half, g_lotDigits) + " lotti chiusi a " + DoubleToString(pr, 2) + "R)" :
             ": resta intero nel weekend (un solo lotto minimo non si divide)") + ", restano " + DoubleToString(vol, g_lotDigits) +
             " lotti, rischio fino allo stop " + Money(left));
      MetaSave();
     }
   //--- A+ (1.18): gestione attiva a terzi, il primo terzo si chiude a +InpAplusPartialR
   if(g_meta[mi].aplus && !g_meta[mi].thirdDone && !g_meta[mi].beDone && InpAplusPartialR > 0.0 &&
      InpAplusPartialR < InpBE_R && pr >= InpAplusPartialR)
     {
      g_meta[mi].thirdDone = true;
      double third = MathMax(FloorLot(g_meta[mi].lots0 / 3.0), g_minLot);
      if(vol >= g_meta[mi].lots0 - g_minLot * 0.5 && vol - third >= g_minLot - 0.0000001)
         if(g_trade.PositionClosePartial(tk, third))
           {
            vol -= third;
            Logf(g_stratName[g_meta[mi].strat] + ": A+ primo terzo chiuso a +" + DoubleToString(pr, 2) + "R (" +
                 DoubleToString(third, g_lotDigits) + " lotti)");
           }
     }
   //--- regola fissa: a +1.5R lo stop va al prezzo di entrata (+ commissione)
   if(!g_meta[mi].beDone && pr >= InpBE_R)
     {
      double be = open + dir * (BeOffsetPx() + MathMax(InpBeLockR, 0.0) * r);   // 1.17: cuscinetto oltre l'entrata
      bool better = (sl <= 0.0) || ((be - sl) * dir > g_tick * 0.5);
      bool roomOk = ((px - be) * dir >= md);
      if(!better)
         g_meta[mi].beDone = true;
      else
         if(roomOk && ModifySL(tk, be, tp))
           {
            g_meta[mi].beDone = true;
            sl = be;
            Logf(g_stratName[g_meta[mi].strat] + ": stop a pareggio a +" + DoubleToString(pr, 2) + "R");
           }
      double ppct = g_meta[mi].aplus ? 50.0 : InpPartialPct;   // A+: al pareggio meta' di quello che resta
      if(g_meta[mi].beDone && !g_meta[mi].partialDone && ppct > 0.0)
        {
         g_meta[mi].partialDone = true;
         double pv = FloorLot(vol * ppct / 100.0);
         if(pv >= g_minLot && vol - pv >= g_minLot - 0.0000001)
            if(g_trade.PositionClosePartial(tk, pv))
               Logf(g_stratName[g_meta[mi].strat] + ": chiusura parziale " + DoubleToString(pv, g_lotDigits) + " lotti");
        }
     }
   //--- trailing da +2R
   if(g_meta[mi].beDone && pr >= InpTrailStartR && !IsOnda(g_meta[mi].strat) && (InpTDTrail || !IsTrendMove(g_meta[mi].strat)))
     {
      double ns = NormPrice(TrailLevel(g_meta[mi].engine, dir));
      if(ns > 0.0 && (ns - sl) * dir > g_tick && (px - ns) * dir >= md && (ns - open) * dir > 0.0)
         ModifySL(tk, ns, tp);
     }
  }

void ManagePending()
  {
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong ot = OrderGetTicket(i);
      if(ot == 0)
         continue;
      if(OrderGetString(ORDER_SYMBOL) != g_sym || !IsOurMagic(OrderGetInteger(ORDER_MAGIC)))
         continue;
      int mi = MetaFind((long)ot);
      bool kill = false;
      if(mi < 0)
         kill = true;
      else
        {
         int age = (int)((TimeCurrent() - g_meta[mi].openTime) / 60);
         if(age >= g_meta[mi].expiryMin)
            kill = true;
         //--- se il primo ingresso dell'idea e' gia' chiuso, gli scaglioni non servono piu'
         bool mainAlive = false;
         for(int j = 0; j < MAX_META; j++)
            if(g_meta[j].active && g_meta[j].idea == g_meta[mi].idea && g_meta[j].tranche == 0)
               mainAlive = true;
         if(!mainAlive)
            kill = true;
         double px = (g_meta[mi].dir > 0) ? PxBid() : PxAsk();
         if((px - g_meta[mi].tp) * g_meta[mi].dir >= 0.0)
            kill = true;
         int m = MinutesToNextTier1(ToUTC(TimeCurrent()));
         if(m >= 0 && m <= 15)
            kill = true;
        }
      if(kill && g_trade.OrderDelete(ot))
        {
         if(mi >= 0)
            MetaRemove(mi);
        }
     }
  }

void ManagePositions()
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym)
         continue;
      if(!IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      long id = PositionGetInteger(POSITION_IDENTIFIER);
      int mi = MetaFind(id);
      if(mi < 0)
         mi = MetaAdopt(tk);
      if(mi < 0)
         continue;
      if(g_meta[mi].isPending)
        {
         //--- scaglione eseguito: ricalcolo rischio reale
         g_meta[mi].isPending = false;
         g_meta[mi].openTime = (datetime)PositionGetInteger(POSITION_TIME);
         double op = PositionGetDouble(POSITION_PRICE_OPEN);
         g_meta[mi].entry = op;
         g_meta[mi].riskPx = (op - g_meta[mi].sl0) * g_meta[mi].dir;
         g_meta[mi].riskMoney = PositionGetDouble(POSITION_VOLUME) * LossPerLot(g_meta[mi].dir, op, g_meta[mi].sl0);
        }
      if(!PositionSelectByTicket(tk))
         continue;
      ManageOne(tk, mi);
     }
   ManagePending();
  }

//+------------------------------------------------------------------+
//| Chiusure: risultato in R dallo storico, statistiche, giornale    |
//+------------------------------------------------------------------+
void BenchCheck(int k)
  {
   if(!InpUseBench || InpOnlyStrategy != PICK_ALL || k <= 0)
      return;
   if(g_ss[k].n >= 25 && g_ss[k].Expectancy() < -0.2 && g_ss[k].RecentSum(10) < 0.0)
     {
      g_ss[k].Reset();
      g_ss[k].benchUntil = TimeCurrent() + 7 * 86400;
      Notify("Strategia " + g_stratName[k] + " in panchina per 7 giorni (aspettativa negativa)");
     }
  }

//--- K (1.25): commissioni+fee e swap di una posizione dallo storico
bool PositionCostsFromHistory(long id, double &comm, double &swap)
  {
   comm = 0.0;
   swap = 0.0;
   if(!HistorySelectByPosition(id))
      return false;
   int n = HistoryDealsTotal();
   for(int i = 0; i < n; i++)
     {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0)
         continue;
      comm += HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE);
      swap += HistoryDealGetDouble(d, DEAL_SWAP);
     }
   return true;
  }

double g_lastCostR = 0.0, g_lastComm = 0.0, g_lastSwap = 0.0;

//--- K (1.25): le medie dei costi sopravvivono ai riavvii (variabili globali del terminale, solo live)
void CostSave()
  {
   if(g_isTester)
      return;
   GlobalVariableSet(GvName("cSlip"), g_costSlipPx);
   GlobalVariableSet(GvName("cSlipN"), (double)g_costSlipN);
   GlobalVariableSet(GvName("cSpr"), g_costSpreadPx);
   GlobalVariableSet(GvName("cSprN"), (double)g_costSpreadN);
   GlobalVariableSet(GvName("cComm"), g_costCommLot);
   GlobalVariableSet(GvName("cCommN"), (double)g_costCommN);
   for(int e = 0; e < 3; e++)
     {
      GlobalVariableSet(GvName("cR" + IntegerToString(e)), g_costR[e]);
      GlobalVariableSet(GvName("cRN" + IntegerToString(e)), (double)g_costRN[e]);
     }
  }

void CostLoad()
  {
   for(int e = 0; e < 3; e++)
     {
      g_costR[e] = 0.0;
      g_costRN[e] = 0;
     }
   if(g_isTester)
      return;
   g_costSlipPx = GvGet("cSlip", 0.0);
   g_costSlipN = (int)GvGet("cSlipN", 0.0);
   g_costSpreadPx = GvGet("cSpr", 0.0);
   g_costSpreadN = (int)GvGet("cSprN", 0.0);
   g_costCommLot = GvGet("cComm", 0.0);
   g_costCommN = (int)GvGet("cCommN", 0.0);
   for(int e = 0; e < 3; e++)
     {
      g_costR[e] = GvGet("cR" + IntegerToString(e), 0.0);
      g_costRN[e] = (int)GvGet("cRN" + IntegerToString(e), 0.0);
     }
  }

//--- K (1.25): costo vero del trade appena chiuso (spread + slittamento all'ingresso + commissioni + swap negativo), in R
void CostOnClose(int mi)
  {
   double comm = 0.0, swap = 0.0;
   PositionCostsFromHistory(g_meta[mi].id, comm, swap);
   double vpu = ValuePerPriceUnit();
   double lots = g_meta[mi].lots0;
   double money = (g_meta[mi].spreadPx + MathMax(g_meta[mi].slipPx, 0.0)) * lots * vpu + MathAbs(comm) + MathMax(-swap, 0.0);
   g_lastComm = comm;
   g_lastSwap = swap;
   g_lastCostR = (g_meta[mi].riskMoney > 0.0) ? money / g_meta[mi].riskMoney : 0.0;
   if(!InpCostTrack || g_meta[mi].isPending)
      return;
   if(lots > 0.0)
     {
      g_costCommLot = CostAvg(g_costCommLot, g_costCommN, MathAbs(comm) / lots);
      g_costCommN++;
     }
   int e = g_meta[mi].engine;
   if(e >= 0 && e < 3)
     {
      g_costR[e] = CostAvg(g_costR[e], g_costRN[e], g_lastCostR);
      g_costRN[e]++;
      if(g_costRN[e] == 10 || (g_costRN[e] > 10 && g_costRN[e] % 20 == 0))
         if(g_costR[e] > InpMaxCostR)
            Notify("Costi veri alti nel motore " + g_engName[e] + ": in media " + DoubleToString(g_costR[e] * 100.0, 0) +
                   "% del rischio su " + IntegerToString(g_costRN[e]) + " trade (limite " + DoubleToString(InpMaxCostR * 100.0, 0) + "%)");
     }
   CostSave();
  }

void JournalWrite(int mi, double R, double net)
  {
   if(g_isOptim)
      return;
   string fn = g_isTester ? "XauCommittee_tester_trades.csv" : "XauCommittee_" + IntegerToString(g_login) + "_trades_costi.csv";
   int h = FileOpen(fn, FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return;
   if(FileSize(h) == 0)
      FileWriteString(h, "chiusura;motore;strategia;direzione;lotti;entrata;stop;target;R;netto;score;recupero;extra_profitti;idea;spread;slittamento;commissioni;swap;costi_R\r\n");
   FileSeek(h, 0, SEEK_END);
   string line = TimeToString(TimeCurrent(), TIME_DATE | TIME_MINUTES) + ";" + g_engName[g_meta[mi].engine] + ";" +
                 g_stratName[g_meta[mi].strat] + ";" + DirName(g_meta[mi].dir) + ";" + DoubleToString(g_meta[mi].lots0, g_lotDigits) + ";" +
                 DoubleToString(g_meta[mi].entry, g_digits) + ";" + DoubleToString(g_meta[mi].sl0, g_digits) + ";" +
                 DoubleToString(g_meta[mi].tp, g_digits) + ";" + DoubleToString(R, 2) + ";" + DoubleToString(net, 2) + ";" +
                 DoubleToString(g_meta[mi].score, 2) + ";" + (g_meta[mi].recovery ? "si" : "no") + ";" + DoubleToString(g_meta[mi].cushion, 2) + ";" +
                 IntegerToString(g_meta[mi].idea) + ";" + DoubleToString(g_meta[mi].spreadPx, g_digits) + ";" + DoubleToString(g_meta[mi].slipPx, g_digits) + ";" +
                 DoubleToString(g_lastComm, 2) + ";" + DoubleToString(g_lastSwap, 2) + ";" + DoubleToString(g_lastCostR, 3) + "\r\n";
   FileWriteString(h, line);
   FileClose(h);
  }

void StatsSave();

void FinalizeTrade(int mi, double net)
  {
   double R = (g_meta[mi].riskMoney > 0.0) ? net / g_meta[mi].riskMoney : 0.0;
   int k = g_meta[mi].strat;
   int e = g_meta[mi].engine;
   if(k > 0)
     {
      g_ss[k].Add(R, net);
      g_rep[k].Add(R, net);
     }
   if(e >= 0 && e < 3)
      g_es[e].Add(R, net);
   g_all.Add(R, net);
   //--- rientro (1.17): idea tornata a pareggio dopo aver toccato +BE_R -> si puo' rientrare una volta
   if(e >= 0 && e < 3)
     {
      if(R < -0.3)
         g_reArmed[e] = false;
      else
         if(InpReentryOn && g_meta[mi].beDone && g_meta[mi].tranche == 0 && !g_meta[mi].reentry && !g_meta[mi].recovery && R < 1.0)
           {
            g_reArmed[e] = true;
            g_reDir[e] = g_meta[mi].dir;
            g_reT[e] = TimeCurrent();
           }
     }
   if(R < -0.3)
     {
      g_lossStreak++;
      g_lossesInRowToday++;
      if(g_meta[mi].recovery)
        {
         g_recoveryArmed = false;
         g_recoveryCooldownUntil = TimeCurrent() + 24 * 3600;
        }
      else
         if(InpRecoveryEnabled && TimeCurrent() >= g_recoveryCooldownUntil)
           {
            g_recoveryArmed = true;
            g_recoveryArmedT = TimeCurrent();
           }
     }
   else
      if(R > 0.3)
        {
         g_lossStreak = 0;
         g_lossesInRowToday = 0;
         g_recoveryArmed = false;
        }
   BenchCheck(k);
   CostOnClose(mi);
   JournalWrite(mi, R, net);
   string msg = "CHIUSO [" + g_engName[e] + "] " + g_stratName[k] + " " + DirName(g_meta[mi].dir) + ": " +
                (net >= 0.0 ? "+" : "") + Money(net) + " (" + (R >= 0.0 ? "+" : "") + DoubleToString(R, 2) + "R)";
   Notify(msg);
   RememberDecision(msg);
   MetaRemove(mi);
   StatsSave();
  }

//--- somma netta di tutti i deal di una posizione (entrata + uscite + commissioni + swap)
bool PositionNetFromHistory(long id, double &net, int &deals)
  {
   net = 0.0;
   deals = 0;
   if(!HistorySelectByPosition(id))
      return false;
   int n = HistoryDealsTotal();
   for(int i = 0; i < n; i++)
     {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0)
         continue;
      net += HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_COMMISSION) +
             HistoryDealGetDouble(d, DEAL_SWAP) + HistoryDealGetDouble(d, DEAL_FEE);
      deals++;
     }
   return true;
  }

//--- metadati senza piu' posizione/ordine -> trade chiuso (o ordine scaduto)
void MetaSweep()
  {
   g_needSweep = false;
   for(int i = 0; i < MAX_META; i++)
     {
      if(!g_meta[i].active)
         continue;
      long id = g_meta[i].id;
      if(g_meta[i].isPending)
        {
         if(OrderExists(id) || PositionExistsById(id))
            continue;
        }
      else
         if(PositionExistsById(id))
            continue;
      double net = 0.0;
      int deals = 0;
      PositionNetFromHistory(id, net, deals);
      if(deals >= 2)
         FinalizeTrade(i, net);
      else
        {
         //--- lo storico puo' arrivare con un attimo di ritardo: riprovo prima di arrendermi
         g_meta[i].sweepTries++;
         if(!g_meta[i].isPending && g_meta[i].sweepTries < 20)
            continue;
         MetaRemove(i);
        }
     }
  }

//+------------------------------------------------------------------+
//| Salvataggio su file (solo live): metadati e statistiche          |
//+------------------------------------------------------------------+
string MetaFile() { return "XauCommittee_" + IntegerToString(g_login) + "_" + IntegerToString(InpMagicBase) + "_meta.txt"; }
string StatsFile() { return "XauCommittee_" + IntegerToString(g_login) + "_" + IntegerToString(InpMagicBase) + "_stats.txt"; }

void MetaSave()
  {
   if(g_isTester)
      return;
   int h = FileOpen(MetaFile(), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   for(int i = 0; i < MAX_META; i++)
     {
      if(!g_meta[i].active)
         continue;
      string l = IntegerToString(g_meta[i].id) + ";" + IntegerToString(g_meta[i].strat) + ";" + IntegerToString(g_meta[i].engine) + ";" +
                 IntegerToString(g_meta[i].dir) + ";" + IntegerToString(g_meta[i].tranche) + ";" + IntegerToString(g_meta[i].idea) + ";" +
                 DoubleToString(g_meta[i].entry, 5) + ";" + DoubleToString(g_meta[i].sl0, 5) + ";" + DoubleToString(g_meta[i].tp, 5) + ";" +
                 DoubleToString(g_meta[i].riskPx, 5) + ";" + DoubleToString(g_meta[i].riskMoney, 2) + ";" + DoubleToString(g_meta[i].lots0, 2) + ";" +
                 DoubleToString(g_meta[i].score, 3) + ";" + IntegerToString(g_meta[i].recovery ? 1 : 0) + ";" +
                 IntegerToString(g_meta[i].beDone ? 1 : 0) + ";" + IntegerToString(g_meta[i].partialDone ? 1 : 0) + ";" +
                 IntegerToString(g_meta[i].isPending ? 1 : 0) + ";" + IntegerToString((long)g_meta[i].openTime) + ";" +
                 IntegerToString(g_meta[i].expiryMin) + ";" + IntegerToString(g_meta[i].reentry ? 1 : 0) + ";" +
                 IntegerToString(g_meta[i].aplus ? 1 : 0) + ";" + IntegerToString((long)g_meta[i].deadline) + ";" +
                 IntegerToString(g_meta[i].wkDone ? 1 : 0) + "\r\n";
      FileWriteString(h, l);
     }
   FileClose(h);
  }

void MetaLoad()
  {
   if(g_isTester || !FileIsExist(MetaFile(), FILE_COMMON))
      return;
   int h = FileOpen(MetaFile(), FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      int np = StringSplit(l, ';', p);
      if(np < 19)
         continue;
      int k = MetaFree();
      if(k < 0)
         break;
      g_meta[k].Reset();
      g_meta[k].active = true;
      g_meta[k].id = StringToInteger(p[0]);
      g_meta[k].strat = (int)StringToInteger(p[1]);
      g_meta[k].engine = (int)StringToInteger(p[2]);
      g_meta[k].dir = (int)StringToInteger(p[3]);
      g_meta[k].tranche = (int)StringToInteger(p[4]);
      g_meta[k].idea = (int)StringToInteger(p[5]);
      g_meta[k].entry = StringToDouble(p[6]);
      g_meta[k].sl0 = StringToDouble(p[7]);
      g_meta[k].tp = StringToDouble(p[8]);
      g_meta[k].riskPx = StringToDouble(p[9]);
      g_meta[k].riskMoney = StringToDouble(p[10]);
      g_meta[k].lots0 = StringToDouble(p[11]);
      g_meta[k].score = StringToDouble(p[12]);
      g_meta[k].recovery = (StringToInteger(p[13]) != 0);
      g_meta[k].beDone = (StringToInteger(p[14]) != 0);
      g_meta[k].partialDone = (StringToInteger(p[15]) != 0);
      g_meta[k].isPending = (StringToInteger(p[16]) != 0);
      g_meta[k].openTime = (datetime)StringToInteger(p[17]);
      g_meta[k].expiryMin = (int)StringToInteger(p[18]);
      g_meta[k].reentry = (np >= 20 && StringToInteger(p[19]) != 0);
      g_meta[k].aplus = (np >= 21 && StringToInteger(p[20]) != 0);
      if(np >= 22)
         g_meta[k].deadline = (datetime)StringToInteger(p[21]);
      g_meta[k].wkDone = (np >= 23 && StringToInteger(p[22]) != 0);
      if(g_meta[k].strat < 0 || g_meta[k].strat >= NSTRAT || g_meta[k].engine < 0 || g_meta[k].engine > 2)
         g_meta[k].Reset();
      else
         if(g_meta[k].idea > g_ideaSeq)
            g_ideaSeq = g_meta[k].idea;
     }
   FileClose(h);
  }

void StatsSave()
  {
   if(g_isTester)
      return;
   int h = FileOpen(StatsFile(), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   for(int k = 1; k < NSTRAT; k++)
     {
      string l = IntegerToString(k) + ";" + IntegerToString(g_ss[k].n) + ";" + IntegerToString(g_ss[k].wins) + ";" +
                 IntegerToString(g_ss[k].losses) + ";" + DoubleToString(g_ss[k].sumR, 4) + ";" + DoubleToString(g_ss[k].sumR2, 4) + ";" +
                 DoubleToString(g_ss[k].grossWinR, 4) + ";" + DoubleToString(g_ss[k].grossLossR, 4) + ";" +
                 DoubleToString(g_ss[k].net, 2) + ";" + IntegerToString((long)g_ss[k].benchUntil);
      for(int j = 0; j < 10; j++)
         l += ";" + DoubleToString(g_ss[k].last[j], 3);
      l += ";" + IntegerToString(g_ss[k].lastN) + ";" + IntegerToString(g_ss[k].lastHead) + "\r\n";
      FileWriteString(h, l);
     }
   FileClose(h);
   MetaSave();
  }

void StatsLoad()
  {
   for(int k = 0; k < NSTRAT; k++)
     {
      g_ss[k].Reset();
      g_rep[k].Reset();
     }
   for(int e = 0; e < 3; e++)
      g_es[e].Reset();
   g_all.Reset();
   if(g_isTester || !FileIsExist(StatsFile(), FILE_COMMON))
      return;
   int h = FileOpen(StatsFile(), FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      if(StringSplit(l, ';', p) < 22)
         continue;
      int k = (int)StringToInteger(p[0]);
      if(k <= 0 || k >= NSTRAT)
         continue;
      g_ss[k].n = (int)StringToInteger(p[1]);
      g_ss[k].wins = (int)StringToInteger(p[2]);
      g_ss[k].losses = (int)StringToInteger(p[3]);
      g_ss[k].sumR = StringToDouble(p[4]);
      g_ss[k].sumR2 = StringToDouble(p[5]);
      g_ss[k].grossWinR = StringToDouble(p[6]);
      g_ss[k].grossLossR = StringToDouble(p[7]);
      g_ss[k].net = StringToDouble(p[8]);
      g_ss[k].benchUntil = (datetime)StringToInteger(p[9]);
      for(int j = 0; j < 10; j++)
         g_ss[k].last[j] = StringToDouble(p[10 + j]);
      g_ss[k].lastN = IMin(10, IMax(0, (int)StringToInteger(p[20])));
      g_ss[k].lastHead = IMin(9, IMax(0, (int)StringToInteger(p[21])));
     }
   FileClose(h);
  }
