//+------------------------------------------------------------------+
//| 1.31: pausa serale del broker                                    |
//| Alla chiusura e alla riapertura di ogni sera lo spread si apre e |
//| il demo stampa prezzi finti (dal 2026 fino a 54 $ lontani, quasi |
//| sempre verso il basso, poi tornano). Uno stop vicino viene preso |
//| da un prezzo che non esiste. Prima della chiusura il bot salva lo |
//| stop vero e lo allarga (o lo toglie); dopo la riapertura, quando  |
//| lo spread e' tornato normale, lo rimette dov'era. Se il prezzo    |
//| vero e' gia' oltre lo stop, chiude al mercato.                    |
//+------------------------------------------------------------------+
bool ModifySL(ulong tk, double sl, double tp);
bool CloseTicket(ulong tk, string why);
void RgDiary(int npos, int avoided, int shut);

int      g_rgClose = -1;          // minuto del giorno (ora server) in cui di solito comincia la pausa
int      g_rgLen = 0;             // durata della pausa (minuti), dall'ultima vista
datetime g_rgLearnDay = 0;
datetime g_rgStartT = 0;          // protezione cominciata a quest'ora (0 = nessuna)
datetime g_rgOpenT = 0;           // riapertura vista a quest'ora (0 = non ancora)
datetime g_rgLastTick = 0;
datetime g_rgDoneDay = 0;         // giorno (server) in cui la protezione e' gia' stata fatta
ulong    g_rgTk[];
double   g_rgSl[];
int      g_rgDir[];
double   g_rgMaxSp = 0.0, g_rgBidLo = 0.0, g_rgAskHi = 0.0;   // diario della pausa: spread massimo, bid piu' basso, ask piu' alto
int      g_rgStatFake = 0;                                 // stop che i prezzi della pausa avrebbero preso (evitati)
int      g_rgN = 0;
int      g_rgStatProt = 0, g_rgStatBack = 0, g_rgStatShut = 0;
string   g_rgLast = "";
bool     g_rgReloaded = false;

string RgGv(ulong tk) { return "XCRG_" + IntegerToString((long)tk); }
string RgHm(int m) { return StringFormat("%02d:%02d", (m / 60) % 24, m % 60); }

//--- impara dalle candele M1 quando comincia la pausa serale di questo broker (cambia con l'ora legale e nel tempo:
//    sul demo MetaQuotes fino al 2025 dalle 23:59 alle 01:00 del server, dal 2026 dalle 23:00 alle 01:00)
void RgLearn()
  {
   datetime now = TimeCurrent();
   datetime day = now - now % 86400;
   if(day == g_rgLearnDay)
      return;
   g_rgLearnDay = day;
   MqlRates b[];
   int n = CopyRates(g_sym, PERIOD_M1, 1, 20000, b);
   if(n < 2000)
      return;
   int cm[];
   int cl[];
   ArrayResize(cm, 10);
   ArrayResize(cl, 10);
   int found = 0;
   for(int i = n - 1; i >= 1 && found < 10; i--)
     {
      int g = (int)((b[i].time - b[i - 1].time) / 60);
      if(g < 20 || g > 12 * 60)
         continue;                                  // buchi piccoli o weekend/feste intere
      datetime c = b[i - 1].time + 60;
      cm[found] = (int)((c % 86400) / 60);
      cl[found] = (int)((b[i].time - c) / 60);
      found++;
     }
   if(found < 2)
      return;
   //--- minuto piu' frequente (a parita' il piu' recente)
   int best = -1, bestN = 0;
   for(int a = 0; a < found; a++)
     {
      int k = 0;
      for(int z = 0; z < found; z++)
         if(cm[z] == cm[a])
            k++;
      if(k > bestN)
        {
         bestN = k;
         best = a;
        }
     }
   //--- il piu' presto tra le chiusure recenti vicine a quella tipica (fino a 70 minuti prima: cambio dell'ora legale
   //    del broker); le chiusure anticipate delle feste (21:30, 90 minuti prima) non contano
   int m0 = cm[best];
   int early = m0;
   for(int z = 0; z < found; z++)
     {
      int d = m0 - cm[z];
      if(d < -720)
         d += 1440;
      if(d > 720)
         d -= 1440;
      if(d > 0 && d <= 70 && z < 3)
         early = cm[z];
     }
   g_rgClose = early;
   g_rgLen = cl[best];
  }

bool RgSaved(ulong tk)
  {
   for(int i = 0; i < g_rgN; i++)
      if(g_rgTk[i] == tk)
         return true;
   return false;
  }

//--- stop vero di una posizione (quello salvato, se nella pausa serale e' allargato o tolto)
double RgRealSl(ulong tk, double sl)
  {
   for(int i = 0; i < g_rgN; i++)
      if(g_rgTk[i] == tk)
         return g_rgSl[i];
   return sl;
  }

void RgPush(ulong tk, double sl, int dir)
  {
   ArrayResize(g_rgTk, g_rgN + 1);
   ArrayResize(g_rgSl, g_rgN + 1);
   ArrayResize(g_rgDir, g_rgN + 1);
   g_rgTk[g_rgN] = tk;
   g_rgSl[g_rgN] = sl;
   g_rgDir[g_rgN] = dir;
   g_rgN++;
  }

void RgAdd(ulong tk, double sl, int dir)
  {
   if(RgSaved(tk))
      return;
   RgPush(tk, sl, dir);
   GlobalVariableSet(RgGv(tk), sl);
  }

void RgDrop(int i)
  {
   GlobalVariableDel(RgGv(g_rgTk[i]));
   for(int k = i; k < g_rgN - 1; k++)
     {
      g_rgTk[k] = g_rgTk[k + 1];
      g_rgSl[k] = g_rgSl[k + 1];
      g_rgDir[k] = g_rgDir[k + 1];
     }
   g_rgN--;
   ArrayResize(g_rgTk, g_rgN);
   ArrayResize(g_rgSl, g_rgN);
   ArrayResize(g_rgDir, g_rgN);
  }

//--- dopo un riavvio dell'EA: le posizioni con lo stop vero salvato tornano nell'elenco
void RgReload()
  {
   if(g_rgReloaded)
      return;
   g_rgReloaded = true;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0 || PositionGetString(POSITION_SYMBOL) != g_sym || !IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      if(GlobalVariableCheck(RgGv(tk)))
         RgPush(tk, GlobalVariableGet(RgGv(tk)), (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1);
     }
   if(g_rgN > 0 && g_rgStartT == 0)
      g_rgStartT = TimeCurrent();
  }

//--- inizio della prossima pausa (ora server) a partire da 'now'; 0 se oggi non c'e' (venerdi': c'e' il weekend)
datetime RgNextClose(datetime now)
  {
   if(g_rgClose < 0)
      return 0;
   datetime day = now - now % 86400;
   datetime c = day + g_rgClose * 60;
   if(c + 60 * 60 < now)
      c += 86400;
   int dow = DowOf(c - 60);                       // giorno dell'ultimo minuto di mercato (la pausa delle 00:00 e' della sera prima)
   if(dow < 1 || dow > 4)
      return 0;
   return c;
  }

//--- finestra della pausa: niente ingressi nuovi da 'prima' fino a quando gli stop veri sono tornati
bool RgBusy()
  {
   if(InpRollGuard <= 0)
      return false;
   if(g_rgStartT > 0)
      return true;
   datetime now = TimeCurrent();
   datetime c = RgNextClose(now);
   return (c > 0 && now >= c - InpRollBeforeMin * 60 && now < c + 60 * 60);
  }

double RgEmergDist(ulong tk)
  {
   double a = AtrOf(g_d1);
   if(a <= 0.0)
     {
      double op = PositionGetDouble(POSITION_PRICE_OPEN), sl = PositionGetDouble(POSITION_SL);
      a = 3.0 * MathAbs(op - sl);
     }
   return MathMax(InpRollEmergAtr, 0.1) * a;
  }

//--- prima della chiusura: salva lo stop vero e lo allarga (modo 1) o lo toglie (modo 2)
void RgProtect()
  {
   int c = 0, f = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0 || PositionGetString(POSITION_SYMBOL) != g_sym || !IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      if(RgSaved(tk))
         continue;
      double sl = PositionGetDouble(POSITION_SL), tp = PositionGetDouble(POSITION_TP);
      if(sl <= 0.0)
         continue;
      int dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      double ns = 0.0;
      if(InpRollGuard == 1)
        {
         ns = sl - dir * RgEmergDist(tk);
         if(ns <= 0.0)
            ns = 0.0;
        }
      RgAdd(tk, sl, dir);
      if(ModifySL(tk, ns, tp))
         c++;
      else
        {
         f++;
         RgDrop(g_rgN - 1);                       // non riuscito: resta lo stop vero
        }
     }
   g_rgStatProt += c;
   if(c > 0 || f > 0)
     {
      g_rgLast = "alle " + TimeToString(TimeCurrent(), TIME_MINUTES) + (InpRollGuard == 1 ? " stop d'emergenza su " : " stop tolti su ") + IntegerToString(c) +
                 " posizioni";
      Logf("Pausa serale: " + g_rgLast + " (stop veri salvati, tornano " + IntegerToString(InpRollAfterMin) + " minuti dopo la riapertura)" +
           (f > 0 ? "; " + IntegerToString(f) + " non riuscite, restano con lo stop vero" : ""));
     }
  }

//--- dopo la riapertura: rimette lo stop vero; se il prezzo vero e' gia' oltre, chiude al mercato
void RgRestore()
  {
   double md = StopsMinDist();
   int back = 0, shut = 0, fake = 0;
   for(int k = 0; k < g_rgN; k++)
      if((g_rgDir[k] > 0 && g_rgBidLo > 0.0 && g_rgBidLo <= g_rgSl[k]) || (g_rgDir[k] < 0 && g_rgAskHi >= g_rgSl[k] && g_rgAskHi > 0.0))
         fake++;                                     // i prezzi della pausa sono passati dallo stop vero
   for(int k = g_rgN - 1; k >= 0; k--)
     {
      ulong tk = g_rgTk[k];
      if(!PositionSelectByTicket(tk))
        {
         RgDrop(k);                                  // chiusa nella pausa (target o stop d'emergenza)
         continue;
        }
      int dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      double px = (dir > 0) ? PxBid() : PxAsk();
      double sl = g_rgSl[k], tp = PositionGetDouble(POSITION_TP);
      if((px - sl) * dir <= md + g_tick)
        {
         if(CloseTicket(tk, "pausa serale: dopo la riapertura il prezzo vero e' oltre lo stop (" + DoubleToString(sl, g_digits) + ")"))
           {
            RgDrop(k);
            shut++;
           }
         continue;
        }
      if(ModifySL(tk, sl, tp))
        {
         RgDrop(k);
         back++;
        }
     }
   g_rgStatBack += back;
   g_rgStatShut += shut;
   int avoided = MathMax(fake - shut, 0);
   g_rgStatFake += avoided;
   if(back > 0 || shut > 0)
      RgDiary(back + shut, avoided, shut);
   if(back > 0 || shut > 0)
     {
      g_rgLast = "alle " + TimeToString(TimeCurrent(), TIME_MINUTES) + " stop veri rimessi su " + IntegerToString(back) + " posizioni" +
                 (shut > 0 ? ", " + IntegerToString(shut) + " chiuse (prezzo vero oltre lo stop)" : "");
      Logf("Pausa serale: " + g_rgLast);
      if(shut > 0)
         Notify("Pausa serale: " + IntegerToString(shut) + " posizioni chiuse alla riapertura, il prezzo vero era oltre lo stop");
     }
  }

//--- diario di ogni pausa serale: quanto si e' aperto lo spread e quanti stop i prezzi finti avrebbero preso
string RgFile() { return g_isTester ? "XauCommittee_tester_pausa.csv" : "XauCommittee_" + IntegerToString(g_login) + "_pausa.csv"; }

void RgDiary(int npos, int avoided, int shut)
  {
   if(g_isOptim)
      return;
   int h = FileOpen(RgFile(), FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return;
   if(FileSize(h) == 0)
      FileWriteString(h, "giorno;inizio;riapertura;stop_rimessi;posizioni;spread_massimo;spread_normale;bid_minimo;ask_massimo;prezzo_rimesso;stop_finti_evitati;chiuse_prezzo_vero\r\n");
   FileSeek(h, 0, SEEK_END);
   FileWriteString(h, TimeToString(g_rgStartT, TIME_DATE) + ";" + TimeToString(g_rgStartT, TIME_MINUTES) + ";" +
                   (g_rgOpenT > 0 ? TimeToString(g_rgOpenT, TIME_MINUTES) : "-") + ";" + TimeToString(TimeCurrent(), TIME_MINUTES) + ";" +
                   IntegerToString(npos) + ";" + DoubleToString(g_rgMaxSp, g_digits) + ";" + DoubleToString(g_spreadAvg, g_digits) + ";" +
                   DoubleToString(g_rgBidLo, g_digits) + ";" + DoubleToString(g_rgAskHi, g_digits) + ";" + DoubleToString(PxBid(), g_digits) + ";" +
                   IntegerToString(avoided) + ";" + IntegerToString(shut) + "\r\n");
   FileClose(h);
  }

void RgTrack()
  {
   double b = PxBid(), a = PxAsk();
   if(b <= 0.0 || a <= 0.0)
      return;
   g_rgMaxSp = MathMax(g_rgMaxSp, a - b);
   g_rgBidLo = (g_rgBidLo <= 0.0) ? b : MathMin(g_rgBidLo, b);
   g_rgAskHi = MathMax(g_rgAskHi, a);
  }

//--- ogni tick (e ogni timer): fa partire e finire la protezione
void RgTick(bool fromTick)
  {
   if(InpRollGuard <= 0)
      return;
   datetime now = TimeCurrent();
   RgLearn();
   RgReload();
   //--- riapertura: il primo prezzo dopo almeno 20 minuti senza prezzi
   if(fromTick)
     {
      if(g_rgStartT > 0 && g_rgOpenT == 0 && (g_rgLastTick == 0 || now - g_rgLastTick >= 20 * 60))
         g_rgOpenT = now;
      g_rgLastTick = now;
     }
   //--- inizio: pochi minuti prima della chiusura (una volta per sera)
   datetime c = RgNextClose(now);
   if(g_rgStartT == 0 && c > 0 && now >= c - InpRollBeforeMin * 60 && now < c && g_rgDoneDay != c)
     {
      g_rgDoneDay = c;
      g_rgStartT = now;
      g_rgOpenT = 0;
      g_rgMaxSp = 0.0;
      g_rgBidLo = 0.0;
      g_rgAskHi = 0.0;
      RgProtect();
     }
   else
      if(g_rgStartT > 0 && g_rgOpenT == 0 && now < c && c > 0 && now >= c - InpRollBeforeMin * 60)
         RgProtect();                                   // posizioni aperte dopo l'inizio (rare): anche loro
   if(g_rgStartT == 0)
      return;
   if(fromTick)
      RgTrack();
   //--- fine: dopo la riapertura, spread tornato normale (o tempo massimo)
   bool done = false;
   if(g_rgOpenT > 0)
     {
      double sp = PxAsk() - PxBid();
      bool calm = (g_spreadAvg <= 0.0 || sp <= InpRollSpreadMult * g_spreadAvg);
      if((now >= g_rgOpenT + InpRollAfterMin * 60 && calm) || now >= g_rgOpenT + InpRollMaxWaitMin * 60)
         done = true;
     }
   else
      if(now >= g_rgStartT + 4 * 3600 && fromTick)
         done = true;                                   // nessuna pausa vista in 4 ore (orario cambiato): rimette comunque
   if(done)
     {
      if(g_rgN > 0)
         RgRestore();
      if(g_rgN == 0)
        {
         g_rgStartT = 0;
         g_rgOpenT = 0;
        }
     }
  }

string RollPanel()
  {
   if(InpRollGuard <= 0)
      return "";
   if(g_rgStartT > 0 && g_rgN > 0)
      return "Pausa serale: " + IntegerToString(g_rgN) + (InpRollGuard == 1 ? " stop allargati" : " stop tolti") + ", tornano " +
             IntegerToString(InpRollAfterMin) + " min dopo la riapertura con spread normale\n";
   if(g_rgClose < 0)
      return "";
   datetime now = TimeCurrent();
   datetime c = RgNextClose(now);
   if(c > 0 && c - now <= 3 * 3600)
      return "Pausa serale alle " + RgHm(g_rgClose) + " del server: " + IntegerToString(InpRollBeforeMin) + " min prima " +
             (InpRollGuard == 1 ? "allarga gli stop" : "toglie gli stop") + (g_rgLast != "" ? " (ultima: " + g_rgLast + ")" : "") + "\n";
   return "";
  }
