//+------------------------------------------------------------------+
//| Dati di mercato e indicatori calcolati internamente              |
//| (stessi numeri nel tester e dal vivo, nessun handle esterno)     |
//+------------------------------------------------------------------+
struct TfData
  {
   ENUM_TIMEFRAMES   tf;
   int               want;
   int               n;
   datetime          lastOpen;
   MqlRates          r[];
   double            ema20[];
   double            ema50[];
   double            ema200[];
   double            atr[];
   double            rsi[];
   double            adx[];
   double            pdi[];
   double            mdi[];
  };

TfData g_m1;
TfData g_m5;
TfData g_m15;
TfData g_h1;
TfData g_h4;
TfData g_d1;

void CalcEMA(const MqlRates &r[], int n, int period, double &out[])
  {
   ArrayResize(out, n);
   if(n <= 0)
      return;
   double k = 2.0 / (period + 1.0);
   //--- seme: media semplice delle prime barre disponibili
   int seed = IMin(period, n);
   double s = 0.0;
   for(int i = 0; i < seed; i++)
      s += r[i].close;
   double v = s / seed;
   for(int i = 0; i < n; i++)
     {
      if(i < seed)
         out[i] = v;
      else
        {
         v = r[i].close * k + v * (1.0 - k);
         out[i] = v;
        }
     }
  }

void CalcATR(const MqlRates &r[], int n, int period, double &out[])
  {
   ArrayResize(out, n);
   if(n <= 0)
      return;
   out[0] = r[0].high - r[0].low;
   for(int i = 1; i < n; i++)
     {
      double tr = MathMax(r[i].high, r[i - 1].close) - MathMin(r[i].low, r[i - 1].close);
      if(i < period)
         out[i] = (out[i - 1] * i + tr) / (i + 1);
      else
         out[i] = (out[i - 1] * (period - 1) + tr) / period;
     }
  }

void CalcRSI(const MqlRates &r[], int n, int period, double &out[])
  {
   ArrayResize(out, n);
   if(n <= 0)
      return;
   double ag = 0.0, al = 0.0;
   out[0] = 50.0;
   for(int i = 1; i < n; i++)
     {
      double ch = r[i].close - r[i - 1].close;
      double g = (ch > 0.0) ? ch : 0.0;
      double l = (ch < 0.0) ? -ch : 0.0;
      if(i <= period)
        {
         ag = (ag * (i - 1) + g) / i;
         al = (al * (i - 1) + l) / i;
        }
      else
        {
         ag = (ag * (period - 1) + g) / period;
         al = (al * (period - 1) + l) / period;
        }
      if(al <= 0.0000000001)
         out[i] = (ag > 0.0) ? 100.0 : 50.0;
      else
         out[i] = 100.0 - 100.0 / (1.0 + ag / al);
     }
  }

void CalcADX(const MqlRates &r[], int n, int period, double &adx[], double &pdi[], double &mdi[])
  {
   ArrayResize(adx, n);
   ArrayResize(pdi, n);
   ArrayResize(mdi, n);
   if(n <= 0)
      return;
   adx[0] = 0.0;
   pdi[0] = 0.0;
   mdi[0] = 0.0;
   double trS = 0.0, pS = 0.0, mS = 0.0, av = 0.0;
   for(int i = 1; i < n; i++)
     {
      double up = r[i].high - r[i - 1].high;
      double dn = r[i - 1].low - r[i].low;
      double pdm = (up > dn && up > 0.0) ? up : 0.0;
      double mdm = (dn > up && dn > 0.0) ? dn : 0.0;
      double tr = MathMax(r[i].high, r[i - 1].close) - MathMin(r[i].low, r[i - 1].close);
      if(i <= period)
        {
         trS += tr;
         pS += pdm;
         mS += mdm;
        }
      else
        {
         trS = trS - trS / period + tr;
         pS = pS - pS / period + pdm;
         mS = mS - mS / period + mdm;
        }
      double p = (trS > 0.0) ? 100.0 * pS / trS : 0.0;
      double m = (trS > 0.0) ? 100.0 * mS / trS : 0.0;
      double dx = (p + m > 0.0) ? 100.0 * MathAbs(p - m) / (p + m) : 0.0;
      if(i <= period)
         av = (av * (i - 1) + dx) / i;
      else
         av = (av * (period - 1) + dx) / period;
      adx[i] = av;
      pdi[i] = p;
      mdi[i] = m;
     }
  }

void TfInit(TfData &d, ENUM_TIMEFRAMES tf, int want)
  {
   d.tf = tf;
   d.want = want;
   d.n = 0;
   d.lastOpen = 0;
  }

bool TfRefresh(TfData &d)
  {
   int got = CopyRates(g_sym, d.tf, 1, d.want, d.r);
   if(got <= 0)
     {
      d.n = 0;
      return false;
     }
   d.n = IMin(got, ArraySize(d.r));
   CalcEMA(d.r, d.n, 20, d.ema20);
   CalcEMA(d.r, d.n, 50, d.ema50);
   CalcEMA(d.r, d.n, 200, d.ema200);
   CalcATR(d.r, d.n, 14, d.atr);
   CalcRSI(d.r, d.n, 14, d.rsi);
   CalcADX(d.r, d.n, 14, d.adx, d.pdi, d.mdi);
   return true;
  }

bool TfNewBar(TfData &d)
  {
   datetime t = iTime(g_sym, d.tf, 0);
   if(t == 0)
      return false;
   if(t != d.lastOpen)
     {
      d.lastOpen = t;
      return true;
     }
   return false;
  }

//--- accesso alle barre chiuse: sh=0 ultima barra chiusa
int TfIdx(const TfData &d, int sh)
  {
   int i = d.n - 1 - sh;
   if(i < 0 || i >= d.n)
      return -1;
   return i;
  }

double BarO(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].open; }
double BarH(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].high; }
double BarL(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].low; }
double BarC(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].close; }
double BarV(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : (double)d.r[i].tick_volume; }
datetime BarT(const TfData &d, int sh) { int i = TfIdx(d, sh); if(i < 0) return 0; return d.r[i].time; }

double Ind(const double &a[], int sh)
  {
   int n = ArraySize(a);
   int i = n - 1 - sh;
   if(i < 0 || i >= n)
      return 0.0;
   return a[i];
  }

double MinInd(const double &a[], int fromSh, int count)
  {
   double m = 1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = ArraySize(a) - 1 - k;
      if(i < 0)
         break;
      if(a[i] < m)
         m = a[i];
     }
   return (m > 1.0e299) ? 0.0 : m;
  }

double MaxInd(const double &a[], int fromSh, int count)
  {
   double m = -1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = ArraySize(a) - 1 - k;
      if(i < 0)
         break;
      if(a[i] > m)
         m = a[i];
     }
   return (m < -1.0e299) ? 0.0 : m;
  }

double HighestH(const TfData &d, int fromSh, int count)
  {
   double m = -1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = TfIdx(d, k);
      if(i < 0)
         break;
      if(d.r[i].high > m)
         m = d.r[i].high;
     }
   return (m < -1.0e299) ? 0.0 : m;
  }

double LowestL(const TfData &d, int fromSh, int count)
  {
   double m = 1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = TfIdx(d, k);
      if(i < 0)
         break;
      if(d.r[i].low < m)
         m = d.r[i].low;
     }
   return (m > 1.0e299) ? 0.0 : m;
  }

double AtrOf(const TfData &d) { return Ind(d.atr, 0); }
double AdxOf(const TfData &d) { return Ind(d.adx, 0); }

//--- +1 rialzo, -1 ribasso, 0 misto (EMA20/EMA50 e chiusura rispetto a EMA50)
int TrendDir(const TfData &d)
  {
   if(d.n < 60)
      return 0;
   double e20 = Ind(d.ema20, 0), e50 = Ind(d.ema50, 0), c = BarC(d, 0);
   if(e20 > e50 && c > e50)
      return 1;
   if(e20 < e50 && c < e50)
      return -1;
   return 0;
  }

int EmaDir(const TfData &d)
  {
   if(d.n < 60)
      return 0;
   double e20 = Ind(d.ema20, 0), e50 = Ind(d.ema50, 0);
   if(e20 > e50)
      return 1;
   if(e20 < e50)
      return -1;
   return 0;
  }

//--- posizione della chiusura nella barra (0 = minimo, 1 = massimo)
double ClosePos(const TfData &d, int sh)
  {
   double h = BarH(d, sh), l = BarL(d, sh);
   if(h - l <= 0.0)
      return 0.5;
   return (BarC(d, sh) - l) / (h - l);
  }

//--- quota di spike nella direzione contraria (rifiuto): long = spike in basso
double WickRatio(const TfData &d, int sh, int dir)
  {
   double h = BarH(d, sh), l = BarL(d, sh), o = BarO(d, sh), c = BarC(d, sh);
   double rg = h - l;
   if(rg <= 0.0)
      return 0.0;
   if(dir > 0)
      return (MathMin(o, c) - l) / rg;
   return (h - MathMax(o, c)) / rg;
  }

//--- divergenza RSI: nuovo estremo di prezzo ma RSI piu' debole (contro la direzione dir)
bool RsiDivergenceAgainst(const TfData &d, int dir, int lookback)
  {
   if(d.n < lookback + 5)
      return false;
   if(dir > 0)
     {
      double hNow = HighestH(d, 0, 3), hPrev = HighestH(d, 3, lookback);
      double rNow = MaxInd(d.rsi, 0, 3), rPrev = MaxInd(d.rsi, 3, lookback);
      return (hNow > hPrev && rNow < rPrev - 3.0);
     }
   double lNow = LowestL(d, 0, 3), lPrev = LowestL(d, 3, lookback);
   double rNow2 = MinInd(d.rsi, 0, 3), rPrev2 = MinInd(d.rsi, 3, lookback);
   return (lNow < lPrev && rNow2 > rPrev2 + 3.0);
  }

bool DataReady()
  {
   return (g_m1.n >= 60 && g_m5.n >= 120 && g_m15.n >= 120 && g_h1.n >= 120 && g_h4.n >= 60 && g_d1.n >= 20);
  }

//+------------------------------------------------------------------+
//| Contesto del momento (calcolato una volta per barra M1)          |
//+------------------------------------------------------------------+
struct Ctx
  {
   double            bid;
   double            ask;
   double            spread;
   double            atrM1;
   double            atrM5;
   double            atrM15;
   double            atrH1;
   double            atrH4;
   double            atrD1;
   double            vwap;
   double            vwSig;
   double            wvwap;
   datetime          nowSrv;
   datetime          nowUtc;
   double            hUtc;
   double            lonOpen;
   double            nyData;
   double            nyOpen;
   double            nyClose;
   int               dow;
  };
Ctx g_ctx;
