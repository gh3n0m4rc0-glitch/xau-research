//+------------------------------------------------------------------+
//| RITRACCIAMENTI NEL VERSO DEL TREND - "ONDA" (1.27)               |
//|                                                                  |
//| Studio sulle M1 2022-2026 (4 periodi, costi inclusi) e sull'oro  |
//| giornaliero 1975-2026:                                           |
//| - il prezzo si muove a onde. Un punto di svolta e' confermato    |
//|   quando una barra chiude a k escursioni medie dall'estremo.     |
//|   Entrare alla conferma di un minimo quando il trend giornaliero |
//|   (EMA20 sopra EMA50 sulle giornate chiuse) e' al rialzo, o di   |
//|   un massimo quando e' al ribasso, rende; fare il contrario      |
//|   perde (-0,24R su H1). Stop oltre il punto di svolta, target    |
//|   2R, pareggio a 1,5R, tempo massimo 3 volte la durata dell'onda.|
//| - H1 onde 0,8: 305 trade, +0,39R, 56% vincenti, 4 periodi su 4;  |
//|   con anche H4 e H1 nel verso (direzione chiara): +0,67R, 61%.   |
//| - M15 onde 0,4, stop max 0,4: 1204 trade (~280 l'anno), +0,16R,  |
//|   4 su 4. H4 onde 1,5: 77 trade, +0,53R, 60%, 4 su 4.            |
//| - M5 onde 0,3, stop max 0,3: regge solo con direzione chiara     |
//|   (D1, H4 e H1 d'accordo): 1122 trade (~260 l'anno), +0,12R,     |
//|   4 su 4. Su M1 la regola non regge: non c'e'.                   |
//| - Oro giornaliero dal 1975: positiva in tutti i blocchi di 5     |
//|   anni. Su EURUSD e' negativa: vale per l'oro, non in generale.  |
//| - La macro non migliora questi ingressi: resta una lettura       |
//|   misurata (vedi LETTURA DEL MERCATO), non un filtro.            |
//| - Chiudere il venerdi' sera dimezza il risultato di H1 e azzera  |
//|   quello di H4; M5 e M15 quasi non cambiano.                     |
//| Target vicino con lotti piu' alti (M5, M15: stop stretto) e      |
//| target lontano con lotti piu' bassi (H1, H4: stop largo).        |
//+------------------------------------------------------------------+
bool MarketShouldBeOpen(datetime utc);

#define ON_N 5   // 1.36: scala 4 = SPINTA-TREND (H1)

struct ZzState
  {
   bool              ok;        // almeno tre punti di svolta nel buffer
   int               n;         // punti di svolta trovati
   int               t0;        // indice della barra del punto due prima dell'ultimo
   double            p0;
   int               t1;
   double            p1;
   int               t2;        // indice della barra dell'ultimo punto confermato
   double            p2;
   int               type2;     // +1 massimo, -1 minimo
   int               c2;        // indice della barra che lo ha confermato
   datetime          time2;     // ora (server) della barra del punto
   datetime          conf2;     // ora (server) di apertura della barra di conferma
   double            a2;        // escursione media alla conferma
   int               legDir;    // verso della gamba in corso (+1 sale)
   double            legExt;    // estremo della gamba in corso
   int               nbars;     // barre nel buffer al momento del calcolo
  };
ZzState  g_zz[ON_N];
datetime g_ondaDone[ON_N];      // punto di svolta (ora della sua barra) gia' giocato: aperto, sulla carta o respinto
string   g_ondaDoneWhy[ON_N];
string   g_ondaText[ON_N];      // riga del pannello
double   g_ondaDayA[];          // per ogni giornata del buffer D1: escursione media delle 20 giornate chiuse prima
bool     g_ondaReady = false;

int    OndaStrat(int sc)  { return (sc == 0) ? ST_ON_M5 : ((sc == 1) ? ST_ON_M15 : ((sc == 2) ? ST_ON_H1 : ((sc == 4) ? ST_SPINTA : ST_ON_H4))); }
int    OndaBarSec(int sc) { return (sc == 0) ? 300 : ((sc == 1) ? 900 : ((sc == 2 || sc == 4) ? 3600 : 14400)); }
string OndaTfName(int sc) { return (sc == 0) ? "M5" : ((sc == 1) ? "M15" : ((sc == 2) ? "H1" : ((sc == 4) ? "SPINTA" : "H4"))); }

double OndaK(int sc)
  {
   double k = (sc == 0) ? InpOndaM5K : ((sc == 1) ? InpOndaM15K : ((sc == 2) ? InpOndaH1K : InpOndaH4K));
   return Clamp(k, 0.05, 5.0);
  }

double OndaStopMax(int sc) { return (sc == 0) ? InpOndaM5StopMax : ((sc == 1) ? InpOndaM15StopMax : 0.0); }

double OndaStopMin(int sc)
  {
   double m = (sc == 0) ? InpOndaM5StopMin : ((sc == 1) ? InpOndaM15StopMin : ((sc == 2 || sc == 4) ? InpOndaH1StopMin : InpOndaH4StopMin));
   return MathMax(m, 0.05);
  }

//--- con il lotto minimo: rischio massimo accettato per un ritracciamento
double OndaMinLotCap() { return MathMin(MathMax(InpOndaMinLotRiskPct, 0.5), InpMaxRiskPerTrade); }

void OndaInit()
  {
   string keys[ON_N] = {"ondaK0", "ondaK1", "ondaK2", "ondaK3", "ondaK4"};
   for(int i = 0; i < ON_N; i++)
     {
      g_zz[i].ok = false;
      g_zz[i].n = 0;
      g_zz[i].t0 = 0;
      g_zz[i].p0 = 0.0;
      g_zz[i].t1 = 0;
      g_zz[i].p1 = 0.0;
      g_zz[i].t2 = 0;
      g_zz[i].p2 = 0.0;
      g_zz[i].type2 = 0;
      g_zz[i].c2 = 0;
      g_zz[i].time2 = 0;
      g_zz[i].conf2 = 0;
      g_zz[i].a2 = 0.0;
      g_zz[i].legDir = 0;
      g_zz[i].legExt = 0.0;
      g_zz[i].nbars = 0;
      g_ondaDone[i] = 0;
      g_ondaDoneWhy[i] = "";
      g_ondaText[i] = "";
      if(!g_isTester)
         g_ondaDone[i] = (datetime)GvGet(keys[i], 0.0);
      if(g_ondaDone[i] > 0)
         g_ondaDoneWhy[i] = "gia' giocato (prima del riavvio)";
     }
   g_ondaReady = false;
  }

//--- questo punto di svolta ha avuto la sua mossa: non si riprova (resta anche dopo un riavvio)
void OndaMarkDone(int sc, string why)
  {
   string keys[ON_N] = {"ondaK0", "ondaK1", "ondaK2", "ondaK3", "ondaK4"};
   if(sc < 0 || sc >= ON_N)
      return;
   g_ondaDone[sc] = g_zz[sc].time2;
   g_ondaDoneWhy[sc] = why;
   if(!g_isTester)
      GlobalVariableSet(GvName(keys[sc]), (double)g_ondaDone[sc]);
  }

//--- escursione media nota all'inizio di ogni giornata del buffer D1 (indice n = la giornata in corso)
void OndaDayAtr()
  {
   int n = g_d1.n;
   ArrayResize(g_ondaDayA, n + 1);
   for(int j = 0; j <= n; j++)
     {
      double sum = 0.0;
      int c = 0;
      for(int q = j - 1; q >= 0 && q >= j - 20; q--)
        {
         double r = g_d1.r[q].high - g_d1.r[q].low;
         if(r > 0.0)
           {
            sum += r;
            c++;
           }
        }
      g_ondaDayA[j] = (c >= 10) ? sum / c : 0.0;
     }
  }

//--- escursione media valida per una barra con ora 't' (server); 'j' e' un puntatore che avanza con le barre
double OndaAtrAt(datetime t, int &j)
  {
   int n = g_d1.n;
   while(j < n && g_d1.r[j].time + 86400 <= t)
      j++;
   if(j < n && g_d1.r[j].time > t)
      return 0.0;                              // barra piu' vecchia del buffer giornaliero
   if(j < 0 || j >= ArraySize(g_ondaDayA))
      return 0.0;
   return g_ondaDayA[j];
  }

//--- onde sul buffer di un timeframe: estremi su massimi/minimi, svolta confermata da una chiusura a k escursioni dall'estremo.
//    Ricalcolato da capo a ogni barra nuova: sui dati da' le stesse conferme della storia intera (regge i riavvii).
void ZzCompute(const TfData &d, double k, ZzState &z)
  {
   z.ok = false;
   z.n = 0;
   z.legDir = 0;
   z.legExt = 0.0;
   int n = d.n;
   z.nbars = n;
   if(n < 30 || ArraySize(g_ondaDayA) < g_d1.n + 1)
      return;
   int dj = 0;
   int dir = 1, ei = 0;
   double ep = d.r[0].high;
   int pi0 = -1, pi1 = -1, pi2 = -1, pt2 = 0, pc2 = -1, cnt = 0;
   double pp0 = 0.0, pp1 = 0.0, pp2 = 0.0, pa2 = 0.0;
   for(int j = 1; j < n; j++)
     {
      double A = OndaAtrAt(d.r[j].time, dj);
      double thr = k * A;
      if(thr <= 0.0)
         continue;
      bool turn = false;
      if(dir > 0)
        {
         if(d.r[j].high > ep)
           {
            ep = d.r[j].high;
            ei = j;
           }
         else
            if(ep - d.r[j].close >= thr)
               turn = true;
        }
      else
        {
         if(d.r[j].low < ep)
           {
            ep = d.r[j].low;
            ei = j;
           }
         else
            if(d.r[j].close - ep >= thr)
               turn = true;
        }
      if(!turn)
         continue;
      pi0 = pi1;
      pp0 = pp1;
      pi1 = pi2;
      pp1 = pp2;
      pi2 = ei;
      pp2 = ep;
      pt2 = dir;
      pc2 = j;
      pa2 = A;
      cnt++;
      dir = -dir;
      ep = (dir > 0) ? d.r[j].high : d.r[j].low;
      ei = j;
     }
   z.n = cnt;
   z.legDir = dir;
   z.legExt = ep;
   if(cnt < 3 || pi0 < 0 || pi2 < 0 || pc2 < 0)
      return;
   z.ok = true;
   z.t0 = pi0;
   z.p0 = pp0;
   z.t1 = pi1;
   z.p1 = pp1;
   z.t2 = pi2;
   z.p2 = pp2;
   z.type2 = pt2;
   z.c2 = pc2;
   z.time2 = d.r[pi2].time;
   z.conf2 = d.r[pc2].time;
   z.a2 = pa2;
  }

void OndaCompute(int sc)
  {
   if(sc == 0)
      ZzCompute(g_m5, OndaK(0), g_zz[0]);
   else
      if(sc == 1)
         ZzCompute(g_m15, OndaK(1), g_zz[1]);
      else
         if(sc == 2)
            ZzCompute(g_h1, OndaK(2), g_zz[2]);
         else
            ZzCompute(g_h4, OndaK(3), g_zz[3]);
  }

//--- a ogni M1: ricalcola solo le scale che hanno una barra nuova (tutte alla partenza e a ogni giornata nuova)
void OndaRefresh(bool n5, bool n15, bool nh1, bool nh4, bool nd1)
  {
   bool all = (!g_ondaReady || nd1);
   if(all)
      OndaDayAtr();
   if(all || n5)
      OndaCompute(0);
   if(all || n15)
      OndaCompute(1);
   if(all || nh1)
      OndaCompute(2);
   if(all || nh4)
      OndaCompute(3);
   g_ondaReady = true;
  }

//--- direzione chiara: H4 e H1 vanno nello stesso verso del trend giornaliero
bool OndaClear(int td) { return (td != 0 && EmaDir(g_h4) == td && EmaDir(g_h1) == td); }

//--- tempo massimo: 'bars' barre di mercato aperto a partire da adesso (weekend, pausa serale e feste non contano)
datetime OndaDeadline(datetime fromUtc, int bars, int barSec)
  {
   long left = (long)bars * barSec;
   datetime t = fromUtc;
   int guard = 0;
   while(left > 0 && guard < 20000)
     {
      guard++;
      t += 900;
      if(MarketShouldBeOpen(t))
         left -= 900;
     }
   return t;
  }

//--- 1.28: target in R per scala (M5 scalping corto con lotti alti, scale lente piu' lontano); mai sotto l'R:R minimo
double OndaTargetR(int sc, bool clear)
  {
   double rr = InpOndaTargetR;
   if(sc == 1)
      rr = InpOndaTargetRM15;
   if(sc == 2)
      rr = InpOndaTargetRH1;
   if(sc >= 3)
      rr = InpOndaTargetRH4;
   if(sc >= 1 && clear)
      rr *= Clamp(InpOndaTargetClearX, 0.5, 3.0);
   return Clamp(rr, InpMinRR, 10.0);
  }

//--- 1.29: target scelto dal bot trade per trade. Candidati nel verso del trade: l'estremo da cui e' partito il
//    ritracciamento (la liquidita' sopra il massimo o sotto il minimo precedente), la misura dell'onda (gamba
//    uguale alla precedente) e i livelli forti del giorno. Prende il primo livello utile, con il target messo appena
//    prima del livello. Di base (InpOndaTgtWay 2) parte dal target della scala e lo allunga fino al livello successivo,
//    al massimo InpOndaTgtMaxR; non lo accorcia mai: sul replay 2022-2026 accorciare prima di un livello costa 11R
//    (i ritracciamenti nel trend passano i livelli), allungare non toglie nulla. Nessun livello utile: target della scala.
string g_ondaTgtWhy = "";
double OndaTargetDyn(int sc, int pdir, double entry, double S, double fixedRR)
  {
   g_ondaTgtWhy = "fisso della scala";
   if(InpOndaTgtMode != 1 || S <= 0.0)
      return fixedRR;
   double minR = MathMax(InpMinRR, 1.0);
   double maxR = Clamp(InpOndaTgtMaxR, minR, 10.0);
   if(InpOndaTgtWay == 1)
      maxR = MathMax(minR, MathMin(maxR, fixedRR));
   if(InpOndaTgtWay == 2)
      minR = MathMin(maxR, MathMax(minR, fixedRR));
   double front = Clamp(InpOndaTgtFront, 0.0, 0.5) * S;
   double best = -1.0;
   string bw = "";
   //--- 1: estremo da cui e' partito il ritracciamento
   if((InpOndaTgtSrc & 1) != 0 && g_zz[sc].p1 > 0.0)
     {
      double r = ((g_zz[sc].p1 - entry) * pdir - front) / S;
      if(r >= minR && r <= maxR && (best < 0.0 || r < best))
        {
         best = r;
         bw = "estremo precedente " + DoubleToString(g_zz[sc].p1, g_digits);
        }
     }
   //--- 2: misura dell'onda (gamba nuova uguale a quella prima del ritracciamento)
   if((InpOndaTgtSrc & 2) != 0 && g_zz[sc].p0 > 0.0 && g_zz[sc].p1 > 0.0)
     {
      double leg = (g_zz[sc].p1 - g_zz[sc].p0) * pdir;
      if(leg > 0.0)
        {
         double lv = g_zz[sc].p2 + pdir * leg;
         double r = ((lv - entry) * pdir - front) / S;
         if(r >= minR && r <= maxR && (best < 0.0 || r < best))
           {
            best = r;
            bw = "misura dell'onda " + DoubleToString(lv, g_digits);
           }
        }
     }
   //--- 4: livelli forti del giorno (massimi e minimi di ieri e della settimana, sessioni, area di valore, tondi forti)
   if((InpOndaTgtSrc & 4) != 0)
      for(int i = 0; i < g_lvN; i++)
        {
         if(g_lv[i].weight < InpOndaTgtMinW)
            continue;
         double r = ((g_lv[i].price - entry) * pdir - front) / S;
         if(r >= minR && r <= maxR && (best < 0.0 || r < best))
           {
            best = r;
            bw = g_lvName[g_lv[i].type] + " " + DoubleToString(g_lv[i].price, g_digits);
           }
        }
   if(best > 0.0)
     {
      g_ondaTgtWhy = "prima di " + bw;
      return best;
     }
   if(InpOndaTgtNone == 1)
     {
      g_ondaTgtWhy = "nessun livello vicino: target massimo";
      return maxR;
     }
   g_ondaTgtWhy = "nessun livello vicino: fisso della scala";
   return fixedRR;
  }

//--- ONDA: ritracciamento finito nel verso del trend giornaliero, sulla scala 'sc'
bool S_Spinta(TSignal &s);
bool S_Onda(TSignal &s, int sc)
  {
   if(sc == 4)
      return S_Spinta(s);
   int strat = OndaStrat(sc);
   string tfn = OndaTfName(sc);
   double A = TdAtr();
   if(A <= 0.0 || !g_zz[sc].ok)
     {
      g_ondaText[sc] = "dati insufficienti";
      return false;
     }
   int td = EmaDir(g_d1);
   if(td == 0)
     {
      g_ondaText[sc] = "trend incerto";
      return false;
     }
   int pdir = (g_zz[sc].type2 < 0) ? 1 : -1;      // ultimo punto = minimo -> idea al rialzo
   string want = (td > 0) ? "minimo" : "massimo";
   string ptw = (pdir > 0) ? "minimo " : "massimo ";
   string pt = ptw + DoubleToString(g_zz[sc].p2, g_digits);
   if(pdir != td)
     {
      g_ondaText[sc] = "aspetta un " + want;
      return false;
     }
   if(g_ondaDone[sc] == g_zz[sc].time2)
     {
      g_ondaText[sc] = pt + " " + g_ondaDoneWhy[sc];
      return false;
     }
   datetime now = g_ctx.nowUtc;
   datetime confClose = ToUTC(g_zz[sc].conf2) + OndaBarSec(sc);
   bool fresh = (g_zz[sc].c2 == g_zz[sc].nbars - 1);
   if(!fresh || now > confClose + IMax(1, InpOndaMaxDelayMin) * 60 + 59)
     {
      g_ondaText[sc] = pt + " gia' passato";
      return false;
     }
   bool clear = OndaClear(td);
   if(sc == 0 && InpOndaM5NeedAll && !clear)
     {
      g_ondaText[sc] = pt + ": H4/H1 non d'accordo";
      return false;
     }
   double A2 = (g_zz[sc].a2 > 0.0) ? g_zz[sc].a2 : A;
   double entry = EntryPx(pdir);
   double sl0 = StopFrom(g_zz[sc].p2, pdir, MathMax(InpOndaBufAtr, 0.0) * A2);
   double S = (entry - sl0) * pdir;
   //--- ingresso in ritardo (news, spread) con il prezzo tornato a ridosso del punto di svolta: lo stop sarebbe cosi'
   //    vicino che spread e slittamento si mangiano l'idea. Alla conferma lo stop e' sempre piu' largo di cosi'.
   if(S <= 3.0 * g_tick || S < 0.5 * OndaStopMin(sc) * A2)
     {
      g_ondaText[sc] = pt + ": tornato sul punto";
      return false;
     }
   double cap = OndaStopMax(sc);
   if(cap > 0.0 && S > cap * A2)
      S = cap * A2;
   //--- conto piccolo: stop piu' stretto, fino al minimo della scala (stesso rischio in denaro, lotti piu' alti)
   double minD = MathMin(OndaStopMin(sc) * A2, S);
   double base = BaseCapital();
   if(base > 0.0 && g_minLot > 0.0)
     {
      double capPct = OndaMinLotCap();
      double wantPct = MathMin(InpRiskPercent * TmRiskMult(strat), InpMaxRiskPerTrade);
      for(int pass = 0; pass < 3; pass++)
        {
         double lpl = LossPerLot(pdir, entry, entry - pdir * S);
         if(InpCostTrack)
            lpl += SlipEstPx(g_ctx.spread) * ValuePerPriceUnit();
         double pctMin = 100.0 * lpl * g_minLot / base;
         if(pctMin <= wantPct || pctMin <= capPct || S <= minD)
            break;
         S = MathMax(minD, S * capPct / pctMin * 0.98);
        }
     }
   double sl = entry - pdir * S;
   double rr = OndaTargetDyn(sc, pdir, entry, S, OndaTargetR(sc, clear));
   double tp = entry + pdir * (rr * S + 3.0 * g_tick);
   int wave = IMax(1, g_zz[sc].t2 - g_zz[sc].t0);
   int limBars = (int)MathRound(Clamp(InpOndaHoldMult, 0.5, 10.0) * wave) + 5;
   datetime dl = OndaDeadline(now, limBars, OndaBarSec(sc));
   string dn = (td > 0) ? "al rialzo" : "al ribasso";
   string clw = clear ? ", direzione chiara (H4 e H1 d'accordo)" : "";
   string why = "ritracciamento finito su " + tfn + " nel trend giornaliero " + dn + ": " + pt + " confermato" + clw + ", stop " + DoubleToString(S / A2, 2) + " escursioni (" +
                DoubleToString(S, 1) + " $), target " + DoubleToString(rr, 1) + "R (" + g_ondaTgtWhy + "), tempo massimo " + IntegerToString((int)((dl - now) / 3600)) + " ore";
   if(!MakeSignalTP(s, strat, pdir, entry, sl, tp, 0.70, why))
      return false;
   s.proven = InpOndaProven;
   s.deadline = dl;
   if(sc == 2 && clear)
      s.riskX = Clamp(InpOndaClearMult, 0.5, 2.0);
   g_ondaText[sc] = pt + " confermato: ingresso";
   return true;
  }

//--- riga del pannello: una voce per scala accesa
string OndaPanel()
  {
   int td = EmaDir(g_d1);
   string tdw = (td > 0) ? "rialzo" : ((td < 0) ? "ribasso" : "incerto");
   string clw = OndaClear(td) ? ", direzione chiara" : "";
   string t = "Ritracciamenti (D1 " + tdw + clw + "):";
   int shown = 0;
   for(int sc = 0; sc < ON_N; sc++)
     {
      int st = OndaStrat(sc);
      if(!StratEnabled(st))
         continue;
      string ob = StratObserved(st) ? " (carta)" : "";
      t += " " + OndaTfName(sc) + ob + " " + StringSubstr(g_ondaText[sc], 0, 40) + ";";
      shown++;
     }
   return (shown > 0) ? t + "\n" : "";
  }

//+------------------------------------------------------------------+
//| SPINTA NEL TREND - "nuova gamba" (1.36)                          |
//|                                                                  |
//| Studio del 27 nov 2026 (studio-inizio-trend): l'inizio di un     |
//| trend non si anticipa (il 51% dei movimenti grandi parte contro  |
//| il trend D1 e ogni regola d'inversione rende come il verso a     |
//| caso), ma quando il prezzo corre nel verso del trend giornaliero |
//| di solito parte una gamba nuova. Se nelle ultime 72 ore H1 il    |
//| prezzo si e' mosso di 1,5 escursioni medie nel verso del trend   |
//| D1 (EMA20/50), entra subito: stop 1 escursione, target 3R.       |
//| H1 2022-26: 76 trade, +0,59R, 4 periodi su 4, long e short       |
//| positivi; verso a caso +0,12R. Oro giornaliero 1975-2026: +0,4/  |
//| +0,8R in tutti i blocchi. Usa la macchina ONDA (scala 4): tempo  |
//| massimo, venerdi' come H1/H4, nessun tetto giornaliero.          |
//+------------------------------------------------------------------+
datetime g_spSigBar = 0;          // barra H1 (server) dell'ultimo segnale

bool SpOpen()
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0 || !PositionSelectByTicket(tk))
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym || !IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      int mi = MetaFind(PositionGetInteger(POSITION_IDENTIFIER));
      if(mi >= 0 && g_meta[mi].strat == ST_SPINTA)
         return true;
     }
   return false;
  }

bool S_Spinta(TSignal &s)
  {
   const int sc = 4;
   double A = TdAtr();
   int nh = IMax(6, InpSpHours);
   if(A <= 0.0 || g_h1.n < nh + 3)
     {
      g_ondaText[sc] = "dati insufficienti";
      return false;
     }
   int td = EmaDir(g_d1);
   double c0 = BarC(g_h1, 0), c1 = BarC(g_h1, 1);
   double mv0 = (c0 - BarC(g_h1, nh)) / A;
   double mv1 = (c1 - BarC(g_h1, nh + 1)) / A;
   double th = MathMax(InpSpMove, 0.1);
   datetime bt = BarT(g_h1, 0);
   string mvw = "spinta " + DoubleToString(mv0, 2) + " escursioni in " + IntegerToString(nh) + " ore";
   //--- il ricordo dell'ultimo segnale vive in g_ondaDone[4] (resta anche dopo un riavvio)
   if(g_ondaDone[sc] > 0 && bt - g_ondaDone[sc] < (long)IMax(0, InpSpCoolHours) * 3600)
     {
      g_ondaText[sc] = mvw + ", pausa dopo il segnale delle " + TimeToString(g_ondaDone[sc], TIME_DATE | TIME_MINUTES);
      return false;
     }
   int pdir = 0;
   if(mv0 >= th && mv1 < th)
      pdir = 1;
   if(mv0 <= -th && mv1 > -th)
      pdir = -1;
   if(pdir == 0)
     {
      g_ondaText[sc] = mvw + " (serve " + DoubleToString(th, 1) + " nel verso del D1)";
      return false;
     }
   if(td == 0 || pdir != td)
     {
      g_ondaText[sc] = mvw + ": contro il trend D1, niente";
      return false;
     }
   datetime now = g_ctx.nowUtc;
   datetime barClose = ToUTC(bt) + 3600;
   if(now > barClose + IMax(1, InpOndaMaxDelayMin) * 60 + 59)
     {
      g_ondaText[sc] = mvw + ": gia' passato";
      return false;
     }
   //--- la scala 4 usa g_zz[4] solo per segnare il segnale gia' giocato (OndaMarkDone)
   g_zz[sc].time2 = bt;
   if(InpSpOnePos && SpOpen())
     {
      OndaMarkDone(sc, "gia' una SPINTA aperta");
      g_ondaText[sc] = mvw + ": gia' una SPINTA aperta";
      return false;
     }
   int strat = ST_SPINTA;
   double entry = EntryPx(pdir);
   double S = MathMax(InpSpStopAtr, 0.1) * A;
   double minD = MathMin(OndaStopMin(sc) * A, S);
   double base = BaseCapital();
   if(base > 0.0 && g_minLot > 0.0)
     {
      double capPct = OndaMinLotCap();
      double wantPct = MathMin(InpRiskPercent * TmRiskMult(strat), InpMaxRiskPerTrade);
      for(int pass = 0; pass < 3; pass++)
        {
         double lpl = LossPerLot(pdir, entry, entry - pdir * S);
         if(InpCostTrack)
            lpl += SlipEstPx(g_ctx.spread) * ValuePerPriceUnit();
         double pctMin = 100.0 * lpl * g_minLot / base;
         if(pctMin <= wantPct || pctMin <= capPct || S <= minD)
            break;
         S = MathMax(minD, S * capPct / pctMin * 0.98);
        }
     }
   double sl = entry - pdir * S;
   double rr = Clamp(InpSpTargetR, InpMinRR, 10.0);
   double tp = entry + pdir * (rr * S + 3.0 * g_tick);
   datetime dl = OndaDeadline(now, IMax(1, InpSpHoldHours), 3600);
   string dn = (td > 0) ? "al rialzo" : "al ribasso";
   string why = "spinta nel trend giornaliero " + dn + ": " + mvw + " (nuova gamba), stop " + DoubleToString(S / A, 2) + " escursioni (" +
                DoubleToString(S, 1) + " $), target " + DoubleToString(rr, 1) + "R, tempo massimo " + IntegerToString((int)((dl - now) / 3600)) + " ore";
   if(!MakeSignalTP(s, strat, pdir, entry, sl, tp, 0.70, why))
      return false;
   s.proven = InpOndaProven;
   s.deadline = dl;
   g_ondaText[sc] = mvw + ": ingresso";
   return true;
  }
