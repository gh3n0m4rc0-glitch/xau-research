//+------------------------------------------------------------------+
//|                                              XauCommitteeEA.mq5  |
//|        Comitato per l'oro (XAUUSD): scalping + intraday + swing  |
//|                                                                  |
//|  Tre motori con segnali diversi che parlano la stessa lingua:    |
//|  ogni idea diventa un TSignal, passa dallo stesso comitato di    |
//|  desk (trend, volumi, liquidita, macro, news, sessione, costi,   |
//|  statistica), dallo stesso avvocato del diavolo e dallo stesso   |
//|  risk manager con lotti dinamici in base al conto.               |
//+------------------------------------------------------------------+
#property copyright   "Progetto XAU Committee"
#property version     "1.22"
#property description "EA per l'oro con 3 motori (scalping, intraday, swing) e un comitato comune."
#property description "Lotti dinamici in base al conto, R:R minimo 1:2, pareggio a +1.5R, stop -7% giorno / -10% settimana / 50% drawdown."

#include <Trade\Trade.mqh>

//--- scelta della strategia da testare (per l'ottimizzazione una alla volta)
enum ENUM_STRAT_PICK
  {
   PICK_ALL = 0,          // Tutte le strategie
   PICK_SC_VWAP = 1,      // Solo SC-VWAP (scalping pullback su VWAP)
   PICK_SC_SWEEP = 2,     // Solo SC-SWEEP (scalping stop run)
   PICK_SC_ORB = 3,       // Solo SC-ORB (scalping range di apertura)
   PICK_IN_PULLBACK = 4,  // Solo IN-PULLBACK (intraday trend pullback)
   PICK_IN_SWEEP = 5,     // Solo IN-SWEEP (intraday stop run sui livelli)
   PICK_IN_BREAKOUT = 6,  // Solo IN-BREAKOUT (intraday breakout + retest)
   PICK_IN_VALUE = 7,     // Solo IN-VALUE80 (regola 80% value area)
   PICK_IN_NEWS = 8,      // Solo IN-NEWS (continuation dopo news)
   PICK_IN_RANGE = 9,     // Solo IN-RANGE (ritorno alla VWAP in laterale)
   PICK_SW_TREND = 10,    // Solo SW-TREND (swing trend pullback H4)
   PICK_SW_WYCKOFF = 11   // Solo SW-WYCKOFF (spring/upthrust H4)
  };

//+------------------------------------------------------------------+
//| Input                                                            |
//+------------------------------------------------------------------+
input group "=== Generale ==="
input string InpSymbolOverride   = "";       // Simbolo oro (vuoto = simbolo del grafico)
input long   InpMagicBase        = 260800;   // Magic base (scalping +1, intraday +2, swing +3)
input bool   InpEnableScalping   = true;     // Motore SCALPING attivo
input bool   InpEnableIntraday   = true;     // Motore INTRADAY attivo
input bool   InpEnableSwing      = true;     // Motore SWING attivo
input ENUM_STRAT_PICK InpOnlyStrategy = PICK_ALL; // Test: usa solo questa strategia
input bool   InpPushNotify       = true;     // Notifiche push sul telefono (app MT5)
input bool   InpVerboseLog       = false;    // Log dettagliato (anche i segnali respinti)

input group "=== Rischio e lotti ==="
input double InpVirtualCapital   = 0.0;      // Capitale virtuale di partenza (0 = conto vero; poi cresce/cala con i risultati)
input double InpRiskPercent      = 1.0;      // Rischio base per trade (% del conto)
input double InpScalpRiskMult    = 0.75;     // Moltiplicatore rischio scalping
input double InpSwingRiskMult    = 1.0;      // Moltiplicatore rischio swing
input double InpMaxRiskPerTrade  = 3.0;      // Rischio massimo per trade (%), recupero incluso
input double InpMinLotMaxRiskPct = 2.5;      // Se serve il lotto minimo: rischio massimo accettato (%)
input double InpMaxOpenRiskPct   = 4.0;      // Rischio aperto totale massimo (%) (posizioni a pareggio = 0)
input int    InpMaxPositions     = 4;        // Posizioni massime contemporanee (tutti i motori)
input double InpMinMarginLevel   = 120.0;    // Livello di margine minimo dopo l'apertura (%)
input double InpMaxLots          = 5.0;      // Lotti massimi per singolo ordine
input double InpDailyLossPct     = 7.0;      // Stop giornaliero (% dall'equity di inizio giorno)
input double InpWeeklyLossPct    = 10.0;     // Stop settimanale (% dall'equity di inizio settimana)
input double InpMaxDrawdownPct   = 50.0;     // Drawdown massimo dal picco: chiude tutto e si ferma (%)
input bool   InpResetHalt        = false;    // Sblocca l'EA dopo lo stop per drawdown massimo
input int    InpMaxLossesInRowDay = 3;       // Perdite di fila nello stesso giorno prima di fermarsi
input double InpCommissionPerLot = 7.0;      // Commissione andata+ritorno per 1 lotto (valuta del conto)

input group "=== Crescita del conto e recupero ==="
input bool   InpUseProfitCushion = true;     // Idee forti: rischio extra pagato con i profitti della settimana
input double InpCushionUse       = 0.5;      // Quota del profitto settimanale usabile come rischio extra
input double InpCushionMaxMult   = 1.0;      // Rischio extra massimo (x rischio base)
input bool   InpRecoveryEnabled  = true;     // Trade di recupero dopo una perdita (una volta sola)
input double InpRecoveryMult     = 1.75;     // Moltiplicatore lotti del trade di recupero
input double InpRecoveryMinScore = 0.75;     // Punteggio minimo del comitato per il recupero
input bool   InpAllowTranches    = true;     // Idee forti: fino a 3 ingressi scaglionati (40/30/30)
input bool   InpUseBench         = true;     // Mette in panchina le strategie con aspettativa negativa

input group "=== Regole fisse dei trade ==="
input double InpMinRR            = 2.0;      // Rischio/rendimento minimo (1:2)
input double InpBE_R             = 1.5;      // Stop a pareggio quando il trade arriva a +R (1.5-1.75)
input double InpPartialPct       = 40.0;     // Chiusura parziale al pareggio (% volume, se il lotto lo permette)
input double InpTrailStartR      = 2.0;      // Trailing stop da +R
input double InpMaxCostR         = 0.15;     // Costi massimi (spread+commissione) come frazione di R

input group "=== Comitato ==="
input double InpMinScoreScalp    = 0.62;     // Punteggio minimo comitato scalping
input double InpMinScoreIntra    = 0.62;     // Punteggio minimo comitato intraday
input double InpMinScoreSwing    = 0.65;     // Punteggio minimo comitato swing
input double InpStrongScore      = 0.78;     // Soglia "idea forte"
input int    InpQuorum           = 6;        // Desk principali favorevoli richiesti (su 8)
input int    InpDevilMax         = 3;        // Obiezioni dell'avvocato del diavolo che bloccano

input group "=== Scalping (M1-M5) ==="
input int    InpScalpMaxTradesDay = 6;       // Trade scalping massimi al giorno
input int    InpScalpMaxMinutes  = 60;       // Chiude lo scalp dopo N minuti se non e' a pareggio
input double InpScalpRR          = 2.2;      // Target scalping (R)
input bool   InpSC_VWAP          = true;     // SC-VWAP: pullback su VWAP in trend
input bool   InpSC_SWEEP         = true;     // SC-SWEEP: stop run sui livelli e rientro
input bool   InpSC_ORB           = true;     // SC-ORB: breakout range di apertura + retest

input group "=== Intraday (M5-M15) ==="
input int    InpIntraMaxTradesDay = 4;       // Trade intraday massimi al giorno
input int    InpIntraMaxHours    = 8;        // Chiude l'intraday dopo N ore se non e' a pareggio
input double InpIntraRR          = 2.5;      // Target intraday (R)
input bool   InpIN_PULLBACK      = true;     // IN-PULLBACK: trend H1 + pullback M15
input bool   InpIN_SWEEP         = true;     // IN-SWEEP: stop run su PDH/PDL/Asia/Londra
input bool   InpIN_BREAKOUT      = true;     // IN-BREAKOUT: breakout con volume + retest
input bool   InpIN_VALUE         = true;     // IN-VALUE80: rientro nella value area di ieri
input bool   InpIN_NEWS          = true;     // IN-NEWS: continuation dopo news coerente con la vista
input bool   InpIN_RANGE         = true;     // IN-RANGE: da VWAP +-2 sigma alla VWAP in laterale

input group "=== Swing (H1-H4) ==="
input int    InpSwingMaxTradesDay = 2;       // Trade swing massimi al giorno
input int    InpSwingMaxBarsH4   = 30;       // Chiude lo swing dopo N barre H4 se non e' a pareggio
input double InpSwingRR          = 3.0;      // Target swing (R)
input bool   InpSwingHoldWeekend = false;    // Tiene lo swing nel weekend anche se non e' a pareggio
input bool   InpSW_TREND         = true;     // SW-TREND: trend H4 + pullback H1
input bool   InpSW_WYCKOFF       = true;     // SW-WYCKOFF: spring/upthrust nel range H4

input group "=== Orari e news ==="
input int    InpGmtOffsetLive    = -99;      // Fuso del server live (ore, -99 = automatico)
input int    InpGmtOffsetTester  = -99;      // Fuso del server nel tester (-99 = GMT+2 inverno / +3 estate)
input int    InpIntraCloseUTC    = 20;       // Ora UTC di chiusura di scalping e intraday
input int    InpNewsBlockBefore  = 30;       // Minuti senza ingressi prima di una news tier1 (scalp/intraday)
input int    InpNewsBlockAfter   = 15;       // Minuti senza ingressi dopo una news tier1 (scalp/intraday)
input int    InpNewsBlockSwingBefore = 90;   // Minuti senza ingressi swing prima di una news tier1
input int    InpNewsBlockSwingAfter  = 60;   // Minuti senza ingressi swing dopo una news tier1
input int    InpNewsBlockFomcAfter   = 90;   // Minuti senza ingressi (anche IN-NEWS) dopo la decisione FOMC, conferenza inclusa (0 = come le altre tier1)
input bool   InpCloseBeforeNews  = true;     // Chiude scalp (e intraday non a pareggio) 5 min prima di news tier1

input group "=== Motori del prezzo (studio 9 nov 2026) ==="
input bool   InpP1RunBrake       = true;     // P1: freno dopo le corse verticali (rischio ridotto, niente long in rottura)
input double InpP1RunSigma       = 2.5;      // P1: corsa degli ultimi 20 giorni oltre questi sigma
input double InpP1Ma200DistPct   = 20.0;     // P1: oppure prezzo oltre questa % sopra la media a 200 giorni
input double InpP1RiskMult       = 0.5;      // P1: moltiplicatore del rischio con il freno acceso
input bool   InpP2ThinLiquidity  = true;     // P2: niente ingressi con liquidita' sottile (feste USA, Asia nelle feste giapponesi, riaperture)
input int    InpP2ReopenMin      = 60;       // P2: minuti senza ingressi dopo una riapertura (pausa oltre 3 ore)
input bool   InpP3NoRiskOffBonus = false;    // P3: azzera il bonus "fuga dal rischio" del desk intermarket
input bool   InpP4FirstDayLong   = true;     // P4: spinta ai long il primo giorno di borsa del mese (acceso dalla 1.20: studio candele)
input double InpP4Bonus          = 0.02;     // P4: punti aggiunti al punteggio dei long
input bool   InpP5AsiaStopBuffer = false;    // P5: nelle ore asiatiche stop oltre i livelli ovvi (PDH/PDL, settimana, Asia, numeri tondi)
input double InpP5BufferAtrH1    = 0.25;     // P5: margine oltre il livello (x ATR H1)
input bool   InpP6ExpiryTargets  = false;    // P6: target dei breakout piu' corti alla scadenza opzioni COMEX e il giorno dopo
input double InpP6TargetMult     = 0.85;     // P6: moltiplicatore del target in R (mai sotto il minimo 1:2)

input group "=== Studio candele (9 nov 2026) ==="
input bool   InpC1BigDayRisk     = true;     // C1: rischio ridotto (scalping e intraday) il giorno dopo una candela D1 molto larga
input double InpC1BigDayAtr      = 2.0;      // C1: candela D1 di ieri oltre questi ATR (ATR 20 giorni prima di ieri)
input double InpC1RiskMult       = 0.75;     // C1: moltiplicatore del rischio
input bool   InpC3TightAsia      = false;    // C3: spinta a SC-SWEEP e IN-SWEEP quando il range di Asia e' stretto
input double InpC3AsiaAtr        = 0.40;     // C3: Asia stretta = range di Asia sotto questa frazione dell'ATR D1
input double InpC3Bonus          = 0.02;     // C3: punti aggiunti al punteggio

input group "=== Studio analisi tecnica (9 nov 2026) ==="
input bool   InpT2NoDiscountBonus = true;    // T2: niente bonus "zona di sconto 38-79%" e niente malus "inseguire l'estensione" nel desk Contesto (non battono il caso)
input bool   InpT3NoRangeEdgeObj  = true;    // T3: niente obiezione del diavolo "prezzo agli estremi del range D1" (comprare in alto non e' peggio)
input bool   InpT4RoundNotMajor   = true;    // T4: i numeri tondi forti non contano come livelli forti (solo target e ostacoli normali)

input group "=== Coda, pareggio e rientro ==="
input bool   InpQueueOn          = true;     // Coda: con altre posizioni aperte, una nuova idea deve essere piu' sicura
input double InpQueueExtraScore  = 0.04;     // Coda: punti in piu' sul punteggio minimo (e quorum +1)
input double InpBeLockR          = 0.10;     // Pareggio: stop all'entrata + costi + questa quota di R (cuscinetto)
input bool   InpReentryOn        = true;     // Rientro: se un trade torna a pareggio, nuovo ingresso nella stessa direzione se le conferme restano
input double InpReentryMult      = 1.25;     // Rientro: moltiplicatore del rischio (una volta sola per idea)
input group "=== Idee A+ (tutte le conferme) ==="
input bool   InpAplusOn          = true;     // A+: con tutte le conferme rischio piu' alto e gestione attiva a terzi
input double InpAplusRiskPct     = 3.0;      // A+: rischio per trade (% del conto, mai oltre il rischio massimo per trade)
input double InpAplusMaxLots     = 0.03;     // A+: lotti massimi per idea (0 = solo il limite di rischio)
input double InpAplusMinScore    = 0.70;     // A+: punteggio minimo (e almeno il minimo del motore + 0.05)
input double InpAplusPartialR    = 1.0;      // A+: a questo +R chiude un terzo, il secondo al pareggio, il resto segue il trailing

input group "=== Dati esterni (solo conto live/demo) ==="
input bool   InpUseWebData       = true;     // Legge macro, comitato AI e livelli GC da GitHub
input string InpMacroUrl         = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/macro_bias.json"; // URL macro_bias.json
input string InpCommitteeUrl     = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/ai_committee.json"; // URL ai_committee.json
input string InpVolumeUrl        = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/volume_levels.json"; // URL volume_levels.json
input string InpNewsUrl          = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/news_calendar.json"; // URL news_calendar.json (riserva)
input string InpMacroHistUrl     = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/macro_history.csv"; // URL storico macro (salvato anche per il tester)
input double InpMacroVetoLevel   = 0.45;     // Macro contraria oltre questo livello: veto per intraday e swing
input double InpContextVetoLevel = 0.60;     // Contesto HTF contrario oltre questo livello: veto per intraday e swing
input int    InpWebRefreshMin    = 15;       // Ogni quanti minuti rilegge i dati esterni
input bool   InpUseDOM           = true;     // Usa il book (DOM) se il broker lo fornisce

//+------------------------------------------------------------------+
//| Costanti                                                         |
//+------------------------------------------------------------------+
#define EA_VERSION     "1.22"
#define ENG_SCALP      0
#define ENG_INTRA      1
#define ENG_SWING      2

#define NSTRAT         12
#define ST_SC_VWAP     1
#define ST_SC_SWEEP    2
#define ST_SC_ORB      3
#define ST_IN_PULLBACK 4
#define ST_IN_SWEEP    5
#define ST_IN_BREAKOUT 6
#define ST_IN_VALUE    7
#define ST_IN_NEWS     8
#define ST_IN_RANGE    9
#define ST_SW_TREND    10
#define ST_SW_WYCKOFF  11

#define STYPE_TREND    0
#define STYPE_REVERSAL 1
#define STYPE_BREAKOUT 2
#define STYPE_MEANREV  3
#define STYPE_NEWS     4

#define REG_UP         0
#define REG_DOWN       1
#define REG_RANGE      2
#define REG_VOLATILE   3
#define REG_QUIET      4

#define NDESK          10
#define D_STRAT        0
#define D_TREND        1
#define D_VOLUME       2
#define D_LIQ          3
#define D_MACRO        4
#define D_NEWS         5
#define D_SESSION      6
#define D_COST         7
#define D_STATS        8
#define D_CONTEXT      9

#define MAX_META       64
#define MAX_NEWS       64
#define MAX_LEVELS     64
#define MICRO_N        1440

string g_stratName[NSTRAT]  = {"-", "SC-VWAP", "SC-SWEEP", "SC-ORB", "IN-PULLBACK", "IN-SWEEP", "IN-BREAKOUT", "IN-VALUE80", "IN-NEWS", "IN-RANGE", "SW-TREND", "SW-WYCKOFF"};
int    g_stratEngine[NSTRAT] = {-1, ENG_SCALP, ENG_SCALP, ENG_SCALP, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_SWING, ENG_SWING};
int    g_stratType[NSTRAT]   = {STYPE_TREND, STYPE_TREND, STYPE_REVERSAL, STYPE_BREAKOUT, STYPE_TREND, STYPE_REVERSAL, STYPE_BREAKOUT, STYPE_MEANREV, STYPE_NEWS, STYPE_MEANREV, STYPE_TREND, STYPE_REVERSAL};
string g_engName[3]          = {"Scalping", "Intraday", "Swing"};
string g_deskName[NDESK]     = {"Strategia", "Trend", "Volumi", "Liquidita", "Macro", "News", "Sessione", "Costi", "Statistica", "Contesto HTF"};
string g_deskShort[NDESK]    = {"Str", "Trd", "Vol", "Liq", "Mac", "New", "Ses", "Cst", "Sta", "Ctx"};
string g_regName[5]          = {"trend rialzista", "trend ribassista", "laterale", "volatile", "calmo"};

//+------------------------------------------------------------------+
//| Globali di base                                                  |
//+------------------------------------------------------------------+
CTrade   g_trade;
string   g_sym = "";
string   g_version = EA_VERSION;
double   g_point = 0.0;
double   g_tick = 0.0;
double   g_minLot = 0.0;
double   g_maxLot = 0.0;
double   g_lotStep = 0.0;
double   g_contract = 0.0;
int      g_digits = 2;
int      g_lotDigits = 2;
bool     g_isTester = false;
bool     g_isOptim = false;
bool     g_isVisual = false;
bool     g_netting = false;
bool     g_ready = false;
long     g_login = 0;
int      g_gmtOffset = 2;
datetime g_gmtCheckedAt = 0;
string   g_currency = "";
string   g_lastDecision[6];
int      g_lastDecisionHead = 0;

//+------------------------------------------------------------------+
//| Utilita'                                                         |
//+------------------------------------------------------------------+
double Clamp(double v, double lo, double hi)
  {
   if(v < lo)
      return lo;
   if(v > hi)
      return hi;
   return v;
  }

int IMax(int a, int b) { return (a > b) ? a : b; }
int IMin(int a, int b) { return (a < b) ? a : b; }

double PxBid() { return SymbolInfoDouble(g_sym, SYMBOL_BID); }
double PxAsk() { return SymbolInfoDouble(g_sym, SYMBOL_ASK); }

double NormPrice(double p)
  {
   if(g_tick <= 0.0)
      return NormalizeDouble(p, g_digits);
   return NormalizeDouble(MathRound(p / g_tick) * g_tick, g_digits);
  }

double FloorLot(double lots)
  {
   if(g_lotStep <= 0.0)
      return 0.0;
   double steps = MathFloor(lots / g_lotStep + 0.0000001);
   return NormalizeDouble(steps * g_lotStep, g_lotDigits);
  }

string DirName(int dir) { return (dir > 0) ? "BUY" : "SELL"; }

string Pct(double v) { return DoubleToString(v, 1) + "%"; }

string Money(double v) { return DoubleToString(v, 2) + " " + g_currency; }

//--- valore di 1.0 di prezzo per 1 lotto, in valuta del conto
double ValuePerPriceUnit()
  {
   double tv = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_VALUE);
   double ts = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_SIZE);
   if(tv <= 0.0 || ts <= 0.0)
      return g_contract;
   return tv / ts;
  }

//--- commissione andata+ritorno espressa in prezzo
double CommissionPx()
  {
   if(InpCommissionPerLot <= 0.0)
      return 0.0;
   double v = ValuePerPriceUnit();
   if(v <= 0.0)
      return 0.0;
   return InpCommissionPerLot / v;
  }

void Logf(string msg)
  {
   if(g_isOptim)
      return;
   Print(msg);
  }

void Notify(string msg)
  {
   Logf(msg);
   if(InpPushNotify && !g_isTester)
     {
      string m = msg;
      if(StringLen(m) > 250)
         m = StringSubstr(m, 0, 250);
      SendNotification(m);
     }
  }

void RememberDecision(string line)
  {
   g_lastDecision[g_lastDecisionHead] = line;
   g_lastDecisionHead = (g_lastDecisionHead + 1) % 6;
  }

//+------------------------------------------------------------------+
//| Tempo: fusi orari, ora legale, sessioni                          |
//+------------------------------------------------------------------+
int YearOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.year;
  }

//--- data (00:00 UTC) della n-esima domenica del mese (n=-1 ultima)
datetime NthSunday(int year, int mon, int n)
  {
   MqlDateTime d;
   d.year = year;
   d.mon = mon;
   d.day = 1;
   d.hour = 0;
   d.min = 0;
   d.sec = 0;
   d.day_of_week = 0;
   d.day_of_year = 0;
   datetime first = StructToTime(d);
   MqlDateTime f;
   TimeToStruct(first, f);
   int toSun = (7 - f.day_of_week) % 7;
   datetime firstSun = first + toSun * 86400;
   if(n > 0)
      return firstSun + (n - 1) * 7 * 86400;
   //--- ultima domenica
   datetime s = firstSun;
   while(true)
     {
      datetime nx = s + 7 * 86400;
      MqlDateTime x;
      TimeToStruct(nx, x);
      if(x.mon != mon)
         break;
      s = nx;
     }
   return s;
  }

//--- ora legale USA: seconda domenica di marzo -> prima domenica di novembre (circa 07:00/06:00 UTC)
bool IsUSDST(datetime utc)
  {
   int y = YearOf(utc);
   datetime a = NthSunday(y, 3, 2) + 7 * 3600;
   datetime b = NthSunday(y, 11, 1) + 6 * 3600;
   return (utc >= a && utc < b);
  }

//--- ora legale UK: ultima domenica di marzo -> ultima domenica di ottobre (01:00 UTC)
bool IsUKDST(datetime utc)
  {
   int y = YearOf(utc);
   datetime a = NthSunday(y, 3, -1) + 3600;
   datetime b = NthSunday(y, 10, -1) + 3600;
   return (utc >= a && utc < b);
  }

void UpdateGmtOffset()
  {
   if(g_isTester)
     {
      if(InpGmtOffsetTester != -99)
         g_gmtOffset = InpGmtOffsetTester;
      else
         g_gmtOffset = IsUSDST(TimeCurrent() - 2 * 3600) ? 3 : 2;
     }
   else
     {
      if(InpGmtOffsetLive != -99)
         g_gmtOffset = InpGmtOffsetLive;
      else
        {
         long diff = (long)(TimeTradeServer() - TimeGMT());
         g_gmtOffset = (int)MathRound((double)diff / 3600.0);
        }
     }
   g_gmtCheckedAt = TimeCurrent();
  }

datetime ToUTC(datetime server) { return server - g_gmtOffset * 3600; }
datetime ToServer(datetime utc) { return utc + g_gmtOffset * 3600; }

double HourOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.hour + d.min / 60.0 + d.sec / 3600.0;
  }

int DowOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.day_of_week;
  }

int DayKey(datetime t) { return (int)(t / 86400); }

double LondonOpenUTC(datetime utc) { return IsUKDST(utc) ? 7.0 : 8.0; }
double NYDataUTC(datetime utc)     { return IsUSDST(utc) ? 12.5 : 13.5; }
double NYOpenUTC(datetime utc)     { return IsUSDST(utc) ? 13.5 : 14.5; }
double NYCloseUTC(datetime utc)    { return IsUSDST(utc) ? 21.0 : 22.0; }

//--- yyyymmdd di una data UTC
int Ymd(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.year * 10000 + d.mon * 100 + d.day;
  }
