//+------------------------------------------------------------------+
//|                                              XauCommitteeEA.mq5  |
//|        Comitato per l'oro (XAUUSD): scalping + intraday + swing  |
//|                                                                  |
//|  Tre motori con segnali diversi che parlano la stessa lingua:    |
//|  ogni idea diventa un TSignal, passa dallo stesso comitato di    |
//|  desk (trend, volumi, liquidita, macro, news, sessione, costi,   |
//|  statistica), dallo stesso avvocato del diavolo e dallo stesso   |
//|  risk manager con lotti dinamici in base al conto.               |
//+------------------------------------------------------------------+
#property copyright   "Progetto XAU Committee"
#property version     "1.29"
#property description "EA per l'oro con 3 motori (scalping, intraday, swing) e un comitato comune."
#property description "Lotti dinamici in base al conto, R:R minimo 1:2, pareggio a +1.5R, stop -7% giorno / -10% settimana / 50% drawdown."

#include <Trade\Trade.mqh>

//--- scelta della strategia da testare (per l'ottimizzazione una alla volta)
enum ENUM_STRAT_PICK
  {
   PICK_ALL = 0,          // Tutte le strategie
   PICK_SC_VWAP = 1,      // Solo SC-VWAP (scalping pullback su VWAP)
   PICK_SC_SWEEP = 2,     // Solo SC-SWEEP (scalping stop run)
   PICK_SC_ORB = 3,       // Solo SC-ORB (scalping range di apertura)
   PICK_IN_PULLBACK = 4,  // Solo IN-PULLBACK (intraday trend pullback)
   PICK_IN_SWEEP = 5,     // Solo IN-SWEEP (intraday stop run sui livelli)
   PICK_IN_BREAKOUT = 6,  // Solo IN-BREAKOUT (intraday breakout + retest)
   PICK_IN_VALUE = 7,     // Solo IN-VALUE80 (regola 80% value area)
   PICK_IN_NEWS = 8,      // Solo IN-NEWS (continuation dopo news)
   PICK_IN_RANGE = 9,     // Solo IN-RANGE (ritorno alla VWAP in laterale)
   PICK_SW_TREND = 10,    // Solo SW-TREND (swing trend pullback H4)
   PICK_SW_WYCKOFF = 11,  // Solo SW-WYCKOFF (spring/upthrust H4)
   PICK_IN_TREND = 12,    // Solo IN-TREND (giornata di tendenza di New York)
   PICK_IN_DATA = 13,     // Solo IN-DATO (dopo un CPI che sorprende)
   PICK_IN_NIGHT = 14,    // Solo IN-NOTTE (movimento forte di notte e a Londra)
   PICK_IN_TREND2 = 15,   // Solo IN-TREND2 (secondo ingresso della giornata di tendenza)
   PICK_ON_M15 = 16,      // Solo ONDA-M15 (ritracciamento nel trend su M15)
   PICK_ON_H1 = 17,       // Solo ONDA-H1 (ritracciamento nel trend su H1)
   PICK_ON_H4 = 18,       // Solo ONDA-H4 (ritracciamento nel trend su H4)
   PICK_ON_M5 = 19        // Solo ONDA-M5 (ritracciamento nel trend su M5, direzione chiara)
  };

//+------------------------------------------------------------------+
//| Input                                                            |
//+------------------------------------------------------------------+
input group "=== Generale ==="
input string InpSymbolOverride   = "";       // Simbolo oro (vuoto = simbolo del grafico)
input long   InpMagicBase        = 260800;   // Magic base (scalping +1, intraday +2, swing +3)
input bool   InpEnableScalping   = true;     // Motore SCALPING attivo
input bool   InpEnableIntraday   = true;     // Motore INTRADAY attivo
input bool   InpEnableSwing      = true;     // Motore SWING attivo
input ENUM_STRAT_PICK InpOnlyStrategy = PICK_ALL; // Test: usa solo questa strategia
input bool   InpPushNotify       = true;     // Notifiche push sul telefono (app MT5)
input bool   InpVerboseLog       = false;    // Log dettagliato (anche i segnali respinti)

input group "=== Rischio e lotti ==="
input double InpVirtualCapital   = 0.0;      // Capitale virtuale di partenza (0 = conto vero; poi cresce/cala con i risultati)
input double InpRiskPercent      = 1.0;      // Rischio base per trade (% del conto)
input double InpScalpRiskMult    = 0.75;     // Moltiplicatore rischio scalping
input double InpSwingRiskMult    = 1.0;      // Moltiplicatore rischio swing
input double InpMaxRiskPerTrade  = 3.0;      // Rischio massimo per trade (%), recupero incluso
input double InpMinLotMaxRiskPct = 2.5;      // Se serve il lotto minimo: rischio massimo accettato (%)
input double InpMaxOpenRiskPct   = 4.0;      // Rischio aperto totale massimo (%) (posizioni a pareggio = 0)
input int    InpMaxPos           = 6;        // Posizioni massime contemporanee (tutti i motori). 1.29: 6 (era InpMaxPositions = 4), il rischio aperto resta al massimo 4%
input double InpMinMarginLevel   = 120.0;    // Livello di margine minimo dopo l'apertura (%)
input double InpMaxLots          = 5.0;      // Lotti massimi per singolo ordine
input double InpDailyLossPct     = 7.0;      // Stop giornaliero (% dall'equity di inizio giorno)
input double InpWeeklyLossPct    = 10.0;     // Stop settimanale (% dall'equity di inizio settimana)
input double InpMaxDrawdownPct   = 50.0;     // Drawdown massimo dal picco: chiude tutto e si ferma (%)
input bool   InpResetHalt        = false;    // Sblocca l'EA dopo lo stop per drawdown massimo
input int    InpMaxLossesInRowDay = 3;       // Perdite di fila nello stesso giorno prima di fermarsi
input double InpCommissionPerLot = 7.0;      // Commissione andata+ritorno per 1 lotto (valuta del conto)

input group "=== Crescita del conto e recupero ==="
input bool   InpUseProfitCushion = true;     // Idee forti: rischio extra pagato con i profitti della settimana
input double InpCushionUse       = 0.5;      // Quota del profitto settimanale usabile come rischio extra
input double InpCushionMaxMult   = 1.0;      // Rischio extra massimo (x rischio base)
input bool   InpRecoveryEnabled  = true;     // Trade di recupero dopo una perdita (una volta sola)
input double InpRecoveryMult     = 1.75;     // Moltiplicatore lotti del trade di recupero
input double InpRecoveryMinScore = 0.75;     // Punteggio minimo del comitato per il recupero
input bool   InpAllowTranches    = true;     // Idee forti: fino a 3 ingressi scaglionati (40/30/30)
input bool   InpUseBench         = true;     // Mette in panchina le strategie con aspettativa negativa

input group "=== Regole fisse dei trade ==="
input double InpMinRR            = 2.0;      // Rischio/rendimento minimo (1:2)
input double InpBE_R             = 1.5;      // Stop a pareggio quando il trade arriva a +R (1.5-1.75)
input double InpPartialPct       = 40.0;     // Chiusura parziale al pareggio (% volume, se il lotto lo permette)
input double InpTrailStartR      = 2.0;      // Trailing stop da +R
input double InpMaxCostR         = 0.15;     // Costi massimi (spread+commissione) come frazione di R

input group "=== Comitato ==="
input double InpMinScoreScalp    = 0.62;     // Punteggio minimo comitato scalping
input double InpMinScoreIntra    = 0.62;     // Punteggio minimo comitato intraday
input double InpMinScoreSwing    = 0.65;     // Punteggio minimo comitato swing
input double InpStrongScore      = 0.78;     // Soglia "idea forte"
input int    InpQuorum           = 6;        // Desk principali favorevoli richiesti (su 8)
input int    InpDevilMax         = 3;        // Obiezioni dell'avvocato del diavolo che bloccano

input group "=== Scalping (M1-M5) ==="
input int    InpScalpMaxTradesDay = 6;       // Trade scalping massimi al giorno
input int    InpScalpMaxMinutes  = 60;       // Chiude lo scalp dopo N minuti se non e' a pareggio
input double InpScalpRR          = 2.2;      // Target scalping (R)
input bool   InpSC_VWAP          = true;     // SC-VWAP: pullback su VWAP in trend
input bool   InpSC_SWEEP         = true;     // SC-SWEEP: stop run sui livelli e rientro
input bool   InpSC_ORB           = true;     // SC-ORB: breakout range di apertura + retest

input group "=== Intraday (M5-M15) ==="
input int    InpIntraMaxTradesDay = 4;       // Trade intraday massimi al giorno
input int    InpIntraMaxHours    = 8;        // Chiude l'intraday dopo N ore se non e' a pareggio
input double InpIntraRR          = 2.5;      // Target intraday (R)
input bool   InpIN_PULLBACK      = true;     // IN-PULLBACK: trend H1 + pullback M15
input bool   InpIN_SWEEP         = true;     // IN-SWEEP: stop run su PDH/PDL/Asia/Londra
input bool   InpIN_BREAKOUT      = true;     // IN-BREAKOUT: breakout con volume + retest
input bool   InpIN_VALUE         = true;     // IN-VALUE80: rientro nella value area di ieri
input bool   InpIN_NEWS          = true;     // IN-NEWS: continuation dopo news coerente con la vista
input bool   InpIN_RANGE         = true;     // IN-RANGE: da VWAP +-2 sigma alla VWAP in laterale

input group "=== Swing (H1-H4) ==="
input int    InpSwingMaxTradesDay = 2;       // Trade swing massimi al giorno
input int    InpSwingMaxBarsH4   = 30;       // Chiude lo swing dopo N barre H4 se non e' a pareggio
input double InpSwingRR          = 3.0;      // Target swing (R)
input bool   InpSwingHoldWeekend = false;    // Tiene lo swing nel weekend anche se non e' a pareggio
input bool   InpSW_TREND         = true;     // SW-TREND: trend H4 + pullback H1
input bool   InpSW_WYCKOFF       = false;    // SW-WYCKOFF: spring/upthrust nel range H4 (spento dalla 1.24: sui dati 2022-26 non batte il caso)

input group "=== Orari e news ==="
input int    InpGmtOffsetLive    = -99;      // Fuso del server live (ore, -99 = automatico)
input int    InpGmtOffsetTester  = -99;      // Fuso del server nel tester (-99 = GMT+2 inverno / +3 estate)
input int    InpIntraCloseUTC    = 20;       // Ora UTC di chiusura di scalping e intraday
input int    InpNewsBlockBefore  = 30;       // Minuti senza ingressi prima di una news tier1 (scalp/intraday)
input int    InpNewsBlockAfter   = 15;       // Minuti senza ingressi dopo una news tier1 (scalp/intraday)
input int    InpNewsBlockSwingBefore = 90;   // Minuti senza ingressi swing prima di una news tier1
input int    InpNewsBlockSwingAfter  = 60;   // Minuti senza ingressi swing dopo una news tier1
input int    InpNewsBlockFomcAfter   = 90;   // Minuti senza ingressi (anche IN-NEWS) dopo la decisione FOMC, conferenza inclusa (0 = come le altre tier1)
input bool   InpCloseBeforeNews  = true;     // Chiude scalp (e intraday non a pareggio) 5 min prima di news tier1

input group "=== Motori del prezzo (studio 9 nov 2026) ==="
input bool   InpP1RunBrake       = true;     // P1: freno dopo le corse verticali (rischio ridotto, niente long in rottura)
input double InpP1RunSigma       = 2.5;      // P1: corsa degli ultimi 20 giorni oltre questi sigma
input double InpP1Ma200DistPct   = 20.0;     // P1: oppure prezzo oltre questa % sopra la media a 200 giorni
input double InpP1RiskMult       = 0.5;      // P1: moltiplicatore del rischio con il freno acceso
input bool   InpP2ThinLiquidity  = true;     // P2: niente ingressi con liquidita' sottile (feste USA, Asia nelle feste giapponesi, riaperture)
input int    InpP2ReopenMin      = 60;       // P2: minuti senza ingressi dopo una riapertura (pausa oltre 3 ore)
input bool   InpP3NoRiskOffBonus = false;    // P3: azzera il bonus "fuga dal rischio" del desk intermarket
input bool   InpP4FirstDayLong   = true;     // P4: spinta ai long il primo giorno di borsa del mese (acceso dalla 1.20: studio candele)
input double InpP4Bonus          = 0.02;     // P4: punti aggiunti al punteggio dei long
input bool   InpP5AsiaStopBuffer = false;    // P5: nelle ore asiatiche stop oltre i livelli ovvi (PDH/PDL, settimana, Asia, numeri tondi)
input double InpP5BufferAtrH1    = 0.25;     // P5: margine oltre il livello (x ATR H1)
input bool   InpP6ExpiryTargets  = false;    // P6: target dei breakout piu' corti alla scadenza opzioni COMEX e il giorno dopo
input double InpP6TargetMult     = 0.85;     // P6: moltiplicatore del target in R (mai sotto il minimo 1:2)

input group "=== Studio candele (9 nov 2026) ==="
input bool   InpC1BigDayRisk     = true;     // C1: rischio ridotto (scalping e intraday) il giorno dopo una candela D1 molto larga
input double InpC1BigDayAtr      = 2.0;      // C1: candela D1 di ieri oltre questi ATR (ATR 20 giorni prima di ieri)
input double InpC1RiskMult       = 0.75;     // C1: moltiplicatore del rischio
input bool   InpC3TightAsia      = false;    // C3: spinta a SC-SWEEP e IN-SWEEP quando il range di Asia e' stretto
input double InpC3AsiaAtr        = 0.40;     // C3: Asia stretta = range dalle 18 di New York all'apertura di Londra sotto questa frazione dell'ATR D1
input double InpC3Bonus          = 0.02;     // C3: punti aggiunti al punteggio

input group "=== Studio analisi tecnica (9 nov 2026) ==="
input bool   InpT2NoDiscountBonus = true;    // T2: niente bonus "zona di sconto 38-79%" e niente malus "inseguire l'estensione" nel desk Contesto (non battono il caso)
input bool   InpT3NoRangeEdgeObj  = true;    // T3: niente obiezione del diavolo "prezzo agli estremi del range D1" (comprare in alto non e' peggio)
input bool   InpT4RoundNotMajor   = true;    // T4: i numeri tondi forti non contano come livelli forti (solo target e ostacoli normali)
input bool   InpT5NoShortAfterCrash = true;  // T5: dopo un movimento esausto in basso sul D1 niente short di trend (i crolli esausti rimbalzano)
input int    InpT5Days            = 5;       // T5: giorni di borsa senza short di trend dopo l'esaurimento in basso

input group "=== Studio order flow (9 nov 2026) ==="
input bool   InpOF1FixNoChase     = true;    // OF1: dopo il fixing LBMA delle 10:30 di Londra, per 15 minuti niente ingressi nel verso del movimento 10:15-10:30 (si gira)
input double InpOF1MinBp          = 3.0;     // OF1: movimento minimo 10:15-10:30 in punti base (3 bp = circa 1,2 $ con l'oro a 4.000)
input bool   InpOF2VolumeNeutral  = true;    // OF2: desk Volumi senza delta, VWAP, climax, profilo e DOM (sul demo non battono il caso); restano RVOL e GC

input group "=== Costi veri, volatilita', diario, protezioni (1.25) ==="
input bool   InpCostTrack         = true;    // K: misura spread, slittamento e commissioni veri di ogni trade e li usa nel desk Costi e nei lotti
input bool   InpVolTarget         = true;    // V: rischio ridotto quando la volatilita' prevista supera il normale (mai sopra il rischio base)
input double InpVolMinMult        = 0.5;     // V: riduzione massima del rischio per volatilita' alta
input bool   InpDecisionLog       = true;    // D: diario CSV di ogni idea valutata (desk, punteggio, veto, esecuzione)
input bool   InpSafetyAlerts      = true;    // S: avvisi sul telefono (Algo Trading spento, niente prezzi, macro ferma, spread esploso, weekend)
input double InpMaxDirRiskPct     = 3.0;     // S: rischio aperto massimo nello stesso verso (% del conto): le posizioni sono tutte oro
input bool   InpWeekendHalfSwing  = true;    // S: il venerdi' sera gli swing non ancora a pareggio vengono dimezzati (gap del weekend)

input group "=== Meno regole: conferme forti e obiezioni misurate (1.25) ==="
input bool   InpOverrideOn         = true;   // MR: conferme forti possono scavalcare le obiezioni secondarie (con rischio ridotto)
input int    InpOverrideQuorum     = 7;      // MR: desk principali a favore richiesti per scavalcare (su 8)
input double InpOverrideExtraScore = 0.06;   // MR: punteggio richiesto sopra la soglia del motore per scavalcare
input int    InpOverrideMaxSoft    = 2;      // MR: obiezioni secondarie scavalcabili insieme (l'avvocato del diavolo conta come una)
input double InpOverrideRiskMult   = 0.6;    // MR: rischio dell'idea che scavalca le obiezioni (x)
input bool   InpObjLearn           = true;   // MR: idee fantasma: il bot misura da solo quali obiezioni servono davvero
input int    InpObjMinN            = 30;     // MR: casi minimi con e senza l'obiezione prima di giudicarla
input bool   InpObjFromTester      = true;   // MR: sul conto parte da quello che ha imparato il Tester (file in Common\Files)

input group "=== Movimenti forti (1.26) ==="
input bool   InpIN_TREND          = true;    // IN-TREND: quando New York porta l'oro lontano dal prezzo delle 8:00, entra nel verso del movimento
input double InpTDThreshAtr       = 0.80;    // MF: distanza dal prezzo di partenza che fa scattare l'ingresso (x escursione media di 20 giorni)
input double InpTDStopAtr         = 0.40;    // MF: stop (x escursione media di 20 giorni)
input double InpTDStopMinAtr      = 0.25;    // MF: stop piu' stretto accettato se il conto non regge quello pieno (lotti piu' alti a parita' di rischio)
input double InpTDTargetAtr       = 2.0;     // MF: target lontano (x escursione media); di norma si esce a pareggio o alla fine della tenuta
input int    InpTDFromMin         = 5;       // IN-TREND: minuti dopo le 8:00 di New York da cui guarda
input int    InpTDUntilMin        = 180;     // IN-TREND: minuti dopo le 8:00 di New York fino a cui puo' entrare (180 = 11:00)
input int    InpTDMaxDelayMin     = 15;      // MF: se al primo superamento non puo' entrare (news, spread), riprova per questi minuti
input int    InpTDHoldDays        = 1;       // MF: tenuta come swing: 0 = chiude la sera stessa, 1 = la sera del giorno di borsa dopo (venerdi' chiude sempre la sera)
input bool   InpTDTrail           = false;   // MF: trailing dopo il pareggio (spento: sui dati taglia i movimenti lunghi)
input double InpTDRiskMult        = 1.5;     // IN-TREND: rischio = rischio base x questo (regola provata: 1,5 = 1,5%); mai oltre il rischio massimo per trade
input double InpTDMinLotRiskPct   = 3.0;     // MF: con il lotto minimo, rischio massimo accettato (%), mai oltre il rischio massimo per trade
input bool   InpTDProven          = true;    // MF: regole proprie misurate sui dati: le fermano solo i limiti di rischio, le news forti, i costi e la liquidita'
input bool   InpIN_DATA           = true;    // IN-DATO: dopo un dato d'inflazione che sorprende (caldo = vende, freddo = compra), stessa gestione
input double InpDataRiskMult      = 0.5;     // IN-DATO: rischio = rischio base x questo (pochi casi nella storia: meta' rischio)
input int    InpDataMaxDelayMin   = 5;       // IN-DATO: entra entro questi minuti da quando il dato e' noto
input bool   InpDataAlerts        = true;    // Dati: legge dato e previsione dal calendario MT5 e avvisa sul telefono (caldo/freddo e cosa fa di solito l'oro)
input bool   InpIN_NIGHT          = true;    // IN-NOTTE: lo stesso movimento forte di notte e a Londra (dal prezzo delle 18:00 di New York)

input group "=== Ritracciamenti nel verso del trend (1.27) ==="
input bool   InpON_M5             = true;    // ONDA-M5: ritracciamento finito su M5, solo con direzione chiara (trend D1, H4 e H1 d'accordo); piu' ingressi al giorno
input bool   InpON_M15            = true;    // ONDA-M15: ritracciamento finito su M15 nel verso del trend giornaliero (target vicino, lotti piu' alti)
input bool   InpON_H1             = true;    // ONDA-H1: ritracciamento finito su H1 nel verso del trend giornaliero (target lontano, lotti piu' bassi)
input bool   InpON_H4             = true;    // ONDA-H4: ritracciamento finito su H4 nel verso del trend giornaliero (target molto lontano)
input double InpOndaM5K           = 0.30;    // ON: M5, ampiezza dell'onda che conferma il punto di svolta (x escursione media di 20 giorni)
input double InpOndaM15K          = 0.40;    // ON: M15, ampiezza dell'onda
input double InpOndaH1K           = 0.80;    // ON: H1, ampiezza dell'onda
input double InpOndaH4K           = 1.50;    // ON: H4, ampiezza dell'onda
input bool   InpOndaM5NeedAll     = true;    // ON: M5 entra solo se anche H4 e H1 vanno nel verso del trend giornaliero (senza, sui dati rende poco)
input double InpOndaBufAtr        = 0.10;    // ON: margine dello stop oltre il punto di svolta (x escursione media)
input double InpOndaM5StopMax     = 0.30;    // ON: M5, stop massimo (x escursione media; 0 = nessun tetto)
input double InpOndaM15StopMax    = 0.40;    // ON: M15, stop massimo (x escursione media; 0 = nessun tetto)
input double InpOndaM5StopMin     = 0.20;    // ON: M5, stop piu' stretto accettato se il conto non regge quello pieno
input double InpOndaM15StopMin    = 0.30;    // ON: M15, stop piu' stretto accettato se il conto non regge quello pieno
input double InpOndaH1StopMin     = 0.50;    // ON: H1, stop piu' stretto accettato se il conto non regge quello pieno
input double InpOndaH4StopMin     = 1.00;    // ON: H4, stop piu' stretto accettato se il conto non regge quello pieno
input double InpOndaTargetR       = 2.0;     // ON: M5, target in R (scalping: target vicino, lotti alti; mai sotto l'R:R minimo)
input double InpOndaTargetRM15    = 4.0;     // ON: M15, target in R (1.28: ogni scala ha il suo; era 2)
input double InpOndaTargetRH1     = 4.0;     // ON: H1, target in R (1.28: era 2; nome nuovo, prima InpOndaTargetRLong valeva per H1 e H4)
input double InpOndaTargetRH4     = 4.0;     // ON: H4, target in R (1.28: era 2)
input int    InpOndaTgtMode       = 1;       // ON: target 0 fisso per scala | 1 scelto dal bot trade per trade sui livelli del mercato (1.29)
input int    InpOndaTgtSrc        = 7;       // ON: livelli usati (somma): 1 estremo precedente dell'onda, 2 misura dell'onda, 4 livelli forti del giorno
input double InpOndaTgtMinW       = 0.8;     // ON: peso minimo di un livello del giorno (0,7 = anche gli swing H1)
input double InpOndaTgtFront      = 0.10;    // ON: target messo prima del livello di questa parte di R
input double InpOndaTgtMaxR       = 6.0;     // ON: target massimo in R
input int    InpOndaTgtWay        = 2;       // ON: 2 allunga il target della scala fino al livello dopo | 1 lo accorcia prima di un livello (peggio di 11R) | 0 primo livello utile
input int    InpOndaTgtNone       = 0;       // ON: nessun livello utile: 0 target fisso della scala | 1 target massimo
input double InpOndaTargetClearX  = 1.0;     // ON: M15, H1, H4 con direzione chiara: target x questo (1 = spento; provato a 1,5, non migliora)
input double InpOndaHoldMult      = 3.0;     // ON: tempo massimo = durata dell'onda x questo + 5 barre
input int    InpOndaMaxDelayMin   = 15;      // ON: se alla conferma non puo' entrare (news, spread), riprova per questi minuti
input double InpOndaRiskMult      = 1.0;     // ON: M15, H1 e H4: rischio = rischio base x questo; mai oltre il rischio massimo per trade
input double InpOndaM5RiskMult    = 0.75;    // ON: M5: rischio = rischio base x questo (come lo scalping)
input double InpOndaClearMult     = 1.0;     // ON: H1 con direzione chiara (anche H4 e H1 nel verso): rischio x questo (1 = uguale; sui dati rende quasi il doppio)
input double InpOndaMinLotRiskPct = 2.0;     // ON: con il lotto minimo, rischio massimo accettato (%), mai oltre il rischio massimo per trade
input int    InpOndaWeekend       = 1;       // ON: venerdi' sera per H1 e H4: 0 = tiene, 1 = dimezza, 2 = chiude (M5 e M15 chiudono sempre)
input bool   InpOndaFriCloseMinLot = false;  // ON: se non si puo' dimezzare (un solo lotto minimo): false = tiene, true = chiude
input bool   InpOndaNoDayLimit    = true;    // ON: nessun tetto al numero di ingressi al giorno (restano i limiti di rischio, le 4 posizioni e gli stop giornalieri)
input bool   InpOndaProven        = true;    // ON: regola propria misurata sui dati: la fermano solo i limiti di rischio, le news forti, i costi e la liquidita'
input bool   InpIN_TREND2         = true;    // IN-TREND2: secondo ingresso della giornata di tendenza, quando il movimento arriva piu' lontano
input double InpTD2ThreshAtr      = 1.20;    // IN-TREND2: distanza dal prezzo delle 8:00 di New York (x escursione media)
input double InpTD2RiskMult       = 1.0;     // IN-TREND2: rischio = rischio base x questo
input bool   InpOndaOwnSlots      = true;    // ON: i ritracciamenti aperti non occupano gli slot dei motori (restano nel tetto delle 4 posizioni e nel rischio aperto)
input bool   InpTDNoStreak        = true;    // MF: le perdite di fila di oggi non fermano i movimenti forti (li fermano gli stop giornalieri e il rischio aperto)
input bool   InpTDNoSlot          = true;    // MF: i movimenti forti non si fermano per gli slot del motore (restano le 4 posizioni e il rischio aperto)
input bool   InpTDFlipOnda        = false;   // MF: un movimento forte contro ritracciamenti ancora a rischio li chiude ed entra (sui dati peggiora: spento)

input group "=== Lettura del mercato (1.27) ==="
input bool   InpReadOn            = true;    // LM: legge trend, macro, liquidita', zone, sbilanciamenti: pannello, diario e ogni idea
input bool   InpReadLearn         = true;    // LM: misura per ogni lettura se le idee vanno meglio con la lettura a favore o contro
input int    InpReadMinN          = 30;      // LM: casi minimi a favore e contro prima di giudicare una lettura
input int    InpReadCutN          = 2;       // LM: letture provate contrarie (tolte quelle a favore) che fanno ridurre il rischio
input double InpReadCutMult       = 0.5;     // LM: rischio x questo quando le letture provate sono contrarie
input double InpReadBoostMult     = 1.0;     // LM: rischio x questo quando le letture provate sono a favore (1 = spento; mai oltre il rischio massimo per trade)
input bool   InpReadTrendGate     = true;    // LM: una strategia in osservazione puo' aprire solo le idee nel verso del trend giornaliero, se quelle guadagnano lontano dal caso

input group "=== Asta del mercato (1.28) ==="
input bool   InpAstaOn            = true;    // AS: legge il mercato come un'asta: equilibrio o squilibrio, valore che si sposta, accettazione, rottura fallita, bilancio iniziale
input double InpAstaOverlap       = 0.5;     // AS: equilibrio se le aree di valore di ieri e dell'altro ieri si sovrappongono almeno cosi' (0-1)
input int    InpAstaMode          = 1;       // AS: 0 = solo misura | 1 = cambia il rischio quando il bot ha provato la lettura | 2 = cambia il rischio da subito
input double InpAstaOutMult       = 0.8;     // AS: rischio x questo per le idee nate fuori dall'equilibrio (quando AS cambia il rischio)
input double InpAstaInMult        = 1.2;     // AS: rischio x questo per le idee nate in equilibrio (1 = spento; mai oltre il rischio massimo per trade)

input group "=== Strategie in osservazione (1.26) ==="
input bool   InpObserveOn         = true;    // OS: le strategie non provate lavorano sulla carta (idee seguite e misurate, nessun ordine)
input string InpObserveList       = "SC-VWAP,SC-SWEEP,SC-ORB,IN-PULLBACK,IN-SWEEP,IN-BREAKOUT,IN-VALUE80,IN-NEWS,IN-RANGE,IN-NOTTE"; // OS: strategie che partono in osservazione
input bool   InpObserveAuto       = true;    // OS: promuove da solo una strategia che sulla carta guadagna, e mette in osservazione una attiva che perde
input int    InpObserveMinN       = 60;      // OS: idee chiuse minime prima di giudicare una strategia
input double InpObservePromoteR   = 0.10;    // OS: R medio dopo i costi per promuoverla (e lontano dal caso: 2,5 errori standard, 3 periodi su 4)
input double InpObserveDemoteR    = -0.05;   // OS: R medio dopo i costi sotto cui una strategia attiva torna in osservazione

input group "=== Coda, pareggio e rientro ==="
input bool   InpQueueOn          = true;     // Coda: con altre posizioni aperte, una nuova idea deve essere piu' sicura
input double InpQueueExtraScore  = 0.04;     // Coda: punti in piu' sul punteggio minimo (e quorum +1)
input double InpBeLockR          = 0.10;     // Pareggio: stop all'entrata + costi + questa quota di R (cuscinetto)
input bool   InpReentryOn        = true;     // Rientro: se un trade torna a pareggio, nuovo ingresso nella stessa direzione se le conferme restano
input double InpReentryMult      = 1.25;     // Rientro: moltiplicatore del rischio (una volta sola per idea)
input group "=== Idee A+ (tutte le conferme) ==="
input bool   InpAplusOn          = true;     // A+: con tutte le conferme rischio piu' alto e gestione attiva a terzi
input double InpAplusRiskPct     = 3.0;      // A+: rischio per trade (% del conto, mai oltre il rischio massimo per trade)
input double InpAplusMaxLots     = 0.03;     // A+: lotti massimi per idea (0 = solo il limite di rischio)
input double InpAplusMinScore    = 0.70;     // A+: punteggio minimo (e almeno il minimo del motore + 0.05)
input double InpAplusPartialR    = 1.0;      // A+: a questo +R chiude un terzo, il secondo al pareggio, il resto segue il trailing

input group "=== Dati esterni (solo conto live/demo) ==="
input bool   InpUseWebData       = true;     // Legge macro, comitato AI e livelli GC da GitHub
input string InpMacroUrl         = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/macro_bias.json"; // URL macro_bias.json
input string InpCommitteeUrl     = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/ai_committee.json"; // URL ai_committee.json
input string InpVolumeUrl        = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/volume_levels.json"; // URL volume_levels.json
input string InpNewsUrl          = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/news_calendar.json"; // URL news_calendar.json (riserva)
input string InpMacroHistUrl     = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/macro_history.csv"; // URL storico macro (salvato anche per il tester)
input double InpMacroVetoLevel   = 0.45;     // Macro contraria oltre questo livello: veto per intraday e swing
input double InpContextVetoLevel = 0.60;     // Contesto HTF contrario oltre questo livello: veto per intraday e swing
input int    InpWebRefreshMin    = 15;       // Ogni quanti minuti rilegge i dati esterni
input bool   InpUseDOM           = true;     // Usa il book (DOM) se il broker lo fornisce

//+------------------------------------------------------------------+
//| Costanti                                                         |
//+------------------------------------------------------------------+
#define EA_VERSION     "1.29"
#define ENG_SCALP      0
#define ENG_INTRA      1
#define ENG_SWING      2

#define NSTRAT         20
#define ST_SC_VWAP     1
#define ST_SC_SWEEP    2
#define ST_SC_ORB      3
#define ST_IN_PULLBACK 4
#define ST_IN_SWEEP    5
#define ST_IN_BREAKOUT 6
#define ST_IN_VALUE    7
#define ST_IN_NEWS     8
#define ST_IN_RANGE    9
#define ST_SW_TREND    10
#define ST_SW_WYCKOFF  11
#define ST_IN_TREND    12
#define ST_IN_DATA     13
#define ST_IN_NIGHT    14
#define ST_IN_TREND2   15
#define ST_ON_M15      16
#define ST_ON_H1       17
#define ST_ON_H4       18
#define ST_ON_M5       19

#define STYPE_TREND    0
#define STYPE_REVERSAL 1
#define STYPE_BREAKOUT 2
#define STYPE_MEANREV  3
#define STYPE_NEWS     4

#define REG_UP         0
#define REG_DOWN       1
#define REG_RANGE      2
#define REG_VOLATILE   3
#define REG_QUIET      4

#define NDESK          10
#define D_STRAT        0
#define D_TREND        1
#define D_VOLUME       2
#define D_LIQ          3
#define D_MACRO        4
#define D_NEWS         5
#define D_SESSION      6
#define D_COST         7
#define D_STATS        8
#define D_CONTEXT      9

#define MAX_META       64
#define MAX_NEWS       64
#define MAX_LEVELS     64
#define MICRO_N        1440

string g_stratName[NSTRAT]  = {"-", "SC-VWAP", "SC-SWEEP", "SC-ORB", "IN-PULLBACK", "IN-SWEEP", "IN-BREAKOUT", "IN-VALUE80", "IN-NEWS", "IN-RANGE", "SW-TREND", "SW-WYCKOFF", "IN-TREND", "IN-DATO", "IN-NOTTE", "IN-TREND2", "ONDA-M15", "ONDA-H1", "ONDA-H4", "ONDA-M5"};
int    g_stratEngine[NSTRAT] = {-1, ENG_SCALP, ENG_SCALP, ENG_SCALP, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_SWING, ENG_SWING, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_SWING, ENG_SWING, ENG_SCALP};
int    g_stratType[NSTRAT]   = {STYPE_TREND, STYPE_TREND, STYPE_REVERSAL, STYPE_BREAKOUT, STYPE_TREND, STYPE_REVERSAL, STYPE_BREAKOUT, STYPE_MEANREV, STYPE_NEWS, STYPE_MEANREV, STYPE_TREND, STYPE_REVERSAL, STYPE_TREND, STYPE_TREND, STYPE_TREND, STYPE_TREND, STYPE_TREND, STYPE_TREND, STYPE_TREND, STYPE_TREND};
string g_engName[3]          = {"Scalping", "Intraday", "Swing"};
//--- 1.26: famiglia "movimenti forti" (stesse regole di stop, tenuta e rischio)
bool IsTrendMove(int st) { return (st == ST_IN_TREND || st == ST_IN_DATA || st == ST_IN_NIGHT || st == ST_IN_TREND2); }
//--- 1.27: famiglia "ritracciamenti nel verso del trend" (ONDA): scala 0 = M5, 1 = M15, 2 = H1, 3 = H4
bool IsOnda(int st) { return (st == ST_ON_M5 || st == ST_ON_M15 || st == ST_ON_H1 || st == ST_ON_H4); }
int  OndaScale(int st) { return (st == ST_ON_M5) ? 0 : ((st == ST_ON_M15) ? 1 : ((st == ST_ON_H1) ? 2 : 3)); }
//--- regole proprie misurate sui dati (passano dal comitato con le sole obiezioni obbligatorie)
bool IsProvenFam(int st) { return (IsTrendMove(st) || IsOnda(st)); }
//--- rischio dei movimenti forti rispetto al rischio base: pieno moltiplicatore solo per la regola provata
double TmRiskMult(int st)
  {
   if(st == ST_IN_TREND)
      return MathMax(0.1, MathMin(InpTDRiskMult, 3.0));
   if(st == ST_IN_DATA)
      return MathMax(0.1, MathMin(InpDataRiskMult, 3.0));
   if(st == ST_IN_TREND2)
      return MathMax(0.1, MathMin(InpTD2RiskMult, 3.0));
   if(st == ST_ON_M5)
      return MathMax(0.1, MathMin(InpOndaM5RiskMult, 3.0));
   if(IsOnda(st))
      return MathMax(0.1, MathMin(InpOndaRiskMult, 3.0));
   return 1.0;
  }

string g_deskName[NDESK]     = {"Strategia", "Trend", "Volumi", "Liquidita", "Macro", "News", "Sessione", "Costi", "Statistica", "Contesto HTF"};
string g_deskShort[NDESK]    = {"Str", "Trd", "Vol", "Liq", "Mac", "New", "Ses", "Cst", "Sta", "Ctx"};
string g_regName[5]          = {"trend rialzista", "trend ribassista", "laterale", "volatile", "calmo"};

//+------------------------------------------------------------------+
//| Globali di base                                                  |
//+------------------------------------------------------------------+
CTrade   g_trade;
string   g_sym = "";
string   g_version = EA_VERSION;
double   g_point = 0.0;
double   g_tick = 0.0;
double   g_minLot = 0.0;
double   g_maxLot = 0.0;
double   g_lotStep = 0.0;
double   g_contract = 0.0;
int      g_digits = 2;
int      g_lotDigits = 2;
bool     g_isTester = false;
bool     g_isOptim = false;
bool     g_isVisual = false;
bool     g_netting = false;
bool     g_ready = false;
long     g_login = 0;
int      g_gmtOffset = 2;
datetime g_gmtCheckedAt = 0;
string   g_currency = "";
string   g_lastDecision[6];
int      g_lastDecisionHead = 0;

//+------------------------------------------------------------------+
//| Utilita'                                                         |
//+------------------------------------------------------------------+
double Clamp(double v, double lo, double hi)
  {
   if(v < lo)
      return lo;
   if(v > hi)
      return hi;
   return v;
  }

int IMax(int a, int b) { return (a > b) ? a : b; }
int IMin(int a, int b) { return (a < b) ? a : b; }

double PxBid() { return SymbolInfoDouble(g_sym, SYMBOL_BID); }
double PxAsk() { return SymbolInfoDouble(g_sym, SYMBOL_ASK); }

double NormPrice(double p)
  {
   if(g_tick <= 0.0)
      return NormalizeDouble(p, g_digits);
   return NormalizeDouble(MathRound(p / g_tick) * g_tick, g_digits);
  }

double FloorLot(double lots)
  {
   if(g_lotStep <= 0.0)
      return 0.0;
   double steps = MathFloor(lots / g_lotStep + 0.0000001);
   return NormalizeDouble(steps * g_lotStep, g_lotDigits);
  }

string DirName(int dir) { return (dir > 0) ? "BUY" : "SELL"; }

string Pct(double v) { return DoubleToString(v, 1) + "%"; }

string Money(double v) { return DoubleToString(v, 2) + " " + g_currency; }

//--- valore di 1.0 di prezzo per 1 lotto, in valuta del conto
double ValuePerPriceUnit()
  {
   double tv = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_VALUE);
   double ts = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_SIZE);
   if(tv <= 0.0 || ts <= 0.0)
      return g_contract;
   return tv / ts;
  }

//--- K (1.25): costi veri misurati sui trade (medie mobili, salvate nelle variabili globali)
double g_costSlipPx = 0.0;    // slittamento medio all'ingresso, in prezzo (positivo = eseguito peggio del prezzo chiesto)
int    g_costSlipN = 0;
double g_costSpreadPx = 0.0;  // spread medio pagato all'ingresso
int    g_costSpreadN = 0;
double g_costCommLot = 0.0;   // commissioni + fee vere per 1 lotto (andata e ritorno)
int    g_costCommN = 0;
double g_costR[3];            // costo medio di un trade in R, per motore
int    g_costRN[3];

double CostAvg(double avg, int n, double x) { int k = (n < 30) ? n + 1 : 30; return avg + (x - avg) / (double)k; }

//--- commissione per lotto da usare: quella misurata se ci sono almeno 3 trade, altrimenti il parametro
double CommPerLotEff()
  {
   if(InpCostTrack && g_costCommN >= 3)
      return MathMax(g_costCommLot, 0.0);
   return MathMax(InpCommissionPerLot, 0.0);
  }

//--- commissione andata+ritorno espressa in prezzo
double CommissionPx()
  {
   double c = CommPerLotEff();
   if(c <= 0.0)
      return 0.0;
   double v = ValuePerPriceUnit();
   if(v <= 0.0)
      return 0.0;
   return c / v;
  }

//--- slittamento atteso all'ingresso: misurato (almeno 5 trade) o stima 10% dello spread
double SlipEstPx(double spread)
  {
   if(InpCostTrack && g_costSlipN >= 5)
      return MathMax(g_costSlipPx, 0.0);
   return 0.1 * spread;
  }

void Logf(string msg)
  {
   if(g_isOptim)
      return;
   Print(msg);
  }

void Notify(string msg)
  {
   Logf(msg);
   if(InpPushNotify && !g_isTester)
     {
      string m = msg;
      if(StringLen(m) > 250)
         m = StringSubstr(m, 0, 250);
      SendNotification(m);
     }
  }

void RememberDecision(string line)
  {
   g_lastDecision[g_lastDecisionHead] = line;
   g_lastDecisionHead = (g_lastDecisionHead + 1) % 6;
  }

//+------------------------------------------------------------------+
//| Tempo: fusi orari, ora legale, sessioni                          |
//+------------------------------------------------------------------+
int YearOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.year;
  }

//--- data (00:00 UTC) della n-esima domenica del mese (n=-1 ultima)
datetime NthSunday(int year, int mon, int n)
  {
   MqlDateTime d;
   d.year = year;
   d.mon = mon;
   d.day = 1;
   d.hour = 0;
   d.min = 0;
   d.sec = 0;
   d.day_of_week = 0;
   d.day_of_year = 0;
   datetime first = StructToTime(d);
   MqlDateTime f;
   TimeToStruct(first, f);
   int toSun = (7 - f.day_of_week) % 7;
   datetime firstSun = first + toSun * 86400;
   if(n > 0)
      return firstSun + (n - 1) * 7 * 86400;
   //--- ultima domenica
   datetime s = firstSun;
   while(true)
     {
      datetime nx = s + 7 * 86400;
      MqlDateTime x;
      TimeToStruct(nx, x);
      if(x.mon != mon)
         break;
      s = nx;
     }
   return s;
  }

//--- ora legale USA: seconda domenica di marzo -> prima domenica di novembre (circa 07:00/06:00 UTC)
bool IsUSDST(datetime utc)
  {
   int y = YearOf(utc);
   datetime a = NthSunday(y, 3, 2) + 7 * 3600;
   datetime b = NthSunday(y, 11, 1) + 6 * 3600;
   return (utc >= a && utc < b);
  }

//--- ora legale UK: ultima domenica di marzo -> ultima domenica di ottobre (01:00 UTC)
bool IsUKDST(datetime utc)
  {
   int y = YearOf(utc);
   datetime a = NthSunday(y, 3, -1) + 3600;
   datetime b = NthSunday(y, 10, -1) + 3600;
   return (utc >= a && utc < b);
  }

void UpdateGmtOffset()
  {
   if(g_isTester)
     {
      if(InpGmtOffsetTester != -99)
         g_gmtOffset = InpGmtOffsetTester;
      else
         g_gmtOffset = IsUSDST(TimeCurrent() - 2 * 3600) ? 3 : 2;
     }
   else
     {
      if(InpGmtOffsetLive != -99)
         g_gmtOffset = InpGmtOffsetLive;
      else
        {
         long diff = (long)(TimeTradeServer() - TimeGMT());
         g_gmtOffset = (int)MathRound((double)diff / 3600.0);
        }
     }
   g_gmtCheckedAt = TimeCurrent();
  }

datetime ToUTC(datetime server) { return server - g_gmtOffset * 3600; }
datetime ToServer(datetime utc) { return utc + g_gmtOffset * 3600; }

double HourOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.hour + d.min / 60.0 + d.sec / 3600.0;
  }

int DowOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.day_of_week;
  }

int DayKey(datetime t) { return (int)(t / 86400); }

double LondonOpenUTC(datetime utc) { return IsUKDST(utc) ? 7.0 : 8.0; }
double NYDataUTC(datetime utc)     { return IsUSDST(utc) ? 12.5 : 13.5; }
double NYOpenUTC(datetime utc)     { return IsUSDST(utc) ? 13.5 : 14.5; }
double NYCloseUTC(datetime utc)    { return IsUSDST(utc) ? 21.0 : 22.0; }
//--- 1.26: il venerdi' sera e' due ore prima della chiusura di New York (20 UTC d'inverno, 19 UTC d'estate).
//    Con l'ora fissa delle 20 UTC, d'estate il mercato del broker chiudeva prima che la regola scattasse
//    e le posizioni restavano aperte nel weekend.
double FridayEveUTC(datetime utc)  { return NYCloseUTC(utc) - 2.0; }
bool   FridayEvening(datetime utc) { return DowOf(utc) == 5 && HourOf(utc) >= FridayEveUTC(utc); }
//--- 1.26: chiusura serale di scalping, intraday e movimenti forti: InpIntraCloseUTC, ma almeno 75 minuti prima della
//    chiusura di New York (d'estate 19:45 UTC), cosi' avviene sempre a mercato aperto: dal 2026 la pausa serale del
//    broker dura due ore e d'estate comincia alle 20 UTC, quindi la chiusura delle 20 scattava solo alla riapertura.
double EveCloseUTC(datetime utc)   { return MathMin((double)InpIntraCloseUTC, NYCloseUTC(utc) - 1.25); }

//--- yyyymmdd di una data UTC
int Ymd(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.year * 10000 + d.mon * 100 + d.day;
  }
