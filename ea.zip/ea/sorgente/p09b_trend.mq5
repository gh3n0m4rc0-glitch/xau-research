//+------------------------------------------------------------------+
//| MOVIMENTI FORTI (1.26)                                           |
//|                                                                  |
//| Studio sulle M1 2022-2026 (4 periodi, costi inclusi):            |
//| - IN-TREND, giornata di tendenza: quando tra le 8:05 e le 11:00  |
//|   di New York l'oro chiude una M1 a 0,8 escursioni medie dal     |
//|   prezzo delle 8:00, il movimento di solito continua. Stop 0,4   |
//|   escursioni, tenuto fino a sera: +0,31R a trade (t 2,7, 4/4);   |
//|   tenuto fino alla sera del giorno dopo con il pareggio a 1,5R:  |
//|   +0,43R (4/4). Giocato dall'EA sulle candele vere: 109 trade,   |
//|   +0,35R, positivo in 4 periodi su 4. Macro, trend D1 e verso di |
//|   Asia/Londra non cambiano il risultato: passa senza quei filtri.|
//| - IN-DATO: dopo un CPI che sorprende in modo netto (totale e     |
//|   core dalla stessa parte) entra nel verso del dato: caldo =     |
//|   vende, freddo = compra, stessa tenuta. Il verso e' giusto 8-10 |
//|   volte su 10 ma buona parte del movimento arriva nel primo      |
//|   minuto. Giocato dall'EA sulle candele vere: 20 casi, +0,67R a  |
//|   trade, positivo in 4 periodi su 4, ma pochi casi (t 1,3):      |
//|   apre ordini a meta' rischio. NFP, PCE, PPI e vendite al        |
//|   dettaglio non reggono: solo avviso.                            |
//| - IN-NOTTE: lo stesso segnale di notte e a Londra (dal prezzo    |
//|   delle 18:00 di New York): sulla carta +0,17R ma non lontano    |
//|   dal caso -> parte in osservazione.                             |
//| Escursione media = media di (massimo - minimo) delle ultime 20   |
//| giornate chiuse.                                                 |
//+------------------------------------------------------------------+
bool InRollover();

#define TM_TREND 0
#define TM_DATA  1
#define TM_NIGHT 2
#define TM_TREND2 3
#define TM_N     4

int    g_tmDoneKey[TM_N];     // giornata (yyyymmdd) in cui la strategia ha gia' aperto, sulla carta o davvero
string g_tmDoneWhy[TM_N];
string g_tmText[TM_N];        // riga del pannello
double g_tdAnchor[2];         // prezzo delle 8:00 di New York di oggi (per il pannello); [0] primo ingresso, [1] secondo
int    g_tdCacheDay[2];
int    g_tdCrossDir[2];
datetime g_tdCrossUtc[2];

int TmSlot(int strat)
  {
   if(strat == ST_IN_DATA)
      return TM_DATA;
   if(strat == ST_IN_NIGHT)
      return TM_NIGHT;
   if(strat == ST_IN_TREND2)
      return TM_TREND2;
   return TM_TREND;
  }

void TmInit()
  {
   string keys[TM_N] = {"tmDay0", "tmDay1", "tmDay2", "tmDay3"};
   for(int v = 0; v < 2; v++)
     {
      g_tdAnchor[v] = 0.0;
      g_tdCacheDay[v] = 0;
      g_tdCrossDir[v] = 0;
      g_tdCrossUtc[v] = 0;
     }
   for(int i = 0; i < TM_N; i++)
     {
      g_tmDoneKey[i] = 0;
      g_tmDoneWhy[i] = "";
      g_tmText[i] = "";
      if(!g_isTester)
         g_tmDoneKey[i] = (int)GvGet(keys[i], 0.0);
      if(g_tmDoneKey[i] > 0)
         g_tmDoneWhy[i] = "gia' fatto (prima del riavvio)";
     }
  }

//--- la strategia ha fatto la sua mossa di oggi: non riprova (resta anche dopo un riavvio)
void TmMarkDone(int strat, int key, string why)
  {
   string keys[TM_N] = {"tmDay0", "tmDay1", "tmDay2", "tmDay3"};
   int k = TmSlot(strat);
   g_tmDoneKey[k] = key;
   g_tmDoneWhy[k] = why;
   if(!g_isTester)
      GlobalVariableSet(GvName(keys[k]), (double)key);
  }

//--- escursione media: massimo - minimo delle ultime 20 giornate chiuse
double TdAtr()
  {
   double sum = 0.0;
   int n = 0;
   for(int k = 0; k < 20; k++)
     {
      int i = TfIdx(g_d1, k);
      if(i < 0)
         break;
      double r = g_d1.r[i].high - g_d1.r[i].low;
      if(r > 0.0)
        {
         sum += r;
         n++;
        }
     }
   return (n >= 10) ? sum / n : 0.0;
  }

datetime DayStartUtc(datetime utc) { return (datetime)((long)utc - (long)utc % 86400); }

//--- le 8:00 di New York del giorno UTC di 'nowUtc'
datetime Ny8Utc(datetime nowUtc)
  {
   return DayStartUtc(nowUtc) + (datetime)MathRound((NYDataUTC(nowUtc) - 0.5) * 3600.0);
  }

//--- fine della tenuta: la sera (EveCloseUTC) dello stesso giorno o del giorno di borsa dopo
datetime TmExitUtc(datetime openUtc)
  {
   datetime d = DayStartUtc(openUtc);
   if(DowOf(openUtc) == 5 && HourOf(openUtc) < FridayEveUTC(openUtc))
      return d + (datetime)MathRound(FridayEveUTC(openUtc) * 3600.0);   // aperto di venerdi': chiude il venerdi' sera
   if(HourOf(openUtc) >= EveCloseUTC(openUtc))
      d += 86400;                              // aperto dopo la chiusura serale (notte): conta come il giorno dopo
   int hold = IMax(0, IMin(InpTDHoldDays, 5));
   int guard = 0;
   while(hold > 0 && guard < 12)
     {
      d += 86400;
      guard++;
      int dw = DowOf(d);
      if(dw != 0 && dw != 6)
         hold--;
     }
   return d + (datetime)MathRound(EveCloseUTC(d + 43200) * 3600.0);
  }

string TmHoldText()
  {
   if(InpTDHoldDays <= 0)
      return "tenuto fino a stasera";
   if(InpTDHoldDays == 1)
      return "swing tenuto fino alla sera del giorno di borsa dopo (venerdi' chiude la sera)";
   return "swing tenuto " + IntegerToString(InpTDHoldDays) + " giorni di borsa (venerdi' chiude la sera)";
  }

bool TmHasPosition(int strat)
  {
   for(int i = 0; i < MAX_META; i++)
      if(g_meta[i].active && g_meta[i].strat == strat)
         return true;
   return false;
  }

//--- finestra comune: mai nel weekend, nel rollover o il venerdi' sera
bool TmWindow()
  {
   if(g_ctx.dow == 0 || g_ctx.dow == 6 || InRollover())
      return false;
   if(g_ctx.dow == 5 && g_ctx.hUtc >= FridayEveUTC(g_ctx.nowUtc) - 2.0)
      return false;
   return true;
  }

//--- primo superamento: prima barra chiusa tra fromU e untilU con chiusura a 'thr' dal prezzo di partenza.
//    Prezzo di partenza: ultima chiusura nei 30 minuti prima di aU, altrimenti la prima apertura dopo.
bool TmScan(const TfData &d, int barSec, datetime aU, datetime fromU, datetime untilU, double thr,
            double &anchor, int &dir, datetime &crossU)
  {
   anchor = 0.0;
   dir = 0;
   crossU = 0;
   for(int i = 0; i < d.n; i++)
     {
      datetime tU = ToUTC(d.r[i].time);
      if(tU < aU)
        {
         if(tU >= aU - 1800)
            anchor = d.r[i].close;
         continue;
        }
      if(anchor <= 0.0)
        {
         if(tU >= aU + 1800)
            return false;                      // niente prezzi intorno all'ora di partenza: oggi non si guarda
         anchor = d.r[i].open;
        }
      if(tU < fromU || tU >= untilU)
         continue;
      double c = d.r[i].close;
      if(c >= anchor + thr)
        {
         dir = 1;
         crossU = tU + barSec;
         return true;
        }
      if(c <= anchor - thr)
        {
         dir = -1;
         crossU = tU + barSec;
         return true;
        }
     }
   return (anchor > 0.0);
  }

//--- segnale comune: stop in escursioni medie (piu' stretto, fino al minimo, se il conto non regge quello pieno:
//    stesso rischio in denaro, lotti piu' alti), target lontano
bool TmSignal(TSignal &s, int strat, int dir, double A, string why)
  {
   double entry = EntryPx(dir);
   double stopD = InpTDStopAtr * A;
   double minD = MathMin(InpTDStopMinAtr, InpTDStopAtr) * A;
   double base = BaseCapital();
   if(base > 0.0 && g_minLot > 0.0)
     {
      double cap = MathMax(MathMin(InpTDMinLotRiskPct, InpMaxRiskPerTrade), InpMinLotMaxRiskPct);
      double want = MathMin(InpRiskPercent * TmRiskMult(strat), InpMaxRiskPerTrade);
      for(int pass = 0; pass < 3; pass++)
        {
         double lpl = LossPerLot(dir, entry, entry - dir * stopD);
         if(InpCostTrack)
            lpl += SlipEstPx(g_ctx.spread) * ValuePerPriceUnit();
         double pctMin = 100.0 * lpl * g_minLot / base;
         if(pctMin <= want || pctMin <= cap || stopD <= minD)
            break;
         stopD = MathMax(minD, stopD * cap / pctMin * 0.98);
        }
     }
   double sl = entry - dir * stopD;
   double tp = entry + dir * MathMax(InpTDTargetAtr * A, InpMinRR * stopD + 3.0 * g_tick);
   string w = why + ", stop " + DoubleToString(stopD / A, 2) + " escursioni (" + DoubleToString(stopD, 1) + " $), " + TmHoldText();
   if(!MakeSignalTP(s, strat, dir, entry, sl, tp, 0.70, w))
      return false;
   s.proven = InpTDProven;
   return true;
  }

//--- IN-TREND: giornata di tendenza di New York (v = 0 primo ingresso; v = 1 secondo ingresso, soglia piu' lontana, 1.27)
bool S_InTrendV(TSignal &s, int v)
  {
   int strat = (v == 0) ? ST_IN_TREND : ST_IN_TREND2;
   int slot = (v == 0) ? TM_TREND : TM_TREND2;
   double thrAtr = (v == 0) ? InpTDThreshAtr : MathMax(InpTD2ThreshAtr, InpTDThreshAtr + 0.05);
   double A = TdAtr();
   if(A <= 0.0 || g_m1.n < 30)
     {
      g_tmText[slot] = "dati insufficienti";
      return false;
     }
   datetime now = g_ctx.nowUtc;
   int today = Ymd(now);
   datetime aU = Ny8Utc(now);
   int until = IMax(10, IMin(InpTDUntilMin, 200));
   int from = IMax(1, IMin(InpTDFromMin, until - 1));
   double thr = thrAtr * A;
   string win = TimeToString(aU + from * 60, TIME_MINUTES) + "-" + TimeToString(aU + until * 60, TIME_MINUTES) + " UTC";
   if(g_tdCacheDay[v] != today)
     {
      g_tdCacheDay[v] = today;
      g_tdAnchor[v] = 0.0;
      g_tdCrossDir[v] = 0;
      g_tdCrossUtc[v] = 0;
     }
   if(g_ctx.dow == 0 || g_ctx.dow == 6)
     {
      g_tmText[slot] = "mercato chiuso";
      return false;
     }
   if(now < aU + 60)
     {
      g_tmText[slot] = "guarda oggi " + win + " | soglia " + DoubleToString(thr, 1) + " $ dal prezzo delle 8:00 di New York";
      return false;
     }
   //--- finche' le barre delle 8:00 sono nel buffer M1 si ricalcola tutto dalle barre chiuse (regge i riavvii);
   //    dopo resta l'ultima lettura, solo per il pannello
   if(now <= aU + (until + InpTDMaxDelayMin + 2) * 60)
     {
      double an = 0.0;
      int dr = 0;
      datetime cu = 0;
      TmScan(g_m1, 60, aU, aU + from * 60, aU + until * 60, thr, an, dr, cu);
      g_tdAnchor[v] = an;
      g_tdCrossDir[v] = dr;
      g_tdCrossUtc[v] = cu;
     }
   double anchor = g_tdAnchor[v];
   int dir = g_tdCrossDir[v];
   datetime crossU = g_tdCrossUtc[v];
   if(anchor <= 0.0)
     {
      g_tmText[slot] = "oggi niente prezzi intorno alle 8:00 di New York";
      return false;
     }
   double c0 = BarC(g_m1, 0);
   double dist = (c0 - anchor) / A;
   string sign = (dist >= 0.0) ? "+" : "";
   string basic = "prezzo delle 8:00 NY " + DoubleToString(anchor, g_digits) + " | soglie " + DoubleToString(anchor + thr, g_digits) + " / " +
                  DoubleToString(anchor - thr, g_digits) + " | adesso " + sign + DoubleToString(dist, 2) + " escursioni";
   if(g_tmDoneKey[slot] == today)
     {
      g_tmText[slot] = "oggi " + g_tmDoneWhy[slot] + " | " + basic;
      return false;
     }
   if(dir == 0)
     {
      string wait = (now < aU + until * 60) ? "in attesa (" + win + ")" : "oggi nessun movimento forte";
      g_tmText[slot] = wait + " | " + basic;
      return false;
     }
   string dn = (dir > 0) ? "al rialzo" : "al ribasso";
   if(now > crossU + InpTDMaxDelayMin * 60 + 59)
     {
      g_tmText[slot] = "superamento " + dn + " alle " + TimeToString(crossU, TIME_MINUTES) + " UTC, ingresso non riuscito in tempo | " + basic;
      return false;
     }
   if((c0 - anchor) * dir < 0.75 * thr)
     {
      g_tmText[slot] = "superamento " + dn + " alle " + TimeToString(crossU, TIME_MINUTES) + " UTC, poi rientrato: aspetto | " + basic;
      return false;
     }
   string why = "giornata di tendenza " + dn + ": " + DoubleToString(MathAbs(dist), 2) + " escursioni medie dal prezzo delle 8:00 di New York (soglia " +
                DoubleToString(thrAtr, 2) + ")" + ((v == 1) ? ", secondo ingresso" : "");
   if(!TmSignal(s, strat, dir, A, why))
      return false;
   g_tmText[slot] = "superamento " + dn + ": ingresso | " + basic;
   return true;
  }

bool S_InTrendDay(TSignal &s) { return S_InTrendV(s, 0); }
bool S_InTrend2(TSignal &s) { return S_InTrendV(s, 1); }

//--- IN-DATO: dato d'inflazione con sorpresa netta -> nel verso del dato (caldo = vende, freddo = compra)
bool S_InData(TSignal &s)
  {
   double A = TdAtr();
   if(A <= 0.0)
      return false;
   datetime now = g_ctx.nowUtc;
   int today = Ymd(now);
   g_tmText[TM_DATA] = "";
   for(int k = 0; k < g_newsN; k++)
     {
      if(g_news[k].kind != 1 || g_news[k].surpN <= 0 || g_news[k].surpAt <= 0)
         continue;
      if(now < g_news[k].surpAt || now - g_news[k].utc > 6 * 3600)
         continue;
      int sp = g_news[k].surp;
      bool clear = (sp != 0 && MathAbs(sp) >= g_news[k].surpN);
      string verdict = DataVerdict(1, sp, g_news[k].surpN);
      if(!clear)
        {
         g_tmText[TM_DATA] = verdict + ": niente ingresso";
         continue;
        }
      if(g_tmDoneKey[TM_DATA] == today)
        {
         g_tmText[TM_DATA] = "oggi " + g_tmDoneWhy[TM_DATA];
         continue;
        }
      long late = (long)(now - g_news[k].surpAt);
      if(!g_isTester && late < 20)
        {
         g_tmText[TM_DATA] = verdict + ": dato appena letto, aspetto che i numeri siano completi";
         continue;
        }
      if(late > InpDataMaxDelayMin * 60 + 59 || now - g_news[k].utc > 15 * 60)
        {
         g_tmText[TM_DATA] = verdict + ": dato letto troppo tardi per entrare";
         continue;
        }
      int dir = (sp > 0) ? -1 : 1;
      string hot = (sp > 0) ? "caldo (sopra le attese): vendita" : "freddo (sotto le attese): acquisto";
      if(!TmSignal(s, ST_IN_DATA, dir, A, "dato d'inflazione " + hot + " | " + StringSubstr(g_news[k].surpText, 0, 80)))
         return false;
      g_tmText[TM_DATA] = verdict;
      return true;
     }
   return false;
  }

//--- IN-NOTTE: lo stesso movimento forte tra le 19:00 e le 8:00 di New York, dal prezzo delle 18:00 (barre M5)
bool S_InNight(TSignal &s)
  {
   double A = TdAtr();
   g_tmText[TM_NIGHT] = "";
   if(A <= 0.0 || g_m5.n < 60)
      return false;
   datetime now = g_ctx.nowUtc;
   datetime ny8 = Ny8Utc(now);
   if(now >= ny8 + 10 * 3600)
      ny8 += 86400;                            // dopo le 18:00 di New York la notte appartiene al giorno dopo
   datetime start = ny8 - 14 * 3600;           // le 18:00 di New York
   int key = Ymd(ny8);
   if(now < start + 3600 || now > ny8 + InpTDMaxDelayMin * 60 + 300)
      return false;
   if(g_tmDoneKey[TM_NIGHT] == key)
     {
      g_tmText[TM_NIGHT] = "stanotte " + g_tmDoneWhy[TM_NIGHT];
      return false;
     }
   double thr = InpTDThreshAtr * A;
   double anchor = 0.0;
   int dir = 0;
   datetime crossU = 0;
   if(!TmScan(g_m5, 300, start, start + 3600, ny8, thr, anchor, dir, crossU) || anchor <= 0.0)
      return false;
   double c0 = BarC(g_m1, 0);
   double dist = (c0 - anchor) / A;
   if(dir == 0)
     {
      g_tmText[TM_NIGHT] = "in attesa | dal prezzo delle 18:00 NY " + DoubleToString(dist, 2) + " escursioni";
      return false;
     }
   if(now > crossU + InpTDMaxDelayMin * 60 + 59 || (c0 - anchor) * dir < 0.75 * thr)
      return false;
   string dn = (dir > 0) ? "al rialzo" : "al ribasso";
   string why = "movimento forte fuori orario " + dn + ": " + DoubleToString(MathAbs(dist), 2) + " escursioni medie dal prezzo delle 18:00 di New York";
   if(!TmSignal(s, ST_IN_NIGHT, dir, A, why))
      return false;
   g_tmText[TM_NIGHT] = "superamento " + dn;
   return true;
  }

//--- righe del pannello
string TmPanel()
  {
   string t = "";
   if(StratEnabled(ST_IN_TREND))
     {
      string st = StratObserved(ST_IN_TREND) ? " (sulla carta)" : "";
      t += "Giornata di tendenza" + st + ": " + g_tmText[TM_TREND] + "\n";
     }
   if(StratEnabled(ST_IN_TREND2) && g_tdCrossDir[1] != 0)
     {
      string st2 = StratObserved(ST_IN_TREND2) ? " (sulla carta)" : "";
      t += "Secondo ingresso" + st2 + ": " + StringSubstr(g_tmText[TM_TREND2], 0, 110) + "\n";
     }
   int k = DataLastIndex(g_ctx.nowUtc, 12);
   if(k >= 0)
      t += "Ultimo dato: " + StringSubstr(DataText(k), 0, 200) + "\n";
   return t;
  }
