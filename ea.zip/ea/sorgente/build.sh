#!/bin/bash
# Unisce le parti in un unico file MQL5
cd "$(dirname "$0")"
cat src/p01_header.mq5 src/p02_data.mq5 src/p03_volume.mq5 src/p04_levels.mq5 src/p04b_context.mq5 src/p05_news.mq5 src/p05b_macro.mq5 \
    src/p06_strategies.mq5 src/p07_state.mq5 src/p08_committee.mq5 src/p09_risk.mq5 src/p10_manage.mq5 \
    src/p11_main.mq5 > out/XauCommitteeEA.mq5
wc -l out/XauCommitteeEA.mq5
