#!/bin/bash
# Unisce le parti in un unico file MQL5
cd "$(dirname "$0")"
cat p01_header.mq5 p02_data.mq5 p03_volume.mq5 p04_levels.mq5 p04b_context.mq5 p05_news.mq5 p05b_macro.mq5 \
    p06_strategies.mq5 p07_state.mq5 p08_committee.mq5 p09_risk.mq5 p09b_trend.mq5 p09c_onda.mq5 p09d_reading.mq5 p10_manage.mq5 \
    p11_main.mq5 > ../XauCommitteeEA.mq5
wc -l ../XauCommitteeEA.mq5
