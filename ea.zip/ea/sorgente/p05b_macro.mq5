//+------------------------------------------------------------------+
//| CAPO MACRO sempre informato:                                     |
//| 1) intermarket dai simboli del broker (funziona anche nel tester)|
//|    dollaro sintetico (pesi DXY), USDJPY come proxy dei           |
//|    rendimenti, argento, indice azionario, correlazione oro-dollaro|
//| 2) servizio di ricerca su GitHub (rendimenti reali, Fed, news)   |
//| 3) storico macro (macro_history.csv) per i backtest              |
//+------------------------------------------------------------------+
#define IM_EURUSD 0
#define IM_USDJPY 1
#define IM_GBPUSD 2
#define IM_USDCAD 3
#define IM_USDSEK 4
#define IM_USDCHF 5
#define IM_XAGUSD 6
#define IM_INDEX  7
#define IM_DXY    8
#define IM_N      9

string g_imSym[IM_N];
double g_imDxyW[6] = {-0.576, 0.136, -0.119, 0.091, 0.042, 0.036};

double g_dollarScore = 0.0;   // + dollaro forte
double g_dollarFast = 0.0;    // momento H4 del dollaro
double g_yieldProxy = 0.0;    // + USDJPY in salita (rendimenti USA su)
double g_silverConf = 0.0;    // + argento conferma l'oro
double g_riskOff = 0.0;       // + fuga dal rischio (azionario in calo forte)
double g_goldDxyCorr = 0.0;   // correlazione 60 giorni rendimenti oro / dollaro
double g_imBias = 0.0;
double g_imConf = 0.0;
int    g_imFx = 0;            // quanti cambi disponibili per il dollaro
bool   g_imOk = false;


//--- storico macro (dal servizio GitHub, anche nel tester)
int    g_mhDate[];
double g_mhBias[];
double g_mhConf[];
int    g_mhN = 0;
datetime g_mhLastTry = 0;

bool TrySymbol(string s)
  {
   if(s == "")
      return false;
   if(!SymbolSelect(s, true))
      return false;
   return true;
  }

//--- trova il simbolo del broker (con eventuali prefissi/suffissi come XAUUSD.a o XAUUSDm)
string ResolveSymbol(string base)
  {
   string up = g_sym;
   StringToUpper(up);
   int p = StringFind(up, "XAUUSD");
   string pre = "", suf = "";
   if(p >= 0)
     {
      pre = StringSubstr(g_sym, 0, p);
      suf = StringSubstr(g_sym, p + 6);
     }
   if(TrySymbol(pre + base + suf))
      return pre + base + suf;
   if(suf != "" && TrySymbol(base + suf))
      return base + suf;
   if(TrySymbol(base))
      return base;
   return "";
  }

void IntermarketInit()
  {
   g_imSym[IM_EURUSD] = ResolveSymbol("EURUSD");
   g_imSym[IM_USDJPY] = ResolveSymbol("USDJPY");
   g_imSym[IM_GBPUSD] = ResolveSymbol("GBPUSD");
   g_imSym[IM_USDCAD] = ResolveSymbol("USDCAD");
   g_imSym[IM_USDSEK] = ResolveSymbol("USDSEK");
   g_imSym[IM_USDCHF] = ResolveSymbol("USDCHF");
   g_imSym[IM_XAGUSD] = ResolveSymbol("XAGUSD");
   if(g_imSym[IM_XAGUSD] == "")
      g_imSym[IM_XAGUSD] = ResolveSymbol("SILVER");
   string idx[6];
   idx[0] = "US500";
   idx[1] = "SPX500";
   idx[2] = "SP500";
   idx[3] = "US500Cash";
   idx[4] = "USA500";
   idx[5] = "SPX";
   g_imSym[IM_INDEX] = "";
   for(int i = 0; i < 6 && g_imSym[IM_INDEX] == ""; i++)
      g_imSym[IM_INDEX] = ResolveSymbol(idx[i]);
   string dx[4];
   dx[0] = "USDX";
   dx[1] = "DXY";
   dx[2] = "DX";
   dx[3] = "USDOLLAR";
   g_imSym[IM_DXY] = "";
   for(int i = 0; i < 4 && g_imSym[IM_DXY] == ""; i++)
     {
      string c = ResolveSymbol(dx[i]);
      //--- accetto solo un vero indice del dollaro (DXY intorno a 70-130), non ETF o altri strumenti
      MqlRates t[];
      if(c != "" && CopyRates(c, PERIOD_D1, 1, 1, t) == 1 && t[0].close > 70.0 && t[0].close < 130.0)
         g_imSym[IM_DXY] = c;
     }
   string found = "";
   for(int i = 0; i < IM_N; i++)
      if(g_imSym[i] != "")
         found += g_imSym[i] + " ";
   if(found == "")
      found = "nessuno (la macro usera' GitHub e lo storico)";
   Logf("Macro intermarket: simboli trovati: " + found);
  }

//--- rendimento logaritmico del simbolo per la barra con tempo t (0 se manca)
double LogRetAt(const MqlRates &r[], int n, datetime t, int &pos)
  {
   while(pos < n && r[pos].time < t)
      pos++;
   if(pos >= n || pos == 0 || r[pos].time != t)
      return 0.0;
   if(r[pos - 1].close <= 0.0 || r[pos].close <= 0.0)
      return 0.0;
   return MathLog(r[pos].close / r[pos - 1].close);
  }

double Tanh(double x)
  {
   if(x > 20.0)
      return 1.0;
   if(x < -20.0)
      return -1.0;
   double e = MathExp(2.0 * x);
   return (e - 1.0) / (e + 1.0);
  }

//--- z-score del movimento delle ultime k barre rispetto alla volatilita'
double ZMove(const double &ret[], int n, int k, double vol)
  {
   if(n < k || vol <= 0.0)
      return 0.0;
   double s = 0.0;
   for(int i = n - k; i < n; i++)
      s += ret[i];
   return s / (vol * MathSqrt((double)k));
  }

double StdLast(const double &ret[], int n, int k)
  {
   int m = IMin(k, n);
   if(m < 5)
      return 0.0;
   double s = 0.0, s2 = 0.0;
   for(int i = n - m; i < n; i++)
     {
      s += ret[i];
      s2 += ret[i] * ret[i];
     }
   double mean = s / m;
   double v = s2 / m - mean * mean;
   return (v > 0.0) ? MathSqrt(v) : 0.0;
  }

//--- serie di rendimenti del dollaro sui tempi delle barre dell'oro (tf = D1 o H4)
int DollarReturns(ENUM_TIMEFRAMES tf, const TfData &gold, int bars, double &dret[], double &gret[])
  {
   ArrayResize(dret, 0);
   ArrayResize(gret, 0);
   int gn = gold.n;
   if(gn < bars + 2)
      return 0;
   MqlRates fx[];
   int cnt = 0;
   ArrayResize(dret, bars);
   ArrayResize(gret, bars);
   ArrayInitialize(dret, 0.0);
   ArrayInitialize(gret, 0.0);
   double wsum[];
   ArrayResize(wsum, bars);
   ArrayInitialize(wsum, 0.0);
   //--- preferisco il paniere dei cambi (24 ore, pesi DXY); l'indice del broker solo se mancano i cambi
   int fxAvail = 0;
   for(int s0 = IM_EURUSD; s0 <= IM_USDCHF; s0++)
      if(g_imSym[s0] != "")
         fxAvail++;
   bool useDxy = (g_imSym[IM_DXY] != "" && (g_imSym[IM_EURUSD] == "" || fxAvail < 3));
   int first = useDxy ? IM_DXY : IM_EURUSD;
   int last = useDxy ? IM_DXY : IM_USDCHF;
   for(int s = first; s <= last; s++)
     {
      if(g_imSym[s] == "")
         continue;
      int got = CopyRates(g_imSym[s], tf, 1, bars + 40, fx);
      if(got <= bars / 2)
         continue;
      double w = useDxy ? 1.0 : g_imDxyW[s];
      int pos = 0;
      int ok = 0;
      for(int j = 0; j < bars; j++)
        {
         int gi = gn - bars + j;
         double lr = LogRetAt(fx, got, gold.r[gi].time, pos);
         if(lr != 0.0)
           {
            dret[j] += w * lr;
            wsum[j] += MathAbs(w);
            ok++;
           }
        }
      if(ok > bars / 2)
         cnt++;
     }
   if(cnt == 0)
      return 0;
   double wfull = 0.0;
   if(useDxy)
      wfull = 1.0;
   else
      for(int s = IM_EURUSD; s <= IM_USDCHF; s++)
         if(g_imSym[s] != "")
            wfull += MathAbs(g_imDxyW[s]);
   for(int j = 0; j < bars; j++)
     {
      if(wsum[j] > 0.0 && wfull > 0.0)
         dret[j] *= wfull / wsum[j];       // rinormalizza se manca qualche cambio quel giorno
      int gi = gn - bars + j;
      if(gi >= 1 && gold.r[gi - 1].close > 0.0)
         gret[j] = MathLog(gold.r[gi].close / gold.r[gi - 1].close);
     }
   return useDxy ? 6 : cnt;
  }

double Corr(const double &a[], const double &b[], int n, int k)
  {
   int m = IMin(k, n);
   if(m < 10)
      return 0.0;
   double sa = 0, sb = 0, saa = 0, sbb = 0, sab = 0;
   for(int i = n - m; i < n; i++)
     {
      sa += a[i];
      sb += b[i];
      saa += a[i] * a[i];
      sbb += b[i] * b[i];
      sab += a[i] * b[i];
     }
   double va = saa / m - (sa / m) * (sa / m);
   double vb = sbb / m - (sb / m) * (sb / m);
   if(va <= 0.0 || vb <= 0.0)
      return 0.0;
   return (sab / m - (sa / m) * (sb / m)) / MathSqrt(va * vb);
  }

//--- momento di un singolo simbolo (z-score a 20 barre D1)
double SymbolZ(string sym, ENUM_TIMEFRAMES tf, int k)
  {
   if(sym == "")
      return 0.0;
   MqlRates r[];
   int got = CopyRates(sym, tf, 1, 80, r);
   if(got < k + 25)
      return 0.0;
   double ret[];
   ArrayResize(ret, got - 1);
   for(int i = 1; i < got; i++)
      ret[i - 1] = (r[i - 1].close > 0.0 && r[i].close > 0.0) ? MathLog(r[i].close / r[i - 1].close) : 0.0;
   double vol = StdLast(ret, got - 1, 60);
   return ZMove(ret, got - 1, k, vol);
  }

void IntermarketUpdate()
  {
   double dret[];
   double gret[];
   int bars = 70;
   g_imFx = DollarReturns(PERIOD_D1, g_d1, bars, dret, gret);
   g_imOk = (g_imFx > 0);
   if(!g_imOk)
     {
      g_imBias = 0.0;
      g_imConf = 0.0;
      return;
     }
   double vol = StdLast(dret, bars, 60);
   double z5 = ZMove(dret, bars, 5, vol);
   double z20 = ZMove(dret, bars, 20, vol);
   //--- trend del livello sintetico (somma cumulata) con due medie
   double lvl = 0.0, e10 = 0.0, e30 = 0.0;
   for(int j = 0; j < bars; j++)
     {
      lvl += dret[j];
      if(j == 0)
        {
         e10 = lvl;
         e30 = lvl;
        }
      else
        {
         e10 += (lvl - e10) * 2.0 / 11.0;
         e30 += (lvl - e30) * 2.0 / 31.0;
        }
     }
   double emaSign = (e10 > e30) ? 1.0 : -1.0;
   g_dollarScore = Clamp(0.4 * Tanh(z5 / 1.5) + 0.4 * Tanh(z20 / 1.5) + 0.2 * emaSign, -1.0, 1.0);
   g_goldDxyCorr = Corr(gret, dret, bars, 60);
   //--- dollaro veloce (H4, ultime 6 barre = un giorno)
   double dh[];
   double gh[];
   int hb = DollarReturns(PERIOD_H4, g_h4, 60, dh, gh);
   g_dollarFast = 0.0;
   if(hb > 0)
     {
      double vh = StdLast(dh, 60, 60);
      g_dollarFast = Tanh(ZMove(dh, 60, 6, vh) / 1.5);
     }
   g_yieldProxy = Tanh(SymbolZ(g_imSym[IM_USDJPY], PERIOD_D1, 20) / 1.5);
   //--- argento: conferma se si muove come l'oro
   double zs = SymbolZ(g_imSym[IM_XAGUSD], PERIOD_D1, 10);
   double zg = ZMove(gret, bars, 10, StdLast(gret, bars, 60));
   g_silverConf = 0.0;
   if(g_imSym[IM_XAGUSD] != "")
     {
      if(zs * zg > 0.0)
         g_silverConf = Tanh(MathMin(MathAbs(zs), MathAbs(zg)) / 1.5) * ((zg > 0.0) ? 1.0 : -1.0);
      else
         g_silverConf = -0.3 * ((zg > 0.0) ? 1.0 : -1.0);   // divergenza: l'oro va da solo, meno affidabile
     }
   double zi = SymbolZ(g_imSym[IM_INDEX], PERIOD_D1, 5);
   g_riskOff = (zi < -1.5) ? Tanh((-zi - 1.5)) : 0.0;
   //--- quanto conta il dollaro adesso: dipende dalla correlazione recente
   double wD = (g_goldDxyCorr < -0.2) ? 1.0 : ((g_goldDxyCorr < 0.2) ? 0.6 : 0.3);
   g_imBias = Clamp(-0.55 * wD * g_dollarScore - 0.15 * g_yieldProxy + 0.20 * g_silverConf + 0.10 * g_riskOff, -1.0, 1.0);
   double avail = MathMin(1.0, g_imFx / 4.0);
   g_imConf = Clamp((0.30 + 0.35 * MathAbs(g_goldDxyCorr)) * avail, 0.0, 0.65);
  }

//+------------------------------------------------------------------+
//| Storico macro (macro_history.csv in Common\Files)                |
//+------------------------------------------------------------------+
void MacroHistLoad()
  {
   g_mhN = 0;
   ArrayResize(g_mhDate, 0);
   ArrayResize(g_mhBias, 0);
   ArrayResize(g_mhConf, 0);
   if(!FileIsExist("macro_history.csv", FILE_COMMON))
      return;
   int h = FileOpen("macro_history.csv", FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      if(StringSplit(l, ',', p) < 3)
         continue;
      if(StringLen(p[0]) < 10 || StringGetCharacter(p[0], 0) < '0' || StringGetCharacter(p[0], 0) > '9')
         continue;
      int ymd = (int)StringToInteger(StringSubstr(p[0], 0, 4)) * 10000 + (int)StringToInteger(StringSubstr(p[0], 5, 2)) * 100 +
                (int)StringToInteger(StringSubstr(p[0], 8, 2));
      ArrayResize(g_mhDate, g_mhN + 1, 4096);
      ArrayResize(g_mhBias, g_mhN + 1, 4096);
      ArrayResize(g_mhConf, g_mhN + 1, 4096);
      g_mhDate[g_mhN] = ymd;
      g_mhBias[g_mhN] = Clamp(StringToDouble(p[1]), -1.0, 1.0);
      g_mhConf[g_mhN] = Clamp(StringToDouble(p[2]), 0.0, 1.0);
      g_mhN++;
     }
   FileClose(h);
   if(g_mhN > 0)
      Logf("Storico macro caricato: " + IntegerToString(g_mhN) + " giorni (" + IntegerToString(g_mhDate[0]) + " - " + IntegerToString(g_mhDate[g_mhN - 1]) + ")");
  }

//--- valore macro di ieri o prima (mai di oggi: nessuna informazione dal futuro), entro 5 giorni
bool MacroHistGet(datetime utc, double &b, double &c)
  {
   if(g_mhN <= 0)
      return false;
   int today = Ymd(utc);
   int lo = 0, hi = g_mhN - 1, best = -1;
   while(lo <= hi)
     {
      int mid = (lo + hi) / 2;
      if(g_mhDate[mid] < today)
        {
         best = mid;
         lo = mid + 1;
        }
      else
         hi = mid - 1;
     }
   if(best < 0)
      return false;
   int y = g_mhDate[best] / 10000, m = (g_mhDate[best] / 100) % 100, d = g_mhDate[best] % 100;
   MqlDateTime dt;
   dt.year = y;
   dt.mon = m;
   dt.day = d;
   dt.hour = 0;
   dt.min = 0;
   dt.sec = 0;
   dt.day_of_week = 0;
   dt.day_of_year = 0;
   if(utc - StructToTime(dt) > 6 * 86400)
      return false;
   b = g_mhBias[best];
   c = g_mhConf[best];
   return true;
  }

//--- in live scarica lo storico da GitHub e lo salva per il tester
void MacroHistDownload(string url)
  {
   if(g_isTester || url == "" || TimeCurrent() - g_mhLastTry < 12 * 3600)
      return;
   g_mhLastTry = TimeCurrent();
   string body;
   if(!HttpGet(url, body))
      return;
   if(StringFind(body, "date,bias") != 0)
      return;
   int h = FileOpen("macro_history.csv", FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   FileWriteString(h, body);
   FileClose(h);
   MacroHistLoad();
  }

//+------------------------------------------------------------------+
//| Macro combinata usata dal comitato                               |
//+------------------------------------------------------------------+
void MacroCombine()
  {
   double hb = 0.0, hc = 0.0;
   bool hist = MacroHistGet(ToUTC(TimeCurrent()), hb, hc);
   if(MacroFresh())
     {
      double wim = g_imOk ? 0.35 : 0.0;
      g_mBias = Clamp((1.0 - wim) * g_macroBias + wim * g_imBias, -1.0, 1.0);
      g_mConf = Clamp(MathMax(g_macroConf, g_imConf) * ((g_macroBias * g_imBias >= 0.0 || !g_imOk) ? 1.0 : 0.7), 0.0, 1.0);
      g_mSource = "GitHub";
      if(g_imOk)
         g_mSource += " + intermarket";
     }
   else
      if(hist && hc > 0.0)
        {
         double wim = g_imOk ? 0.4 : 0.0;
         g_mBias = Clamp((1.0 - wim) * hb + wim * g_imBias, -1.0, 1.0);
         g_mConf = Clamp(MathMax(hc * 0.9, g_imConf) * ((hb * g_imBias >= 0.0 || !g_imOk) ? 1.0 : 0.7), 0.0, 1.0);
         g_mSource = "storico macro";
         if(g_imOk)
            g_mSource += " + intermarket";
        }
      else
         if(g_imOk)
           {
            g_mBias = g_imBias;
            g_mConf = g_imConf * 0.85;
            g_mSource = "intermarket";
           }
         else
           {
            g_mBias = 0.0;
            g_mConf = 0.0;
            g_mSource = "nessuna";
           }
  }

string MacroText()
  {
   string t = "bias " + DoubleToString(g_mBias, 2) + " conf " + DoubleToString(g_mConf, 2) + " (" + g_mSource + ")";
   if(g_imOk)
     {
      string dw = "neutro";
      if(g_dollarScore > 0.25)
         dw = "forte";
      if(g_dollarScore < -0.25)
         dw = "debole";
      t += " | dollaro " + dw + " " + DoubleToString(g_dollarScore, 2) + ", corr oro-dollaro " + DoubleToString(g_goldDxyCorr, 2);
      if(g_imSym[IM_XAGUSD] != "")
        {
         if(g_silverConf > 0.2)
            t += ", argento conferma";
         else
            if(g_silverConf < -0.2)
               t += ", argento contrario";
            else
               t += ", argento neutro";
        }
      if(g_yieldProxy > 0.3)
         t += ", rendimenti in salita";
      if(g_yieldProxy < -0.3)
         t += ", rendimenti in calo";
     }
   if(MacroFresh() && g_macroHalt)
      t += " | STOP dal servizio: " + g_macroHaltReason;
   return t;
  }
