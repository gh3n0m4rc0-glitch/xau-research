//+------------------------------------------------------------------+
//| LETTURA DEL MERCATO (1.27)                                       |
//|                                                                  |
//| Il bot guarda il grafico come lo guarda un operatore: trend sui  |
//| timeframe alti, macro, liquidita' presa, zone di domanda e       |
//| offerta, sbilanciamenti, sconto/premio, falsa partenza di New    |
//| York, mediana della forchetta H4, VWAP, euro e argento, candele  |
//| di rifiuto, volumi. Ogni lettura dice "a favore dei rialzi", "a  |
//| favore dei ribassi" o "neutra".                                  |
//|                                                                  |
//| Come ingressi da soli questi concetti sui dati 2022-2026 NON     |
//| battono il caso (presa di liquidita', sbilanciamenti, zone,      |
//| livelli: provati in oltre 150 varianti). Per questo qui sono     |
//| CONOSCENZA, non regole: ogni idea di ogni strategia viene        |
//| etichettata con le letture a favore e contro, finisce nel        |
//| diario, e il bot misura per famiglia di strategie se le idee     |
//| vanno meglio con la lettura a favore che contro. Solo una        |
//| lettura che passa la regola degli studi (casi sufficienti, 2,5   |
//| errori standard, 3 periodi su 4) comincia a contare: riduce il   |
//| rischio quando e' contraria (e lo alza, se lo si accende, quando |
//| e' a favore).                                                    |
//|                                                                  |
//| Collegamento con le vecchie strategie: il bot tiene anche il     |
//| conto delle loro idee nel solo verso del trend giornaliero. Se   |
//| quelle guadagnano lontano dal caso, la strategia resta in        |
//| osservazione per le idee contro trend ma apre quelle nel trend.  |
//+------------------------------------------------------------------+
#define NREAD       14
#define RD_D1       0
#define RD_H4       1
#define RD_H1       2
#define RD_MACRO    3
#define RD_LIQ      4
#define RD_ZONE     5
#define RD_FVG      6
#define RD_DISC     7
#define RD_FALSE    8
#define RD_FORK     9
#define RD_VWAP     10
#define RD_XMKT     11
#define RD_WICK     12
#define RD_FLOW     13
#define NFAM        4
#define FAM_ONDA    0
#define FAM_MF      1
#define FAM_TREND   2
#define FAM_REV     3
#define RDS_TEST    0
#define RDS_USEFUL  1
#define RDS_INVERSE 2

string g_rdName[NREAD] = {"trend giornaliero", "trend H4", "trend H1", "macro", "liquidita' presa", "zona di domanda/offerta", "sbilanciamento M15",
                          "sconto/premio", "falsa partenza di New York", "mediana della forchetta H4", "VWAP", "euro e argento",
                          "candela di rifiuto H1", "volumi"
                         };
string g_famName[NFAM] = {"ritracciamenti", "movimenti forti", "vecchie di tendenza", "vecchie di inversione"};
int    g_rdDir[NREAD];                        // +1 a favore dei rialzi, -1 dei ribassi, 0 neutra
string g_rdNote = "";                         // dettagli per il pannello (livelli, zone)
double g_rdN[NFAM * NREAD * 2 * NPER];        // idee chiuse: famiglia, lettura, lato (0 a favore, 1 contro), periodo
double g_rdS[NFAM * NREAD * 2 * NPER];        // somma dei loro R dopo i costi
double g_rdQ[NFAM * NREAD * 2 * NPER];        // somma dei quadrati
int    g_rdState[NFAM * NREAD];
double g_rdTot = 0.0;                         // idee contate in tutto
//--- vecchie strategie nel solo verso del trend giornaliero
double g_stTN[NSTRAT * NPER];
double g_stTS[NSTRAT * NPER];
double g_stTQ[NSTRAT * NPER];
bool   g_stCond[NSTRAT];                      // promossa per le sole idee nel verso del trend giornaliero
//--- stato delle letture che hanno memoria
int      g_liqDir = 0;
datetime g_liqUtc = 0;
double   g_liqExt = 0.0;
string   g_liqName = "";
double   g_zoneDemLo = 0.0, g_zoneDemHi = 0.0, g_zoneSupLo = 0.0, g_zoneSupHi = 0.0;
double   g_fvgUpLo = 0.0, g_fvgUpHi = 0.0, g_fvgDnLo = 0.0, g_fvgDnHi = 0.0;
int      g_fsDir = 0;
double   g_xmEur = 0.0, g_xmXag = 0.0;
bool     g_rdReady = false;

int RdIdx(int f, int k, int side, int p) { return ((f * NREAD + k) * 2 + side) * NPER + p; }

int RdFamily(int strat)
  {
   if(IsOnda(strat))
      return FAM_ONDA;
   if(IsTrendMove(strat))
      return FAM_MF;
   if(strat > 0 && strat < NSTRAT && (g_stratType[strat] == STYPE_REVERSAL || g_stratType[strat] == STYPE_MEANREV))
      return FAM_REV;
   return FAM_TREND;
  }

void RdInit()
  {
   for(int i = 0; i < NFAM * NREAD * 2 * NPER; i++)
     {
      g_rdN[i] = 0.0;
      g_rdS[i] = 0.0;
      g_rdQ[i] = 0.0;
     }
   for(int i = 0; i < NFAM * NREAD; i++)
      g_rdState[i] = RDS_TEST;
   for(int i = 0; i < NSTRAT * NPER; i++)
     {
      g_stTN[i] = 0.0;
      g_stTS[i] = 0.0;
      g_stTQ[i] = 0.0;
     }
   for(int i = 0; i < NSTRAT; i++)
      g_stCond[i] = false;
   for(int i = 0; i < NREAD; i++)
      g_rdDir[i] = 0;
   g_rdTot = 0.0;
  }

//+------------------------------------------------------------------+
//| Le letture                                                       |
//+------------------------------------------------------------------+
//--- liquidita' presa e recuperata: il prezzo buca un minimo importante (Asia, Londra, ieri, settimana scorsa)
//    e richiude sopra entro due barre M5 -> a favore dei rialzi per 4 ore, finche' non chiude sotto l'estremo
void RdLiqLevel(double L, int side, string name, double tol, double lo, double hi, double c0, double c2)
  {
   if(L <= 0.0)
      return;
   if(side < 0 && lo < L - tol && c0 > L && c2 > L)
     {
      g_liqDir = 1;
      g_liqUtc = g_ctx.nowUtc;
      g_liqExt = lo;
      g_liqName = "preso " + name + " e recuperato";
     }
   if(side > 0 && hi > L + tol && c0 < L && c2 < L)
     {
      g_liqDir = -1;
      g_liqUtc = g_ctx.nowUtc;
      g_liqExt = hi;
      g_liqName = "preso " + name + " e respinto";
     }
  }

void RdLiqOnM5(double A)
  {
   if(g_m5.n < 5 || A <= 0.0)
      return;
   double tol = 0.02 * A;
   double c0 = BarC(g_m5, 0), c2 = BarC(g_m5, 2);
   double lo = MathMin(BarL(g_m5, 0), BarL(g_m5, 1)), hi = MathMax(BarH(g_m5, 0), BarH(g_m5, 1));
   if(g_sess.asiaDone)
     {
      RdLiqLevel(g_sess.asiaL, -1, "il minimo di Asia", tol, lo, hi, c0, c2);
      RdLiqLevel(g_sess.asiaH, 1, "il massimo di Asia", tol, lo, hi, c0, c2);
     }
   if(g_sess.lonDone)
     {
      RdLiqLevel(g_sess.lonL, -1, "il minimo di Londra", tol, lo, hi, c0, c2);
      RdLiqLevel(g_sess.lonH, 1, "il massimo di Londra", tol, lo, hi, c0, c2);
     }
   if(g_d1.n >= 2)
     {
      RdLiqLevel(BarL(g_d1, 0), -1, "il minimo di ieri", tol, lo, hi, c0, c2);
      RdLiqLevel(BarH(g_d1, 0), 1, "il massimo di ieri", tol, lo, hi, c0, c2);
     }
   RdLiqLevel(g_pwL, -1, "il minimo della settimana scorsa", tol, lo, hi, c0, c2);
   RdLiqLevel(g_pwH, 1, "il massimo della settimana scorsa", tol, lo, hi, c0, c2);
   if(g_liqDir > 0 && c0 < g_liqExt)
      g_liqDir = 0;
   if(g_liqDir < 0 && c0 > g_liqExt)
      g_liqDir = 0;
   if(g_liqDir != 0 && g_ctx.nowUtc - g_liqUtc > 4 * 3600)
      g_liqDir = 0;
  }

//--- zone di domanda e offerta su H1: l'ultima candela contraria prima di una spinta forte (corpo >= 1,5 ATR),
//    finche' il prezzo non ci chiude oltre
void RdZonesOnH1()
  {
   g_zoneDemLo = 0.0;
   g_zoneDemHi = 0.0;
   g_zoneSupLo = 0.0;
   g_zoneSupHi = 0.0;
   int n = g_h1.n;
   if(n < 60 || ArraySize(g_h1.atr) < n)
      return;
   bool dem = false, sup = false;
   for(int i = n - 2; i >= 3 && i >= n - 80 && !(dem && sup); i--)
     {
      double body = g_h1.r[i].close - g_h1.r[i].open;
      double atr = g_h1.atr[i];
      if(atr <= 0.0)
         continue;
      if(!dem && body >= 1.5 * atr)
        {
         for(int j = i - 1; j >= i - 3 && j >= 0; j--)
           {
            if(g_h1.r[j].close >= g_h1.r[j].open)
               continue;
            double zl = g_h1.r[j].low, zh = g_h1.r[j].open;
            bool valid = (zh > zl);
            for(int q = i + 1; q < n && valid; q++)
               if(g_h1.r[q].close < zl)
                  valid = false;
            if(valid)
              {
               g_zoneDemLo = zl;
               g_zoneDemHi = zh;
               dem = true;
              }
            break;
           }
        }
      if(!sup && body <= -1.5 * atr)
        {
         for(int j = i - 1; j >= i - 3 && j >= 0; j--)
           {
            if(g_h1.r[j].close <= g_h1.r[j].open)
               continue;
            double zl = g_h1.r[j].open, zh = g_h1.r[j].high;
            bool valid = (zh > zl);
            for(int q = i + 1; q < n && valid; q++)
               if(g_h1.r[q].close > zh)
                  valid = false;
            if(valid)
              {
               g_zoneSupLo = zl;
               g_zoneSupHi = zh;
               sup = true;
              }
            break;
           }
        }
     }
  }

//--- sbilanciamenti su M15 (vuoto tra il massimo di due barre prima e il minimo della barra, o il contrario) non ancora riempiti
void RdFvgOnM15(double A)
  {
   g_fvgUpLo = 0.0;
   g_fvgUpHi = 0.0;
   g_fvgDnLo = 0.0;
   g_fvgDnHi = 0.0;
   int n = g_m15.n;
   if(n < 10 || A <= 0.0)
      return;
   double minGap = 0.05 * A;
   bool up = false, dn = false;
   for(int i = n - 1; i >= 2 && i >= n - 60 && !(up && dn); i--)
     {
      if(!up && g_m15.r[i].low - g_m15.r[i - 2].high >= minGap)
        {
         double bot = g_m15.r[i - 2].high;
         bool filled = false;
         for(int q = i + 1; q < n && !filled; q++)
            if(g_m15.r[q].low <= bot)
               filled = true;
         if(!filled)
           {
            g_fvgUpLo = bot;
            g_fvgUpHi = g_m15.r[i].low;
            up = true;
           }
        }
      if(!dn && g_m15.r[i - 2].low - g_m15.r[i].high >= minGap)
        {
         double top = g_m15.r[i - 2].low;
         bool filled = false;
         for(int q = i + 1; q < n && !filled; q++)
            if(g_m15.r[q].high >= top)
               filled = true;
         if(!filled)
           {
            g_fvgDnLo = g_m15.r[i].high;
            g_fvgDnHi = top;
            dn = true;
           }
        }
     }
  }

//--- falsa partenza di New York: nella prima mezz'ora dall'apertura (9:30) il prezzo va da una parte di almeno
//    0,15 escursioni, poi torna oltre il prezzo d'apertura dall'altra -> a favore del verso opposto (per 4 ore)
void RdFalseStartOnM5(double A)
  {
   g_fsDir = 0;
   if(A <= 0.0 || g_m5.n < 20)
      return;
   datetime now = g_ctx.nowUtc;
   datetime openU = DayStartUtc(now) + (datetime)MathRound(g_ctx.nyOpen * 3600.0);
   if(now < openU + 2100 || now > openU + 4 * 3600)
      return;
   double O = 0.0, up = 0.0, dn = 0.0;
   for(int i = 0; i < g_m5.n; i++)
     {
      datetime tU = ToUTC(g_m5.r[i].time);
      if(tU < openU)
         continue;
      if(O <= 0.0)
        {
         if(tU >= openU + 900)
            return;                            // niente barre all'apertura: oggi non si legge
         O = g_m5.r[i].open;
        }
      if(tU < openU + 1800)
        {
         up = MathMax(up, g_m5.r[i].high - O);
         dn = MathMax(dn, O - g_m5.r[i].low);
        }
     }
   if(O <= 0.0)
      return;
   double c0 = BarC(g_m5, 0);
   if(up >= 0.15 * A && up > dn && c0 < O - 0.05 * A)
      g_fsDir = -1;
   if(dn >= 0.15 * A && dn > up && c0 > O + 0.05 * A)
      g_fsDir = 1;
  }

//--- movimento dell'ultima ora di un altro mercato rispetto alla sua misura tipica (barre M5); 0 se il simbolo manca o e' fermo
double RdSymZ(string sym)
  {
   if(sym == "")
      return 0.0;
   MqlRates r[];
   int got = CopyRates(sym, PERIOD_M5, 1, 300, r);
   if(got < 150)
      return 0.0;
   if(TimeCurrent() - r[got - 1].time > 1200)
      return 0.0;
   double mv = r[got - 1].close - r[got - 13].close;
   double s2 = 0.0;
   int c = 0;
   for(int i = 12; i < got - 1; i += 12)
     {
      double d = r[i].close - r[i - 12].close;
      s2 += d * d;
      c++;
     }
   if(c < 8 || s2 <= 0.0)
      return 0.0;
   return mv / MathSqrt(s2 / c);
  }

//--- a ogni M1: aggiorna tutte le letture (le piu' pesanti solo alla barra nuova del loro timeframe)
void RdUpdate(bool n5, bool n15, bool nh1)
  {
   if(!InpReadOn)
      return;
   double A = TdAtr();
   bool first = !g_rdReady;
   g_rdReady = true;
   if(n5 || first)
     {
      RdLiqOnM5(A);
      RdFalseStartOnM5(A);
      g_xmEur = RdSymZ(g_imSym[IM_EURUSD]);
      g_xmXag = RdSymZ(g_imSym[IM_XAGUSD]);
     }
   if(n15 || first)
      RdFvgOnM15(A);
   if(nh1 || first)
      RdZonesOnH1();
   double px = 0.5 * (g_ctx.bid + g_ctx.ask);
   string note = "";
   g_rdDir[RD_D1] = EmaDir(g_d1);
   g_rdDir[RD_H4] = EmaDir(g_h4);
   g_rdDir[RD_H1] = EmaDir(g_h1);
   g_rdDir[RD_MACRO] = 0;
   if(g_mConf >= 0.3 && MathAbs(g_mBias) >= 0.15)
      g_rdDir[RD_MACRO] = (g_mBias > 0.0) ? 1 : -1;
   g_rdDir[RD_LIQ] = g_liqDir;
   if(g_liqDir != 0)
      note += g_liqName + "; ";
   //--- zona: il prezzo e' tornato dentro (o appena sopra/sotto) una zona valida
   g_rdDir[RD_ZONE] = 0;
   bool inDem = (g_zoneDemHi > 0.0 && px >= g_zoneDemLo && px <= g_zoneDemHi + 0.1 * A);
   bool inSup = (g_zoneSupHi > 0.0 && px <= g_zoneSupHi && px >= g_zoneSupLo - 0.1 * A);
   if(inDem && !inSup)
     {
      g_rdDir[RD_ZONE] = 1;
      note += "in zona di domanda H1 " + DoubleToString(g_zoneDemLo, g_digits) + "-" + DoubleToString(g_zoneDemHi, g_digits) + "; ";
     }
   if(inSup && !inDem)
     {
      g_rdDir[RD_ZONE] = -1;
      note += "in zona di offerta H1 " + DoubleToString(g_zoneSupLo, g_digits) + "-" + DoubleToString(g_zoneSupHi, g_digits) + "; ";
     }
   //--- sbilanciamento: il prezzo sta ritracciando dentro un vuoto non riempito
   g_rdDir[RD_FVG] = 0;
   bool inUp = (g_fvgUpHi > 0.0 && px >= g_fvgUpLo && px <= g_fvgUpHi);
   bool inDn = (g_fvgDnHi > 0.0 && px >= g_fvgDnLo && px <= g_fvgDnHi);
   if(inUp && !inDn)
     {
      g_rdDir[RD_FVG] = 1;
      note += "dentro uno sbilanciamento rialzista M15; ";
     }
   if(inDn && !inUp)
     {
      g_rdDir[RD_FVG] = -1;
      note += "dentro uno sbilanciamento ribassista M15; ";
     }
   //--- sconto/premio: posizione del prezzo tra massimo e minimo delle ultime 60 barre H4 (10 giorni)
   g_rdDir[RD_DISC] = 0;
   double hh = HighestH(g_h4, 0, 60), ll = LowestL(g_h4, 0, 60);
   if(hh > ll && ll > 0.0)
     {
      double pos = (px - ll) / (hh - ll);
      if(pos < 0.4)
         g_rdDir[RD_DISC] = 1;
      if(pos > 0.6)
         g_rdDir[RD_DISC] = -1;
      string dw = (pos < 0.4) ? "prezzo in sconto" : ((pos > 0.6) ? "prezzo in premio" : "prezzo a meta'");
      note += dw + " (" + DoubleToString(100.0 * pos, 0) + "% dei 10 giorni); ";
     }
   g_rdDir[RD_FALSE] = g_fsDir;
   if(g_fsDir != 0)
     {
      string fw = (g_fsDir > 0) ? "al ribasso" : "al rialzo";
      note += "falsa partenza di New York " + fw + "; ";
     }
   //--- mediana della forchetta H4: linea dal primo punto al centro degli ultimi due; conta se il prezzo deve ancora raggiungerla
   g_rdDir[RD_FORK] = 0;
   if(g_zz[3].ok)
     {
      int d = (g_zz[3].type2 < 0) ? 1 : -1;
      double mt = 0.5 * (g_zz[3].t1 + g_zz[3].t2), mp = 0.5 * (g_zz[3].p1 + g_zz[3].p2);
      if(mt > g_zz[3].t0)
        {
         double ml = g_zz[3].p0 + (mp - g_zz[3].p0) / (mt - g_zz[3].t0) * (g_zz[3].nbars - g_zz[3].t0);
         if((ml - px) * d > 0.0)
           {
            g_rdDir[RD_FORK] = d;
            note += "mediana H4 a " + DoubleToString(ml, g_digits) + "; ";
           }
        }
     }
   g_rdDir[RD_VWAP] = 0;
   if(g_ctx.vwap > 0.0 && g_ctx.wvwap > 0.0)
     {
      if(px > g_ctx.vwap && px > g_ctx.wvwap)
         g_rdDir[RD_VWAP] = 1;
      if(px < g_ctx.vwap && px < g_ctx.wvwap)
         g_rdDir[RD_VWAP] = -1;
     }
   g_rdDir[RD_XMKT] = 0;
   if(g_xmEur > 1.0 && g_xmXag > 1.0)
      g_rdDir[RD_XMKT] = 1;
   if(g_xmEur < -1.0 && g_xmXag < -1.0)
      g_rdDir[RD_XMKT] = -1;
   if(g_rdDir[RD_XMKT] != 0)
     {
      string xw = (g_rdDir[RD_XMKT] > 0) ? "salgono" : "scendono";
      note += "euro e argento " + xw + " insieme; ";
     }
   g_rdDir[RD_WICK] = 0;
   if(g_h1.n > 20 && BarH(g_h1, 0) - BarL(g_h1, 0) >= 0.7 * g_ctx.atrH1 && g_ctx.atrH1 > 0.0)
     {
      double wu = WickRatio(g_h1, 0, 1), wd = WickRatio(g_h1, 0, -1);
      if(wu >= 0.5 && wd < 0.3)
         g_rdDir[RD_WICK] = 1;
      if(wd >= 0.5 && wu < 0.3)
         g_rdDir[RD_WICK] = -1;
     }
   g_rdDir[RD_FLOW] = 0;
   double cv = MicroCvdRatio(60);
   if(cv > 0.15)
      g_rdDir[RD_FLOW] = 1;
   if(cv < -0.15)
      g_rdDir[RD_FLOW] = -1;
   g_rdNote = note;
  }

//--- etichetta un'idea con le letture a favore e contro, e conta quelle provate
void RdEval(TSignal &s)
  {
   s.rdFav = 0;
   s.rdAg = 0;
   s.rdConf = 0;
   if(!InpReadOn || s.dir == 0)
      return;
   int f = RdFamily(s.strat);
   for(int k = 0; k < NREAD; k++)
     {
      int v = g_rdDir[k] * s.dir;
      if(v == 0)
         continue;
      if(v > 0)
         s.rdFav |= (1 << k);
      else
         s.rdAg |= (1 << k);
      int st = g_rdState[f * NREAD + k];
      if(st == RDS_USEFUL)
         s.rdConf += (v > 0) ? 1 : -1;
      if(st == RDS_INVERSE)
         s.rdConf += (v > 0) ? -1 : 1;
     }
  }

//--- le letture provate cambiano il rischio dell'idea: meno se sono contrarie, di piu' (se acceso) se sono a favore
double ReadRiskMult(const TSignal &s)
  {
   if(!InpReadOn || !InpReadLearn)
      return 1.0;
   int cut = IMax(1, InpReadCutN);
   if(s.rdConf <= -cut)
      return Clamp(InpReadCutMult, 0.1, 1.0);
   if(s.rdConf >= cut)
      return Clamp(InpReadBoostMult, 1.0, 1.5);
   return 1.0;
  }

string RdList(int mask)
  {
   string t = "";
   for(int k = 0; k < NREAD; k++)
      if((mask & (1 << k)) != 0)
         t += (t == "" ? "" : ", ") + g_rdName[k];
   return t;
  }

//+------------------------------------------------------------------+
//| Misura: ogni idea chiusa (seguita sulla carta) aggiorna i conti  |
//+------------------------------------------------------------------+
int RdEvaluate(int f, int k)
  {
   if(!InpReadLearn)
      return RDS_TEST;
   double nf = 0.0, sf = 0.0, qf = 0.0, na = 0.0, sa = 0.0, qa = 0.0;
   int perOk = 0, perPos = 0, perNeg = 0;
   for(int p = 0; p < NPER; p++)
     {
      double a = g_rdN[RdIdx(f, k, 0, p)], b = g_rdN[RdIdx(f, k, 1, p)];
      nf += a;
      sf += g_rdS[RdIdx(f, k, 0, p)];
      qf += g_rdQ[RdIdx(f, k, 0, p)];
      na += b;
      sa += g_rdS[RdIdx(f, k, 1, p)];
      qa += g_rdQ[RdIdx(f, k, 1, p)];
      if(a < 5.0 || b < 5.0)
         continue;
      perOk++;
      double df = g_rdS[RdIdx(f, k, 0, p)] / a - g_rdS[RdIdx(f, k, 1, p)] / b;
      if(df > 0.0)
         perPos++;
      if(df < 0.0)
         perNeg++;
     }
   double minN = (double)IMax(10, InpReadMinN);
   if(nf < minN || na < minN)
      return RDS_TEST;
   //--- con meno di 3 periodi misurabili (conto vero, un anno solo) servono il doppio dei casi
   if(perOk < 3 && (nf < 2.0 * minN || na < 2.0 * minN))
      return RDS_TEST;
   double mf = sf / nf, ma = sa / na;
   double vf = MathMax(qf / nf - mf * mf, 0.0), va = MathMax(qa / na - ma * ma, 0.0);
   double se = MathSqrt(vf / nf + va / na);
   double diff = mf - ma;
   if(diff >= 2.5 * se && diff >= 0.10 && (perOk < 3 || perPos >= 3))
      return RDS_USEFUL;
   if(diff <= -2.5 * se && diff <= -0.10 && (perOk < 3 || perNeg >= 3))
      return RDS_INVERSE;
   return RDS_TEST;
  }

//--- vecchia strategia nel solo verso del trend giornaliero: guadagna lontano dal caso?
bool StTrendEvaluate(int k)
  {
   if(!InpReadOn || !InpReadTrendGate || !InpObserveOn || !InpObserveAuto || IsProvenFam(k))
      return false;
   double n = 0.0, sum = 0.0, q = 0.0;
   int perOk = 0, perPos = 0;
   for(int p = 0; p < NPER; p++)
     {
      double a = g_stTN[k * NPER + p];
      n += a;
      sum += g_stTS[k * NPER + p];
      q += g_stTQ[k * NPER + p];
      if(a < 8.0)
         continue;
      perOk++;
      if(g_stTS[k * NPER + p] > 0.0)
         perPos++;
     }
   if(n < InpObserveMinN || (perOk < 3 && n < 2.0 * InpObserveMinN))
      return false;
   double mean = sum / n;
   double se = MathSqrt(MathMax(q / n - mean * mean, 0.0) / n);
   return (mean >= InpObservePromoteR && mean >= 2.5 * se && (perOk < 3 || perPos >= 3));
  }

string RdStateName(int st) { return (st == RDS_USEFUL) ? "provata" : ((st == RDS_INVERSE) ? "provata al contrario" : "in prova"); }

void RdRefresh(bool tell)
  {
   for(int f = 0; f < NFAM; f++)
      for(int k = 0; k < NREAD; k++)
        {
         int st = RdEvaluate(f, k);
         if(st != g_rdState[f * NREAD + k])
           {
            g_rdState[f * NREAD + k] = st;
            if(tell && st != RDS_TEST)
               Notify("Lettura del mercato: '" + g_rdName[k] + "' " + RdStateName(st) + " per " + g_famName[f] +
                      ((st == RDS_USEFUL) ? ": le idee vanno meglio con la lettura a favore, da adesso conta" : ": le idee vanno meglio con la lettura contro, da adesso conta al contrario"));
           }
        }
   for(int k = 1; k < NSTRAT; k++)
     {
      bool c = StTrendEvaluate(k);
      if(c != g_stCond[k])
        {
         g_stCond[k] = c;
         if(tell && c && StratObserved(k))
            Notify(g_stratName[k] + ": le idee nel verso del trend giornaliero guadagnano sulla carta lontano dal caso: da adesso quelle aprono ordini, le altre restano in osservazione");
        }
     }
  }

//--- chiamata alla chiusura di ogni idea seguita sulla carta
void RdAdd(int strat, int fav, int ag, datetime t0, double r, bool passed)
  {
   if(!InpReadOn || !InpReadLearn || strat <= 0 || strat >= NSTRAT)
      return;
   int p = ObPeriod(t0);
   int f = RdFamily(strat);
   for(int k = 0; k < NREAD; k++)
     {
      int side = -1;
      if((fav & (1 << k)) != 0)
         side = 0;
      else
         if((ag & (1 << k)) != 0)
            side = 1;
      if(side < 0)
         continue;
      g_rdN[RdIdx(f, k, side, p)] += 1.0;
      g_rdS[RdIdx(f, k, side, p)] += r;
      g_rdQ[RdIdx(f, k, side, p)] += r * r;
     }
   g_rdTot += 1.0;
   if(passed && (fav & (1 << RD_D1)) != 0)
     {
      g_stTN[strat * NPER + p] += 1.0;
      g_stTS[strat * NPER + p] += r;
      g_stTQ[strat * NPER + p] += r * r;
     }
  }

//--- una strategia in osservazione puo' aprire le sole idee nel verso del trend giornaliero, se quelle sono promosse
bool IdeaObserved(const TSignal &s)
  {
   if(!StratObserved(s.strat))
      return false;
   if(InpReadOn && InpReadTrendGate && s.strat > 0 && s.strat < NSTRAT && g_stCond[s.strat] && (s.rdFav & (1 << RD_D1)) != 0)
      return false;
   return true;
  }

string RdFile(bool tester) { return tester ? "XauCommittee_tester_letture.csv" : "XauCommittee_" + IntegerToString(g_login) + "_letture.csv"; }

void RdSave()
  {
   if(g_isOptim || !InpReadOn || !InpReadLearn || g_rdTot <= 0.0)
      return;
   int h = FileOpen(RdFile(g_isTester), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   string hd = "tipo;famiglia_o_strategia;lettura;stato;casi_favore;R_medio_favore;casi_contro;R_medio_contro";
   string pn[NPER] = {"2022", "2023", "2024", "2025_26"};
   for(int p = 0; p < NPER; p++)
      hd += ";n_fav_" + pn[p] + ";R_fav_" + pn[p] + ";q_fav_" + pn[p] + ";n_con_" + pn[p] + ";R_con_" + pn[p] + ";q_con_" + pn[p];
   FileWriteString(h, hd + "\r\n");
   FileWriteString(h, "totale;-;-;-;" + DoubleToString(g_rdTot, 0) + ";0;0;0\r\n");
   for(int f = 0; f < NFAM; f++)
      for(int k = 0; k < NREAD; k++)
        {
         double nf = 0.0, sf = 0.0, na = 0.0, sa = 0.0;
         string per = "";
         for(int p = 0; p < NPER; p++)
           {
            nf += g_rdN[RdIdx(f, k, 0, p)];
            sf += g_rdS[RdIdx(f, k, 0, p)];
            na += g_rdN[RdIdx(f, k, 1, p)];
            sa += g_rdS[RdIdx(f, k, 1, p)];
            for(int side = 0; side < 2; side++)
               per += ";" + DoubleToString(g_rdN[RdIdx(f, k, side, p)], 0) + ";" + DoubleToString(g_rdS[RdIdx(f, k, side, p)], 3) + ";" +
                      DoubleToString(g_rdQ[RdIdx(f, k, side, p)], 3);
           }
         if(nf + na <= 0.0)
            continue;
         FileWriteString(h, "lettura;" + g_famName[f] + ";" + g_rdName[k] + ";" + RdStateName(g_rdState[f * NREAD + k]) + ";" + DoubleToString(nf, 0) + ";" +
                         (nf > 0.0 ? DoubleToString(sf / nf, 3) : "0") + ";" + DoubleToString(na, 0) + ";" + (na > 0.0 ? DoubleToString(sa / na, 3) : "0") + per + "\r\n");
        }
   for(int k = 1; k < NSTRAT; k++)
     {
      double n = 0.0, sum = 0.0;
      string per = "";
      for(int p = 0; p < NPER; p++)
        {
         n += g_stTN[k * NPER + p];
         sum += g_stTS[k * NPER + p];
         per += ";" + DoubleToString(g_stTN[k * NPER + p], 0) + ";" + DoubleToString(g_stTS[k * NPER + p], 3) + ";" + DoubleToString(g_stTQ[k * NPER + p], 3) + ";0;0;0";
        }
      if(n <= 0.0)
         continue;
      FileWriteString(h, "trend;" + g_stratName[k] + ";idee nel verso del trend giornaliero;" + (g_stCond[k] ? "promosse" : "in prova") + ";" + DoubleToString(n, 0) + ";" +
                      DoubleToString(sum / n, 3) + ";0;0" + per + "\r\n");
     }
   FileClose(h);
  }

double RdReadFile(string fname)
  {
   RdInit();
   if(!FileIsExist(fname, FILE_COMMON))
      return 0.0;
   int h = FileOpen(fname, FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return 0.0;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      int np = StringSplit(l, ';', p);
      if(np >= 5 && p[0] == "totale")
        {
         g_rdTot = MathMax(StringToDouble(p[4]), 0.0);
         continue;
        }
      if(np < 8 + 6 * NPER)
         continue;
      if(p[0] == "lettura")
        {
         int f = -1, k = -1;
         for(int j = 0; j < NFAM; j++)
            if(p[1] == g_famName[j])
               f = j;
         for(int j = 0; j < NREAD; j++)
            if(p[2] == g_rdName[j])
               k = j;
         if(f < 0 || k < 0)
            continue;
         for(int q = 0; q < NPER; q++)
            for(int side = 0; side < 2; side++)
              {
               int b = 8 + 6 * q + 3 * side;
               g_rdN[RdIdx(f, k, side, q)] = MathMax(StringToDouble(p[b]), 0.0);
               g_rdS[RdIdx(f, k, side, q)] = StringToDouble(p[b + 1]);
               g_rdQ[RdIdx(f, k, side, q)] = MathMax(StringToDouble(p[b + 2]), 0.0);
              }
        }
      if(p[0] == "trend")
        {
         int k = StratByName(p[1]);
         if(k <= 0)
            continue;
         for(int q = 0; q < NPER; q++)
           {
            int b = 8 + 6 * q;
            g_stTN[k * NPER + q] = MathMax(StringToDouble(p[b]), 0.0);
            g_stTS[k * NPER + q] = StringToDouble(p[b + 1]);
            g_stTQ[k * NPER + q] = MathMax(StringToDouble(p[b + 2]), 0.0);
           }
        }
     }
   FileClose(h);
   //--- un file rovinato non deve far credere al bot di sapere: nessun conto oltre il totale
   for(int i = 0; i < NFAM * NREAD * 2 * NPER; i++)
      if(g_rdN[i] > g_rdTot)
        {
         g_rdN[i] = 0.0;
         g_rdS[i] = 0.0;
         g_rdQ[i] = 0.0;
        }
   for(int i = 0; i < NSTRAT * NPER; i++)
      if(g_stTN[i] > g_rdTot)
        {
         g_stTN[i] = 0.0;
         g_stTS[i] = 0.0;
         g_stTQ[i] = 0.0;
        }
   return g_rdTot;
  }

//--- carica quello che e' gia' stato misurato (conto: il suo file, altrimenti quello del Tester)
void RdLoad()
  {
   RdInit();
   if(g_isTester || !InpReadOn || !InpReadLearn)
      return;                                   // nel Tester si misura da zero, come in una prova vera
   double nt = RdReadFile(RdFile(false));
   if(nt <= 0.0 && InpObjFromTester)
     {
      nt = RdReadFile(RdFile(true));
      if(nt > 0.0)
         Notify("Lettura del mercato: parto da quello che ha misurato il Tester (" + DoubleToString(nt, 0) + " idee)");
     }
   RdRefresh(false);
  }

//--- righe del pannello: cosa vede adesso (part 0), i dettagli (part 1), quali letture contano (part 2)
string RdPanelPart(int part)
  {
   if(!InpReadOn)
      return "";
   if(part == 0)
     {
      int up = 0, dn = 0;
      for(int k = 0; k < NREAD; k++)
        {
         if(g_rdDir[k] > 0)
            up++;
         if(g_rdDir[k] < 0)
            dn++;
        }
      return "Lettura del mercato: " + IntegerToString(up) + " letture al rialzo, " + IntegerToString(dn) + " al ribasso | D1 " + DirWord(g_rdDir[RD_D1]) +
             ", H4 " + DirWord(g_rdDir[RD_H4]) + ", H1 " + DirWord(g_rdDir[RD_H1]) + ", macro " + DirWord(g_rdDir[RD_MACRO]) + "\n";
     }
   if(part == 1)
      return (g_rdNote != "") ? "  " + StringSubstr(g_rdNote, 0, 170) + "\n" : "";
   string pr = "";
   int np = 0;
   for(int f = 0; f < NFAM; f++)
      for(int k = 0; k < NREAD; k++)
         if(g_rdState[f * NREAD + k] != RDS_TEST)
           {
            np++;
            if(np <= 4)
               pr += (pr == "" ? "" : ", ") + g_rdName[k] + " (" + g_famName[f] + (g_rdState[f * NREAD + k] == RDS_INVERSE ? ", al contrario" : "") + ")";
           }
   if(np > 0)
      return "  Letture provate (" + IntegerToString(np) + "): " + StringSubstr(pr, 0, 170) + "\n";
   if(InpReadLearn)
      return "  Letture in prova: " + DoubleToString(g_rdTot, 0) + " idee misurate, nessuna ancora provata (non cambiano il rischio)\n";
   return "";
  }

string RdPanel() { return RdPanelPart(0) + RdPanelPart(1) + RdPanelPart(2); }

//--- report a fine test: per famiglia, le letture con abbastanza casi
void RdReport()
  {
   if(!InpReadOn || !InpReadLearn || g_rdTot <= 0.0)
      return;
   Print("LETTURA DEL MERCATO - idee seguite sulla carta: ", DoubleToString(g_rdTot, 0), " (R medio con la lettura a favore / contro)");
   for(int f = 0; f < NFAM; f++)
      for(int k = 0; k < NREAD; k++)
        {
         double nf = 0.0, sf = 0.0, na = 0.0, sa = 0.0;
         for(int p = 0; p < NPER; p++)
           {
            nf += g_rdN[RdIdx(f, k, 0, p)];
            sf += g_rdS[RdIdx(f, k, 0, p)];
            na += g_rdN[RdIdx(f, k, 1, p)];
            sa += g_rdS[RdIdx(f, k, 1, p)];
           }
         if(nf < 10.0 && na < 10.0)
            continue;
         Print("  ", g_famName[f], " | ", g_rdName[k], ": a favore ", DoubleToString(nf, 0), " idee ", (nf > 0.0 ? DoubleToString(sf / nf, 2) : "-"), "R, contro ",
               DoubleToString(na, 0), " idee ", (na > 0.0 ? DoubleToString(sa / na, 2) : "-"), "R -> ", RdStateName(g_rdState[f * NREAD + k]));
        }
   for(int k = 1; k < NSTRAT; k++)
     {
      double n = 0.0, sum = 0.0;
      for(int p = 0; p < NPER; p++)
        {
         n += g_stTN[k * NPER + p];
         sum += g_stTS[k * NPER + p];
        }
      if(n >= 10.0 && !IsProvenFam(k))
         Print("  ", g_stratName[k], " nel verso del trend giornaliero: ", DoubleToString(n, 0), " idee, ", DoubleToString(sum / n, 2), "R -> ", (g_stCond[k] ? "promosse" : "in prova"));
     }
  }
