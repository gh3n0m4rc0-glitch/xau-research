//+------------------------------------------------------------------+
//| AS (1.33): ASSORBIMENTO col delta vero del future GC              |
//| Il delta arriva da GCDeltaFeed (MetaTrader della demo AMP), che   |
//| scrive ogni minuto GC_delta.csv nella cartella comune. Quando     |
//| prezzo e delta vanno in versi opposti si segue il prezzo:         |
//|  2 ore (mossa > 0,15 ATR), 1 ora e 15 min con mossa efficiente.   |
//| Stop 0,5 ATR, target 1,5 ATR, uscita dopo 8 ore, venerdi' 23:45.  |
//| Magic proprio (base + 10): il resto del bot non vede queste       |
//| posizioni e non conta i loro soldi (equity, saldo, margine, stop  |
//| giornaliero/settimanale, drawdown): apre gli stessi trade e gli   |
//| stessi lotti della 1.32 (replay: 1.899 trade identici).           |
//| Senza file (o con InpAbsOn = false) il bot e' identico alla 1.32. |
//+------------------------------------------------------------------+
#define ABS_RING 20160                           // due settimane di minuti
#define ABS_MAXT 64
#define ABS_TAIL 1000000                         // dal vivo, al primo giro legge solo l'ultimo milione di byte (circa 17 giorni)

CTrade   g_absTrade;
long     g_absMin[ABS_RING];                     // minuto UTC (secondi/60) salvato nella cella
long     g_absVal[ABS_RING];                     // delta del minuto (acquisti - vendite aggressive)
long     g_absPos = 0;                           // punto del file gia' letto
long     g_absFirst = 0, g_absLast = 0;          // primo e ultimo minuto letti
datetime g_absDone15 = 0, g_absDone1h = 0;       // ultima barra M15/H1 gia' valutata (ora del server)
datetime g_abs2hSig = 0;                         // ultimo segnale 2 ore
datetime g_absLastBuy = 0, g_absLastSell = 0;    // ultimo trade per verso
int      g_absNSig = 0, g_absNOpen = 0, g_absNClosed = 0;
double   g_absSumR = 0.0;
string   g_absMsg = "";
long     g_absTId[ABS_MAXT];
double   g_absTRisk[ABS_MAXT];
string   g_absTName[ABS_MAXT];
int      g_absTDir[ABS_MAXT];
datetime g_absTTime[ABS_MAXT];
int      g_absNT = 0;

long AbsMagic() { return InpMagicBase + 10; }

//--- dichiarazioni (le funzioni sono scritte piu' sotto)
void   AbsReadFeed();
bool   AbsDelta(long a, long b, long &sum);
double AbsAtr();
double AbsTickRel(ENUM_TIMEFRAMES tf, datetime barTime, long barTicks);
void   AbsBar(ENUM_TIMEFRAMES tf, const MqlRates &bar, long a, long b, double atr, double moveMin, double effMax, string name);
void   AbsSignal(int dir, string name, double atr, string info);
string AbsOpen(int dir, double atr, string name);
double AbsLossPerLot(double dist);
double AbsLots(double lossPerLot);
void   AbsManage();
void   AbsRemember(int dir, string name, double riskMoney);
void   AbsCheckClosed();
void   AbsNote(string s);
string AbsFileName(string what);
void   AbsLog(string name, int dir, string info, string esito);
void   AbsLogTrade(datetime opened, string name, int dir, double net, double R);
void   AbsAccountRefresh();
double AbsEquity();
void   AbsFeedAlert();
bool   MarketShouldBeOpen(datetime utc);


void AbsInit()
  {
   for(int i = 0; i < ABS_RING; i++)
     {
      g_absMin[i] = -1;
      g_absVal[i] = 0;
     }
   g_absPos = 0;                                 // (anche dopo un cambio di grafico, quando MT5 non azzera le variabili)
   g_absFirst = 0;
   g_absLast = 0;
   g_absTrade.SetExpertMagicNumber((ulong)AbsMagic());
   g_absTrade.SetDeviationInPoints(30);
   g_absTrade.SetTypeFillingBySymbol(g_sym);
   if(g_isTester)                                // nel tester i registri ripartono da zero
     {
      int fh = FileOpen(AbsFileName("segnali"), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
      if(fh != INVALID_HANDLE)
         FileClose(fh);
      fh = FileOpen(AbsFileName("trade"), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
      if(fh != INVALID_HANDLE)
         FileClose(fh);
     }
   g_absDone15 = iTime(g_sym, PERIOD_M15, 1);
   g_absDone1h = iTime(g_sym, PERIOD_H1, 1);
   //--- al riavvio: posizioni gia' aperte (niente doppioni, esito in R alla chiusura senza il rischio iniziale)
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0 || !PositionSelectByTicket(tk))
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym || PositionGetInteger(POSITION_MAGIC) != AbsMagic())
         continue;
      datetime ot = (datetime)PositionGetInteger(POSITION_TIME);
      if(PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY)
        { if(ot > g_absLastBuy) g_absLastBuy = ot; }
      else
        { if(ot > g_absLastSell) g_absLastSell = ot; }
     }
  }

//--- 1.33: quanto dell'equity, del saldo e del margine e' dell'assorbimento (lo toglie il resto del bot)
ulong    g_absLastDeal = 0;                      // ultimo deal gia' contato
datetime g_absHistFrom = 0, g_absScanAt = 0;
double   g_absLastBal = -1.0;

void AbsAccountRefresh()
  {
   datetime now = ServerNow();
   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   if(bal != g_absLastBal)
      g_absPnlDirty = true;
   if(!g_isTester && now - g_absScanAt >= 60)      // dal vivo lo storico puo' arrivare un attimo dopo: ricontrollo ogni minuto
      g_absPnlDirty = true;
   if(g_absPnlDirty && HistorySelect(g_absHistFrom, now + 3600))
     {
      g_absPnlDirty = false;
      g_absLastBal = bal;
      g_absScanAt = now;
      ulong maxD = g_absLastDeal;
      int n = HistoryDealsTotal();
      for(int i = 0; i < n; i++)
        {
         ulong d = HistoryDealGetTicket(i);
         if(d == 0 || d <= g_absLastDeal)
            continue;
         if(d > maxD)
            maxD = d;
         if(HistoryDealGetInteger(d, DEAL_MAGIC) != AbsMagic() || HistoryDealGetString(d, DEAL_SYMBOL) != g_sym)
            continue;
         g_absClosed += HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_COMMISSION) +
                        HistoryDealGetDouble(d, DEAL_SWAP) + HistoryDealGetDouble(d, DEAL_FEE);
        }
      g_absLastDeal = maxD;
      g_absHistFrom = now - 86400;                // i deal nuovi hanno sempre un'ora recente
     }
   double flo = 0.0, mrg = 0.0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0 || !PositionSelectByTicket(tk))
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym || PositionGetInteger(POSITION_MAGIC) != AbsMagic())
         continue;
      flo += PositionGetDouble(POSITION_PROFIT) + PositionGetDouble(POSITION_SWAP);
      double m = 0.0;
      bool buy = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY);
      if(OrderCalcMargin(buy ? ORDER_TYPE_BUY : ORDER_TYPE_SELL, g_sym, PositionGetDouble(POSITION_VOLUME), PositionGetDouble(POSITION_PRICE_OPEN), m))
         mrg += m;
     }
   g_absPart = g_absClosed + flo;
   g_absMargin = mrg;
  }

//--- capitale su cui l'assorbimento calcola il rischio: quello del bot (anche virtuale) piu' il suo risultato
double AbsEquity() { return AccEquity() + g_absPart; }

long AbsNowMin() { return (long)ToUTC(ServerNow()) / 60; }

//--- legge le righe nuove del feed (solo minuti gia' passati)
datetime g_absReadAt = 0;

void AbsReadFeed()
  {
   datetime now = ServerNow();
   if(!g_isTester && now == g_absReadAt)         // dal vivo al massimo una lettura al secondo
      return;
   g_absReadAt = now;
   int h = FileOpen(InpAbsFile, FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ | FILE_SHARE_WRITE);
   if(h == INVALID_HANDLE)
      return;
   if((long)FileSize(h) < g_absPos)              // il feed ha ricominciato il file
      g_absPos = 0;
   long nowMin = AbsNowMin();
   if(g_absPos == 0 && !g_isTester && (long)FileSize(h) > 2 * ABS_TAIL)
     {
      FileSeek(h, (long)FileSize(h) - ABS_TAIL, SEEK_SET);
      FileReadString(h);                         // riga presa a meta': la salto
      g_absPos = (long)FileTell(h);
     }
   if(g_absPos > 0)
      FileSeek(h, g_absPos, SEEK_SET);
   while(!FileIsEnding(h))
     {
      string line = FileReadString(h);
      string f[];
      int nf = StringSplit(line, ';', f);
      if(nf < 6 || f[5] == "")
        {
         if(FileIsEnding(h))
            break;                               // ultima riga ancora a meta' (il feed la sta scrivendo): la rileggo dopo
         g_absPos = (long)FileTell(h);
         continue;
        }
      if(f[0] == "utc")
        {
         g_absPos = (long)FileTell(h);
         continue;
        }
      datetime t = StringToTime(f[0]);
      if(t <= 0)
        {
         g_absPos = (long)FileTell(h);
         continue;
        }
      long mn = (long)t / 60;
      if(mn > nowMin)                            // riga nel futuro (solo nel tester): la riprendo piu' avanti
         break;
      int k = (int)(mn % ABS_RING);
      g_absMin[k] = mn;
      g_absVal[k] = StringToInteger(f[1]) - StringToInteger(f[2]);
      if(g_absFirst == 0)
         g_absFirst = mn;
      if(mn > g_absLast)
         g_absLast = mn;
      g_absPos = (long)FileTell(h);
     }
   FileClose(h);
  }

//--- somma del delta nei minuti [a, b]; false se il feed non copre la finestra
bool AbsDelta(long a, long b, long &sum)
  {
   sum = 0;
   if(g_absFirst == 0 || g_absFirst > a || g_absLast < b)
      return false;
   int miss = 0;
   for(long mn = a; mn <= b; mn++)
     {
      int k = (int)(mn % ABS_RING);
      if(g_absMin[k] == mn)
         sum += g_absVal[k];
      else
         miss++;
     }
   return (miss <= InpAbsMaxHoleMin);
  }

//--- avviso sul telefono se il feed, dopo aver funzionato, si ferma a mercato aperto (demo AMP scaduta, MetaTrader AMP chiuso)
datetime g_absAlertAt = 0;

void AbsFeedAlert()
  {
   if(g_isTester || g_absLast == 0)
      return;
   datetime srv = ServerNow();
   long age = AbsNowMin() - g_absLast;
   if(age >= 30 && MarketShouldBeOpen(ToUTC(srv)) && srv - g_absAlertAt >= 6 * 3600)
     {
      g_absAlertAt = srv;
      Notify("Assorbimento fermo: il delta del future GC non arriva da " + IntegerToString((int)age) +
             " minuti. Controlla il MetaTrader di AMP e GCDeltaFeed (demo scaduta?). Il resto del bot lavora normale");
     }
  }

//--- ATR giornaliero: media max-min degli ultimi 14 giorni chiusi
double AbsAtr()
  {
   MqlRates r[];
   if(CopyRates(g_sym, PERIOD_D1, 1, 14, r) < 14)
      return 0.0;
   double s = 0.0;
   for(int i = 0; i < 14; i++)
      s += r[i].high - r[i].low;
   return s / 14.0;
  }

//--- tick della barra diviso la mediana dei tick della stessa ora negli ultimi 20 giorni
double AbsTickRel(ENUM_TIMEFRAMES tf, datetime barTime, long barTicks)
  {
   int perDay = (tf == PERIOD_M15) ? 96 : 24;
   MqlRates r[];
   int n = CopyRates(g_sym, tf, 2, perDay * 30, r);
   if(n <= 0)
      return -1.0;
   int slot = (int)(barTime % 86400);
   datetime day0 = barTime - slot;
   double v[];
   int k = 0;
   for(int i = n - 1; i >= 0 && k < 20; i--)
     {
      if((int)(r[i].time % 86400) != slot || r[i].time >= day0)
         continue;
      ArrayResize(v, k + 1);
      v[k] = (double)r[i].tick_volume;
      k++;
     }
   if(k < 5)
      return -1.0;
   ArraySort(v);
   double med = (k % 2 == 1) ? v[k / 2] : 0.5 * (v[k / 2 - 1] + v[k / 2]);
   if(med <= 0.0)
      return -1.0;
   return (double)barTicks / med;
  }

//--- a ogni tick e a ogni timer
void AbsWork()
  {
   if(!InpAbsOn)
      return;
   AbsReadFeed();
   AbsFeedAlert();
   AbsManage();
   AbsCheckClosed();
   if(g_absFirst == 0)
      return;                                    // nessun feed: niente da valutare
   datetime now = ServerNow();
   //--- H1: regola 2 ore e variante 1 ora
   datetime t1 = iTime(g_sym, PERIOD_H1, 1);
   if(t1 > 0 && t1 != g_absDone1h)
     {
      long b = (long)ToUTC(t1 + 3600) / 60 - 1;  // ultimo minuto della barra appena chiusa
      if(g_absLast < b && now - (t1 + 3600) < InpAbsMaxWaitMin * 60)
         return;                                 // aspetto il delta dell'ultimo minuto
      g_absDone1h = t1;
      MqlRates r[];
      double atr = AbsAtr();
      if(atr > 0.0 && CopyRates(g_sym, PERIOD_H1, 1, 3, r) == 3)
        {
         if(InpAbsUse2h && r[0].time == t1 - 2 * 3600 && (g_abs2hSig == 0 || t1 - g_abs2hSig >= 2 * 3600))
           {
            double mv = r[2].close - r[0].close;
            long d = 0;
            bool ok = AbsDelta(b - 119, b, d);
            if(ok && d != 0 && MathAbs(mv) > InpAbsMove2h * atr && ((d > 0) != (mv > 0)))
              {
               g_abs2hSig = t1;
               AbsSignal(mv > 0 ? 1 : -1, "2 ore", atr, StringFormat("mossa %.2f ATR, delta %d", mv / atr, (int)d));
              }
            else
               if(!ok)
                  AbsNote("2 ore: feed non completo, salto");
           }
         if(InpAbsUse1h)
            AbsBar(PERIOD_H1, r[2], b - 59, b, atr, InpAbsMove1h, InpAbsEff1h, "1 ora");
        }
     }
   //--- M15: variante 15 minuti
   datetime t15 = iTime(g_sym, PERIOD_M15, 1);
   if(t15 > 0 && t15 != g_absDone15)
     {
      long b = (long)ToUTC(t15 + 900) / 60 - 1;
      if(g_absLast < b && now - (t15 + 900) < InpAbsMaxWaitMin * 60)
         return;
      g_absDone15 = t15;
      MqlRates r[];
      double atr = AbsAtr();
      if(InpAbsUse15m && atr > 0.0 && CopyRates(g_sym, PERIOD_M15, 1, 1, r) == 1)
         AbsBar(PERIOD_M15, r[0], b - 14, b, atr, InpAbsMove15m, InpAbsEff15m, "15 min");
     }
  }

//--- una barra: movimento netto, delta contrario, movimento fatto con pochi tick
void AbsBar(ENUM_TIMEFRAMES tf, const MqlRates &bar, long a, long b, double atr, double moveMin, double effMax, string name)
  {
   double mv = (bar.close - bar.open) / atr;
   if(MathAbs(mv) <= moveMin)
      return;
   long d = 0;
   if(!AbsDelta(a, b, d))
     {
      AbsNote(name + ": feed non completo, salto");
      return;
     }
   if(d == 0 || ((d > 0) == (mv > 0)))
      return;
   double tr = AbsTickRel(tf, bar.time, bar.tick_volume);
   if(tr < 0.0)
      return;
   double eff = tr / MathAbs(mv);
   if(eff > effMax)
      return;
   AbsSignal(mv > 0 ? 1 : -1, name, atr, StringFormat("mossa %.2f ATR, delta %d, tick rel %.2f, efficienza %.2f", mv, (int)d, tr, eff));
  }

//--- segnale: niente doppioni nello stesso verso, poi il trade
void AbsSignal(int dir, string name, double atr, string info)
  {
   g_absNSig++;
   datetime now = ServerNow();
   datetime last = (dir > 0) ? g_absLastBuy : g_absLastSell;
   string esito;
   if(last > 0 && now - last < InpAbsGapMin * 60)
      esito = "doppione (trade nello stesso verso da meno di " + IntegerToString(InpAbsGapMin) + " min)";
   else
     {
      esito = AbsOpen(dir, atr, name);
      if(StringFind(esito, "aperto") == 0)
        {
         g_absNOpen++;
         if(dir > 0) g_absLastBuy = now; else g_absLastSell = now;
        }
     }
   string msg = "ASSORBIMENTO " + name + (dir > 0 ? " BUY" : " SELL") + ": " + info + " -> " + esito;
   g_absMsg = TimeToString(now, TIME_DATE | TIME_MINUTES) + " " + name + (dir > 0 ? " BUY " : " SELL ") + StringSubstr(esito, 0, 60);
   if(!g_isTester)
      Print(msg);
   AbsLog(name, dir, info, esito);
  }

string AbsOpen(int dir, double atr, string name)
  {
   string why = "";
   if(TradingHalted(why))
      return "saltato: bot fermo (" + StringSubstr(why, 0, 60) + ")";
   MqlTick tk;
   if(!SymbolInfoTick(g_sym, tk))
      return "saltato: niente prezzo";
   MqlDateTime dt;
   TimeToStruct(ServerNow(), dt);
   if(dt.day_of_week == 5 && dt.hour >= 23)
      return "saltato: venerdi' sera";
   double spread = tk.ask - tk.bid;
   if(spread > InpAbsMaxSpread)
      return "saltato: spread " + DoubleToString(spread, 2);
   double price = (dir > 0) ? tk.ask : tk.bid;
   double dist = InpAbsStopAtr * atr;
   double lossPerLot = AbsLossPerLot(dist);
   double lots = AbsLots(lossPerLot);
   if(lots <= 0.0)
      return "saltato: lotto minimo oltre il rischio massimo";
   double need = 0.0;
   if(OrderCalcMargin(dir > 0 ? ORDER_TYPE_BUY : ORDER_TYPE_SELL, g_sym, lots, price, need) &&
      AccountInfoDouble(ACCOUNT_MARGIN_FREE) - need < InpAbsKeepFreeMargin / 100.0 * AccountInfoDouble(ACCOUNT_EQUITY))
      return "saltato: margine da lasciare al resto del bot";
   double sl = NormalizeDouble(price - dir * dist, g_digits);
   double tp = NormalizeDouble(price + dir * InpAbsTargetAtr * atr, g_digits);
   bool ok = (dir > 0) ? g_absTrade.Buy(lots, g_sym, 0.0, sl, tp, "ASSORB " + name)
                       : g_absTrade.Sell(lots, g_sym, 0.0, sl, tp, "ASSORB " + name);
   if(!ok)
      return "saltato: ordine rifiutato (" + IntegerToString((int)g_absTrade.ResultRetcode()) + ")";
   AbsRemember(dir, name, lots * lossPerLot);
   return "aperto " + DoubleToString(lots, 2) + " lotti, stop " + DoubleToString(sl, g_digits) + ", target " + DoubleToString(tp, g_digits);
  }

double AbsLossPerLot(double dist)
  {
   double tv = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_VALUE);
   double ts = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_SIZE);
   if(tv <= 0.0 || ts <= 0.0)
      return 0.0;
   return dist / ts * tv;
  }

double AbsLots(double lossPerLot)
  {
   double step = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_STEP);
   double vmin = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_MIN);
   double vmax = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_MAX);
   if(lossPerLot <= 0.0 || step <= 0.0)
      return 0.0;
   double eq = AbsEquity();
   double lots = MathFloor(eq * InpAbsRiskPct / 100.0 / lossPerLot / step) * step;
   if(lots < vmin)
     {
      if(vmin * lossPerLot <= eq * InpAbsMinLotMaxRisk / 100.0)
         lots = vmin;
      else
         return 0.0;
     }
   return MathMin(lots, vmax);
  }

//--- uscita dopo InpAbsMaxMinutes e il venerdi' sera prima della chiusura
void AbsManage()
  {
   datetime now = ServerNow();
   MqlDateTime dt;
   TimeToStruct(now, dt);
   bool friLate = (dt.day_of_week == 5 && dt.hour == 23 && dt.min >= 45);
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0 || !PositionSelectByTicket(tk))
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym || PositionGetInteger(POSITION_MAGIC) != AbsMagic())
         continue;
      datetime ot = (datetime)PositionGetInteger(POSITION_TIME);
      if(now - ot >= InpAbsMaxMinutes * 60 || friLate)
         g_absTrade.PositionClose(tk);
     }
  }

//--- la posizione appena aperta (quella del magic assorbimento che non e' ancora in tabella)
void AbsRemember(int dir, string name, double riskMoney)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0 || !PositionSelectByTicket(tk))
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym || PositionGetInteger(POSITION_MAGIC) != AbsMagic())
         continue;
      long id = PositionGetInteger(POSITION_IDENTIFIER);
      bool known = false;
      for(int k = 0; k < g_absNT; k++)
         if(g_absTId[k] == id)
            known = true;
      if(known || g_absNT >= ABS_MAXT)
         continue;
      g_absTId[g_absNT] = id;
      g_absTRisk[g_absNT] = riskMoney;
      g_absTName[g_absNT] = name;
      g_absTDir[g_absNT] = dir;
      g_absTTime[g_absNT] = (datetime)PositionGetInteger(POSITION_TIME);
      g_absNT++;
      return;
     }
  }

//--- posizioni chiuse: esito in R nel registro
void AbsCheckClosed()
  {
   for(int k = g_absNT - 1; k >= 0; k--)
     {
      bool open = false;
      for(int i = PositionsTotal() - 1; i >= 0; i--)
        {
         ulong tk = PositionGetTicket(i);
         if(tk > 0 && PositionSelectByTicket(tk) && PositionGetInteger(POSITION_IDENTIFIER) == g_absTId[k])
            open = true;
        }
      if(open)
         continue;
      if(!HistorySelectByPosition(g_absTId[k]))
         continue;
      double net = 0.0;
      int nd = HistoryDealsTotal();
      for(int j = 0; j < nd; j++)
        {
         ulong dt = HistoryDealGetTicket(j);
         if(dt == 0)
            continue;
         net += HistoryDealGetDouble(dt, DEAL_PROFIT) + HistoryDealGetDouble(dt, DEAL_COMMISSION) + HistoryDealGetDouble(dt, DEAL_SWAP);
        }
      double R = (g_absTRisk[k] > 0.0) ? net / g_absTRisk[k] : 0.0;
      g_absSumR += R;
      g_absNClosed++;
      AbsLogTrade(g_absTTime[k], g_absTName[k], g_absTDir[k], net, R);
      for(int j = k; j < g_absNT - 1; j++)
        {
         g_absTId[j] = g_absTId[j + 1];
         g_absTRisk[j] = g_absTRisk[j + 1];
         g_absTName[j] = g_absTName[j + 1];
         g_absTDir[j] = g_absTDir[j + 1];
         g_absTTime[j] = g_absTTime[j + 1];
        }
      g_absNT--;
     }
  }

void AbsNote(string s) { g_absMsg = TimeToString(ServerNow(), TIME_DATE | TIME_MINUTES) + " " + s; }

string AbsFileName(string what) { return g_isTester ? "XauCommittee_tester_assorb_" + what + ".csv" : "XauCommittee_assorb_" + what + ".csv"; }

void AbsLog(string name, int dir, string info, string esito)
  {
   int h = FileOpen(AbsFileName("segnali"), FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return;
   if(FileSize(h) == 0)
      FileWriteString(h, "ora_server;regola;verso;letture;esito\r\n");
   FileSeek(h, 0, SEEK_END);
   FileWriteString(h, TimeToString(ServerNow(), TIME_DATE | TIME_MINUTES) + ";" + name + ";" + (dir > 0 ? "BUY" : "SELL") + ";" + info + ";" + esito + "\r\n");
   FileClose(h);
  }

void AbsLogTrade(datetime opened, string name, int dir, double net, double R)
  {
   int h = FileOpen(AbsFileName("trade"), FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return;
   if(FileSize(h) == 0)
      FileWriteString(h, "apertura;chiusura;regola;verso;netto;R\r\n");
   FileSeek(h, 0, SEEK_END);
   FileWriteString(h, TimeToString(opened, TIME_DATE | TIME_MINUTES) + ";" + TimeToString(ServerNow(), TIME_DATE | TIME_MINUTES) + ";" +
                   name + ";" + (dir > 0 ? "BUY" : "SELL") + ";" + DoubleToString(net, 2) + ";" + DoubleToString(R, 3) + "\r\n");
   FileClose(h);
  }

//--- riga del pannello
string AbsPanel()
  {
   if(!InpAbsOn)
      return "";
   long age = AbsNowMin() - g_absLast;
   string feed = (g_absLast == 0) ? "nessun dato (serve GCDeltaFeed sulla demo AMP)" : (age <= 2 ? "ok" : "fermo da " + IntegerToString((int)age) + " min");
   string t = "Assorbimento: feed " + feed + " | trade " + IntegerToString(g_absNOpen) + ", chiusi " + IntegerToString(g_absNClosed) +
              " (" + DoubleToString(g_absSumR, 1) + "R)";
   if(g_absMsg != "")
      t += " | " + StringSubstr(g_absMsg, 0, 90);
   return t + "\n";
  }
//+------------------------------------------------------------------+
