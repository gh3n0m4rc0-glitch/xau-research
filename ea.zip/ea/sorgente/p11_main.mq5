//+------------------------------------------------------------------+
//| Motori, pannello, eventi MT5                                     |
//+------------------------------------------------------------------+
void CtxUpdate()
  {
   g_ctx.bid = PxBid();
   g_ctx.ask = PxAsk();
   g_ctx.spread = MathMax(g_ctx.ask - g_ctx.bid, 0.0);
   g_ctx.atrM1 = AtrOf(g_m1);
   g_ctx.atrM5 = AtrOf(g_m5);
   g_ctx.atrM15 = AtrOf(g_m15);
   g_ctx.atrH1 = AtrOf(g_h1);
   g_ctx.atrH4 = AtrOf(g_h4);
   g_ctx.atrD1 = AtrOf(g_d1);
   g_ctx.vwap = VwapVal(g_vwD);
   g_ctx.vwSig = VwapSigma(g_vwD);
   g_ctx.wvwap = VwapVal(g_vwW);
   g_ctx.nowSrv = TimeCurrent();
   g_ctx.nowUtc = ToUTC(g_ctx.nowSrv);
   g_ctx.hUtc = HourOf(g_ctx.nowUtc);
   g_ctx.lonOpen = LondonOpenUTC(g_ctx.nowUtc);
   g_ctx.nyData = NYDataUTC(g_ctx.nowUtc);
   g_ctx.nyOpen = NYOpenUTC(g_ctx.nowUtc);
   g_ctx.nyClose = NYCloseUTC(g_ctx.nowUtc);
   g_ctx.dow = DowOf(g_ctx.nowUtc);
  }

//--- finestre operative dei motori (UTC, con ora legale)
bool InRollover()
  {
   double h = g_ctx.hUtc, c = g_ctx.nyClose;
   double d = h - c;
   if(d < -12.0)
      d += 24.0;
   return (d >= -0.25 && d <= 1.25);
  }

bool EngineWindow(int e)
  {
   double h = g_ctx.hUtc;
   int dow = g_ctx.dow;
   if(dow == 0 || dow == 6 || InRollover())
      return false;
   if(dow == 5 && h >= 18.0)
      return false;
   if(e == ENG_SCALP)
     {
      bool lon = (h >= g_ctx.lonOpen && h < g_ctx.lonOpen + 3.0);
      bool ny = (h >= g_ctx.nyData - 0.25 && h < g_ctx.nyOpen + 2.5);
      return ((lon || ny) && h < InpIntraCloseUTC - 0.5);
     }
   if(e == ENG_INTRA)
      return (h >= g_ctx.lonOpen && h < InpIntraCloseUTC - 1.0);
   if(dow == 1 && h < 2.0)
      return false;
   return true;
  }

bool EngineEnabled(int e)
  {
   if(e == ENG_SCALP)
      return InpEnableScalping;
   if(e == ENG_INTRA)
      return InpEnableIntraday;
   return InpEnableSwing;
  }

string DecisionLine(const TSignal &s)
  {
   string verdict = s.passed ? "APPROVATO" : "RESPINTO";
   string t = "[" + g_engName[s.engine] + "] " + g_stratName[s.strat] + " " + DirName(s.dir) +
              " score " + DoubleToString(s.score, 2) + " quorum " + IntegerToString(s.quorum) + "/8 diavolo " +
              IntegerToString(s.devil) + " -> " + verdict;
   if(s.veto)
      t += " (" + s.vetoWhy + ")";
   return t;
  }

//--- valuta i segnali di un motore e esegue il migliore approvato
void RunEngine(int e, TSignal &cands[], int n)
  {
   int best = -1;
   for(int i = 0; i < n; i++)
     {
      SignalAdjust(cands[i]);
      Committee(cands[i]);
      string line = DecisionLine(cands[i]);
      if(cands[i].passed)
        {
         if(best < 0 || cands[i].score > cands[best].score)
            best = i;
        }
      if(InpVerboseLog)
         Logf(line + " | " + DeskLine(cands[i]) + " | " + cands[i].why);
      if(!cands[i].passed)
         RememberDecision(line);
     }
   if(best < 0)
      return;
   Logf(DecisionLine(cands[best]) + " | " + cands[best].why + " | " + DeskLine(cands[best]));
   Execute(cands[best]);
  }

void AddCand(TSignal &cands[], int &n, const TSignal &s)
  {
   ArrayResize(cands, n + 1);
   SigCopy(cands[n], s);
   n++;
  }

void EvalScalping()
  {
   if(!EngineEnabled(ENG_SCALP) || !EngineWindow(ENG_SCALP))
      return;
   TSignal cands[];
   int n = 0;
   TSignal s;
   if(StratEnabled(ST_SC_VWAP) && S_ScVwap(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_SC_SWEEP) && S_ScSweep(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_SC_ORB) && S_ScOrb(s))
      AddCand(cands, n, s);
   if(n > 0)
      RunEngine(ENG_SCALP, cands, n);
  }

void EvalIntraday(bool newM15)
  {
   if(!EngineEnabled(ENG_INTRA) || !EngineWindow(ENG_INTRA))
     {
      g_vaNewM15 = false;
      return;
     }
   TSignal cands[];
   int n = 0;
   TSignal s;
   if(StratEnabled(ST_IN_PULLBACK) && S_InPullback(s))
      AddCand(cands, n, s);
   if(newM15 && StratEnabled(ST_IN_SWEEP) && S_InSweep(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_BREAKOUT) && S_InBreakout(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_VALUE) && S_InValue(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_NEWS) && S_InNews(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_RANGE) && S_InRange(s))
      AddCand(cands, n, s);
   g_vaNewM15 = false;
   if(n > 0)
      RunEngine(ENG_INTRA, cands, n);
  }

void EvalSwing()
  {
   if(!EngineEnabled(ENG_SWING) || !EngineWindow(ENG_SWING))
      return;
   TSignal cands[];
   int n = 0;
   TSignal s;
   if(StratEnabled(ST_SW_TREND) && S_SwTrend(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_SW_WYCKOFF) && S_SwWyckoff(s))
      AddCand(cands, n, s);
   if(n > 0)
      RunEngine(ENG_SWING, cands, n);
  }

//+------------------------------------------------------------------+
//| Pannello sul grafico                                             |
//+------------------------------------------------------------------+
string EngineStatus(int e)
  {
   if(!EngineEnabled(e))
      return g_engName[e] + ": spento";
   double slPx = (e == ENG_SCALP) ? g_ctx.atrM5 : ((e == ENG_INTRA) ? g_ctx.atrM15 : g_ctx.atrH4);
   double base = BaseCapital();
   if(slPx > 0.0 && base > 0.0)
     {
      double lpl = LossPerLot(1, g_ctx.ask, g_ctx.ask - slPx);
      double minRisk = lpl * g_minLot;
      double pct = 100.0 * minRisk / base;
      if(pct > InpMinLotMaxRiskPct)
         return g_engName[e] + ": in attesa (serve conto ~" + DoubleToString(minRisk * 100.0 / InpMinLotMaxRiskPct, 0) + " " + g_currency + ")";
     }
   return g_engName[e] + (EngineWindow(e) ? ": attivo" : ": fuori orario");
  }

string SessionName()
  {
   double h = g_ctx.hUtc;
   if(InRollover())
      return "rollover";
   if(h < g_ctx.lonOpen)
      return "Asia";
   if(h < g_ctx.nyData)
      return "Londra";
   if(h < g_ctx.nyClose - 4.0)
      return "Londra+New York";
   return "New York";
  }

void Panel()
  {
   if(g_isOptim)
      return;
   double eq = AccEquity();
   double dayPct = (g_dayStartEq > 0.0) ? 100.0 * (eq / g_dayStartEq - 1.0) : 0.0;
   double weekPct = (g_weekStartEq > 0.0) ? 100.0 * (eq / g_weekStartEq - 1.0) : 0.0;
   double dd = (g_peakEq > 0.0) ? 100.0 * (1.0 - eq / g_peakEq) : 0.0;
   string why = "";
   string st = TradingHalted(why) ? "FERMO - " + why : "operativo";
   string macro = MacroText();
   if(AiFresh())
      macro += " | comitato AI: " + g_aiStance + " " + DoubleToString(g_aiConv, 2);
   int k = NextTier1Index(g_ctx.nowUtc);
   string nx = "nessuna nelle prossime 36 ore";
   if(k >= 0)
      nx = g_news[k].title + " alle " + TimeToString(g_news[k].utc, TIME_MINUTES) + " UTC (tra " + IntegerToString(MinutesToNextTier1(g_ctx.nowUtc)) + " min)";
   PortfolioScan();
   string txt = "XAU COMMITTEE EA " + g_version + "  [" + g_sym + "]" + (g_netting ? "  ATTENZIONE: conto netting (1 posizione)" : "") + "\n";
   txt += "Stato: " + st + "\n";
   if(InpVirtualCapital > 0.0)
      txt += "Capitale virtuale " + Money(InpVirtualCapital) + " (conto vero " + Money(AccountInfoDouble(ACCOUNT_EQUITY)) + "): lotti e limiti calcolati sul virtuale\n";
   txt += "Equity " + Money(eq) + " | oggi " + DoubleToString(dayPct, 2) + "% | settimana " + DoubleToString(weekPct, 2) + "% | drawdown " + DoubleToString(dd, 1) + "%\n";
   txt += "Regime H1: " + g_regName[g_regime] + " | sessione: " + SessionName() + " | spread " + DoubleToString(g_ctx.spread, g_digits) + "\n";
   txt += "Macro: " + macro + "\n";
   if(g_extraText != "" && StringFind(g_mSource, "GitHub") >= 0)
      txt += "Extra (solo info): " + StringSubstr(g_extraText, 0, 160) + "\n";
   if(g_lastDataText != "" && g_lastDataTime > 0 && g_ctx.nowUtc - g_lastDataTime <= 6 * 3600)
      txt += "Dopo il dato: " + g_lastDataText + "\n";
   txt += "Contesto: " + g_ctxText + "\n";
   txt += "Favoriti adesso: " + FavoredText() + "\n";
   txt += "Prossima news forte: " + nx + "\n";
   txt += EngineStatus(ENG_SCALP) + " | " + EngineStatus(ENG_INTRA) + " | " + EngineStatus(ENG_SWING) + "\n";
   txt += "Posizioni " + IntegerToString(g_cntAll) + "/" + IntegerToString(MaxPositionsEff()) + " | rischio aperto " + Money(g_openRiskMoney) +
          " | serie perdite " + IntegerToString(g_lossStreak) + (g_recoveryArmed ? " | recupero pronto" : "") +
          ((g_reArmed[0] || g_reArmed[1] || g_reArmed[2]) ? " | rientro pronto" : "") + "\n";
   txt += "Ultime decisioni:\n";
   for(int i = 0; i < 6; i++)
     {
      int idx = (g_lastDecisionHead - 1 - i + 12) % 6;
      if(g_lastDecision[idx] != "")
         txt += "  " + StringSubstr(g_lastDecision[idx], 0, 150) + "\n";
     }
   Comment(txt);
  }

//+------------------------------------------------------------------+
//| Report statistico (tester e chiusura EA)                         |
//+------------------------------------------------------------------+
string StatRow(string name, const StratStat &st)
  {
   return name + ": trade " + IntegerToString(st.n) + " | win " + DoubleToString(st.WinRate(), 1) + "% | aspettativa " +
          DoubleToString(st.Expectancy(), 2) + "R | PF " + DoubleToString(st.ProfitFactor(), 2) + " | netto " + DoubleToString(st.net, 2);
  }

void PrintReport()
  {
   if(g_isOptim)
      return;
   Print("===== REPORT XAU COMMITTEE (per strategia) =====");
   for(int k = 1; k < NSTRAT; k++)
      if(g_rep[k].n > 0)
         Print(StatRow(g_stratName[k], g_rep[k]));
   for(int e = 0; e < 3; e++)
      if(g_es[e].n > 0)
         Print(StatRow("MOTORE " + g_engName[e], g_es[e]));
   Print(StatRow("TOTALE", g_all));
   if(!g_isTester)
      return;
   int h = FileOpen("XauCommittee_tester_report.csv", FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   FileWriteString(h, "strategia;trade;win%;aspettativa_R;profit_factor;netto\r\n");
   for(int k = 1; k < NSTRAT; k++)
      FileWriteString(h, g_stratName[k] + ";" + IntegerToString(g_rep[k].n) + ";" + DoubleToString(g_rep[k].WinRate(), 1) + ";" +
                      DoubleToString(g_rep[k].Expectancy(), 3) + ";" + DoubleToString(g_rep[k].ProfitFactor(), 2) + ";" + DoubleToString(g_rep[k].net, 2) + "\r\n");
   FileClose(h);
  }

//+------------------------------------------------------------------+
//| Eventi                                                           |
//+------------------------------------------------------------------+
//--- briefing giornaliero: il quadro che il comitato usa per tutto il giorno
datetime g_lastBriefing = 0;

void Briefing()
  {
   if(g_isOptim)
      return;
   datetime d = iTime(g_sym, PERIOD_D1, 0);
   if(d == g_lastBriefing)
      return;
   g_lastBriefing = d;
   double tot = Clamp(0.5 * g_ctxBias + 0.5 * g_mBias * Clamp(g_mConf * 1.4, 0.0, 1.0), -1.0, 1.0);
   string verso = (tot > 0.25) ? "preferenza LONG" : ((tot < -0.25) ? "preferenza SHORT" : "nessuna direzione netta: solo setup molto puliti");
   string msg = "BRIEFING ORO " + TimeToString(TimeCurrent(), TIME_DATE) + "\n" +
                "Contesto: " + g_ctxText + "\n" +
                "Macro: " + MacroText() + "\n" +
                (g_extraText != "" ? "Extra (solo info): " + g_extraText + "\n" : "") +
                "Quadro: " + verso + " (" + DoubleToString(tot, 2) + ") | favoriti: " + FavoredText() + "\n" +
                "Motori del prezzo: " + RunBrakeText();
   Logf(msg);
   if(InpPushNotify && !g_isTester)
      SendNotification(StringSubstr("Oro: " + verso + " | " + FavoredText(), 0, 250));
  }

void OnNewM1(datetime m1open)
  {
   MicroFinalize();
   g_tkDelta = 0.0;
   g_tkCount = 0.0;
   g_tkBarOpen = m1open;
   g_m1.lastOpen = m1open;
   TfRefresh(g_m1);
   bool n5 = TfNewBar(g_m5);
   bool n15 = TfNewBar(g_m15);
   bool nh1 = TfNewBar(g_h1);
   bool nh4 = TfNewBar(g_h4);
   bool nd1 = TfNewBar(g_d1);
   bool nw1 = TfNewBar(g_w1);
   if(n5)
      TfRefresh(g_m5);
   if(n15)
      TfRefresh(g_m15);
   if(nh1)
      TfRefresh(g_h1);
   if(nh4)
      TfRefresh(g_h4);
   if(nd1)
     {
      TfRefresh(g_d1);
      UpdateWeekly();
     }
   if(nw1)
      TfRefresh(g_w1);
   if(nh1)
     {
      UpdateGmtOffset();
      UpdateRegime();
     }
   if(nh4 || nd1)
     {
      UpdateContext();
      IntermarketUpdate();
     }
   if(nh1 || nh4 || nd1)
      MacroCombine();
   CtxUpdate();
   RunBrakeUpdate();
   if(g_isTester)
      TesterNewsRefresh(g_ctx.nowUtc);
   //--- barra M1 appena chiusa -> VWAP del giorno e sessioni
   datetime dAnchor = iTime(g_sym, PERIOD_D1, 0);
   int i1 = TfIdx(g_m1, 0);
   if(i1 >= 0)
     {
      VwapFeed(g_vwD, dAnchor, g_m1.r[i1].time, g_m1.r[i1].high, g_m1.r[i1].low, g_m1.r[i1].close, (double)g_m1.r[i1].tick_volume);
      SessFeed(g_m1.r[i1].time, g_m1.r[i1].high, g_m1.r[i1].low);
     }
   if(n5)
     {
      int i5 = TfIdx(g_m5, 0);
      if(i5 >= 0)
        {
         RvolAdd(g_m5.r[i5].time, (double)g_m5.r[i5].tick_volume);
         ProfileFeed(dAnchor, g_m5.r[i5].time, g_m5.r[i5].low, g_m5.r[i5].high, (double)g_m5.r[i5].tick_volume);
         VwapFeed(g_vwW, iTime(g_sym, PERIOD_W1, 0), g_m5.r[i5].time, g_m5.r[i5].high, g_m5.r[i5].low, g_m5.r[i5].close, (double)g_m5.r[i5].tick_volume);
        }
     }
   CtxUpdate();
   if(n5)
     {
      NewsTrack();
      BuildLevels();
     }
   if(n15)
     {
      BrkOnM15();
      ValueOnM15();
     }
   RiskPeriodCheck();
   MetaSweep();
   if(nd1)
      Briefing();
   if(!DataReady())
      return;
   string why = "";
   if(TradingHalted(why))
      return;
   EvalScalping();
   if(n5)
      EvalIntraday(n15);
   if(nh1)
      EvalSwing();
  }

int OnInit()
  {
   g_isTester = (MQLInfoInteger(MQL_TESTER) != 0);
   g_isOptim = (MQLInfoInteger(MQL_OPTIMIZATION) != 0);
   g_isVisual = (MQLInfoInteger(MQL_VISUAL_MODE) != 0);
   g_sym = (InpSymbolOverride != "") ? InpSymbolOverride : _Symbol;
   if(!SymbolSelect(g_sym, true))
     {
      Print("Simbolo non trovato: ", g_sym);
      return INIT_FAILED;
     }
   if(InpRiskPercent <= 0.0 || InpRiskPercent > 10.0 || InpMinRR < 1.0 || InpBE_R <= 0.0 || InpMaxPositions < 1 ||
      InpDailyLossPct <= 0.0 || InpWeeklyLossPct <= 0.0 || InpMaxDrawdownPct <= 0.0 || InpMaxDrawdownPct > 100.0)
     {
      Print("Parametri non validi: controlla rischio, R:R, pareggio e limiti");
      return INIT_PARAMETERS_INCORRECT;
     }
   g_point = SymbolInfoDouble(g_sym, SYMBOL_POINT);
   g_tick = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_SIZE);
   if(g_tick <= 0.0)
      g_tick = g_point;
   g_digits = (int)SymbolInfoInteger(g_sym, SYMBOL_DIGITS);
   g_minLot = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_MIN);
   g_maxLot = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_MAX);
   g_lotStep = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_STEP);
   g_contract = SymbolInfoDouble(g_sym, SYMBOL_TRADE_CONTRACT_SIZE);
   g_lotDigits = (g_lotStep >= 1.0) ? 0 : ((g_lotStep >= 0.1) ? 1 : ((g_lotStep >= 0.01) ? 2 : 3));
   g_currency = AccountInfoString(ACCOUNT_CURRENCY);
   g_login = AccountInfoInteger(ACCOUNT_LOGIN);
   g_netting = (AccountInfoInteger(ACCOUNT_MARGIN_MODE) != ACCOUNT_MARGIN_MODE_RETAIL_HEDGING);
   string up = g_sym;
   StringToUpper(up);
   if(StringFind(up, "XAU") < 0 && StringFind(up, "GOLD") < 0)
      Print("ATTENZIONE: ", g_sym, " non sembra l'oro. L'EA e' pensato per XAUUSD.");
   g_trade.SetDeviationInPoints((ulong)MathMax(10.0, MathRound(0.30 / MathMax(g_point, 0.00001))));
   g_trade.SetTypeFillingBySymbol(g_sym);
   g_trade.LogLevel(LOG_LEVEL_ERRORS);
   UpdateGmtOffset();
   TfInit(g_m1, PERIOD_M1, 240);
   TfInit(g_m5, PERIOD_M5, 400);
   TfInit(g_m15, PERIOD_M15, 400);
   TfInit(g_h1, PERIOD_H1, 400);
   TfInit(g_h4, PERIOD_H4, 300);
   TfInit(g_d1, PERIOD_D1, 160);
   TfInit(g_w1, PERIOD_W1, 150);
   TfNewBar(g_m1);
   TfNewBar(g_m5);
   TfNewBar(g_m15);
   TfNewBar(g_h1);
   TfNewBar(g_h4);
   TfNewBar(g_d1);
   TfNewBar(g_w1);
   TfRefresh(g_m1);
   TfRefresh(g_m5);
   TfRefresh(g_m15);
   TfRefresh(g_h1);
   TfRefresh(g_h4);
   TfRefresh(g_d1);
   TfRefresh(g_w1);
   g_tkBarOpen = g_m1.lastOpen;
   MicroInit();
   RvolInit();
   VwapInit();
   ProfileInit();
   SessInit();
   UpdateWeekly();
   CtxUpdate();
   UpdateRegime();
   BuildLevels();
   IntermarketInit();
   MacroHistLoad();
   UpdateContext();
   IntermarketUpdate();
   StatsLoad();
   for(int i = 0; i < MAX_META; i++)
      g_meta[i].Reset();
   MetaLoad();
   RiskStateInit();
   CashFlowScan();
   g_lastRealBal = AccountInfoDouble(ACCOUNT_BALANCE);
   //--- nel tester il giornale dei trade riparte vuoto a ogni test
   if(g_isTester && !g_isOptim)
     {
      int fh = FileOpen("XauCommittee_tester_trades.csv", FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
      if(fh != INVALID_HANDLE)
         FileClose(fh);
     }
   g_newsN = 0;
   if(g_isTester)
      TesterNewsRefresh(g_ctx.nowUtc);
   else
     {
      CalendarRefresh();
      WebRefresh();
      MacroHistDownload(InpMacroHistUrl);
      EventSetTimer(5);
      if(InpUseDOM)
         g_domOn = MarketBookAdd(g_sym);
     }
   MacroCombine();
   g_ready = true;
   double base = BaseCapital();
   Logf("XAU Committee EA " + g_version + " avviato su " + g_sym + " | conto " + Money(base) + " | lotto minimo " +
        DoubleToString(g_minLot, g_lotDigits) + " | contratto " + DoubleToString(g_contract, 0) + " | fuso server GMT" +
        (g_gmtOffset >= 0 ? "+" : "") + IntegerToString(g_gmtOffset) + (g_netting ? " | conto NETTING: massimo 1 posizione" : " | conto hedging"));
   Logf(EngineStatus(ENG_SCALP) + " | " + EngineStatus(ENG_INTRA) + " | " + EngineStatus(ENG_SWING));
   if(!g_isTester && (!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED)))
      Notify("Attiva il pulsante 'Algo Trading' e la spunta 'Consenti trading algoritmico' nelle proprieta' dell'EA");
   if(g_ddHalt)
      Notify("EA fermo per drawdown massimo raggiunto. Per ripartire: proprieta' EA > 'Sblocca' = true");
   Briefing();
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   if(!g_isTester)
     {
      EventKillTimer();
      if(g_domOn)
         MarketBookRelease(g_sym);
      StatsSave();
      GvSave();
     }
   PrintReport();
   Comment("");
  }

void OnTick()
  {
   if(!g_ready)
      return;
   MqlTick tk;
   if(!SymbolInfoTick(g_sym, tk))
      return;
   FlowCheck();
   datetime m1open = iTime(g_sym, PERIOD_M1, 0);
   bool newM1 = (m1open != 0 && m1open != g_m1.lastOpen);
   if(newM1)
      OnNewM1(m1open);
   TickDelta(tk.bid);
   SpreadTrack(tk.ask - tk.bid);
   RiskCheckLimits();
   if(g_needSweep)
      MetaSweep();
   if(g_needFlowScan)
     {
      g_needFlowScan = false;
      CashFlowScan();
     }
   ManagePositions();
   if(newM1 && g_isTester && g_isVisual)
      Panel();
  }

void OnTimer()
  {
   if(TimeCurrent() - g_gmtCheckedAt >= 3600)
      UpdateGmtOffset();
   if(TimeCurrent() - g_newsRefreshedAt >= 15 * 60)
      CalendarRefresh();
   if(TimeCurrent() - g_webLastTry >= InpWebRefreshMin * 60)
     {
      WebRefresh();
      MacroHistDownload(InpMacroHistUrl);
      MacroCombine();
     }
   CtxUpdate();
   Panel();
  }

void OnTradeTransaction(const MqlTradeTransaction &trans, const MqlTradeRequest &request, const MqlTradeResult &result)
  {
   if(trans.type == TRADE_TRANSACTION_DEAL_ADD)
     {
      g_needSweep = true;
      g_needFlowScan = true;
     }
  }

void OnBookEvent(const string &symbol)
  {
   if(symbol == g_sym && g_domOn)
      DomUpdate();
  }

//--- criterio per l'ottimizzazione: SQN in R corretto per il drawdown
double OnTester()
  {
   int n = g_all.n;
   if(n < 20)
      return 0.0;
   double mean = g_all.sumR / n;
   double var = g_all.sumR2 / n - mean * mean;
   double sd = MathSqrt(MathMax(var, 0.000001));
   double sqn = mean / sd * MathSqrt((double)IMin(n, 100));
   double dd = TesterStatistics(STAT_EQUITY_DDREL_PERCENT);
   return NormalizeDouble(sqn * (1.0 - MathMin(dd, 90.0) / 100.0), 4);
  }
//+------------------------------------------------------------------+
