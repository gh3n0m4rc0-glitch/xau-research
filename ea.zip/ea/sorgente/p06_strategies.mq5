//+------------------------------------------------------------------+
//| Segnale comune: tutte le strategie parlano questa lingua         |
//+------------------------------------------------------------------+
struct TSignal
  {
   int               strat;
   int               engine;
   int               stype;
   int               dir;
   double            entry;
   double            sl;
   double            tp;
   double            quality;
   string            why;
   double            desk[NDESK];
   bool              veto;
   string            vetoWhy;
   double            score;
   int               quorum;
   int               devil;
   bool              strong;
   bool              recovery;
   bool              reentry;
   bool              aplus;
   double            cushion;
   double            obstacleR;
   double            cvdRatio;
   bool              passed;

   void              Reset()
     {
      strat = 0;
      engine = 0;
      stype = 0;
      dir = 0;
      entry = 0.0;
      sl = 0.0;
      tp = 0.0;
      quality = 0.0;
      why = "";
      for(int i = 0; i < NDESK; i++)
         desk[i] = 0.5;
      veto = false;
      vetoWhy = "";
      score = 0.0;
      quorum = 0;
      devil = 0;
      strong = false;
      recovery = false;
      reentry = false;
      aplus = false;
      cushion = 0.0;
      obstacleR = -1.0;
      cvdRatio = 0.0;
      passed = false;
     }
  };

double RiskPx(const TSignal &s) { return (s.entry - s.sl) * s.dir; }

//--- copia esplicita (piu' sicura dell'assegnazione di struct con stringhe)
void SigCopy(TSignal &d, const TSignal &s)
  {
   d.strat = s.strat;
   d.engine = s.engine;
   d.stype = s.stype;
   d.dir = s.dir;
   d.entry = s.entry;
   d.sl = s.sl;
   d.tp = s.tp;
   d.quality = s.quality;
   d.why = s.why;
   for(int i = 0; i < NDESK; i++)
      d.desk[i] = s.desk[i];
   d.veto = s.veto;
   d.vetoWhy = s.vetoWhy;
   d.score = s.score;
   d.quorum = s.quorum;
   d.devil = s.devil;
   d.strong = s.strong;
   d.recovery = s.recovery;
   d.reentry = s.reentry;
   d.aplus = s.aplus;
   d.cushion = s.cushion;
   d.obstacleR = s.obstacleR;
   d.cvdRatio = s.cvdRatio;
   d.passed = s.passed;
  }

//--- costruisce il segnale con target in R (mai sotto il minimo 1:2)
bool MakeSignal(TSignal &s, int strat, int dir, double entry, double sl, double rr, double quality, string why)
  {
   s.Reset();
   s.strat = strat;
   s.engine = g_stratEngine[strat];
   s.stype = g_stratType[strat];
   s.dir = dir;
   s.entry = entry;
   s.sl = NormPrice(sl);
   double risk = (entry - s.sl) * dir;
   if(risk <= 2.0 * g_tick)
      return false;
   s.tp = NormPrice(entry + dir * risk * MathMax(rr, InpMinRR));
   s.quality = Clamp(quality, 0.0, 1.0);
   s.why = why;
   return true;
  }

//--- come sopra ma con target strutturale: valido solo se rispetta l'R:R minimo
bool MakeSignalTP(TSignal &s, int strat, int dir, double entry, double sl, double tp, double quality, string why)
  {
   s.Reset();
   s.strat = strat;
   s.engine = g_stratEngine[strat];
   s.stype = g_stratType[strat];
   s.dir = dir;
   s.entry = entry;
   s.sl = NormPrice(sl);
   double risk = (entry - s.sl) * dir;
   if(risk <= 2.0 * g_tick)
      return false;
   if((tp - entry) * dir < InpMinRR * risk)
      return false;
   s.tp = NormPrice(tp);
   s.quality = Clamp(quality, 0.0, 1.0);
   s.why = why;
   return true;
  }

double EntryPx(int dir) { return (dir > 0) ? g_ctx.ask : g_ctx.bid; }

//--- stop strutturale + buffer; per le vendite aggiunge lo spread (lo stop scatta sull'ask)
double StopFrom(double extreme, int dir, double buffer)
  {
   if(dir > 0)
      return extreme - buffer;
   return extreme + buffer + g_ctx.spread;
  }

//--- aggiusta la distanza dello stop dentro [minD, maxD]; false se troppo largo
bool FitStop(double entry, int dir, double &sl, double minD, double maxD)
  {
   double risk = (entry - sl) * dir;
   if(risk < minD)
      sl = entry - dir * minD;
   risk = (entry - sl) * dir;
   return (risk <= maxD);
  }

bool StratEnabled(int st)
  {
   if(InpOnlyStrategy != PICK_ALL && (int)InpOnlyStrategy != st)
      return false;
   switch(st)
     {
      case ST_SC_VWAP:
         return InpSC_VWAP;
      case ST_SC_SWEEP:
         return InpSC_SWEEP;
      case ST_SC_ORB:
         return InpSC_ORB;
      case ST_IN_PULLBACK:
         return InpIN_PULLBACK;
      case ST_IN_SWEEP:
         return InpIN_SWEEP;
      case ST_IN_BREAKOUT:
         return InpIN_BREAKOUT;
      case ST_IN_VALUE:
         return InpIN_VALUE;
      case ST_IN_NEWS:
         return InpIN_NEWS;
      case ST_IN_RANGE:
         return InpIN_RANGE;
      case ST_SW_TREND:
         return InpSW_TREND;
      case ST_SW_WYCKOFF:
         return InpSW_WYCKOFF;
     }
   return false;
  }

//+------------------------------------------------------------------+
//| SCALPING                                                         |
//+------------------------------------------------------------------+
//--- SC-VWAP: trend M15+M5, pullback sulla VWAP/EMA20 M5, ripartenza su M1
bool S_ScVwap(TSignal &s)
  {
   int t15 = TrendDir(g_m15), t5 = TrendDir(g_m5);
   if(t15 == 0 || t5 != t15)
      return false;
   int dir = t15;
   double vw = g_ctx.vwap, a5 = g_ctx.atrM5;
   if(vw <= 0.0 || a5 <= 0.0)
      return false;
   double c1 = BarC(g_m1, 0);
   if((c1 - vw) * dir <= 0.0)
      return false;
   double e20m5 = Ind(g_m5.ema20, 0);
   double zone = (dir > 0) ? MathMax(vw, e20m5) : MathMin(vw, e20m5);
   double ext = (dir > 0) ? LowestL(g_m1, 0, 7) : HighestH(g_m1, 0, 7);
   if(dir > 0)
     {
      if(ext > zone + 0.15 * a5 || ext < vw - 0.6 * a5)
         return false;
      if(!(c1 > BarH(g_m1, 1) && c1 > Ind(g_m1.ema20, 0) && c1 > BarO(g_m1, 0)))
         return false;
     }
   else
     {
      if(ext < zone - 0.15 * a5 || ext > vw + 0.6 * a5)
         return false;
      if(!(c1 < BarL(g_m1, 1) && c1 < Ind(g_m1.ema20, 0) && c1 < BarO(g_m1, 0)))
         return false;
     }
   if(MicroDelta(0) * dir < 0.0)
      return false;
   double entry = EntryPx(dir);
   double sl = StopFrom(ext, dir, 0.25 * g_ctx.atrM1);
   if(!FitStop(entry, dir, sl, 0.5 * a5, 2.0 * a5))
      return false;
   double q = 0.55;
   double rsi5 = Ind(g_m5.rsi, 0);
   if((dir > 0 && rsi5 > 45.0 && rsi5 < 68.0) || (dir < 0 && rsi5 < 55.0 && rsi5 > 32.0))
      q += 0.1;
   if(RvolBar(g_m1, 0) >= 1.2)
      q += 0.1;
   if(MicroCvdRatio(30) * dir > 0.0)
      q += 0.1;
   return MakeSignal(s, ST_SC_VWAP, dir, entry, sl, InpScalpRR, q, "pullback sulla VWAP in trend M15/M5");
  }

//--- SC-SWEEP: spazzata di un livello (stop run) e rientro rapido
bool S_ScSweep(TSignal &s)
  {
   double a5 = g_ctx.atrM5;
   if(a5 <= 0.0)
      return false;
   double lv[8];
   string nm[8];
   int n = 0;
   if(g_sess.asiaDone)
     {
      lv[n] = g_sess.asiaH;
      nm[n] = "Asia H";
      n++;
      lv[n] = g_sess.asiaL;
      nm[n] = "Asia L";
      n++;
     }
   if(g_sess.lonDone)
     {
      lv[n] = g_sess.lonH;
      nm[n] = "Londra H";
      n++;
      lv[n] = g_sess.lonL;
      nm[n] = "Londra L";
      n++;
     }
   if(g_d1.n >= 2)
     {
      lv[n] = BarH(g_d1, 0);
      nm[n] = "PDH";
      n++;
      lv[n] = BarL(g_d1, 0);
      nm[n] = "PDL";
      n++;
     }
   if(g_h1.n >= 2)
     {
      lv[n] = BarH(g_h1, 0);
      nm[n] = "max ora prec.";
      n++;
      lv[n] = BarL(g_h1, 0);
      nm[n] = "min ora prec.";
      n++;
     }
   double c = BarC(g_m1, 0), o = BarO(g_m1, 0);
   double lo5 = LowestL(g_m1, 0, 5), hi5 = HighestH(g_m1, 0, 5);
   bool found = false;
   double bestQ = 0.0;
   TSignal tmp;
   for(int i = 0; i < n; i++)
     {
      double L = lv[i];
      if(L <= 0.0)
         continue;
      for(int dir = -1; dir <= 1; dir += 2)
        {
         double ext = (dir > 0) ? lo5 : hi5;
         bool swept = (dir > 0) ? (ext < L - 0.1 * a5 && ext > L - 1.2 * a5) : (ext > L + 0.1 * a5 && ext < L + 1.2 * a5);
         bool reclaim = (dir > 0) ? (c > L && c > o) : (c < L && c < o);
         bool approach = (dir > 0) ? (BarC(g_m1, 6) > L) : (BarC(g_m1, 6) < L);
         if(!swept || !reclaim || !approach)
            continue;
         //--- barra della spazzata
         int sb = 0;
         for(int k = 0; k < 5; k++)
           {
            double x = (dir > 0) ? BarL(g_m1, k) : BarH(g_m1, k);
            if(x == ext)
              {
               sb = k;
               break;
              }
           }
         double wick = WickRatio(g_m1, sb, dir);
         double rv = RvolBar(g_m1, sb);
         if(wick < 0.4 && rv < 1.5)
            continue;
         if((MicroDelta(0) + MicroDelta(1)) * dir <= 0.0)
            continue;
         double entry = EntryPx(dir);
         double sl = StopFrom(ext, dir, 0.2 * g_ctx.atrM1);
         if(!FitStop(entry, dir, sl, 0.4 * a5, 2.0 * a5))
            continue;
         double q = 0.55;
         if(wick >= 0.5)
            q += 0.1;
         if(rv >= 1.5)
            q += 0.1;
         if(nm[i] == "PDH" || nm[i] == "PDL")
            q += 0.05;
         if(q > bestQ && MakeSignal(tmp, ST_SC_SWEEP, dir, entry, sl, InpScalpRR, q, "stop run su " + nm[i] + " e rientro"))
           {
            bestQ = q;
            SigCopy(s, tmp);
            found = true;
           }
        }
     }
   return found;
  }

//--- SC-ORB: range dei primi 15 minuti di Londra/NY, rottura con volume, retest
bool OrbCheck(TSignal &s, OrState &o, double openUtc, string name)
  {
   if(!o.done || o.used)
      return false;
   double h = g_ctx.hUtc;
   double a5 = g_ctx.atrM5;
   if(h > openUtc + 1.5 || a5 <= 0.0)
     {
      o.used = true;
      return false;
     }
   double height = o.h - o.l;
   if(height < 0.4 * a5 || height > 3.0 * a5)
     {
      o.used = true;
      return false;
     }
   double c = BarC(g_m1, 0);
   if(o.brk == 0)
     {
      double rv = RvolBar(g_m1, 0);
      if(c > o.h + 0.05 * a5 && rv >= 1.3)
        {
         o.brk = 1;
         o.brkT = BarT(g_m1, 0);
        }
      else
         if(c < o.l - 0.05 * a5 && rv >= 1.3)
           {
            o.brk = -1;
            o.brkT = BarT(g_m1, 0);
           }
      return false;
     }
   if(BarT(g_m1, 0) - o.brkT > 30 * 60)
     {
      o.used = true;
      return false;
     }
   int dir = o.brk;
   double lvl = (dir > 0) ? o.h : o.l;
   if((dir > 0 && c < o.l) || (dir < 0 && c > o.h))
     {
      o.used = true;
      return false;
     }
   double ext = (dir > 0) ? BarL(g_m1, 0) : BarH(g_m1, 0);
   bool touched = (dir > 0) ? (ext <= lvl + 0.15 * a5) : (ext >= lvl - 0.15 * a5);
   bool held = (dir > 0) ? (c > lvl && c > BarO(g_m1, 0)) : (c < lvl && c < BarO(g_m1, 0));
   if(!touched || !held)
      return false;
   o.used = true;
   double entry = EntryPx(dir);
   double ref = (dir > 0) ? MathMin(ext, lvl) : MathMax(ext, lvl);
   double sl = StopFrom(ref, dir, 0.2 * g_ctx.atrM1);
   if(!FitStop(entry, dir, sl, 0.4 * a5, 2.0 * a5))
      return false;
   double q = 0.6;
   if(height < 1.5 * a5)
      q += 0.05;
   if(MicroCvdRatio(10) * dir > 0.05)
      q += 0.1;
   return MakeSignal(s, ST_SC_ORB, dir, entry, sl, InpScalpRR, q, "range di apertura " + name + ": rottura e retest");
  }

bool S_ScOrb(TSignal &s)
  {
   if(OrbCheck(s, g_sess.orLon, g_ctx.lonOpen, "Londra"))
      return true;
   return OrbCheck(s, g_sess.orNy, g_ctx.nyOpen, "New York");
  }

//+------------------------------------------------------------------+
//| INTRADAY                                                         |
//+------------------------------------------------------------------+
//--- IN-PULLBACK: trend H1, pullback sull'EMA20 M15 con RSI scarico, ripartenza M5
bool S_InPullback(TSignal &s)
  {
   int dir = TrendDir(g_h1);
   if(dir == 0 || AdxOf(g_h1) < 18.0 || EmaDir(g_m15) != dir)
      return false;
   double a15 = g_ctx.atrM15;
   if(a15 <= 0.0)
      return false;
   double e20 = Ind(g_m15.ema20, 0), e50 = Ind(g_m15.ema50, 0);
   double ext = (dir > 0) ? LowestL(g_m15, 0, 4) : HighestH(g_m15, 0, 4);
   if(dir > 0 && (ext > e20 + 0.2 * a15 || ext < e50 - 0.3 * a15))
      return false;
   if(dir < 0 && (ext < e20 - 0.2 * a15 || ext > e50 + 0.3 * a15))
      return false;
   if(dir > 0)
     {
      double rmin = MinInd(g_m15.rsi, 0, 4);
      if(rmin < 35.0 || rmin > 52.0)
         return false;
     }
   else
     {
      double rmax = MaxInd(g_m15.rsi, 0, 4);
      if(rmax > 65.0 || rmax < 48.0)
         return false;
     }
   double c5 = BarC(g_m5, 0);
   if(dir > 0 && !(c5 > HighestH(g_m5, 1, 3) && c5 > Ind(g_m5.ema20, 0) && c5 > BarO(g_m5, 0)))
      return false;
   if(dir < 0 && !(c5 < LowestL(g_m5, 1, 3) && c5 < Ind(g_m5.ema20, 0) && c5 < BarO(g_m5, 0)))
      return false;
   double ext5 = (dir > 0) ? LowestL(g_m5, 0, 12) : HighestH(g_m5, 0, 12);
   double ref = (dir > 0) ? MathMin(ext, ext5) : MathMax(ext, ext5);
   double entry = EntryPx(dir);
   double sl = StopFrom(ref, dir, 0.2 * a15);
   if(!FitStop(entry, dir, sl, 0.6 * a15, 2.0 * a15))
      return false;
   double q = 0.6;
   if(AdxOf(g_h1) > 25.0)
      q += 0.1;
   if(TrendDir(g_h4) == dir)
      q += 0.1;
   if(RvolBar(g_m5, 0) >= 1.1)
      q += 0.05;
   return MakeSignal(s, ST_IN_PULLBACK, dir, entry, sl, InpIntraRR, q, "trend H1, pullback su EMA20 M15");
  }

//--- IN-SWEEP: barra M15 che spazza PDH/PDL/Asia/Londra/settimana e rientra
datetime g_lastInSweepBar = 0;

bool S_InSweep(TSignal &s)
  {
   double a15 = g_ctx.atrM15;
   if(a15 <= 0.0 || BarT(g_m15, 0) == g_lastInSweepBar)
      return false;
   double lv[8];
   string nm[8];
   int n = 0;
   if(g_d1.n >= 2)
     {
      lv[n] = BarH(g_d1, 0);
      nm[n] = "PDH";
      n++;
      lv[n] = BarL(g_d1, 0);
      nm[n] = "PDL";
      n++;
     }
   if(g_pwH > 0.0)
     {
      lv[n] = g_pwH;
      nm[n] = "PWH";
      n++;
      lv[n] = g_pwL;
      nm[n] = "PWL";
      n++;
     }
   if(g_sess.asiaDone)
     {
      lv[n] = g_sess.asiaH;
      nm[n] = "Asia H";
      n++;
      lv[n] = g_sess.asiaL;
      nm[n] = "Asia L";
      n++;
     }
   if(g_sess.lonDone)
     {
      lv[n] = g_sess.lonH;
      nm[n] = "Londra H";
      n++;
      lv[n] = g_sess.lonL;
      nm[n] = "Londra L";
      n++;
     }
   double hb = BarH(g_m15, 0), lb = BarL(g_m15, 0), cb = BarC(g_m15, 0);
   double c5 = BarC(g_m5, 0), o5 = BarO(g_m5, 0);
   bool found = false;
   double bestQ = 0.0;
   TSignal tmp;
   for(int i = 0; i < n; i++)
     {
      double L = lv[i];
      if(L <= 0.0)
         continue;
      for(int dir = -1; dir <= 1; dir += 2)
        {
         double ext = (dir > 0) ? lb : hb;
         bool swept = (dir > 0) ? (ext < L - 0.15 * a15 && ext > L - 1.5 * a15) : (ext > L + 0.15 * a15 && ext < L + 1.5 * a15);
         bool reclaim = (dir > 0) ? (cb > L) : (cb < L);
         bool approach = (dir > 0) ? (BarC(g_m15, 1) > L) : (BarC(g_m15, 1) < L);
         bool trig = (dir > 0) ? (c5 > L && c5 > o5) : (c5 < L && c5 < o5);
         if(!swept || !reclaim || !approach || !trig)
            continue;
         double wick = WickRatio(g_m15, 0, dir);
         double rv = RvolBar(g_m15, 0);
         if(wick < 0.5 && rv < 1.3)
            continue;
         double entry = EntryPx(dir);
         double sl = StopFrom(ext, dir, 0.15 * a15);
         if(!FitStop(entry, dir, sl, 0.5 * a15, 2.2 * a15))
            continue;
         double q = 0.55;
         if(wick >= 0.5)
            q += 0.1;
         if(rv >= 1.3)
            q += 0.1;
         if(nm[i] == "PDH" || nm[i] == "PDL" || nm[i] == "PWH" || nm[i] == "PWL")
            q += 0.05;
         //--- divergenza del delta: prezzo su nuovo estremo ma CVD a favore
         if(MicroCvdRatio(60) * dir > 0.05)
            q += 0.1;
         if(q > bestQ && MakeSignal(tmp, ST_IN_SWEEP, dir, entry, sl, InpIntraRR, q, "stop run M15 su " + nm[i]))
           {
            bestQ = q;
            SigCopy(s, tmp);
            found = true;
           }
        }
     }
   if(found)
      g_lastInSweepBar = BarT(g_m15, 0);
   return found;
  }

//--- IN-BREAKOUT: rottura con volume di un livello chiave su M15, ingresso al retest su M5
struct BrkState
  {
   double            lvl;
   int               dir;
   datetime          brkT;
   bool              used;
   double            rvol;
   string            name;
  };
BrkState g_brk[8];
int      g_brkN = 0;
int      g_brkDay = 0;

void BrkRegister(double L, string name)
  {
   if(L <= 0.0)
      return;
   for(int i = 0; i < g_brkN; i++)
      if(MathAbs(g_brk[i].lvl - L) < g_tick * 0.5)
         return;
   double a15 = g_ctx.atrM15;
   double c = BarC(g_m15, 0), cp = ClosePos(g_m15, 0), rv = RvolBar(g_m15, 0);
   int dir = 0;
   if(c > L + 0.1 * a15 && BarO(g_m15, 0) < L + 0.1 * a15 && cp >= 0.7 && rv >= 1.3)
      dir = 1;
   if(c < L - 0.1 * a15 && BarO(g_m15, 0) > L - 0.1 * a15 && cp <= 0.3 && rv >= 1.3)
      dir = -1;
   if(dir == 0 || g_brkN >= 8)
      return;
   g_brk[g_brkN].lvl = L;
   g_brk[g_brkN].dir = dir;
   g_brk[g_brkN].brkT = BarT(g_m15, 0);
   g_brk[g_brkN].used = false;
   g_brk[g_brkN].rvol = rv;
   g_brk[g_brkN].name = name;
   g_brkN++;
  }

//--- chiamata a ogni nuova barra M15
void BrkOnM15()
  {
   int dk = DayKey(g_ctx.nowUtc);
   if(dk != g_brkDay)
     {
      g_brkDay = dk;
      g_brkN = 0;
     }
   if(g_ctx.atrM15 <= 0.0)
      return;
   if(g_sess.asiaDone && g_ctx.hUtc < 17.0)
     {
      BrkRegister(g_sess.asiaH, "Asia H");
      BrkRegister(g_sess.asiaL, "Asia L");
     }
   if(g_sess.lonDone)
     {
      BrkRegister(g_sess.lonH, "Londra H");
      BrkRegister(g_sess.lonL, "Londra L");
     }
   if(g_d1.n >= 2)
     {
      BrkRegister(BarH(g_d1, 0), "PDH");
      BrkRegister(BarL(g_d1, 0), "PDL");
     }
  }

bool S_InBreakout(TSignal &s)
  {
   double a15 = g_ctx.atrM15;
   if(a15 <= 0.0)
      return false;
   double l5 = BarL(g_m5, 0), h5 = BarH(g_m5, 0), c5 = BarC(g_m5, 0), o5 = BarO(g_m5, 0);
   for(int i = 0; i < g_brkN; i++)
     {
      if(g_brk[i].used)
         continue;
      if(BarT(g_m5, 0) - g_brk[i].brkT > 2 * 3600)
        {
         g_brk[i].used = true;
         continue;
        }
      if(BarT(g_m5, 0) <= g_brk[i].brkT + 15 * 60)
         continue;
      int dir = g_brk[i].dir;
      double L = g_brk[i].lvl;
      if((L - c5) * dir > 0.3 * a15)
        {
         g_brk[i].used = true;
         continue;
        }
      bool touched = (dir > 0) ? (l5 <= L + 0.15 * a15) : (h5 >= L - 0.15 * a15);
      bool held = (dir > 0) ? (c5 > L && c5 > o5) : (c5 < L && c5 < o5);
      if(!touched || !held)
         continue;
      g_brk[i].used = true;
      double entry = EntryPx(dir);
      double ref = (dir > 0) ? MathMin(l5, L) : MathMax(h5, L);
      double sl = StopFrom(ref, dir, 0.25 * a15);
      if(!FitStop(entry, dir, sl, 0.5 * a15, 1.8 * a15))
         continue;
      double q = 0.6;
      if(TrendDir(g_h1) == dir)
         q += 0.1;
      if(g_brk[i].rvol >= 1.8)
         q += 0.1;
      return MakeSignal(s, ST_IN_BREAKOUT, dir, entry, sl, InpIntraRR, q, "breakout " + g_brk[i].name + " con volume e retest");
     }
   return false;
  }

//--- IN-VALUE80: apertura fuori dalla value area di ieri, rientro con 2 chiusure M15 -> lato opposto
int      g_vaDay = 0;
int      g_vaOpenSide = 0;
int      g_vaInside = 0;
bool     g_vaUsed = false;
bool     g_vaNewM15 = false;

void ValueOnM15()
  {
   g_vaNewM15 = true;
   datetime anchor = iTime(g_sym, PERIOD_D1, 0);
   int dk = (int)(anchor / 86400);
   if(dk != g_vaDay)
     {
      g_vaDay = dk;
      g_vaOpenSide = 0;
      g_vaInside = 0;
      g_vaUsed = false;
      if(PrevProfileOk())
        {
         double op = BarO(g_m15, 0);
         if(op > PrevVAH())
            g_vaOpenSide = 1;
         else
            if(op < PrevVAL())
               g_vaOpenSide = -1;
        }
      return;
     }
   if(g_vaOpenSide == 0 || g_vaUsed)
      return;
   double c = BarC(g_m15, 0);
   bool inside = (c < PrevVAH() && c > PrevVAL());
   g_vaInside = inside ? g_vaInside + 1 : 0;
  }

bool S_InValue(TSignal &s)
  {
   if(!g_vaNewM15)
      return false;
   g_vaNewM15 = false;
   if(g_vaOpenSide == 0 || g_vaUsed || g_vaInside < 2 || !PrevProfileOk())
      return false;
   g_vaUsed = true;
   int dir = -g_vaOpenSide;
   double a15 = g_ctx.atrM15;
   double entry = EntryPx(dir);
   double edge = (dir > 0) ? PrevVAL() : PrevVAH();
   double ext = (dir > 0) ? LowestL(g_m15, 0, 3) : HighestH(g_m15, 0, 3);
   double ref = (dir > 0) ? MathMin(ext, edge - 0.3 * a15) : MathMax(ext, edge + 0.3 * a15);
   double sl = StopFrom(ref, dir, 0.1 * a15);
   if(!FitStop(entry, dir, sl, 0.5 * a15, 2.0 * a15))
      return false;
   double tp = (dir > 0) ? PrevVAH() : PrevVAL();
   double q = 0.6;
   if(RvolBar(g_m15, 0) >= 1.0)
      q += 0.05;
   if(MicroCvdRatio(60) * dir > 0.05)
      q += 0.1;
   return MakeSignalTP(s, ST_IN_VALUE, dir, entry, sl, tp, q, "regola 80%: rientro nella value area di ieri");
  }

//--- IN-NEWS: continuation dopo la news SOLO nella direzione della vista pre-news
bool S_InNews(TSignal &s)
  {
   datetime nowU = g_ctx.nowUtc;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier > 2 || !g_news[i].viewTaken || g_news[i].viewDir == 0 || g_news[i].eUsed)
         continue;
      double mins = (double)(nowU - g_news[i].utc) / 60.0;
      if(mins < 5.0 || mins > 90.0)
         continue;
      int dir = g_news[i].viewDir;
      double c = BarC(g_m5, 0);
      double imp = (g_news[i].extreme - g_news[i].preClose) * dir;
      if((c - g_news[i].preClose) * dir < 0.0)
        {
         g_news[i].eUsed = true;   // il mercato ha smentito la vista
         continue;
        }
      if(imp < 1.5 * g_news[i].preAtr)
         continue;
      double barExt = (dir > 0) ? BarL(g_m5, 0) : BarH(g_m5, 0);
      double retr = (g_news[i].extreme - barExt) * dir / imp;
      if(retr < 0.30 || retr > 0.62)
         continue;
      if(!((dir > 0 && c > BarO(g_m5, 0)) || (dir < 0 && c < BarO(g_m5, 0))))
         continue;
      g_news[i].eUsed = true;
      double entry = EntryPx(dir);
      double sl = StopFrom(barExt, dir, 0.25 * g_ctx.atrM5);
      if(!FitStop(entry, dir, sl, 0.5 * g_ctx.atrM15, 2.5 * g_ctx.atrM15))
         continue;
      double q = 0.65;
      if(g_news[i].preConf >= 0.6)
         q += 0.1;
      double tp = g_news[i].extreme + dir * 0.5 * imp;
      if(MakeSignalTP(s, ST_IN_NEWS, dir, entry, sl, tp, q, "continuation dopo " + g_news[i].title + " coerente con la vista"))
         return true;
      return MakeSignal(s, ST_IN_NEWS, dir, entry, sl, InpMinRR, q, "continuation dopo " + g_news[i].title + " coerente con la vista");
     }
   return false;
  }

//--- IN-RANGE: in laterale, rifiuto a VWAP +-2 sigma con RSI estremo, target VWAP
bool S_InRange(TSignal &s)
  {
   if(g_regime != REG_RANGE && g_regime != REG_QUIET)
      return false;
   if(AdxOf(g_h1) > 20.0)
      return false;
   double vw = g_ctx.vwap, sg = g_ctx.vwSig;
   if(vw <= 0.0 || sg <= 0.0)
      return false;
   double l = BarL(g_m5, 0), h = BarH(g_m5, 0), c = BarC(g_m5, 0);
   int dir = 0;
   if(l <= vw - 2.0 * sg && c > vw - 2.0 * sg && WickRatio(g_m5, 0, 1) >= 0.5 && MinInd(g_m5.rsi, 0, 3) <= 30.0)
      dir = 1;
   if(h >= vw + 2.0 * sg && c < vw + 2.0 * sg && WickRatio(g_m5, 0, -1) >= 0.5 && MaxInd(g_m5.rsi, 0, 3) >= 70.0)
      dir = -1;
   if(dir == 0)
      return false;
   double entry = EntryPx(dir);
   double ext = (dir > 0) ? l : h;
   double sl = StopFrom(ext, dir, 0.3 * g_ctx.atrM5);
   if(!FitStop(entry, dir, sl, 0.4 * g_ctx.atrM15, 1.5 * g_ctx.atrM15))
      return false;
   double q = 0.55;
   if(IsAbsorption(g_m5, 0) || RvolBar(g_m5, 0) >= 1.5)
      q += 0.1;
   if(MicroCvdRatio(10) * dir > 0.05)
      q += 0.1;
   return MakeSignalTP(s, ST_IN_RANGE, dir, entry, sl, vw, q, "laterale: rifiuto a VWAP 2 sigma, target VWAP");
  }

//+------------------------------------------------------------------+
//| SWING                                                            |
//+------------------------------------------------------------------+
//--- SW-TREND: trend H4 (D1 non contrario), pullback sull'EMA20 H4, ripartenza H1
bool S_SwTrend(TSignal &s)
  {
   int dir = TrendDir(g_h4);
   if(dir == 0 || AdxOf(g_h4) < 20.0)
      return false;
   int td = EmaDir(g_d1);
   if(td != 0 && td != dir)
      return false;
   double a1 = g_ctx.atrH1, a4 = g_ctx.atrH4;
   if(a1 <= 0.0 || a4 <= 0.0)
      return false;
   double e20 = Ind(g_h4.ema20, 0), e50 = Ind(g_h4.ema50, 0);
   double ext = (dir > 0) ? LowestL(g_h1, 0, 6) : HighestH(g_h1, 0, 6);
   if(dir > 0 && (ext > e20 + 0.3 * a4 || ext < e50 - 0.3 * a4))
      return false;
   if(dir < 0 && (ext < e20 - 0.3 * a4 || ext > e50 + 0.3 * a4))
      return false;
   if(dir > 0)
     {
      double rmin = MinInd(g_h1.rsi, 0, 6);
      if(rmin < 35.0 || rmin > 52.0)
         return false;
     }
   else
     {
      double rmax = MaxInd(g_h1.rsi, 0, 6);
      if(rmax > 65.0 || rmax < 48.0)
         return false;
     }
   double c = BarC(g_h1, 0);
   if(dir > 0 && !(c > HighestH(g_h1, 1, 3) && c > BarO(g_h1, 0)))
      return false;
   if(dir < 0 && !(c < LowestL(g_h1, 1, 3) && c < BarO(g_h1, 0)))
      return false;
   double entry = EntryPx(dir);
   double sl = StopFrom(ext, dir, 0.25 * a1);
   if(!FitStop(entry, dir, sl, 1.0 * a1, 1.2 * a4))
      return false;
   double q = 0.6;
   if(AdxOf(g_h4) > 25.0)
      q += 0.1;
   if(RvolBar(g_h1, 0) >= 1.1)
      q += 0.05;
   if(td == dir)
      q += 0.05;
   return MakeSignal(s, ST_SW_TREND, dir, entry, sl, InpSwingRR, q, "trend H4, pullback su EMA20 H4");
  }

//--- SW-WYCKOFF: range H4, spring (falsa rottura del minimo) o upthrust con volume
datetime g_lastWyckBar = 0;

bool S_SwWyckoff(TSignal &s)
  {
   if(g_h4.n < 40 || BarT(g_h1, 0) == g_lastWyckBar)
      return false;
   double a1 = g_ctx.atrH1, a4 = g_ctx.atrH4;
   if(a1 <= 0.0 || a4 <= 0.0)
      return false;
   double rh = HighestH(g_h4, 1, 30), rl = LowestL(g_h4, 1, 30);
   double height = rh - rl;
   if(height < 2.0 * a4 || height > 7.0 * a4 || AdxOf(g_h4) > 22.0)
      return false;
   double l = BarL(g_h1, 0), h = BarH(g_h1, 0), c = BarC(g_h1, 0);
   double cp = ClosePos(g_h1, 0), rv = RvolBar(g_h1, 0);
   int dir = 0;
   if(l < rl - 0.1 * a4 && l > rl - 1.0 * a4 && c > rl && cp >= 0.5 && rv >= 1.3)
      dir = 1;
   if(h > rh + 0.1 * a4 && h < rh + 1.0 * a4 && c < rh && cp <= 0.5 && rv >= 1.3)
      dir = -1;
   if(dir == 0)
      return false;
   g_lastWyckBar = BarT(g_h1, 0);
   double entry = EntryPx(dir);
   double ext = (dir > 0) ? l : h;
   double sl = StopFrom(ext, dir, 0.2 * a1);
   if(!FitStop(entry, dir, sl, 0.8 * a1, 1.5 * a4))
      return false;
   double tp = (dir > 0) ? rh - 0.1 * a4 : rl + 0.1 * a4;
   double q = 0.6;
   if(rv >= 1.8)
      q += 0.1;
   if(MicroCvdRatio(120) * dir > 0.05)
      q += 0.1;
   string nm = (dir > 0) ? "spring" : "upthrust";
   return MakeSignalTP(s, ST_SW_WYCKOFF, dir, entry, sl, tp, q, "Wyckoff " + nm + " nel range H4");
  }
