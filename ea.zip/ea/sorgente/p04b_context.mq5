//+------------------------------------------------------------------+
//| CAPO "CONTESTO HTF": struttura, ritracciamento, compressione ed  |
//| espansione su W1 / D1 / H4. Dice in che fase e' il mercato e     |
//| quali strategie hanno senso in quel momento.                     |
//+------------------------------------------------------------------+
#define PH_LATERALE       0
#define PH_IMPULSO        1
#define PH_RITRACCIAMENTO 2
#define PH_COMPRESSIONE   3
#define PH_ESPANSIONE     4
#define PH_ESAURIMENTO    5

string g_phName[6] = {"laterale", "impulso", "ritracciamento", "compressione", "espansione", "esaurimento"};

struct TfContext
  {
   bool              valid;
   int               structure;  // +1 massimi e minimi crescenti, -1 decrescenti, 0 misto
   int               bos;        // rottura dell'ultimo swing: +1 sopra il massimo, -1 sotto il minimo
   int               emaDir;     // posizione rispetto alle medie
   int               dir;        // direzione dominante
   double            rangeHi;    // estremi del range di riferimento (dealing range)
   double            rangeLo;
   double            rangePos;   // 0 = sul minimo, 1 = sul massimo
   double            retr;       // profondita' del ritracciamento contro la direzione dominante (0..1)
   double            atrRatio;   // ATR attuale / mediana ATR (volatilita' relativa)
   double            bwPct;      // percentile larghezza Bollinger (0 = compressa, 1 = espansa)
   double            extAtr;     // distanza dalla EMA20 in ATR (con segno)
   bool              nr7;        // barra piu' stretta delle ultime 7
   int               phase;
  };

TfData    g_w1;
TfContext g_cxW1;
TfContext g_cxD1;
TfContext g_cxH4;
double    g_ctxBias = 0.0;     // -1..+1: direzione suggerita dai timeframe alti
string    g_ctxText = "";

void CtxReset(TfContext &c)
  {
   c.valid = false;
   c.structure = 0;
   c.bos = 0;
   c.emaDir = 0;
   c.dir = 0;
   c.rangeHi = 0.0;
   c.rangeLo = 0.0;
   c.rangePos = 0.5;
   c.retr = 0.0;
   c.atrRatio = 1.0;
   c.bwPct = 0.5;
   c.extAtr = 0.0;
   c.nr7 = false;
   c.phase = PH_LATERALE;
  }

//--- mediana degli ultimi 'count' valori di un array
double MedianLast(const double &a[], int count)
  {
   int n = ArraySize(a);
   int m = IMin(count, n);
   if(m <= 0)
      return 0.0;
   double tmp[200];
   if(m > 200)
      m = 200;
   for(int k = 0; k < m; k++)
      tmp[k] = a[n - 1 - k];
   for(int i = 1; i < m; i++)
     {
      double v = tmp[i];
      int j = i - 1;
      while(j >= 0 && tmp[j] > v)
        {
         tmp[j + 1] = tmp[j];
         j--;
        }
      tmp[j + 1] = v;
     }
   return tmp[m / 2];
  }

//--- larghezza relativa delle Bollinger(period,2) chiuse alla barra i
double BollWidthAt(const TfData &d, int i, int period)
  {
   double s = 0.0, s2 = 0.0;
   for(int k = i - period + 1; k <= i; k++)
     {
      s += d.r[k].close;
      s2 += d.r[k].close * d.r[k].close;
     }
   double mean = s / period;
   double var = s2 / period - mean * mean;
   return (mean > 0.0 && var > 0.0) ? 4.0 * MathSqrt(var) / mean : 0.0;
  }

//--- percentile (0..1) della larghezza attuale delle Bollinger sulle ultime 'lookback' barre
double BollWidthPct(const TfData &d, int period, int lookback)
  {
   int n = d.n;
   if(n < period + 10)
      return 0.5;
   double cur = BollWidthAt(d, n - 1, period);
   int start = IMax(period - 1, n - lookback);
   int below = 0, cnt = 0;
   for(int i = start; i < n - 1; i++)
     {
      cnt++;
      if(BollWidthAt(d, i, period) < cur)
         below++;
     }
   return (cnt > 0) ? (double)below / cnt : 0.5;
  }

//--- analisi di un timeframe: strength = barre per lato dei pivot, lookback = barre del range
void AnalyzeTf(const TfData &d, TfContext &c, int strength, int lookback)
  {
   CtxReset(c);
   int n = d.n;
   if(n < 2 * strength + 25)
      return;
   //--- pivot (swing) piu' recenti
   double ph[3];
   double pl[3];
   int nh = 0, nl = 0;
   int maxSh = IMin(lookback * 2, n - strength - 1);
   for(int sh = strength; sh <= maxSh && (nh < 3 || nl < 3); sh++)
     {
      int i = n - 1 - sh;
      bool isH = true, isL = true;
      for(int k = 1; k <= strength; k++)
        {
         if(d.r[i].high <= d.r[i - k].high || d.r[i].high < d.r[i + k].high)
            isH = false;
         if(d.r[i].low >= d.r[i - k].low || d.r[i].low > d.r[i + k].low)
            isL = false;
        }
      if(isH && nh < 3)
        {
         ph[nh] = d.r[i].high;
         nh++;
        }
      if(isL && nl < 3)
        {
         pl[nl] = d.r[i].low;
         nl++;
        }
     }
   double c0 = d.r[n - 1].close;
   if(nh >= 2 && nl >= 2)
     {
      bool hh = ph[0] > ph[1], hl = pl[0] > pl[1];
      bool lh = ph[0] < ph[1], ll = pl[0] < pl[1];
      if(hh && hl)
         c.structure = 1;
      else
         if(lh && ll)
            c.structure = -1;
     }
   if(nh >= 1 && c0 > ph[0])
      c.bos = 1;
   else
      if(nl >= 1 && c0 < pl[0])
         c.bos = -1;
   //--- medie (sui settimanali con poche barre uso solo EMA20)
   double e20 = Ind(d.ema20, 0), e50 = Ind(d.ema50, 0);
   if(n >= 60)
     {
      if(e20 > e50 && c0 > e50)
         c.emaDir = 1;
      else
         if(e20 < e50 && c0 < e50)
            c.emaDir = -1;
     }
   else
      c.emaDir = (c0 > e20) ? 1 : -1;
   c.dir = c.structure;
   if(c.dir == 0)
      c.dir = (c.bos != 0) ? c.bos : c.emaDir;
   //--- range di riferimento e ritracciamento
   int lb = IMin(lookback, n);
   double hi = HighestH(d, 0, lb), lo = LowestL(d, 0, lb);
   c.rangeHi = hi;
   c.rangeLo = lo;
   double rg = hi - lo;
   c.rangePos = (rg > 0.0) ? (c0 - lo) / rg : 0.5;
   if(c.dir > 0)
      c.retr = (rg > 0.0) ? (hi - c0) / rg : 0.0;
   else
      if(c.dir < 0)
         c.retr = (rg > 0.0) ? (c0 - lo) / rg : 0.0;
   //--- volatilita': compressione / espansione
   double a = Ind(d.atr, 0);
   double med = MedianLast(d.atr, 100);
   c.atrRatio = (med > 0.0) ? a / med : 1.0;
   c.bwPct = BollWidthPct(d, 20, 120);
   c.extAtr = (a > 0.0) ? (c0 - e20) / a : 0.0;
   double rg0 = d.r[n - 1].high - d.r[n - 1].low;
   c.nr7 = true;
   for(int k = 1; k < 7 && n - 1 - k >= 0; k++)
      if(d.r[n - 1 - k].high - d.r[n - 1 - k].low <= rg0)
         c.nr7 = false;
   bool comp = (c.bwPct <= 0.20 || c.atrRatio <= 0.75 || (c.nr7 && c.bwPct <= 0.35));
   bool expn = (c.bwPct >= 0.80 || c.atrRatio >= 1.35);
   double rsi = Ind(d.rsi, 0);
   bool exhaust = expn && (MathAbs(c.extAtr) >= 2.5 || (c.extAtr > 0.0 && rsi >= 75.0) || (c.extAtr < 0.0 && rsi <= 25.0));
   if(exhaust)
      c.phase = PH_ESAURIMENTO;
   else
      if(comp)
         c.phase = PH_COMPRESSIONE;
      else
         if(c.dir != 0 && c.structure != 0)
           {
            if(c.retr < 0.382)
               c.phase = expn ? PH_ESPANSIONE : PH_IMPULSO;
            else
               c.phase = PH_RITRACCIAMENTO;
           }
         else
            c.phase = expn ? PH_ESPANSIONE : PH_LATERALE;
   c.valid = true;
  }

double TfCtxScore(const TfContext &c)
  {
   if(!c.valid)
      return 0.0;
   double s = 0.6 * c.structure + 0.4 * c.emaDir;
   if(c.bos != 0 && c.bos != c.structure)
      s += 0.3 * c.bos;
   if(c.phase == PH_RITRACCIAMENTO && c.retr > 0.786)
      s *= 0.5;                              // struttura a rischio
   return Clamp(s, -1.0, 1.0);
  }

string DirWord(int d) { return (d > 0) ? "rialzo" : ((d < 0) ? "ribasso" : "neutro"); }

string TfCtxText(string name, const TfContext &c)
  {
   if(!c.valid)
      return name + " n.d.";
   string t = name + " " + DirWord(c.dir) + ", " + g_phName[c.phase];
   if(c.phase == PH_RITRACCIAMENTO)
      t += " " + DoubleToString(c.retr * 100.0, 0) + "%";
   return t;
  }

//--- ricalcolo (a ogni nuova barra H4 e all'avvio)
void UpdateContext()
  {
   AnalyzeTf(g_w1, g_cxW1, 2, 52);
   AnalyzeTf(g_d1, g_cxD1, 2, 60);
   AnalyzeTf(g_h4, g_cxH4, 3, 90);
   double w = 0.0, s = 0.0;
   if(g_cxW1.valid)
     {
      s += 0.30 * TfCtxScore(g_cxW1);
      w += 0.30;
     }
   if(g_cxD1.valid)
     {
      s += 0.45 * TfCtxScore(g_cxD1);
      w += 0.45;
     }
   if(g_cxH4.valid)
     {
      s += 0.25 * TfCtxScore(g_cxH4);
      w += 0.25;
     }
   g_ctxBias = (w > 0.0) ? Clamp(s / w, -1.0, 1.0) : 0.0;
   g_ctxText = TfCtxText("W1", g_cxW1) + " | " + TfCtxText("D1", g_cxD1) + " | " + TfCtxText("H4", g_cxH4) +
               " -> bias " + DoubleToString(g_ctxBias, 2);
  }

//--- contesto del timeframe "di fase" per ogni motore
int PhaseFor(int engine)
  {
   if(engine == ENG_SWING)
      return g_cxD1.phase;
   return g_cxH4.phase;
  }

int PhaseDirFor(int engine) { return (engine == ENG_SWING) ? g_cxD1.dir : g_cxH4.dir; }
double PhaseRetrFor(int engine) { return (engine == ENG_SWING) ? g_cxD1.retr : g_cxH4.retr; }
double PhaseExtFor(int engine) { return (engine == ENG_SWING) ? g_cxD1.extAtr : g_cxH4.extAtr; }

//--- quali strategie hanno senso adesso (testo per briefing e pannello)
string FavoredText()
  {
   int ph = g_cxH4.phase;
   int phD = g_cxD1.phase;
   string d = (g_ctxBias > 0.2) ? " long" : ((g_ctxBias < -0.2) ? " short" : "");
   if(ph == PH_COMPRESSIONE || phD == PH_COMPRESSIONE)
      return "breakout" + d + " (mercato compresso: in arrivo espansione)";
   if(ph == PH_ESAURIMENTO || phD == PH_ESAURIMENTO)
      return "inversioni / stop run (movimento esausto), niente inseguimenti";
   if(ph == PH_RITRACCIAMENTO && g_cxH4.retr <= 0.786)
      return "pullback" + d + " nella zona di sconto del trend";
   if(ph == PH_IMPULSO || ph == PH_ESPANSIONE)
      return "pullback" + d + " piccoli, evitare di inseguire l'estensione";
   return "range e ritorno alla media (VWAP, value area)";
  }
