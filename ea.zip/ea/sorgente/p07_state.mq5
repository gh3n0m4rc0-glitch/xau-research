//+------------------------------------------------------------------+
//| Stato: statistiche per strategia, metadati posizioni, rischio    |
//+------------------------------------------------------------------+
struct StratStat
  {
   int               n;
   int               wins;
   int               losses;
   double            sumR;
   double            sumR2;
   double            grossWinR;
   double            grossLossR;
   double            net;
   double            last[10];
   int               lastN;
   int               lastHead;
   datetime          benchUntil;

   void              Reset()
     {
      n = 0;
      wins = 0;
      losses = 0;
      sumR = 0.0;
      sumR2 = 0.0;
      grossWinR = 0.0;
      grossLossR = 0.0;
      net = 0.0;
      for(int i = 0; i < 10; i++)
         last[i] = 0.0;
      lastN = 0;
      lastHead = 0;
      benchUntil = 0;
     }

   void              Add(double r, double money)
     {
      n++;
      sumR += r;
      sumR2 += r * r;
      net += money;
      if(r > 0.05)
        {
         wins++;
         grossWinR += r;
        }
      else
         if(r < -0.05)
           {
            losses++;
            grossLossR += -r;
           }
      last[lastHead] = r;
      lastHead = (lastHead + 1) % 10;
      if(lastN < 10)
         lastN++;
     }

   double            Expectancy() const { return (n > 0) ? sumR / n : 0.0; }
   double            WinRate() const { return (n > 0) ? 100.0 * wins / n : 0.0; }
   double            ProfitFactor() const { return (grossLossR > 0.0) ? grossWinR / grossLossR : ((grossWinR > 0.0) ? 99.0 : 0.0); }

   //--- perdite negli ultimi k trade
   int               RecentLosses(int k) const
     {
      int c = 0;
      for(int j = 0; j < k && j < lastN; j++)
        {
         int idx = (lastHead - 1 - j + 20) % 10;
         if(last[idx] < -0.05)
            c++;
        }
      return c;
     }

   double            RecentSum(int k) const
     {
      double s = 0.0;
      for(int j = 0; j < k && j < lastN; j++)
        {
         int idx = (lastHead - 1 - j + 20) % 10;
         s += last[idx];
        }
      return s;
     }
  };

StratStat g_ss[NSTRAT];     // statistiche usate dal comitato (si azzerano in panchina)
StratStat g_rep[NSTRAT];    // statistiche complete per il report
StratStat g_es[3];
StratStat g_all;

//+------------------------------------------------------------------+
//| Metadati di ogni posizione/ordine aperto dall'EA                 |
//+------------------------------------------------------------------+
struct PosMeta
  {
   long              id;
   int               strat;
   int               engine;
   int               dir;
   int               tranche;
   int               idea;
   double            entry;
   double            sl0;
   double            tp;
   double            riskPx;
   double            riskMoney;
   double            lots0;
   double            score;
   double            cushion;
   bool              recovery;
   bool              reentry;
   bool              aplus;
   bool              thirdDone;
   bool              beDone;
   bool              partialDone;
   bool              isPending;
   bool              active;
   datetime          openTime;
   int               expiryMin;
   int               sweepTries;
   double            spreadPx;     // K (1.25): spread pagato all'ingresso
   double            slipPx;       // K (1.25): slittamento all'ingresso (positivo = peggio)
   datetime          deadline;     // 1.27: tempo massimo (UTC) della posizione; 0 = regole del motore
   bool              wkDone;       // 1.27: gia' gestita per il weekend (dimezzata o avvisata)

   void              Reset()
     {
      id = 0;
      strat = 0;
      engine = 0;
      dir = 0;
      tranche = 0;
      idea = 0;
      entry = 0.0;
      sl0 = 0.0;
      tp = 0.0;
      riskPx = 0.0;
      riskMoney = 0.0;
      lots0 = 0.0;
      score = 0.0;
      cushion = 0.0;
      recovery = false;
      reentry = false;
      aplus = false;
      thirdDone = false;
      beDone = false;
      partialDone = false;
      isPending = false;
      active = false;
      openTime = 0;
      expiryMin = 0;
      sweepTries = 0;
      spreadPx = 0.0;
      slipPx = 0.0;
      deadline = 0;
      wkDone = false;
     }
  };
PosMeta g_meta[MAX_META];
int     g_ideaSeq = 0;
bool    g_needSweep = false;
bool    g_needFlowScan = false;

int MetaFind(long id)
  {
   for(int i = 0; i < MAX_META; i++)
      if(g_meta[i].active && g_meta[i].id == id)
         return i;
   return -1;
  }

int MetaFree()
  {
   for(int i = 0; i < MAX_META; i++)
      if(!g_meta[i].active)
         return i;
   return -1;
  }

void MetaRemove(int i)
  {
   if(i >= 0 && i < MAX_META)
      g_meta[i].Reset();
  }

bool IsOurMagic(long magic) { return (magic > InpMagicBase && magic <= InpMagicBase + 3); }
int  EngineOfMagic(long magic) { return (int)(magic - InpMagicBase - 1); }
long MagicOfEngine(int e) { return InpMagicBase + 1 + e; }

int StratByName(string name)
  {
   for(int i = 1; i < NSTRAT; i++)
      if(g_stratName[i] == name)
         return i;
   return 0;
  }

//+------------------------------------------------------------------+
//| Conteggi del portafoglio                                         |
//+------------------------------------------------------------------+
int    g_cntAll = 0;
int    g_cntOnda = 0;         // 1.27: quante delle posizioni aperte sono ritracciamenti (fuori da slot e coda)
int    g_cntEng[3];
int    g_cntDir[2];        // [0]=buy [1]=sell (posizioni non a pareggio)
double g_openRiskDir[2];   // S (1.25): rischio aperto per verso [0]=buy [1]=sell
double g_openRiskMoney = 0.0;

bool PositionExistsById(long id)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetInteger(POSITION_IDENTIFIER) == id)
         return true;
     }
   return false;
  }

bool OrderExists(long ticket)
  {
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong tk = OrderGetTicket(i);
      if(tk == 0)
         continue;
      if((long)tk == ticket)
         return true;
     }
   return false;
  }

void PortfolioScan()
  {
   g_cntAll = 0;
   g_cntOnda = 0;
   g_cntEng[0] = 0;
   g_cntEng[1] = 0;
   g_cntEng[2] = 0;
   g_cntDir[0] = 0;
   g_cntDir[1] = 0;
   g_openRiskMoney = 0.0;
   g_openRiskDir[0] = 0.0;
   g_openRiskDir[1] = 0.0;
   double vpu = ValuePerPriceUnit();
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym)
         continue;
      long mg = PositionGetInteger(POSITION_MAGIC);
      if(!IsOurMagic(mg))
         continue;
      int e = EngineOfMagic(mg);
      int dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      double op = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      double vol = PositionGetDouble(POSITION_VOLUME);
      g_cntAll++;
      //--- 1.27: i ritracciamenti non hanno slot: non devono nemmeno togliere il posto alle altre strategie del motore
      int pm = MetaFind(PositionGetInteger(POSITION_IDENTIFIER));
      bool ownSlot = (InpOndaOwnSlots && pm >= 0 && IsOnda(g_meta[pm].strat));
      if(e >= 0 && e < 3 && !ownSlot)
         g_cntEng[e]++;
      if(ownSlot)
         g_cntOnda++;
      double riskPx = (sl > 0.0) ? (op - sl) * dir : AtrOf(g_h1);
      if(riskPx > 0.0)
        {
         g_openRiskMoney += riskPx * vol * vpu;
         g_openRiskDir[(dir > 0) ? 0 : 1] += riskPx * vol * vpu;
         g_cntDir[(dir > 0) ? 0 : 1]++;
        }
     }
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong tk = OrderGetTicket(i);
      if(tk == 0)
         continue;
      if(OrderGetString(ORDER_SYMBOL) != g_sym)
         continue;
      long mg = OrderGetInteger(ORDER_MAGIC);
      if(!IsOurMagic(mg))
         continue;
      int e = EngineOfMagic(mg);
      ENUM_ORDER_TYPE ot = (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      int dir = (ot == ORDER_TYPE_BUY_LIMIT || ot == ORDER_TYPE_BUY_STOP) ? 1 : -1;
      double op = OrderGetDouble(ORDER_PRICE_OPEN);
      double sl = OrderGetDouble(ORDER_SL);
      double vol = OrderGetDouble(ORDER_VOLUME_CURRENT);
      g_cntAll++;
      if(e >= 0 && e < 3)
         g_cntEng[e]++;
      double riskPx = (sl > 0.0) ? (op - sl) * dir : 0.0;
      if(riskPx > 0.0)
        {
         g_openRiskMoney += riskPx * vol * vpu;
         g_openRiskDir[(dir > 0) ? 0 : 1] += riskPx * vol * vpu;
         g_cntDir[(dir > 0) ? 0 : 1]++;
        }
     }
  }

int MaxPositionsEff() { return g_netting ? 1 : InpMaxPositions; }

int EngineMaxPos(int e)
  {
   if(g_netting)
      return 1;
   if(e == ENG_SCALP)
      return 1;
   return 2;
  }

//+------------------------------------------------------------------+
//| Stato del rischio del conto                                      |
//+------------------------------------------------------------------+
double   g_dayStartEq = 0.0;
double   g_weekStartEq = 0.0;
double   g_weekStartBal = 0.0;
double   g_peakEq = 0.0;
datetime g_dayAnchor = 0;
datetime g_weekAnchor = 0;
bool     g_dayHalt = false;
bool     g_weekHalt = false;
bool     g_ddHalt = false;
int      g_tradesToday[3];
int      g_lossesInRowToday = 0;
int      g_lossStreak = 0;
bool     g_recoveryArmed = false;
datetime g_recoveryArmedT = 0;
datetime g_recoveryCooldownUntil = 0;
//--- rientro dopo pareggio (1.17), uno per motore
bool     g_reArmed[3];
int      g_reDir[3];
datetime g_reT[3];

string GvName(string key) { return "XC." + IntegerToString(g_login) + "." + IntegerToString(InpMagicBase) + "." + key; }

void GvSave()
  {
   GlobalVariableSet(GvName("dayEq"), g_dayStartEq);
   GlobalVariableSet(GvName("dayAnchor"), (double)g_dayAnchor);
   GlobalVariableSet(GvName("weekEq"), g_weekStartEq);
   GlobalVariableSet(GvName("weekBal"), g_weekStartBal);
   GlobalVariableSet(GvName("weekAnchor"), (double)g_weekAnchor);
   GlobalVariableSet(GvName("peak"), g_peakEq);
   GlobalVariableSet(GvName("halt"), g_ddHalt ? 1.0 : 0.0);
   GlobalVariableSet(GvName("dayHalt"), g_dayHalt ? 1.0 : 0.0);
   GlobalVariableSet(GvName("weekHalt"), g_weekHalt ? 1.0 : 0.0);
  }

double GvGet(string key, double def)
  {
   string n = GvName(key);
   if(!GlobalVariableCheck(n))
      return def;
   return GlobalVariableGet(n);
  }

//+------------------------------------------------------------------+
//| Capitale virtuale: il bot si comporta come se il conto fosse di  |
//| InpVirtualCapital (+ i profitti/perdite fatti da quando parte)   |
//+------------------------------------------------------------------+
double g_vStartEq = 0.0;
double g_vStartBal = 0.0;

//--- ora del server affidabile anche a mercato chiuso (TimeCurrent si ferma all'ultimo tick del venerdi')
datetime ServerNow()
  {
   datetime t = TimeTradeServer();
   if(t < TimeCurrent())
      t = TimeCurrent();
   return t;
  }

void VirtualInit()
  {
   if(InpVirtualCapital <= 0.0)
      return;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   bool ok = (GvGet("vCap", -1.0) == InpVirtualCapital && GvGet("vStartBal", 0.0) > 0.0);
   if(ok)
     {
      g_vStartEq = GvGet("vStartEq", eq);
      g_vStartBal = GvGet("vStartBal", bal);
      //--- valore impossibile (lo stop al 50% lo avrebbe fermato prima): dati vecchi o sbagliati -> riparto
      double v = InpVirtualCapital + (bal - g_vStartBal);
      if(v < 0.3 * InpVirtualCapital || v > 50.0 * InpVirtualCapital)
        {
         ok = false;
         GlobalVariableDel(GvName("capMode"));
        }
     }
   if(!ok)
     {
      g_vStartEq = eq;
      g_vStartBal = bal;
      GlobalVariableSet(GvName("vCap"), InpVirtualCapital);
      GlobalVariableSet(GvName("vStartEq"), g_vStartEq);
      GlobalVariableSet(GvName("vStartBal"), g_vStartBal);
     }
  }

double AccEquity()
  {
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   if(InpVirtualCapital <= 0.0)
      return eq;
   return InpVirtualCapital + (eq - g_vStartBal);
  }

double AccBalance()
  {
   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   if(InpVirtualCapital <= 0.0)
      return bal;
   return InpVirtualCapital + (bal - g_vStartBal);
  }

#define STATE_VER 115

void RiskStateInit()
  {
   if(!g_isTester && GvGet("stateVer", 0.0) < STATE_VER)
     {
      GlobalVariableDel(GvName("vCap"));
      GlobalVariableDel(GvName("capMode"));
      GlobalVariableDel(GvName("peak"));
      GlobalVariableSet(GvName("flowTo"), (double)ServerNow());
      GlobalVariableSet(GvName("stateVer"), STATE_VER);
      Logf("Stato del rischio azzerato per la versione " + g_version + " (riferimenti ripartono da adesso)");
     }
   VirtualInit();
   double eq = AccEquity();
   double bal = AccBalance();
   datetime dA = iTime(g_sym, PERIOD_D1, 0);
   datetime wA = iTime(g_sym, PERIOD_W1, 0);
   g_peakEq = MathMax(eq, GvGet("peak", eq));
   g_ddHalt = (GvGet("halt", 0.0) > 0.5);
   //--- capitale virtuale attivato/cambiato/tolto: i vecchi riferimenti (picco, inizio giorno/settimana)
   //--- erano su un'altra base e farebbero scattare stop falsi -> riparto da qui
   bool capChanged = (GvGet("capMode", -1.0) != InpVirtualCapital);
   if(capChanged)
     {
      g_peakEq = eq;
      GlobalVariableSet(GvName("capMode"), InpVirtualCapital);
      GlobalVariableDel(GvName("dayAnchor"));
      GlobalVariableDel(GvName("weekAnchor"));
      Logf("Base del capitale cambiata: picco e riferimenti giornalieri/settimanali ripartono da " + Money(eq));
     }
   if(InpResetHalt)
     {
      g_ddHalt = false;
      g_peakEq = eq;
     }
   if((datetime)GvGet("dayAnchor", 0.0) == dA)
     {
      g_dayAnchor = dA;
      g_dayStartEq = GvGet("dayEq", eq);
      g_dayHalt = (GvGet("dayHalt", 0.0) > 0.5);
     }
   else
     {
      g_dayAnchor = dA;
      g_dayStartEq = eq;
      g_dayHalt = false;
     }
   if((datetime)GvGet("weekAnchor", 0.0) == wA)
     {
      g_weekAnchor = wA;
      g_weekStartEq = GvGet("weekEq", eq);
      g_weekStartBal = GvGet("weekBal", bal);
      g_weekHalt = (GvGet("weekHalt", 0.0) > 0.5);
     }
   else
     {
      g_weekAnchor = wA;
      g_weekStartEq = eq;
      g_weekStartBal = bal;
      g_weekHalt = false;
     }
   g_tradesToday[0] = 0;
   g_tradesToday[1] = 0;
   g_tradesToday[2] = 0;
   GvSave();
  }
