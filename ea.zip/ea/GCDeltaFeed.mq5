//+------------------------------------------------------------------+
//| GCDeltaFeed.mq5 - gira sul MetaTrader 5 della demo AMP Futures   |
//| Legge gli scambi del future oro (GC) con il lato dell'aggressore |
//| e scrive ogni minuto acquisti e vendite aggressive in un file     |
//| comune, che la 1.33 (su IC Markets) legge.                       |
//| 1.02: sceglie da solo il contratto piu' scambiato del giorno     |
//| prima (come i dati dello studio), niente cambio di mese a mano.  |
//| Scrive una riga per ogni minuto in cui e' collegato, anche senza |
//| scambi: un buco nel file vuol dire feed spento o scollegato.     |
//+------------------------------------------------------------------+
#property copyright "XAU Committee"
#property version   "1.02"

input string InpSymbol   = "";              // simbolo fisso del future (vuoto = sceglie da solo il piu' scambiato, consigliato)
input string InpFile     = "GC_delta.csv";  // file nella cartella comune (Common\Files)
input int    InpCheckSec = 1;               // ogni quanti secondi leggere gli scambi

string   g_sym;
long     g_lastMsc = 0;      // ultimo scambio letto (ms, ora del server)
datetime g_curMin  = 0;      // minuto in corso (UTC)
long     g_buy = 0, g_sell = 0, g_none = 0, g_nTicks = 0;
double   g_lastPrice = 0;
long     g_totBuy = 0, g_totSell = 0, g_totNone = 0, g_late = 0;
string   g_pending = "";     // righe non ancora scritte (file occupato)
int      g_sameMs = 0;       // scambi gia' contati con l'ora g_lastMsc (stesso millisecondo)
string   g_root = "";        // radice dei contratti (es. GCE da GCEG27)
datetime g_rollAt = 0;       // ultimo controllo del contratto
string   g_rollInfo = "";    // riga del pannello sulla scelta del contratto

int OnInit()
  {
   g_sym = (InpSymbol == "") ? _Symbol : InpSymbol;
   if(!SymbolSelect(g_sym, true))
     {
      Print("Simbolo non trovato: ", g_sym);
      return INIT_FAILED;
     }
   g_root = (InpSymbol == "") ? RootOf(_Symbol) : "";
   g_lastMsc = ((long)TimeTradeServer() - 5) * 1000;
   ChooseContract();
   EventSetTimer(MathMax(1, InpCheckSec));
   Print("GCDeltaFeed su ", g_sym, " -> ", InpFile, " (cartella comune)");
   return INIT_SUCCEEDED;
  }

//--- radice del contratto: GCEG27 -> GCE, @GCE -> GCE; "" se il nome non e' un contratto con mese
string RootOf(string s)
  {
   if(StringSubstr(s, 0, 1) == "@")
      return StringSubstr(s, 1);
   int n = StringLen(s);
   if(n < 4 || !IsMonthCode(s, n - 3))
      return "";
   return StringSubstr(s, 0, n - 3);
  }

bool IsMonthCode(string s, int pos)          // lettera del mese + due cifre dell'anno (es. G27)
  {
   if(StringFind("FGHJKMNQUVXZ", StringSubstr(s, pos, 1)) < 0)
      return false;
   ushort a = StringGetCharacter(s, pos + 1), b = StringGetCharacter(s, pos + 2);
   return (a >= '0' && a <= '9' && b >= '0' && b <= '9');
  }

//--- contratti scambiati nell'ultima giornata completa prima di oggi (lun-ven; la domenica sera fa parte del lunedi')
long LastDayVolume(string s)
  {
   MqlRates r[];
   int n = CopyRates(s, PERIOD_D1, 0, 5, r);
   datetime now = TimeTradeServer();
   datetime today = now - (now % 86400);
   for(int i = n - 1; i >= 0; i--)
     {
      if(r[i].time >= today)
         continue;                              // giornata in corso
      MqlDateTime d;
      TimeToStruct(r[i].time, d);
      if(d.day_of_week == 0 || d.day_of_week == 6)
         continue;
      return (r[i].real_volume > 0) ? r[i].real_volume : r[i].tick_volume;
     }
   return -1;                                   // dati non ancora arrivati: riprovo dopo
  }

//--- sceglie il contratto con piu' scambi nell'ultima giornata, tra i 3 che scadono prima (come GC.v.0 dello studio)
void ChooseContract()
  {
   if(g_root == "")
      return;                                   // simbolo fisso o nome non riconosciuto: resta quello
   datetime now = TimeTradeServer();
   if(g_rollAt != 0 && now - g_rollAt < 600)
      return;                                   // ogni 10 minuti basta
   g_rollAt = now;
   string c[];
   datetime e[];
   int k = 0, L = StringLen(g_root);
   int tot = SymbolsTotal(false);
   for(int i = 0; i < tot; i++)
     {
      string s = SymbolName(i, false);
      if(StringLen(s) != L + 3 || StringSubstr(s, 0, L) != g_root || !IsMonthCode(s, L))
         continue;
      datetime ex = (datetime)SymbolInfoInteger(s, SYMBOL_EXPIRATION_TIME);
      if(ex != 0 && ex <= now)
         continue;                              // scaduto
      ArrayResize(c, k + 1);
      ArrayResize(e, k + 1);
      c[k] = s;
      e[k] = (ex == 0) ? D'2100.01.01' : ex;
      k++;
     }
   for(int i = 1; i < k; i++)                   // in ordine di scadenza
      for(int j = i; j > 0 && e[j] < e[j - 1]; j--)
        {
         datetime te = e[j]; e[j] = e[j - 1]; e[j - 1] = te;
         string ts = c[j]; c[j] = c[j - 1]; c[j - 1] = ts;
        }
   string best = "", info = "";
   long bestV = -1, curV = -1;
   bool curIn = false;                          // il contratto in uso e' tra i candidati
   for(int i = 0; i < k && i < 3; i++)
     {
      SymbolSelect(c[i], true);
      long v = LastDayVolume(c[i]);
      info += (info == "" ? "" : ", ") + c[i] + " " + (v < 0 ? "?" : IntegerToString(v));
      if(c[i] == g_sym)
        {
         curIn = true;
         curV = v;
        }
      if(v > bestV)
        {
         bestV = v;
         best = c[i];
        }
     }
   //--- cambio solo se so quanto ha fatto anche quello in uso (dati mancanti: aspetto), oppure se quello in uso e' scaduto
   if(best != "" && best != g_sym && bestV > 0 && (!curIn || (curV >= 0 && bestV > curV)))
     {
      Print("GCDeltaFeed: cambio contratto ", g_sym, " -> ", best, " (contratti dell'ultima giornata: ", info, ")");
      g_sym = best;
      g_lastMsc = ((long)TimeTradeServer() - 1) * 1000;   // dal nuovo contratto leggo da adesso
      g_sameMs = 0;
     }
   g_rollInfo = "contratto scelto da solo (il piu' scambiato ieri): " + g_sym + " | ieri: " + info;
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   WritePending();
   Comment("");
  }

int ServerOffsetSec()   // ora del server - UTC, arrotondata al quarto d'ora
  {
   long d = (long)TimeTradeServer() - (long)TimeGMT();
   return (int)(MathRound(d / 900.0) * 900);
  }

void WritePending()
  {
   if(g_pending == "")
      return;
   int h = FileOpen(InpFile, FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ | FILE_SHARE_WRITE);
   if(h == INVALID_HANDLE)
      return;                                    // file occupato: riprovo al prossimo giro, le righe restano
   if(FileSize(h) == 0)
      FileWriteString(h, "utc;buy;sell;none;ticks;last;contratto\r\n");
   FileSeek(h, 0, SEEK_END);
   FileWriteString(h, g_pending);
   FileClose(h);
   g_pending = "";
  }

void CloseMinute()
  {
   if(g_curMin == 0)
      return;
   g_pending += TimeToString(g_curMin, TIME_DATE | TIME_MINUTES) + ";" + IntegerToString(g_buy) + ";" + IntegerToString(g_sell) + ";" +
                IntegerToString(g_none) + ";" + IntegerToString(g_nTicks) + ";" + DoubleToString(g_lastPrice, 2) + ";" + g_sym + "\r\n";
   g_buy = g_sell = g_none = g_nTicks = 0;
   g_curMin += 60;
  }

void OnTimer()
  {
   bool conn = (TerminalInfoInteger(TERMINAL_CONNECTED) != 0);
   int off = ServerOffsetSec();
   datetime nowUtc = (datetime)((long)TimeTradeServer() - off);
   if(!conn)
     {
      g_curMin = 0;                              // scollegato: lascio un buco nel file
      Comment("GCDeltaFeed ", g_sym, ": SCOLLEGATO");
      return;
     }
   ChooseContract();
   MqlTick t[];
   long now = (long)TimeTradeServer() * 1000 + 999;
   int n = CopyTicksRange(g_sym, t, COPY_TICKS_TRADE, (ulong)g_lastMsc, (ulong)now);
   int skip = g_sameMs;                         // gli scambi di g_lastMsc gia' contati al giro prima
   for(int i = 0; i < n; i++)
     {
      if(t[i].time_msc == g_lastMsc && skip > 0)
        {
         skip--;
         continue;
        }
      datetime utc = (datetime)(t[i].time_msc / 1000 - off);
      datetime mn  = utc - (utc % 60);
      if(g_curMin == 0)
         g_curMin = mn;
      while(mn > g_curMin)
         CloseMinute();
      long v = (long)t[i].volume;
      if(mn < g_curMin)
         g_late++;                               // arrivato dopo: lo conto nel minuto in corso
      if((t[i].flags & TICK_FLAG_BUY) != 0 && (t[i].flags & TICK_FLAG_SELL) == 0)
        { g_buy += v; g_totBuy += v; }
      else
         if((t[i].flags & TICK_FLAG_SELL) != 0 && (t[i].flags & TICK_FLAG_BUY) == 0)
           { g_sell += v; g_totSell += v; }
         else
           { g_none += v; g_totNone += v; }
      g_nTicks++;
      g_lastPrice = t[i].last;
      if(t[i].time_msc == g_lastMsc)
         g_sameMs++;
      else
        {
         g_lastMsc = t[i].time_msc;
         g_sameMs = 1;
        }
     }
   //--- minuti finiti da piu' di 10 secondi senza altri scambi: li chiudo (anche vuoti)
   if(g_curMin == 0)
      g_curMin = nowUtc - (nowUtc % 60);
   while(g_curMin + 60 <= nowUtc - 10)
      CloseMinute();
   WritePending();
   string side = (g_totBuy + g_totSell + g_totNone == 0) ? "ancora nessuno scambio"
                 : StringFormat("con il lato %.0f%%", 100.0 * (g_totBuy + g_totSell) / (g_totBuy + g_totSell + g_totNone));
   long delay = (long)TimeTradeServer() - g_lastMsc / 1000;
   Comment("GCDeltaFeed ", g_sym, " -> ", InpFile,
           "\nultimo scambio ", TimeToString((datetime)(g_lastMsc / 1000), TIME_SECONDS), " (", delay, " secondi fa: deve restare di pochi secondi, se sono minuti i dati sono ritardati)",
           "\nacquisti aggressivi ", g_totBuy, " | vendite aggressive ", g_totSell, " | senza lato ", g_totNone, " (", side, ")",
           "\nse quasi tutto e' 'senza lato', questo feed non da' il delta",
           "\nscambi arrivati in ritardo ", g_late,
           "\n", (g_root == "" ? "contratto fisso: " + g_sym + " (a fine mese va cambiato a mano)" : g_rollInfo));
  }
//+------------------------------------------------------------------+
