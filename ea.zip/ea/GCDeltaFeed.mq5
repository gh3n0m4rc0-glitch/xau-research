//+------------------------------------------------------------------+
//| GCDeltaFeed.mq5 - gira sul MetaTrader 5 della demo AMP Futures   |
//| Legge gli scambi del future oro (GC) con il lato dell'aggressore |
//| e scrive ogni minuto acquisti e vendite aggressive in un file     |
//| comune, che XauAssorbimento (su IC Markets) legge.               |
//| Scrive una riga per ogni minuto in cui e' collegato, anche senza |
//| scambi: un buco nel file vuol dire feed spento o scollegato.     |
//+------------------------------------------------------------------+
#property copyright "XAU Committee"
#property version   "1.01"

input string InpSymbol   = "";              // simbolo del future (vuoto = quello del grafico, es. il GC del mese attivo)
input string InpFile     = "GC_delta.csv";  // file nella cartella comune (Common\Files)
input int    InpCheckSec = 1;               // ogni quanti secondi leggere gli scambi

string   g_sym;
long     g_lastMsc = 0;      // ultimo scambio letto (ms, ora del server)
datetime g_curMin  = 0;      // minuto in corso (UTC)
long     g_buy = 0, g_sell = 0, g_none = 0, g_nTicks = 0;
double   g_lastPrice = 0;
long     g_totBuy = 0, g_totSell = 0, g_totNone = 0, g_late = 0;
string   g_pending = "";     // righe non ancora scritte (file occupato)
int      g_sameMs = 0;       // scambi gia' contati con l'ora g_lastMsc (stesso millisecondo)

int OnInit()
  {
   g_sym = (InpSymbol == "") ? _Symbol : InpSymbol;
   if(!SymbolSelect(g_sym, true))
     {
      Print("Simbolo non trovato: ", g_sym);
      return INIT_FAILED;
     }
   g_lastMsc = ((long)TimeTradeServer() - 5) * 1000;
   EventSetTimer(MathMax(1, InpCheckSec));
   Print("GCDeltaFeed su ", g_sym, " -> ", InpFile, " (cartella comune)");
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   WritePending();
   Comment("");
  }

int ServerOffsetSec()   // ora del server - UTC, arrotondata al quarto d'ora
  {
   long d = (long)TimeTradeServer() - (long)TimeGMT();
   return (int)(MathRound(d / 900.0) * 900);
  }

void WritePending()
  {
   if(g_pending == "")
      return;
   int h = FileOpen(InpFile, FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ | FILE_SHARE_WRITE);
   if(h == INVALID_HANDLE)
      return;                                    // file occupato: riprovo al prossimo giro, le righe restano
   if(FileSize(h) == 0)
      FileWriteString(h, "utc;buy;sell;none;ticks;last\r\n");
   FileSeek(h, 0, SEEK_END);
   FileWriteString(h, g_pending);
   FileClose(h);
   g_pending = "";
  }

void CloseMinute()
  {
   if(g_curMin == 0)
      return;
   g_pending += TimeToString(g_curMin, TIME_DATE | TIME_MINUTES) + ";" + IntegerToString(g_buy) + ";" + IntegerToString(g_sell) + ";" +
                IntegerToString(g_none) + ";" + IntegerToString(g_nTicks) + ";" + DoubleToString(g_lastPrice, 2) + "\r\n";
   g_buy = g_sell = g_none = g_nTicks = 0;
   g_curMin += 60;
  }

void OnTimer()
  {
   bool conn = (TerminalInfoInteger(TERMINAL_CONNECTED) != 0);
   int off = ServerOffsetSec();
   datetime nowUtc = (datetime)((long)TimeTradeServer() - off);
   if(!conn)
     {
      g_curMin = 0;                              // scollegato: lascio un buco nel file
      Comment("GCDeltaFeed ", g_sym, ": SCOLLEGATO");
      return;
     }
   MqlTick t[];
   long now = (long)TimeTradeServer() * 1000 + 999;
   int n = CopyTicksRange(g_sym, t, COPY_TICKS_TRADE, (ulong)g_lastMsc, (ulong)now);
   int skip = g_sameMs;                         // gli scambi di g_lastMsc gia' contati al giro prima
   for(int i = 0; i < n; i++)
     {
      if(t[i].time_msc == g_lastMsc && skip > 0)
        {
         skip--;
         continue;
        }
      datetime utc = (datetime)(t[i].time_msc / 1000 - off);
      datetime mn  = utc - (utc % 60);
      if(g_curMin == 0)
         g_curMin = mn;
      while(mn > g_curMin)
         CloseMinute();
      long v = (long)t[i].volume;
      if(mn < g_curMin)
         g_late++;                               // arrivato dopo: lo conto nel minuto in corso
      if((t[i].flags & TICK_FLAG_BUY) != 0 && (t[i].flags & TICK_FLAG_SELL) == 0)
        { g_buy += v; g_totBuy += v; }
      else
         if((t[i].flags & TICK_FLAG_SELL) != 0 && (t[i].flags & TICK_FLAG_BUY) == 0)
           { g_sell += v; g_totSell += v; }
         else
           { g_none += v; g_totNone += v; }
      g_nTicks++;
      g_lastPrice = t[i].last;
      if(t[i].time_msc == g_lastMsc)
         g_sameMs++;
      else
        {
         g_lastMsc = t[i].time_msc;
         g_sameMs = 1;
        }
     }
   //--- minuti finiti da piu' di 10 secondi senza altri scambi: li chiudo (anche vuoti)
   if(g_curMin == 0)
      g_curMin = nowUtc - (nowUtc % 60);
   while(g_curMin + 60 <= nowUtc - 10)
      CloseMinute();
   WritePending();
   string side = (g_totBuy + g_totSell + g_totNone == 0) ? "ancora nessuno scambio"
                 : StringFormat("con il lato %.0f%%", 100.0 * (g_totBuy + g_totSell) / (g_totBuy + g_totSell + g_totNone));
   long delay = (long)TimeTradeServer() - g_lastMsc / 1000;
   Comment("GCDeltaFeed ", g_sym, " -> ", InpFile,
           "\nultimo scambio ", TimeToString((datetime)(g_lastMsc / 1000), TIME_SECONDS), " (", delay, " secondi fa: deve restare di pochi secondi, se sono minuti i dati sono ritardati)",
           "\nacquisti aggressivi ", g_totBuy, " | vendite aggressive ", g_totSell, " | senza lato ", g_totNone, " (", side, ")",
           "\nse quasi tutto e' 'senza lato', questo feed non da' il delta",
           "\nscambi arrivati in ritardo ", g_late);
  }
//+------------------------------------------------------------------+
