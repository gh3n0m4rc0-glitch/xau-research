//+------------------------------------------------------------------+
//|                                              XauCommitteeEA.mq5  |
//|        Comitato per l'oro (XAUUSD): scalping + intraday + swing  |
//|                                                                  |
//|  Tre motori con segnali diversi che parlano la stessa lingua:    |
//|  ogni idea diventa un TSignal, passa dallo stesso comitato di    |
//|  desk (trend, volumi, liquidita, macro, news, sessione, costi,   |
//|  statistica), dallo stesso avvocato del diavolo e dallo stesso   |
//|  risk manager con lotti dinamici in base al conto.               |
//+------------------------------------------------------------------+
#property copyright   "Progetto XAU Committee"
#property version     "1.27"
#property description "EA per l'oro con 3 motori (scalping, intraday, swing) e un comitato comune."
#property description "Lotti dinamici in base al conto, R:R minimo 1:2, pareggio a +1.5R, stop -7% giorno / -10% settimana / 50% drawdown."

#include <Trade\Trade.mqh>

//--- scelta della strategia da testare (per l'ottimizzazione una alla volta)
enum ENUM_STRAT_PICK
  {
   PICK_ALL = 0,          // Tutte le strategie
   PICK_SC_VWAP = 1,      // Solo SC-VWAP (scalping pullback su VWAP)
   PICK_SC_SWEEP = 2,     // Solo SC-SWEEP (scalping stop run)
   PICK_SC_ORB = 3,       // Solo SC-ORB (scalping range di apertura)
   PICK_IN_PULLBACK = 4,  // Solo IN-PULLBACK (intraday trend pullback)
   PICK_IN_SWEEP = 5,     // Solo IN-SWEEP (intraday stop run sui livelli)
   PICK_IN_BREAKOUT = 6,  // Solo IN-BREAKOUT (intraday breakout + retest)
   PICK_IN_VALUE = 7,     // Solo IN-VALUE80 (regola 80% value area)
   PICK_IN_NEWS = 8,      // Solo IN-NEWS (continuation dopo news)
   PICK_IN_RANGE = 9,     // Solo IN-RANGE (ritorno alla VWAP in laterale)
   PICK_SW_TREND = 10,    // Solo SW-TREND (swing trend pullback H4)
   PICK_SW_WYCKOFF = 11,  // Solo SW-WYCKOFF (spring/upthrust H4)
   PICK_IN_TREND = 12,    // Solo IN-TREND (giornata di tendenza di New York)
   PICK_IN_DATA = 13,     // Solo IN-DATO (dopo un CPI che sorprende)
   PICK_IN_NIGHT = 14,    // Solo IN-NOTTE (movimento forte di notte e a Londra)
   PICK_IN_TREND2 = 15,   // Solo IN-TREND2 (secondo ingresso della giornata di tendenza)
   PICK_ON_M15 = 16,      // Solo ONDA-M15 (ritracciamento nel trend su M15)
   PICK_ON_H1 = 17,       // Solo ONDA-H1 (ritracciamento nel trend su H1)
   PICK_ON_H4 = 18,       // Solo ONDA-H4 (ritracciamento nel trend su H4)
   PICK_ON_M5 = 19        // Solo ONDA-M5 (ritracciamento nel trend su M5, direzione chiara)
  };

//+------------------------------------------------------------------+
//| Input                                                            |
//+------------------------------------------------------------------+
input group "=== Generale ==="
input string InpSymbolOverride   = "";       // Simbolo oro (vuoto = simbolo del grafico)
input long   InpMagicBase        = 260800;   // Magic base (scalping +1, intraday +2, swing +3)
input bool   InpEnableScalping   = true;     // Motore SCALPING attivo
input bool   InpEnableIntraday   = true;     // Motore INTRADAY attivo
input bool   InpEnableSwing      = true;     // Motore SWING attivo
input ENUM_STRAT_PICK InpOnlyStrategy = PICK_ALL; // Test: usa solo questa strategia
input bool   InpPushNotify       = true;     // Notifiche push sul telefono (app MT5)
input bool   InpVerboseLog       = false;    // Log dettagliato (anche i segnali respinti)

input group "=== Rischio e lotti ==="
input double InpVirtualCapital   = 0.0;      // Capitale virtuale di partenza (0 = conto vero; poi cresce/cala con i risultati)
input double InpRiskPercent      = 1.0;      // Rischio base per trade (% del conto)
input double InpScalpRiskMult    = 0.75;     // Moltiplicatore rischio scalping
input double InpSwingRiskMult    = 1.0;      // Moltiplicatore rischio swing
input double InpMaxRiskPerTrade  = 3.0;      // Rischio massimo per trade (%), recupero incluso
input double InpMinLotMaxRiskPct = 2.5;      // Se serve il lotto minimo: rischio massimo accettato (%)
input double InpMaxOpenRiskPct   = 4.0;      // Rischio aperto totale massimo (%) (posizioni a pareggio = 0)
input int    InpMaxPositions     = 4;        // Posizioni massime contemporanee (tutti i motori)
input double InpMinMarginLevel   = 120.0;    // Livello di margine minimo dopo l'apertura (%)
input double InpMaxLots          = 5.0;      // Lotti massimi per singolo ordine
input double InpDailyLossPct     = 7.0;      // Stop giornaliero (% dall'equity di inizio giorno)
input double InpWeeklyLossPct    = 10.0;     // Stop settimanale (% dall'equity di inizio settimana)
input double InpMaxDrawdownPct   = 50.0;     // Drawdown massimo dal picco: chiude tutto e si ferma (%)
input bool   InpResetHalt        = false;    // Sblocca l'EA dopo lo stop per drawdown massimo
input int    InpMaxLossesInRowDay = 3;       // Perdite di fila nello stesso giorno prima di fermarsi
input double InpCommissionPerLot = 7.0;      // Commissione andata+ritorno per 1 lotto (valuta del conto)

input group "=== Crescita del conto e recupero ==="
input bool   InpUseProfitCushion = true;     // Idee forti: rischio extra pagato con i profitti della settimana
input double InpCushionUse       = 0.5;      // Quota del profitto settimanale usabile come rischio extra
input double InpCushionMaxMult   = 1.0;      // Rischio extra massimo (x rischio base)
input bool   InpRecoveryEnabled  = true;     // Trade di recupero dopo una perdita (una volta sola)
input double InpRecoveryMult     = 1.75;     // Moltiplicatore lotti del trade di recupero
input double InpRecoveryMinScore = 0.75;     // Punteggio minimo del comitato per il recupero
input bool   InpAllowTranches    = true;     // Idee forti: fino a 3 ingressi scaglionati (40/30/30)
input bool   InpUseBench         = true;     // Mette in panchina le strategie con aspettativa negativa

input group "=== Regole fisse dei trade ==="
input double InpMinRR            = 2.0;      // Rischio/rendimento minimo (1:2)
input double InpBE_R             = 1.5;      // Stop a pareggio quando il trade arriva a +R (1.5-1.75)
input double InpPartialPct       = 40.0;     // Chiusura parziale al pareggio (% volume, se il lotto lo permette)
input double InpTrailStartR      = 2.0;      // Trailing stop da +R
input double InpMaxCostR         = 0.15;     // Costi massimi (spread+commissione) come frazione di R

input group "=== Comitato ==="
input double InpMinScoreScalp    = 0.62;     // Punteggio minimo comitato scalping
input double InpMinScoreIntra    = 0.62;     // Punteggio minimo comitato intraday
input double InpMinScoreSwing    = 0.65;     // Punteggio minimo comitato swing
input double InpStrongScore      = 0.78;     // Soglia "idea forte"
input int    InpQuorum           = 6;        // Desk principali favorevoli richiesti (su 8)
input int    InpDevilMax         = 3;        // Obiezioni dell'avvocato del diavolo che bloccano

input group "=== Scalping (M1-M5) ==="
input int    InpScalpMaxTradesDay = 6;       // Trade scalping massimi al giorno
input int    InpScalpMaxMinutes  = 60;       // Chiude lo scalp dopo N minuti se non e' a pareggio
input double InpScalpRR          = 2.2;      // Target scalping (R)
input bool   InpSC_VWAP          = true;     // SC-VWAP: pullback su VWAP in trend
input bool   InpSC_SWEEP         = true;     // SC-SWEEP: stop run sui livelli e rientro
input bool   InpSC_ORB           = true;     // SC-ORB: breakout range di apertura + retest

input group "=== Intraday (M5-M15) ==="
input int    InpIntraMaxTradesDay = 4;       // Trade intraday massimi al giorno
input int    InpIntraMaxHours    = 8;        // Chiude l'intraday dopo N ore se non e' a pareggio
input double InpIntraRR          = 2.5;      // Target intraday (R)
input bool   InpIN_PULLBACK      = true;     // IN-PULLBACK: trend H1 + pullback M15
input bool   InpIN_SWEEP         = true;     // IN-SWEEP: stop run su PDH/PDL/Asia/Londra
input bool   InpIN_BREAKOUT      = true;     // IN-BREAKOUT: breakout con volume + retest
input bool   InpIN_VALUE         = true;     // IN-VALUE80: rientro nella value area di ieri
input bool   InpIN_NEWS          = true;     // IN-NEWS: continuation dopo news coerente con la vista
input bool   InpIN_RANGE         = true;     // IN-RANGE: da VWAP +-2 sigma alla VWAP in laterale

input group "=== Swing (H1-H4) ==="
input int    InpSwingMaxTradesDay = 2;       // Trade swing massimi al giorno
input int    InpSwingMaxBarsH4   = 30;       // Chiude lo swing dopo N barre H4 se non e' a pareggio
input double InpSwingRR          = 3.0;      // Target swing (R)
input bool   InpSwingHoldWeekend = false;    // Tiene lo swing nel weekend anche se non e' a pareggio
input bool   InpSW_TREND         = true;     // SW-TREND: trend H4 + pullback H1
input bool   InpSW_WYCKOFF       = false;    // SW-WYCKOFF: spring/upthrust nel range H4 (spento dalla 1.24: sui dati 2022-26 non batte il caso)

input group "=== Orari e news ==="
input int    InpGmtOffsetLive    = -99;      // Fuso del server live (ore, -99 = automatico)
input int    InpGmtOffsetTester  = -99;      // Fuso del server nel tester (-99 = GMT+2 inverno / +3 estate)
input int    InpIntraCloseUTC    = 20;       // Ora UTC di chiusura di scalping e intraday
input int    InpNewsBlockBefore  = 30;       // Minuti senza ingressi prima di una news tier1 (scalp/intraday)
input int    InpNewsBlockAfter   = 15;       // Minuti senza ingressi dopo una news tier1 (scalp/intraday)
input int    InpNewsBlockSwingBefore = 90;   // Minuti senza ingressi swing prima di una news tier1
input int    InpNewsBlockSwingAfter  = 60;   // Minuti senza ingressi swing dopo una news tier1
input int    InpNewsBlockFomcAfter   = 90;   // Minuti senza ingressi (anche IN-NEWS) dopo la decisione FOMC, conferenza inclusa (0 = come le altre tier1)
input bool   InpCloseBeforeNews  = true;     // Chiude scalp (e intraday non a pareggio) 5 min prima di news tier1

input group "=== Motori del prezzo (studio 9 nov 2026) ==="
input bool   InpP1RunBrake       = true;     // P1: freno dopo le corse verticali (rischio ridotto, niente long in rottura)
input double InpP1RunSigma       = 2.5;      // P1: corsa degli ultimi 20 giorni oltre questi sigma
input double InpP1Ma200DistPct   = 20.0;     // P1: oppure prezzo oltre questa % sopra la media a 200 giorni
input double InpP1RiskMult       = 0.5;      // P1: moltiplicatore del rischio con il freno acceso
input bool   InpP2ThinLiquidity  = true;     // P2: niente ingressi con liquidita' sottile (feste USA, Asia nelle feste giapponesi, riaperture)
input int    InpP2ReopenMin      = 60;       // P2: minuti senza ingressi dopo una riapertura (pausa oltre 3 ore)
input bool   InpP3NoRiskOffBonus = false;    // P3: azzera il bonus "fuga dal rischio" del desk intermarket
input bool   InpP4FirstDayLong   = true;     // P4: spinta ai long il primo giorno di borsa del mese (acceso dalla 1.20: studio candele)
input double InpP4Bonus          = 0.02;     // P4: punti aggiunti al punteggio dei long
input bool   InpP5AsiaStopBuffer = false;    // P5: nelle ore asiatiche stop oltre i livelli ovvi (PDH/PDL, settimana, Asia, numeri tondi)
input double InpP5BufferAtrH1    = 0.25;     // P5: margine oltre il livello (x ATR H1)
input bool   InpP6ExpiryTargets  = false;    // P6: target dei breakout piu' corti alla scadenza opzioni COMEX e il giorno dopo
input double InpP6TargetMult     = 0.85;     // P6: moltiplicatore del target in R (mai sotto il minimo 1:2)

input group "=== Studio candele (9 nov 2026) ==="
input bool   InpC1BigDayRisk     = true;     // C1: rischio ridotto (scalping e intraday) il giorno dopo una candela D1 molto larga
input double InpC1BigDayAtr      = 2.0;      // C1: candela D1 di ieri oltre questi ATR (ATR 20 giorni prima di ieri)
input double InpC1RiskMult       = 0.75;     // C1: moltiplicatore del rischio
input bool   InpC3TightAsia      = false;    // C3: spinta a SC-SWEEP e IN-SWEEP quando il range di Asia e' stretto
input double InpC3AsiaAtr        = 0.40;     // C3: Asia stretta = range dalle 18 di New York all'apertura di Londra sotto questa frazione dell'ATR D1
input double InpC3Bonus          = 0.02;     // C3: punti aggiunti al punteggio

input group "=== Studio analisi tecnica (9 nov 2026) ==="
input bool   InpT2NoDiscountBonus = true;    // T2: niente bonus "zona di sconto 38-79%" e niente malus "inseguire l'estensione" nel desk Contesto (non battono il caso)
input bool   InpT3NoRangeEdgeObj  = true;    // T3: niente obiezione del diavolo "prezzo agli estremi del range D1" (comprare in alto non e' peggio)
input bool   InpT4RoundNotMajor   = true;    // T4: i numeri tondi forti non contano come livelli forti (solo target e ostacoli normali)
input bool   InpT5NoShortAfterCrash = true;  // T5: dopo un movimento esausto in basso sul D1 niente short di trend (i crolli esausti rimbalzano)
input int    InpT5Days            = 5;       // T5: giorni di borsa senza short di trend dopo l'esaurimento in basso

input group "=== Studio order flow (9 nov 2026) ==="
input bool   InpOF1FixNoChase     = true;    // OF1: dopo il fixing LBMA delle 10:30 di Londra, per 15 minuti niente ingressi nel verso del movimento 10:15-10:30 (si gira)
input double InpOF1MinBp          = 3.0;     // OF1: movimento minimo 10:15-10:30 in punti base (3 bp = circa 1,2 $ con l'oro a 4.000)
input bool   InpOF2VolumeNeutral  = true;    // OF2: desk Volumi senza delta, VWAP, climax, profilo e DOM (sul demo non battono il caso); restano RVOL e GC

input group "=== Costi veri, volatilita', diario, protezioni (1.25) ==="
input bool   InpCostTrack         = true;    // K: misura spread, slittamento e commissioni veri di ogni trade e li usa nel desk Costi e nei lotti
input bool   InpVolTarget         = true;    // V: rischio ridotto quando la volatilita' prevista supera il normale (mai sopra il rischio base)
input double InpVolMinMult        = 0.5;     // V: riduzione massima del rischio per volatilita' alta
input bool   InpDecisionLog       = true;    // D: diario CSV di ogni idea valutata (desk, punteggio, veto, esecuzione)
input bool   InpSafetyAlerts      = true;    // S: avvisi sul telefono (Algo Trading spento, niente prezzi, macro ferma, spread esploso, weekend)
input double InpMaxDirRiskPct     = 3.0;     // S: rischio aperto massimo nello stesso verso (% del conto): le posizioni sono tutte oro
input bool   InpWeekendHalfSwing  = true;    // S: il venerdi' sera gli swing non ancora a pareggio vengono dimezzati (gap del weekend)

input group "=== Meno regole: conferme forti e obiezioni misurate (1.25) ==="
input bool   InpOverrideOn         = true;   // MR: conferme forti possono scavalcare le obiezioni secondarie (con rischio ridotto)
input int    InpOverrideQuorum     = 7;      // MR: desk principali a favore richiesti per scavalcare (su 8)
input double InpOverrideExtraScore = 0.06;   // MR: punteggio richiesto sopra la soglia del motore per scavalcare
input int    InpOverrideMaxSoft    = 2;      // MR: obiezioni secondarie scavalcabili insieme (l'avvocato del diavolo conta come una)
input double InpOverrideRiskMult   = 0.6;    // MR: rischio dell'idea che scavalca le obiezioni (x)
input bool   InpObjLearn           = true;   // MR: idee fantasma: il bot misura da solo quali obiezioni servono davvero
input int    InpObjMinN            = 30;     // MR: casi minimi con e senza l'obiezione prima di giudicarla
input bool   InpObjFromTester      = true;   // MR: sul conto parte da quello che ha imparato il Tester (file in Common\Files)

input group "=== Movimenti forti (1.26) ==="
input bool   InpIN_TREND          = true;    // IN-TREND: quando New York porta l'oro lontano dal prezzo delle 8:00, entra nel verso del movimento
input double InpTDThreshAtr       = 0.80;    // MF: distanza dal prezzo di partenza che fa scattare l'ingresso (x escursione media di 20 giorni)
input double InpTDStopAtr         = 0.40;    // MF: stop (x escursione media di 20 giorni)
input double InpTDStopMinAtr      = 0.25;    // MF: stop piu' stretto accettato se il conto non regge quello pieno (lotti piu' alti a parita' di rischio)
input double InpTDTargetAtr       = 2.0;     // MF: target lontano (x escursione media); di norma si esce a pareggio o alla fine della tenuta
input int    InpTDFromMin         = 5;       // IN-TREND: minuti dopo le 8:00 di New York da cui guarda
input int    InpTDUntilMin        = 180;     // IN-TREND: minuti dopo le 8:00 di New York fino a cui puo' entrare (180 = 11:00)
input int    InpTDMaxDelayMin     = 15;      // MF: se al primo superamento non puo' entrare (news, spread), riprova per questi minuti
input int    InpTDHoldDays        = 1;       // MF: tenuta come swing: 0 = chiude la sera stessa, 1 = la sera del giorno di borsa dopo (venerdi' chiude sempre la sera)
input bool   InpTDTrail           = false;   // MF: trailing dopo il pareggio (spento: sui dati taglia i movimenti lunghi)
input double InpTDRiskMult        = 1.5;     // IN-TREND: rischio = rischio base x questo (regola provata: 1,5 = 1,5%); mai oltre il rischio massimo per trade
input double InpTDMinLotRiskPct   = 3.0;     // MF: con il lotto minimo, rischio massimo accettato (%), mai oltre il rischio massimo per trade
input bool   InpTDProven          = true;    // MF: regole proprie misurate sui dati: le fermano solo i limiti di rischio, le news forti, i costi e la liquidita'
input bool   InpIN_DATA           = true;    // IN-DATO: dopo un dato d'inflazione che sorprende (caldo = vende, freddo = compra), stessa gestione
input double InpDataRiskMult      = 0.5;     // IN-DATO: rischio = rischio base x questo (pochi casi nella storia: meta' rischio)
input int    InpDataMaxDelayMin   = 5;       // IN-DATO: entra entro questi minuti da quando il dato e' noto
input bool   InpDataAlerts        = true;    // Dati: legge dato e previsione dal calendario MT5 e avvisa sul telefono (caldo/freddo e cosa fa di solito l'oro)
input bool   InpIN_NIGHT          = true;    // IN-NOTTE: lo stesso movimento forte di notte e a Londra (dal prezzo delle 18:00 di New York)

input group "=== Ritracciamenti nel verso del trend (1.27) ==="
input bool   InpON_M5             = true;    // ONDA-M5: ritracciamento finito su M5, solo con direzione chiara (trend D1, H4 e H1 d'accordo); piu' ingressi al giorno
input bool   InpON_M15            = true;    // ONDA-M15: ritracciamento finito su M15 nel verso del trend giornaliero (target vicino, lotti piu' alti)
input bool   InpON_H1             = true;    // ONDA-H1: ritracciamento finito su H1 nel verso del trend giornaliero (target lontano, lotti piu' bassi)
input bool   InpON_H4             = true;    // ONDA-H4: ritracciamento finito su H4 nel verso del trend giornaliero (target molto lontano)
input double InpOndaM5K           = 0.30;    // ON: M5, ampiezza dell'onda che conferma il punto di svolta (x escursione media di 20 giorni)
input double InpOndaM15K          = 0.40;    // ON: M15, ampiezza dell'onda
input double InpOndaH1K           = 0.80;    // ON: H1, ampiezza dell'onda
input double InpOndaH4K           = 1.50;    // ON: H4, ampiezza dell'onda
input bool   InpOndaM5NeedAll     = true;    // ON: M5 entra solo se anche H4 e H1 vanno nel verso del trend giornaliero (senza, sui dati rende poco)
input double InpOndaBufAtr        = 0.10;    // ON: margine dello stop oltre il punto di svolta (x escursione media)
input double InpOndaM5StopMax     = 0.30;    // ON: M5, stop massimo (x escursione media; 0 = nessun tetto)
input double InpOndaM15StopMax    = 0.40;    // ON: M15, stop massimo (x escursione media; 0 = nessun tetto)
input double InpOndaM5StopMin     = 0.20;    // ON: M5, stop piu' stretto accettato se il conto non regge quello pieno
input double InpOndaM15StopMin    = 0.30;    // ON: M15, stop piu' stretto accettato se il conto non regge quello pieno
input double InpOndaH1StopMin     = 0.50;    // ON: H1, stop piu' stretto accettato se il conto non regge quello pieno
input double InpOndaH4StopMin     = 1.00;    // ON: H4, stop piu' stretto accettato se il conto non regge quello pieno
input double InpOndaTargetR       = 2.0;     // ON: M5 e M15, target in R (mai sotto l'R:R minimo)
input double InpOndaTargetRLong   = 2.0;     // ON: H1 e H4, target in R (mai sotto l'R:R minimo)
input double InpOndaHoldMult      = 3.0;     // ON: tempo massimo = durata dell'onda x questo + 5 barre
input int    InpOndaMaxDelayMin   = 15;      // ON: se alla conferma non puo' entrare (news, spread), riprova per questi minuti
input double InpOndaRiskMult      = 1.0;     // ON: M15, H1 e H4: rischio = rischio base x questo; mai oltre il rischio massimo per trade
input double InpOndaM5RiskMult    = 0.75;    // ON: M5: rischio = rischio base x questo (come lo scalping)
input double InpOndaClearMult     = 1.0;     // ON: H1 con direzione chiara (anche H4 e H1 nel verso): rischio x questo (1 = uguale; sui dati rende quasi il doppio)
input double InpOndaMinLotRiskPct = 2.0;     // ON: con il lotto minimo, rischio massimo accettato (%), mai oltre il rischio massimo per trade
input int    InpOndaWeekend       = 1;       // ON: venerdi' sera per H1 e H4: 0 = tiene, 1 = dimezza, 2 = chiude (M5 e M15 chiudono sempre)
input bool   InpOndaFriCloseMinLot = false;  // ON: se non si puo' dimezzare (un solo lotto minimo): false = tiene, true = chiude
input bool   InpOndaNoDayLimit    = true;    // ON: nessun tetto al numero di ingressi al giorno (restano i limiti di rischio, le 4 posizioni e gli stop giornalieri)
input bool   InpOndaProven        = true;    // ON: regola propria misurata sui dati: la fermano solo i limiti di rischio, le news forti, i costi e la liquidita'
input bool   InpIN_TREND2         = true;    // IN-TREND2: secondo ingresso della giornata di tendenza, quando il movimento arriva piu' lontano
input double InpTD2ThreshAtr      = 1.20;    // IN-TREND2: distanza dal prezzo delle 8:00 di New York (x escursione media)
input double InpTD2RiskMult       = 1.0;     // IN-TREND2: rischio = rischio base x questo
input bool   InpOndaOwnSlots      = true;    // ON: i ritracciamenti aperti non occupano gli slot dei motori (restano nel tetto delle 4 posizioni e nel rischio aperto)
input bool   InpTDNoStreak        = true;    // MF: le perdite di fila di oggi non fermano i movimenti forti (li fermano gli stop giornalieri e il rischio aperto)
input bool   InpTDNoSlot          = true;    // MF: i movimenti forti non si fermano per gli slot del motore (restano le 4 posizioni e il rischio aperto)
input bool   InpTDFlipOnda        = false;   // MF: un movimento forte contro ritracciamenti ancora a rischio li chiude ed entra (sui dati peggiora: spento)

input group "=== Lettura del mercato (1.27) ==="
input bool   InpReadOn            = true;    // LM: legge trend, macro, liquidita', zone, sbilanciamenti: pannello, diario e ogni idea
input bool   InpReadLearn         = true;    // LM: misura per ogni lettura se le idee vanno meglio con la lettura a favore o contro
input int    InpReadMinN          = 30;      // LM: casi minimi a favore e contro prima di giudicare una lettura
input int    InpReadCutN          = 2;       // LM: letture provate contrarie (tolte quelle a favore) che fanno ridurre il rischio
input double InpReadCutMult       = 0.5;     // LM: rischio x questo quando le letture provate sono contrarie
input double InpReadBoostMult     = 1.0;     // LM: rischio x questo quando le letture provate sono a favore (1 = spento; mai oltre il rischio massimo per trade)
input bool   InpReadTrendGate     = true;    // LM: una strategia in osservazione puo' aprire solo le idee nel verso del trend giornaliero, se quelle guadagnano lontano dal caso

input group "=== Strategie in osservazione (1.26) ==="
input bool   InpObserveOn         = true;    // OS: le strategie non provate lavorano sulla carta (idee seguite e misurate, nessun ordine)
input string InpObserveList       = "SC-VWAP,SC-SWEEP,SC-ORB,IN-PULLBACK,IN-SWEEP,IN-BREAKOUT,IN-VALUE80,IN-NEWS,IN-RANGE,IN-NOTTE"; // OS: strategie che partono in osservazione
input bool   InpObserveAuto       = true;    // OS: promuove da solo una strategia che sulla carta guadagna, e mette in osservazione una attiva che perde
input int    InpObserveMinN       = 60;      // OS: idee chiuse minime prima di giudicare una strategia
input double InpObservePromoteR   = 0.10;    // OS: R medio dopo i costi per promuoverla (e lontano dal caso: 2,5 errori standard, 3 periodi su 4)
input double InpObserveDemoteR    = -0.05;   // OS: R medio dopo i costi sotto cui una strategia attiva torna in osservazione

input group "=== Coda, pareggio e rientro ==="
input bool   InpQueueOn          = true;     // Coda: con altre posizioni aperte, una nuova idea deve essere piu' sicura
input double InpQueueExtraScore  = 0.04;     // Coda: punti in piu' sul punteggio minimo (e quorum +1)
input double InpBeLockR          = 0.10;     // Pareggio: stop all'entrata + costi + questa quota di R (cuscinetto)
input bool   InpReentryOn        = true;     // Rientro: se un trade torna a pareggio, nuovo ingresso nella stessa direzione se le conferme restano
input double InpReentryMult      = 1.25;     // Rientro: moltiplicatore del rischio (una volta sola per idea)
input group "=== Idee A+ (tutte le conferme) ==="
input bool   InpAplusOn          = true;     // A+: con tutte le conferme rischio piu' alto e gestione attiva a terzi
input double InpAplusRiskPct     = 3.0;      // A+: rischio per trade (% del conto, mai oltre il rischio massimo per trade)
input double InpAplusMaxLots     = 0.03;     // A+: lotti massimi per idea (0 = solo il limite di rischio)
input double InpAplusMinScore    = 0.70;     // A+: punteggio minimo (e almeno il minimo del motore + 0.05)
input double InpAplusPartialR    = 1.0;      // A+: a questo +R chiude un terzo, il secondo al pareggio, il resto segue il trailing

input group "=== Dati esterni (solo conto live/demo) ==="
input bool   InpUseWebData       = true;     // Legge macro, comitato AI e livelli GC da GitHub
input string InpMacroUrl         = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/macro_bias.json"; // URL macro_bias.json
input string InpCommitteeUrl     = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/ai_committee.json"; // URL ai_committee.json
input string InpVolumeUrl        = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/volume_levels.json"; // URL volume_levels.json
input string InpNewsUrl          = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/news_calendar.json"; // URL news_calendar.json (riserva)
input string InpMacroHistUrl     = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/macro_history.csv"; // URL storico macro (salvato anche per il tester)
input double InpMacroVetoLevel   = 0.45;     // Macro contraria oltre questo livello: veto per intraday e swing
input double InpContextVetoLevel = 0.60;     // Contesto HTF contrario oltre questo livello: veto per intraday e swing
input int    InpWebRefreshMin    = 15;       // Ogni quanti minuti rilegge i dati esterni
input bool   InpUseDOM           = true;     // Usa il book (DOM) se il broker lo fornisce

//+------------------------------------------------------------------+
//| Costanti                                                         |
//+------------------------------------------------------------------+
#define EA_VERSION     "1.27"
#define ENG_SCALP      0
#define ENG_INTRA      1
#define ENG_SWING      2

#define NSTRAT         20
#define ST_SC_VWAP     1
#define ST_SC_SWEEP    2
#define ST_SC_ORB      3
#define ST_IN_PULLBACK 4
#define ST_IN_SWEEP    5
#define ST_IN_BREAKOUT 6
#define ST_IN_VALUE    7
#define ST_IN_NEWS     8
#define ST_IN_RANGE    9
#define ST_SW_TREND    10
#define ST_SW_WYCKOFF  11
#define ST_IN_TREND    12
#define ST_IN_DATA     13
#define ST_IN_NIGHT    14
#define ST_IN_TREND2   15
#define ST_ON_M15      16
#define ST_ON_H1       17
#define ST_ON_H4       18
#define ST_ON_M5       19

#define STYPE_TREND    0
#define STYPE_REVERSAL 1
#define STYPE_BREAKOUT 2
#define STYPE_MEANREV  3
#define STYPE_NEWS     4

#define REG_UP         0
#define REG_DOWN       1
#define REG_RANGE      2
#define REG_VOLATILE   3
#define REG_QUIET      4

#define NDESK          10
#define D_STRAT        0
#define D_TREND        1
#define D_VOLUME       2
#define D_LIQ          3
#define D_MACRO        4
#define D_NEWS         5
#define D_SESSION      6
#define D_COST         7
#define D_STATS        8
#define D_CONTEXT      9

#define MAX_META       64
#define MAX_NEWS       64
#define MAX_LEVELS     64
#define MICRO_N        1440

string g_stratName[NSTRAT]  = {"-", "SC-VWAP", "SC-SWEEP", "SC-ORB", "IN-PULLBACK", "IN-SWEEP", "IN-BREAKOUT", "IN-VALUE80", "IN-NEWS", "IN-RANGE", "SW-TREND", "SW-WYCKOFF", "IN-TREND", "IN-DATO", "IN-NOTTE", "IN-TREND2", "ONDA-M15", "ONDA-H1", "ONDA-H4", "ONDA-M5"};
int    g_stratEngine[NSTRAT] = {-1, ENG_SCALP, ENG_SCALP, ENG_SCALP, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_SWING, ENG_SWING, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_SWING, ENG_SWING, ENG_SCALP};
int    g_stratType[NSTRAT]   = {STYPE_TREND, STYPE_TREND, STYPE_REVERSAL, STYPE_BREAKOUT, STYPE_TREND, STYPE_REVERSAL, STYPE_BREAKOUT, STYPE_MEANREV, STYPE_NEWS, STYPE_MEANREV, STYPE_TREND, STYPE_REVERSAL, STYPE_TREND, STYPE_TREND, STYPE_TREND, STYPE_TREND, STYPE_TREND, STYPE_TREND, STYPE_TREND, STYPE_TREND};
string g_engName[3]          = {"Scalping", "Intraday", "Swing"};
//--- 1.26: famiglia "movimenti forti" (stesse regole di stop, tenuta e rischio)
bool IsTrendMove(int st) { return (st == ST_IN_TREND || st == ST_IN_DATA || st == ST_IN_NIGHT || st == ST_IN_TREND2); }
//--- 1.27: famiglia "ritracciamenti nel verso del trend" (ONDA): scala 0 = M5, 1 = M15, 2 = H1, 3 = H4
bool IsOnda(int st) { return (st == ST_ON_M5 || st == ST_ON_M15 || st == ST_ON_H1 || st == ST_ON_H4); }
int  OndaScale(int st) { return (st == ST_ON_M5) ? 0 : ((st == ST_ON_M15) ? 1 : ((st == ST_ON_H1) ? 2 : 3)); }
//--- regole proprie misurate sui dati (passano dal comitato con le sole obiezioni obbligatorie)
bool IsProvenFam(int st) { return (IsTrendMove(st) || IsOnda(st)); }
//--- rischio dei movimenti forti rispetto al rischio base: pieno moltiplicatore solo per la regola provata
double TmRiskMult(int st)
  {
   if(st == ST_IN_TREND)
      return MathMax(0.1, MathMin(InpTDRiskMult, 3.0));
   if(st == ST_IN_DATA)
      return MathMax(0.1, MathMin(InpDataRiskMult, 3.0));
   if(st == ST_IN_TREND2)
      return MathMax(0.1, MathMin(InpTD2RiskMult, 3.0));
   if(st == ST_ON_M5)
      return MathMax(0.1, MathMin(InpOndaM5RiskMult, 3.0));
   if(IsOnda(st))
      return MathMax(0.1, MathMin(InpOndaRiskMult, 3.0));
   return 1.0;
  }

string g_deskName[NDESK]     = {"Strategia", "Trend", "Volumi", "Liquidita", "Macro", "News", "Sessione", "Costi", "Statistica", "Contesto HTF"};
string g_deskShort[NDESK]    = {"Str", "Trd", "Vol", "Liq", "Mac", "New", "Ses", "Cst", "Sta", "Ctx"};
string g_regName[5]          = {"trend rialzista", "trend ribassista", "laterale", "volatile", "calmo"};

//+------------------------------------------------------------------+
//| Globali di base                                                  |
//+------------------------------------------------------------------+
CTrade   g_trade;
string   g_sym = "";
string   g_version = EA_VERSION;
double   g_point = 0.0;
double   g_tick = 0.0;
double   g_minLot = 0.0;
double   g_maxLot = 0.0;
double   g_lotStep = 0.0;
double   g_contract = 0.0;
int      g_digits = 2;
int      g_lotDigits = 2;
bool     g_isTester = false;
bool     g_isOptim = false;
bool     g_isVisual = false;
bool     g_netting = false;
bool     g_ready = false;
long     g_login = 0;
int      g_gmtOffset = 2;
datetime g_gmtCheckedAt = 0;
string   g_currency = "";
string   g_lastDecision[6];
int      g_lastDecisionHead = 0;

//+------------------------------------------------------------------+
//| Utilita'                                                         |
//+------------------------------------------------------------------+
double Clamp(double v, double lo, double hi)
  {
   if(v < lo)
      return lo;
   if(v > hi)
      return hi;
   return v;
  }

int IMax(int a, int b) { return (a > b) ? a : b; }
int IMin(int a, int b) { return (a < b) ? a : b; }

double PxBid() { return SymbolInfoDouble(g_sym, SYMBOL_BID); }
double PxAsk() { return SymbolInfoDouble(g_sym, SYMBOL_ASK); }

double NormPrice(double p)
  {
   if(g_tick <= 0.0)
      return NormalizeDouble(p, g_digits);
   return NormalizeDouble(MathRound(p / g_tick) * g_tick, g_digits);
  }

double FloorLot(double lots)
  {
   if(g_lotStep <= 0.0)
      return 0.0;
   double steps = MathFloor(lots / g_lotStep + 0.0000001);
   return NormalizeDouble(steps * g_lotStep, g_lotDigits);
  }

string DirName(int dir) { return (dir > 0) ? "BUY" : "SELL"; }

string Pct(double v) { return DoubleToString(v, 1) + "%"; }

string Money(double v) { return DoubleToString(v, 2) + " " + g_currency; }

//--- valore di 1.0 di prezzo per 1 lotto, in valuta del conto
double ValuePerPriceUnit()
  {
   double tv = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_VALUE);
   double ts = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_SIZE);
   if(tv <= 0.0 || ts <= 0.0)
      return g_contract;
   return tv / ts;
  }

//--- K (1.25): costi veri misurati sui trade (medie mobili, salvate nelle variabili globali)
double g_costSlipPx = 0.0;    // slittamento medio all'ingresso, in prezzo (positivo = eseguito peggio del prezzo chiesto)
int    g_costSlipN = 0;
double g_costSpreadPx = 0.0;  // spread medio pagato all'ingresso
int    g_costSpreadN = 0;
double g_costCommLot = 0.0;   // commissioni + fee vere per 1 lotto (andata e ritorno)
int    g_costCommN = 0;
double g_costR[3];            // costo medio di un trade in R, per motore
int    g_costRN[3];

double CostAvg(double avg, int n, double x) { int k = (n < 30) ? n + 1 : 30; return avg + (x - avg) / (double)k; }

//--- commissione per lotto da usare: quella misurata se ci sono almeno 3 trade, altrimenti il parametro
double CommPerLotEff()
  {
   if(InpCostTrack && g_costCommN >= 3)
      return MathMax(g_costCommLot, 0.0);
   return MathMax(InpCommissionPerLot, 0.0);
  }

//--- commissione andata+ritorno espressa in prezzo
double CommissionPx()
  {
   double c = CommPerLotEff();
   if(c <= 0.0)
      return 0.0;
   double v = ValuePerPriceUnit();
   if(v <= 0.0)
      return 0.0;
   return c / v;
  }

//--- slittamento atteso all'ingresso: misurato (almeno 5 trade) o stima 10% dello spread
double SlipEstPx(double spread)
  {
   if(InpCostTrack && g_costSlipN >= 5)
      return MathMax(g_costSlipPx, 0.0);
   return 0.1 * spread;
  }

void Logf(string msg)
  {
   if(g_isOptim)
      return;
   Print(msg);
  }

void Notify(string msg)
  {
   Logf(msg);
   if(InpPushNotify && !g_isTester)
     {
      string m = msg;
      if(StringLen(m) > 250)
         m = StringSubstr(m, 0, 250);
      SendNotification(m);
     }
  }

void RememberDecision(string line)
  {
   g_lastDecision[g_lastDecisionHead] = line;
   g_lastDecisionHead = (g_lastDecisionHead + 1) % 6;
  }

//+------------------------------------------------------------------+
//| Tempo: fusi orari, ora legale, sessioni                          |
//+------------------------------------------------------------------+
int YearOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.year;
  }

//--- data (00:00 UTC) della n-esima domenica del mese (n=-1 ultima)
datetime NthSunday(int year, int mon, int n)
  {
   MqlDateTime d;
   d.year = year;
   d.mon = mon;
   d.day = 1;
   d.hour = 0;
   d.min = 0;
   d.sec = 0;
   d.day_of_week = 0;
   d.day_of_year = 0;
   datetime first = StructToTime(d);
   MqlDateTime f;
   TimeToStruct(first, f);
   int toSun = (7 - f.day_of_week) % 7;
   datetime firstSun = first + toSun * 86400;
   if(n > 0)
      return firstSun + (n - 1) * 7 * 86400;
   //--- ultima domenica
   datetime s = firstSun;
   while(true)
     {
      datetime nx = s + 7 * 86400;
      MqlDateTime x;
      TimeToStruct(nx, x);
      if(x.mon != mon)
         break;
      s = nx;
     }
   return s;
  }

//--- ora legale USA: seconda domenica di marzo -> prima domenica di novembre (circa 07:00/06:00 UTC)
bool IsUSDST(datetime utc)
  {
   int y = YearOf(utc);
   datetime a = NthSunday(y, 3, 2) + 7 * 3600;
   datetime b = NthSunday(y, 11, 1) + 6 * 3600;
   return (utc >= a && utc < b);
  }

//--- ora legale UK: ultima domenica di marzo -> ultima domenica di ottobre (01:00 UTC)
bool IsUKDST(datetime utc)
  {
   int y = YearOf(utc);
   datetime a = NthSunday(y, 3, -1) + 3600;
   datetime b = NthSunday(y, 10, -1) + 3600;
   return (utc >= a && utc < b);
  }

void UpdateGmtOffset()
  {
   if(g_isTester)
     {
      if(InpGmtOffsetTester != -99)
         g_gmtOffset = InpGmtOffsetTester;
      else
         g_gmtOffset = IsUSDST(TimeCurrent() - 2 * 3600) ? 3 : 2;
     }
   else
     {
      if(InpGmtOffsetLive != -99)
         g_gmtOffset = InpGmtOffsetLive;
      else
        {
         long diff = (long)(TimeTradeServer() - TimeGMT());
         g_gmtOffset = (int)MathRound((double)diff / 3600.0);
        }
     }
   g_gmtCheckedAt = TimeCurrent();
  }

datetime ToUTC(datetime server) { return server - g_gmtOffset * 3600; }
datetime ToServer(datetime utc) { return utc + g_gmtOffset * 3600; }

double HourOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.hour + d.min / 60.0 + d.sec / 3600.0;
  }

int DowOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.day_of_week;
  }

int DayKey(datetime t) { return (int)(t / 86400); }

double LondonOpenUTC(datetime utc) { return IsUKDST(utc) ? 7.0 : 8.0; }
double NYDataUTC(datetime utc)     { return IsUSDST(utc) ? 12.5 : 13.5; }
double NYOpenUTC(datetime utc)     { return IsUSDST(utc) ? 13.5 : 14.5; }
double NYCloseUTC(datetime utc)    { return IsUSDST(utc) ? 21.0 : 22.0; }
//--- 1.26: il venerdi' sera e' due ore prima della chiusura di New York (20 UTC d'inverno, 19 UTC d'estate).
//    Con l'ora fissa delle 20 UTC, d'estate il mercato del broker chiudeva prima che la regola scattasse
//    e le posizioni restavano aperte nel weekend.
double FridayEveUTC(datetime utc)  { return NYCloseUTC(utc) - 2.0; }
bool   FridayEvening(datetime utc) { return DowOf(utc) == 5 && HourOf(utc) >= FridayEveUTC(utc); }
//--- 1.26: chiusura serale di scalping, intraday e movimenti forti: InpIntraCloseUTC, ma almeno 75 minuti prima della
//    chiusura di New York (d'estate 19:45 UTC), cosi' avviene sempre a mercato aperto: dal 2026 la pausa serale del
//    broker dura due ore e d'estate comincia alle 20 UTC, quindi la chiusura delle 20 scattava solo alla riapertura.
double EveCloseUTC(datetime utc)   { return MathMin((double)InpIntraCloseUTC, NYCloseUTC(utc) - 1.25); }

//--- yyyymmdd di una data UTC
int Ymd(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.year * 10000 + d.mon * 100 + d.day;
  }
//+------------------------------------------------------------------+
//| Dati di mercato e indicatori calcolati internamente              |
//| (stessi numeri nel tester e dal vivo, nessun handle esterno)     |
//+------------------------------------------------------------------+
struct TfData
  {
   ENUM_TIMEFRAMES   tf;
   int               want;
   int               n;
   datetime          lastOpen;
   MqlRates          r[];
   double            ema20[];
   double            ema50[];
   double            ema200[];
   double            atr[];
   double            rsi[];
   double            adx[];
   double            pdi[];
   double            mdi[];
  };

TfData g_m1;
TfData g_m5;
TfData g_m15;
TfData g_h1;
TfData g_h4;
TfData g_d1;

void CalcEMA(const MqlRates &r[], int n, int period, double &out[])
  {
   ArrayResize(out, n);
   if(n <= 0)
      return;
   double k = 2.0 / (period + 1.0);
   //--- seme: media semplice delle prime barre disponibili
   int seed = IMin(period, n);
   double s = 0.0;
   for(int i = 0; i < seed; i++)
      s += r[i].close;
   double v = s / seed;
   for(int i = 0; i < n; i++)
     {
      if(i < seed)
         out[i] = v;
      else
        {
         v = r[i].close * k + v * (1.0 - k);
         out[i] = v;
        }
     }
  }

void CalcATR(const MqlRates &r[], int n, int period, double &out[])
  {
   ArrayResize(out, n);
   if(n <= 0)
      return;
   out[0] = r[0].high - r[0].low;
   for(int i = 1; i < n; i++)
     {
      double tr = MathMax(r[i].high, r[i - 1].close) - MathMin(r[i].low, r[i - 1].close);
      if(i < period)
         out[i] = (out[i - 1] * i + tr) / (i + 1);
      else
         out[i] = (out[i - 1] * (period - 1) + tr) / period;
     }
  }

void CalcRSI(const MqlRates &r[], int n, int period, double &out[])
  {
   ArrayResize(out, n);
   if(n <= 0)
      return;
   double ag = 0.0, al = 0.0;
   out[0] = 50.0;
   for(int i = 1; i < n; i++)
     {
      double ch = r[i].close - r[i - 1].close;
      double g = (ch > 0.0) ? ch : 0.0;
      double l = (ch < 0.0) ? -ch : 0.0;
      if(i <= period)
        {
         ag = (ag * (i - 1) + g) / i;
         al = (al * (i - 1) + l) / i;
        }
      else
        {
         ag = (ag * (period - 1) + g) / period;
         al = (al * (period - 1) + l) / period;
        }
      if(al <= 0.0000000001)
         out[i] = (ag > 0.0) ? 100.0 : 50.0;
      else
         out[i] = 100.0 - 100.0 / (1.0 + ag / al);
     }
  }

void CalcADX(const MqlRates &r[], int n, int period, double &adx[], double &pdi[], double &mdi[])
  {
   ArrayResize(adx, n);
   ArrayResize(pdi, n);
   ArrayResize(mdi, n);
   if(n <= 0)
      return;
   adx[0] = 0.0;
   pdi[0] = 0.0;
   mdi[0] = 0.0;
   double trS = 0.0, pS = 0.0, mS = 0.0, av = 0.0;
   for(int i = 1; i < n; i++)
     {
      double up = r[i].high - r[i - 1].high;
      double dn = r[i - 1].low - r[i].low;
      double pdm = (up > dn && up > 0.0) ? up : 0.0;
      double mdm = (dn > up && dn > 0.0) ? dn : 0.0;
      double tr = MathMax(r[i].high, r[i - 1].close) - MathMin(r[i].low, r[i - 1].close);
      if(i <= period)
        {
         trS += tr;
         pS += pdm;
         mS += mdm;
        }
      else
        {
         trS = trS - trS / period + tr;
         pS = pS - pS / period + pdm;
         mS = mS - mS / period + mdm;
        }
      double p = (trS > 0.0) ? 100.0 * pS / trS : 0.0;
      double m = (trS > 0.0) ? 100.0 * mS / trS : 0.0;
      double dx = (p + m > 0.0) ? 100.0 * MathAbs(p - m) / (p + m) : 0.0;
      if(i <= period)
         av = (av * (i - 1) + dx) / i;
      else
         av = (av * (period - 1) + dx) / period;
      adx[i] = av;
      pdi[i] = p;
      mdi[i] = m;
     }
  }

void TfInit(TfData &d, ENUM_TIMEFRAMES tf, int want)
  {
   d.tf = tf;
   d.want = want;
   d.n = 0;
   d.lastOpen = 0;
  }

bool TfRefresh(TfData &d)
  {
   int got = CopyRates(g_sym, d.tf, 1, d.want, d.r);
   if(got <= 0)
     {
      d.n = 0;
      return false;
     }
   d.n = IMin(got, ArraySize(d.r));
   CalcEMA(d.r, d.n, 20, d.ema20);
   CalcEMA(d.r, d.n, 50, d.ema50);
   CalcEMA(d.r, d.n, 200, d.ema200);
   CalcATR(d.r, d.n, 14, d.atr);
   CalcRSI(d.r, d.n, 14, d.rsi);
   CalcADX(d.r, d.n, 14, d.adx, d.pdi, d.mdi);
   return true;
  }

bool TfNewBar(TfData &d)
  {
   datetime t = iTime(g_sym, d.tf, 0);
   if(t == 0)
      return false;
   if(t != d.lastOpen)
     {
      d.lastOpen = t;
      return true;
     }
   return false;
  }

//--- accesso alle barre chiuse: sh=0 ultima barra chiusa
int TfIdx(const TfData &d, int sh)
  {
   int i = d.n - 1 - sh;
   if(i < 0 || i >= d.n)
      return -1;
   return i;
  }

double BarO(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].open; }
double BarH(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].high; }
double BarL(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].low; }
double BarC(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].close; }
double BarV(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : (double)d.r[i].tick_volume; }
datetime BarT(const TfData &d, int sh) { int i = TfIdx(d, sh); if(i < 0) return 0; return d.r[i].time; }

double Ind(const double &a[], int sh)
  {
   int n = ArraySize(a);
   int i = n - 1 - sh;
   if(i < 0 || i >= n)
      return 0.0;
   return a[i];
  }

double MinInd(const double &a[], int fromSh, int count)
  {
   double m = 1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = ArraySize(a) - 1 - k;
      if(i < 0)
         break;
      if(a[i] < m)
         m = a[i];
     }
   return (m > 1.0e299) ? 0.0 : m;
  }

double MaxInd(const double &a[], int fromSh, int count)
  {
   double m = -1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = ArraySize(a) - 1 - k;
      if(i < 0)
         break;
      if(a[i] > m)
         m = a[i];
     }
   return (m < -1.0e299) ? 0.0 : m;
  }

double HighestH(const TfData &d, int fromSh, int count)
  {
   double m = -1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = TfIdx(d, k);
      if(i < 0)
         break;
      if(d.r[i].high > m)
         m = d.r[i].high;
     }
   return (m < -1.0e299) ? 0.0 : m;
  }

double LowestL(const TfData &d, int fromSh, int count)
  {
   double m = 1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = TfIdx(d, k);
      if(i < 0)
         break;
      if(d.r[i].low < m)
         m = d.r[i].low;
     }
   return (m > 1.0e299) ? 0.0 : m;
  }

double AtrOf(const TfData &d) { return Ind(d.atr, 0); }
double AdxOf(const TfData &d) { return Ind(d.adx, 0); }

//--- +1 rialzo, -1 ribasso, 0 misto (EMA20/EMA50 e chiusura rispetto a EMA50)
int TrendDir(const TfData &d)
  {
   if(d.n < 60)
      return 0;
   double e20 = Ind(d.ema20, 0), e50 = Ind(d.ema50, 0), c = BarC(d, 0);
   if(e20 > e50 && c > e50)
      return 1;
   if(e20 < e50 && c < e50)
      return -1;
   return 0;
  }

int EmaDir(const TfData &d)
  {
   if(d.n < 60)
      return 0;
   double e20 = Ind(d.ema20, 0), e50 = Ind(d.ema50, 0);
   if(e20 > e50)
      return 1;
   if(e20 < e50)
      return -1;
   return 0;
  }

//--- posizione della chiusura nella barra (0 = minimo, 1 = massimo)
double ClosePos(const TfData &d, int sh)
  {
   double h = BarH(d, sh), l = BarL(d, sh);
   if(h - l <= 0.0)
      return 0.5;
   return (BarC(d, sh) - l) / (h - l);
  }

//--- quota di spike nella direzione contraria (rifiuto): long = spike in basso
double WickRatio(const TfData &d, int sh, int dir)
  {
   double h = BarH(d, sh), l = BarL(d, sh), o = BarO(d, sh), c = BarC(d, sh);
   double rg = h - l;
   if(rg <= 0.0)
      return 0.0;
   if(dir > 0)
      return (MathMin(o, c) - l) / rg;
   return (h - MathMax(o, c)) / rg;
  }

//--- divergenza RSI: nuovo estremo di prezzo ma RSI piu' debole (contro la direzione dir)
bool RsiDivergenceAgainst(const TfData &d, int dir, int lookback)
  {
   if(d.n < lookback + 5)
      return false;
   if(dir > 0)
     {
      double hNow = HighestH(d, 0, 3), hPrev = HighestH(d, 3, lookback);
      double rNow = MaxInd(d.rsi, 0, 3), rPrev = MaxInd(d.rsi, 3, lookback);
      return (hNow > hPrev && rNow < rPrev - 3.0);
     }
   double lNow = LowestL(d, 0, 3), lPrev = LowestL(d, 3, lookback);
   double rNow2 = MinInd(d.rsi, 0, 3), rPrev2 = MinInd(d.rsi, 3, lookback);
   return (lNow < lPrev && rNow2 > rPrev2 + 3.0);
  }

bool DataReady()
  {
   return (g_m1.n >= 60 && g_m5.n >= 120 && g_m15.n >= 120 && g_h1.n >= 120 && g_h4.n >= 60 && g_d1.n >= 20);
  }

//+------------------------------------------------------------------+
//| Contesto del momento (calcolato una volta per barra M1)          |
//+------------------------------------------------------------------+
struct Ctx
  {
   double            bid;
   double            ask;
   double            spread;
   double            atrM1;
   double            atrM5;
   double            atrM15;
   double            atrH1;
   double            atrH4;
   double            atrD1;
   double            vwap;
   double            vwSig;
   double            wvwap;
   datetime          nowSrv;
   datetime          nowUtc;
   double            hUtc;
   double            lonOpen;
   double            nyData;
   double            nyOpen;
   double            nyClose;
   int               dow;
  };
Ctx g_ctx;
//+------------------------------------------------------------------+
//| Motore volumi: delta tick (tick rule), RVOL per orario, VWAP,    |
//| volume profile (POC/VAH/VAL), VSA, DOM                           |
//+------------------------------------------------------------------+
struct MicroBar
  {
   datetime          t;
   double            o;
   double            h;
   double            l;
   double            c;
   double            vol;
   double            delta;
  };

MicroBar g_micro[MICRO_N];
int      g_microHead = -1;
int      g_microCount = 0;

//--- accumulatori del delta tick della barra M1 in formazione
double   g_tkLastBid = 0.0;
int      g_tkLastDir = 0;
double   g_tkDelta = 0.0;
double   g_tkCount = 0.0;
datetime g_tkBarOpen = 0;

//--- spread medio (per riconoscere spread anomali)
double   g_spreadAvg = 0.0;

void MicroPush(datetime t, double o, double h, double l, double c, double vol, double delta)
  {
   g_microHead = (g_microHead + 1) % MICRO_N;
   g_micro[g_microHead].t = t;
   g_micro[g_microHead].o = o;
   g_micro[g_microHead].h = h;
   g_micro[g_microHead].l = l;
   g_micro[g_microHead].c = c;
   g_micro[g_microHead].vol = vol;
   g_micro[g_microHead].delta = delta;
   if(g_microCount < MICRO_N)
      g_microCount++;
  }

int MicroIdx(int sh)
  {
   if(sh < 0 || sh >= g_microCount || g_microHead < 0)
      return -1;
   return (g_microHead - sh + MICRO_N) % MICRO_N;
  }

double ClvDelta(double h, double l, double c, double vol)
  {
   double rg = h - l;
   if(rg <= 0.0)
      return 0.0;
   double clv = ((c - l) - (h - c)) / rg;
   return clv * vol;
  }

double MicroDelta(int sh)
  {
   int i = MicroIdx(sh);
   return (i < 0) ? 0.0 : g_micro[i].delta;
  }

double MicroCvd(int nBars)
  {
   double s = 0.0;
   for(int k = 0; k < nBars; k++)
     {
      int i = MicroIdx(k);
      if(i < 0)
         break;
      s += g_micro[i].delta;
     }
   return s;
  }

double MicroVolSum(int nBars)
  {
   double s = 0.0;
   for(int k = 0; k < nBars; k++)
     {
      int i = MicroIdx(k);
      if(i < 0)
         break;
      s += g_micro[i].vol;
     }
   return s;
  }

//--- CVD normalizzato (-1..+1) sulle ultime n barre M1
double MicroCvdRatio(int nBars)
  {
   double v = MicroVolSum(nBars);
   if(v <= 0.0)
      return 0.0;
   return MicroCvd(nBars) / v;
  }

void TickDelta(double bid)
  {
   if(g_tkLastBid > 0.0)
     {
      if(bid > g_tkLastBid)
         g_tkLastDir = 1;
      else
         if(bid < g_tkLastBid)
            g_tkLastDir = -1;
      g_tkDelta += g_tkLastDir;
      g_tkCount += 1.0;
     }
   g_tkLastBid = bid;
  }

void SpreadTrack(double sp)
  {
   if(sp <= 0.0)
      return;
   if(g_spreadAvg <= 0.0)
      g_spreadAvg = sp;
   else
      g_spreadAvg += (sp - g_spreadAvg) * 0.002;
  }

bool SpreadAbnormal()
  {
   double sp = PxAsk() - PxBid();
   return (g_spreadAvg > 0.0 && sp > 2.5 * g_spreadAvg && sp > 3.0 * g_tick);
  }

//--- chiude la barra M1 appena finita nel buffer micro
void MicroFinalize()
  {
   MqlRates b[];
   if(CopyRates(g_sym, PERIOD_M1, 1, 1, b) != 1)
      return;
   if(g_microHead >= 0 && g_micro[g_microHead].t >= b[0].time)
      return;
   double vol = (double)b[0].tick_volume;
   double delta;
   if(g_tkBarOpen == b[0].time && g_tkCount >= 3.0)
      delta = (g_tkDelta / g_tkCount) * vol;
   else
      delta = ClvDelta(b[0].high, b[0].low, b[0].close, vol);
   MicroPush(b[0].time, b[0].open, b[0].high, b[0].low, b[0].close, vol, delta);
  }

void MicroInit()
  {
   MqlRates b[];
   int got = CopyRates(g_sym, PERIOD_M1, 1, 600, b);
   g_microHead = -1;
   g_microCount = 0;
   for(int i = 0; i < got; i++)
      MicroPush(b[i].time, b[i].open, b[i].high, b[i].low, b[i].close, (double)b[i].tick_volume,
                ClvDelta(b[i].high, b[i].low, b[i].close, (double)b[i].tick_volume));
  }

//+------------------------------------------------------------------+
//| RVOL: volume rispetto alla media della stessa fascia oraria      |
//+------------------------------------------------------------------+
double g_rvolAvg[288];
int    g_rvolCnt[288];

int SlotOf(datetime serverTime)
  {
   datetime u = ToUTC(serverTime);
   int sec = (int)(u % 86400);
   if(sec < 0)
      sec += 86400;
   return (sec / 300) % 288;
  }

void RvolAdd(datetime barTime, double vol)
  {
   int s = SlotOf(barTime);
   if(g_rvolCnt[s] < 20)
     {
      g_rvolAvg[s] = (g_rvolAvg[s] * g_rvolCnt[s] + vol) / (g_rvolCnt[s] + 1);
      g_rvolCnt[s]++;
     }
   else
      g_rvolAvg[s] += (vol - g_rvolAvg[s]) / 20.0;
  }

void RvolInit()
  {
   ArrayInitialize(g_rvolAvg, 0.0);
   ArrayInitialize(g_rvolCnt, 0);
   MqlRates b[];
   int got = CopyRates(g_sym, PERIOD_M5, 1, 6000, b);
   for(int i = 0; i < got; i++)
      RvolAdd(b[i].time, (double)b[i].tick_volume);
  }

//--- volume atteso per una barra di timeframe tf che inizia a barTime
double RvolExpected(datetime barTime, ENUM_TIMEFRAMES tf)
  {
   int secs = PeriodSeconds(tf);
   int s0 = SlotOf(barTime);
   if(secs < 300)
      return g_rvolAvg[s0] * secs / 300.0;
   int m = secs / 300;
   if(m > 288)
      m = 288;
   double e = 0.0;
   for(int k = 0; k < m; k++)
      e += g_rvolAvg[(s0 + k) % 288];
   return e;
  }

double RvolBar(const TfData &d, int sh)
  {
   int i = TfIdx(d, sh);
   if(i < 0)
      return 1.0;
   double e = RvolExpected(d.r[i].time, d.tf);
   if(e <= 0.0)
      return 1.0;
   return (double)d.r[i].tick_volume / e;
  }

//+------------------------------------------------------------------+
//| VWAP giornaliera (barre M1) e settimanale (barre M5)             |
//+------------------------------------------------------------------+
struct VwapAcc
  {
   datetime          anchor;
   double            sv;
   double            spv;
   double            sp2v;
  };
VwapAcc g_vwD;
VwapAcc g_vwW;

void VwapReset(VwapAcc &a, datetime anchor)
  {
   a.anchor = anchor;
   a.sv = 0.0;
   a.spv = 0.0;
   a.sp2v = 0.0;
  }

void VwapAdd(VwapAcc &a, double tp, double v)
  {
   if(v <= 0.0)
      v = 1.0;
   a.sv += v;
   a.spv += tp * v;
   a.sp2v += tp * tp * v;
  }

double VwapVal(const VwapAcc &a)
  {
   if(a.sv <= 0.0)
      return 0.0;
   return a.spv / a.sv;
  }

double VwapSigma(const VwapAcc &a)
  {
   if(a.sv <= 0.0)
      return 0.0;
   double m = a.spv / a.sv;
   double var = a.sp2v / a.sv - m * m;
   return (var > 0.0) ? MathSqrt(var) : 0.0;
  }

//--- aggiunge una barra chiusa all'accumulatore ancorato a 'anchorNow'
void VwapFeed(VwapAcc &a, datetime anchorNow, datetime barTime, double h, double l, double c, double v)
  {
   if(barTime >= anchorNow && a.anchor != anchorNow)
      VwapReset(a, anchorNow);
   VwapAdd(a, (h + l + c) / 3.0, v);
  }

void VwapInit()
  {
   datetime dAnchor = iTime(g_sym, PERIOD_D1, 0);
   datetime wAnchor = iTime(g_sym, PERIOD_W1, 0);
   VwapReset(g_vwD, dAnchor);
   VwapReset(g_vwW, wAnchor);
   MqlRates b[];
   datetime curM1 = iTime(g_sym, PERIOD_M1, 0);
   int got = CopyRates(g_sym, PERIOD_M1, dAnchor, curM1, b);
   for(int i = 0; i < got; i++)
     {
      if(b[i].time >= curM1)
         continue;
      VwapAdd(g_vwD, (b[i].high + b[i].low + b[i].close) / 3.0, (double)b[i].tick_volume);
     }
   MqlRates w[];
   datetime curM5 = iTime(g_sym, PERIOD_M5, 0);
   int gw = CopyRates(g_sym, PERIOD_M5, wAnchor, curM5, w);
   for(int i = 0; i < gw; i++)
     {
      if(w[i].time >= curM5)
         continue;
      VwapAdd(g_vwW, (w[i].high + w[i].low + w[i].close) / 3.0, (double)w[i].tick_volume);
     }
  }

//+------------------------------------------------------------------+
//| Volume profile giornaliero (barre M5)                            |
//+------------------------------------------------------------------+
struct Profile
  {
   datetime          anchor;
   double            base;
   double            bin;
   double            vol[];
   double            total;
   double            poc;
   double            vah;
   double            val;
   bool              valid;
  };
Profile g_prof[2];
int     g_profCur = 0;

void ProfReset(Profile &p, datetime anchor, double refPrice, double bin)
  {
   p.anchor = anchor;
   p.bin = MathMax(bin, g_tick);
   p.base = refPrice - 100.0 * p.bin;
   ArrayResize(p.vol, 200);
   ArrayInitialize(p.vol, 0.0);
   p.total = 0.0;
   p.poc = 0.0;
   p.vah = 0.0;
   p.val = 0.0;
   p.valid = false;
  }

int ProfIndex(Profile &p, double price)
  {
   int n = ArraySize(p.vol);
   int idx = (int)MathFloor((price - p.base) / p.bin);
   if(idx < 0)
     {
      int k = -idx + 20;
      if(n + k > 3000)
         return 0;
      ArrayResize(p.vol, n + k);
      for(int i = n - 1; i >= 0; i--)
         p.vol[i + k] = p.vol[i];
      for(int i = 0; i < k; i++)
         p.vol[i] = 0.0;
      p.base -= k * p.bin;
      idx += k;
      n += k;
     }
   if(idx >= n)
     {
      int nn = idx + 20;
      if(nn > 3000)
         return n - 1;
      ArrayResize(p.vol, nn);
      for(int i = n; i < nn; i++)
         p.vol[i] = 0.0;
     }
   return idx;
  }

void ProfAddBar(Profile &p, double lo, double hi, double v)
  {
   if(p.bin <= 0.0 || v <= 0.0)
      return;
   int a = ProfIndex(p, lo);
   int b = ProfIndex(p, hi);
   a = ProfIndex(p, lo);   // l'indice basso puo' spostarsi dopo un'estensione
   if(b < a)
     {
      int t = a;
      a = b;
      b = t;
     }
   int cnt = b - a + 1;
   double each = v / cnt;
   for(int i = a; i <= b; i++)
      p.vol[i] += each;
   p.total += v;
  }

void ProfCompute(Profile &p)
  {
   int n = ArraySize(p.vol);
   p.valid = false;
   if(n <= 0 || p.total <= 0.0)
      return;
   int pi = 0;
   for(int i = 1; i < n; i++)
      if(p.vol[i] > p.vol[pi])
         pi = i;
   double target = p.total * 0.70;
   double acc = p.vol[pi];
   int lo = pi, hi = pi;
   while(acc < target && (lo > 0 || hi < n - 1))
     {
      double up = (hi < n - 1) ? p.vol[hi + 1] : -1.0;
      double dn = (lo > 0) ? p.vol[lo - 1] : -1.0;
      if(up >= dn)
        {
         hi++;
         acc += p.vol[hi];
        }
      else
        {
         lo--;
         acc += p.vol[lo];
        }
     }
   p.poc = p.base + (pi + 0.5) * p.bin;
   p.val = p.base + lo * p.bin;
   p.vah = p.base + (hi + 1) * p.bin;
   p.valid = true;
  }

double ProfileBin()
  {
   double a = AtrOf(g_d1);
   double b = (a > 0.0) ? a / 60.0 : 50.0 * g_tick;
   return MathMax(10.0 * g_tick, NormPrice(b));
  }

//--- barra M5 chiusa -> profilo del giorno del broker
void ProfileFeed(datetime dayAnchorNow, datetime barTime, double lo, double hi, double v)
  {
   if(barTime >= dayAnchorNow && g_prof[g_profCur].anchor != dayAnchorNow)
     {
      ProfCompute(g_prof[g_profCur]);
      g_profCur = 1 - g_profCur;
      ProfReset(g_prof[g_profCur], dayAnchorNow, (lo + hi) / 2.0, ProfileBin());
     }
   ProfAddBar(g_prof[g_profCur], lo, hi, v);
  }

void ProfileInit()
  {
   datetime today = iTime(g_sym, PERIOD_D1, 0);
   datetime yday = iTime(g_sym, PERIOD_D1, 1);
   double bin = ProfileBin();
   double ref = PxBid();
   g_profCur = 0;
   ProfReset(g_prof[1], yday, ref, bin);
   ProfReset(g_prof[0], today, ref, bin);
   MqlRates b[];
   datetime curM5 = iTime(g_sym, PERIOD_M5, 0);
   int got = CopyRates(g_sym, PERIOD_M5, yday, curM5, b);
   for(int i = 0; i < got; i++)
     {
      if(b[i].time >= curM5)
         continue;
      if(b[i].time < today)
         ProfAddBar(g_prof[1], b[i].low, b[i].high, (double)b[i].tick_volume);
      else
         ProfAddBar(g_prof[0], b[i].low, b[i].high, (double)b[i].tick_volume);
     }
   ProfCompute(g_prof[1]);
   ProfCompute(g_prof[0]);
  }

bool PrevProfileOk() { return g_prof[1 - g_profCur].valid; }
double PrevVAH() { return g_prof[1 - g_profCur].vah; }
double PrevVAL() { return g_prof[1 - g_profCur].val; }
double PrevPOC() { return g_prof[1 - g_profCur].poc; }

//+------------------------------------------------------------------+
//| VSA: climax e assorbimento                                       |
//+------------------------------------------------------------------+
//--- barra di climax nella direzione 'dir' (volume molto alto, barra ampia, chiusura all'estremo)
bool IsClimax(const TfData &d, int sh, int dir)
  {
   double a = Ind(d.atr, sh + 1);
   if(a <= 0.0)
      return false;
   double rg = BarH(d, sh) - BarL(d, sh);
   if(RvolBar(d, sh) < 2.2 || rg < 1.5 * a)
      return false;
   double cp = ClosePos(d, sh);
   if(dir > 0)
      return (BarC(d, sh) > BarO(d, sh) && cp > 0.7);
   return (BarC(d, sh) < BarO(d, sh) && cp < 0.3);
  }

//--- assorbimento: molto volume ma poco movimento
bool IsAbsorption(const TfData &d, int sh)
  {
   double a = Ind(d.atr, sh + 1);
   if(a <= 0.0)
      return false;
   double rg = BarH(d, sh) - BarL(d, sh);
   return (RvolBar(d, sh) >= 1.8 && rg <= 0.6 * a);
  }

//+------------------------------------------------------------------+
//| DOM (book) - solo se il broker lo fornisce                       |
//+------------------------------------------------------------------+
bool     g_domOn = false;
double   g_domImb = 0.0;
datetime g_domTime = 0;

bool DomFresh() { return (g_domOn && TimeCurrent() - g_domTime <= 10); }

void DomUpdate()
  {
   MqlBookInfo book[];
   if(!MarketBookGet(g_sym, book))
      return;
   int n = ArraySize(book);
   double bv = 0.0, av = 0.0;
   for(int i = 0; i < n; i++)
     {
      double v = (book[i].volume_real > 0.0) ? book[i].volume_real : (double)book[i].volume;
      if(book[i].type == BOOK_TYPE_BUY || book[i].type == BOOK_TYPE_BUY_MARKET)
         bv += v;
      else
         if(book[i].type == BOOK_TYPE_SELL || book[i].type == BOOK_TYPE_SELL_MARKET)
            av += v;
     }
   if(bv + av <= 0.0)
      return;
   g_domImb = (bv - av) / (bv + av);
   g_domTime = TimeCurrent();
  }
//+------------------------------------------------------------------+
//| Sessioni (UTC con ora legale), mappa della liquidita', regime    |
//+------------------------------------------------------------------+
struct OrState
  {
   double            h;
   double            l;
   bool              started;
   bool              done;
   int               brk;
   datetime          brkT;
   bool              used;
  };

struct SessionState
  {
   int               dayKey;
   double            asiaH;
   double            asiaL;
   bool              asiaOn;
   bool              asiaDone;
   double            lonH;
   double            lonL;
   bool              lonOn;
   bool              lonDone;
   double            dayH;
   double            dayL;
   OrState           orLon;
   OrState           orNy;
  };
SessionState g_sess;
//--- C3 (1.20): Asia della seduta, dalla riapertura delle 18 di New York all'apertura di Londra
int    g_c3Key = -1;
double g_c3H = 0.0;
double g_c3L = 0.0;
bool   g_c3On = false;
bool   g_c3Done = false;

void C3AsiaFeed(datetime u, double hu, double lon, double hi, double lo)
  {
   int ck = Ymd(u + 6 * 3600 - (IsUSDST(u) ? 4 : 5) * 3600);   // giorno di borsa: inizia alle 18 di New York
   if(ck != g_c3Key)
     {
      g_c3Key = ck;
      g_c3H = 0.0;
      g_c3L = 0.0;
      g_c3On = false;
      g_c3Done = false;
     }
   if(g_c3Done)
      return;
   if(hu < lon || hu >= 20.0)
     {
      if(!g_c3On)
        {
         g_c3H = hi;
         g_c3L = lo;
         g_c3On = true;
        }
      else
        {
         g_c3H = MathMax(g_c3H, hi);
         g_c3L = MathMin(g_c3L, lo);
        }
     }
   else
      if(g_c3On)
         g_c3Done = true;
  }

void OrReset(OrState &o)
  {
   o.h = 0.0;
   o.l = 0.0;
   o.started = false;
   o.done = false;
   o.brk = 0;
   o.brkT = 0;
   o.used = false;
  }

void SessReset(int dayKey)
  {
   g_sess.dayKey = dayKey;
   g_sess.asiaH = 0.0;
   g_sess.asiaL = 0.0;
   g_sess.asiaOn = false;
   g_sess.asiaDone = false;
   g_sess.lonH = 0.0;
   g_sess.lonL = 0.0;
   g_sess.lonOn = false;
   g_sess.lonDone = false;
   g_sess.dayH = 0.0;
   g_sess.dayL = 0.0;
   OrReset(g_sess.orLon);
   OrReset(g_sess.orNy);
  }

void OrFeed(OrState &o, double hu, double openH, double hi, double lo)
  {
   if(hu >= openH && hu < openH + 0.25)
     {
      if(!o.started)
        {
         o.h = hi;
         o.l = lo;
         o.started = true;
        }
      else
        {
         o.h = MathMax(o.h, hi);
         o.l = MathMin(o.l, lo);
        }
     }
   if(hu >= openH + 0.25 && o.started)
      o.done = true;
  }

//--- barra M1 chiusa (tempo server) -> stato delle sessioni del giorno UTC
void SessFeed(datetime barSrv, double hi, double lo)
  {
   datetime u = ToUTC(barSrv);
   int dk = DayKey(u);
   if(dk != g_sess.dayKey)
      SessReset(dk);
   double hu = HourOf(u);
   double lon = LondonOpenUTC(u);
   double nyd = NYDataUTC(u);
   double nyo = NYOpenUTC(u);
   C3AsiaFeed(u, hu, lon, hi, lo);
   if(g_sess.dayH == 0.0 || hi > g_sess.dayH)
      g_sess.dayH = hi;
   if(g_sess.dayL == 0.0 || lo < g_sess.dayL)
      g_sess.dayL = lo;
   if(hu < lon)
     {
      if(!g_sess.asiaOn)
        {
         g_sess.asiaH = hi;
         g_sess.asiaL = lo;
         g_sess.asiaOn = true;
        }
      else
        {
         g_sess.asiaH = MathMax(g_sess.asiaH, hi);
         g_sess.asiaL = MathMin(g_sess.asiaL, lo);
        }
     }
   else
      if(g_sess.asiaOn)
         g_sess.asiaDone = true;
   if(hu >= lon && hu < nyd)
     {
      if(!g_sess.lonOn)
        {
         g_sess.lonH = hi;
         g_sess.lonL = lo;
         g_sess.lonOn = true;
        }
      else
        {
         g_sess.lonH = MathMax(g_sess.lonH, hi);
         g_sess.lonL = MathMin(g_sess.lonL, lo);
        }
     }
   if(hu >= nyd && g_sess.lonOn)
      g_sess.lonDone = true;
   OrFeed(g_sess.orLon, hu, lon, hi, lo);
   OrFeed(g_sess.orNy, hu, nyo, hi, lo);
  }

void SessInit()
  {
   datetime nowU = ToUTC(TimeCurrent());
   SessReset(DayKey(nowU));
   datetime startSrv = ToServer((datetime)(DayKey(nowU)) * 86400);
   MqlRates b[];
   datetime curM1 = iTime(g_sym, PERIOD_M1, 0);
   int got = CopyRates(g_sym, PERIOD_M1, startSrv, curM1, b);
   for(int i = 0; i < got; i++)
     {
      if(b[i].time >= curM1)
         continue;
      SessFeed(b[i].time, b[i].high, b[i].low);
     }
   //--- gli OR gia' passati non vanno piu' tradati dopo un riavvio
   if(g_sess.orLon.done)
      g_sess.orLon.used = true;
   if(g_sess.orNy.done)
      g_sess.orNy.used = true;
  }

//+------------------------------------------------------------------+
//| Mappa dei livelli di liquidita'                                  |
//+------------------------------------------------------------------+
#define LV_PDH     0
#define LV_PDL     1
#define LV_PDC     2
#define LV_PWH     3
#define LV_PWL     4
#define LV_ASIAH   5
#define LV_ASIAL   6
#define LV_LONH    7
#define LV_LONL    8
#define LV_VAH     9
#define LV_VAL     10
#define LV_POC     11
#define LV_VWAP    12
#define LV_VWAPB1  13
#define LV_VWAPB2  14
#define LV_WVWAP   15
#define LV_SWING   16
#define LV_ROUND   17
#define LV_ROUNDM  18
#define LV_GC      19
#define LV_DAYHL   20

string g_lvName[21] = {"PDH", "PDL", "PDC", "PWH", "PWL", "Asia H", "Asia L", "Londra H", "Londra L", "VAH ieri", "VAL ieri", "POC ieri", "VWAP", "VWAP 1s", "VWAP 2s", "VWAP sett", "swing H1", "tondo", "tondo forte", "livello GC", "max/min oggi"};

struct TLevel
  {
   double            price;
   int               type;
   double            weight;
  };
TLevel g_lv[MAX_LEVELS];
int    g_lvN = 0;
double g_pwH = 0.0;
double g_pwL = 0.0;

void LvAdd(double price, int type, double weight)
  {
   if(price <= 0.0 || g_lvN >= MAX_LEVELS)
      return;
   g_lv[g_lvN].price = price;
   g_lv[g_lvN].type = type;
   g_lv[g_lvN].weight = weight;
   g_lvN++;
  }

bool IsMajorLevel(int type)
  {
   if(type == LV_ROUNDM)
      return !InpT4RoundNotMajor;            // T4: i tondi reagiscono come livelli a caso (studio tecnico)
   return (type == LV_PDH || type == LV_PDL || type == LV_PWH || type == LV_PWL ||
           type == LV_VAH || type == LV_VAL || type == LV_POC || type == LV_GC);
  }

void UpdateWeekly()
  {
   MqlRates w[];
   if(CopyRates(g_sym, PERIOD_W1, 1, 1, w) == 1)
     {
      g_pwH = w[0].high;
      g_pwL = w[0].low;
     }
  }

//--- livelli GC (futures CME) mappati sul prezzo spot: riempiti dal modulo web
double   g_gcPoc = 0.0, g_gcVah = 0.0, g_gcVal = 0.0, g_gcLast = 0.0, g_gcDeltaTrend = 0.0;
datetime g_gcTime = 0;
bool GcFresh() { return (g_gcLast > 0.0 && ToUTC(TimeCurrent()) - g_gcTime <= 4 * 3600); }

void BuildLevels()
  {
   g_lvN = 0;
   if(g_d1.n >= 2)
     {
      LvAdd(BarH(g_d1, 0), LV_PDH, 1.0);
      LvAdd(BarL(g_d1, 0), LV_PDL, 1.0);
      LvAdd(BarC(g_d1, 0), LV_PDC, 0.6);
     }
   LvAdd(g_pwH, LV_PWH, 1.0);
   LvAdd(g_pwL, LV_PWL, 1.0);
   if(g_sess.asiaDone)
     {
      LvAdd(g_sess.asiaH, LV_ASIAH, 0.8);
      LvAdd(g_sess.asiaL, LV_ASIAL, 0.8);
     }
   if(g_sess.lonDone)
     {
      LvAdd(g_sess.lonH, LV_LONH, 0.8);
      LvAdd(g_sess.lonL, LV_LONL, 0.8);
     }
   if(PrevProfileOk())
     {
      LvAdd(PrevVAH(), LV_VAH, 0.9);
      LvAdd(PrevVAL(), LV_VAL, 0.9);
      LvAdd(PrevPOC(), LV_POC, 0.9);
     }
   double vw = VwapVal(g_vwD), sg = VwapSigma(g_vwD);
   if(vw > 0.0)
     {
      LvAdd(vw, LV_VWAP, 0.7);
      if(sg > 0.0)
        {
         LvAdd(vw + sg, LV_VWAPB1, 0.5);
         LvAdd(vw - sg, LV_VWAPB1, 0.5);
         LvAdd(vw + 2.0 * sg, LV_VWAPB2, 0.6);
         LvAdd(vw - 2.0 * sg, LV_VWAPB2, 0.6);
        }
     }
   double wv = VwapVal(g_vwW);
   if(wv > 0.0)
      LvAdd(wv, LV_WVWAP, 0.8);
   //--- swing H1 (frattali a 2 barre) delle ultime 48 ore
   int foundH = 0, foundL = 0;
   for(int sh = 2; sh < 48 && sh + 2 < g_h1.n; sh++)
     {
      double h = BarH(g_h1, sh), l = BarL(g_h1, sh);
      if(foundH < 4 && h > BarH(g_h1, sh - 1) && h > BarH(g_h1, sh - 2) && h > BarH(g_h1, sh + 1) && h > BarH(g_h1, sh + 2))
        {
         LvAdd(h, LV_SWING, 0.7);
         foundH++;
        }
      if(foundL < 4 && l < BarL(g_h1, sh - 1) && l < BarL(g_h1, sh - 2) && l < BarL(g_h1, sh + 1) && l < BarL(g_h1, sh + 2))
        {
         LvAdd(l, LV_SWING, 0.7);
         foundL++;
        }
     }
   //--- numeri tondi (oro a 4000: ogni 10 e forti ogni 50)
   double px = PxBid();
   if(px > 0.0)
     {
      double mag = MathPow(10.0, MathFloor(MathLog10(px)) - 2.0);
      double major = 5.0 * mag;
      double base = MathFloor(px / mag) * mag;
      for(int k = -3; k <= 4; k++)
        {
         double rp = base + k * mag;
         double rem = MathAbs(rp / major - MathRound(rp / major));
         if(rem < 0.0001)
            LvAdd(rp, LV_ROUNDM, 1.0);
         else
            LvAdd(rp, LV_ROUND, 0.5);
        }
     }
   if(GcFresh())
     {
      double basis = PxBid() - g_gcLast;
      if(g_gcPoc > 0.0)
         LvAdd(g_gcPoc + basis, LV_GC, 1.0);
      if(g_gcVah > 0.0)
         LvAdd(g_gcVah + basis, LV_GC, 0.9);
      if(g_gcVal > 0.0)
         LvAdd(g_gcVal + basis, LV_GC, 0.9);
     }
  }

//--- distanza dal primo livello oltre 'from' nella direzione dir (piu' lontano di minDist). -1 se nessuno
double NearestLevelDist(double from, int dir, double minDist, int &typeOut)
  {
   double best = -1.0;
   typeOut = -1;
   for(int i = 0; i < g_lvN; i++)
     {
      double d = (g_lv[i].price - from) * dir;
      if(d <= minDist)
         continue;
      if(best < 0.0 || d < best)
        {
         best = d;
         typeOut = g_lv[i].type;
        }
     }
   return best;
  }

//--- un livello forte molto vicino a un prezzo (es. lo stop messo proprio sul livello)
bool PriceOnMajorLevel(double price, double tol)
  {
   for(int i = 0; i < g_lvN; i++)
      if(IsMajorLevel(g_lv[i].type) && MathAbs(g_lv[i].price - price) <= tol)
         return true;
   return false;
  }

//+------------------------------------------------------------------+
//| Regime di mercato (H1)                                           |
//+------------------------------------------------------------------+
int    g_regime = REG_RANGE;
double g_atrRatioH1 = 1.0;

void UpdateRegime()
  {
   if(g_h1.n < 120)
      return;
   double a = AtrOf(g_h1);
   //--- mediana dell'ATR delle ultime 100 ore
   double tmp[100];
   int m = 0;
   for(int k = 0; k < 100; k++)
     {
      int i = ArraySize(g_h1.atr) - 1 - k;
      if(i < 0)
         break;
      tmp[m] = g_h1.atr[i];
      m++;
     }
   for(int i = 1; i < m; i++)
     {
      double v = tmp[i];
      int j = i - 1;
      while(j >= 0 && tmp[j] > v)
        {
         tmp[j + 1] = tmp[j];
         j--;
        }
      tmp[j + 1] = v;
     }
   double med = (m > 0) ? tmp[m / 2] : a;
   g_atrRatioH1 = (med > 0.0) ? a / med : 1.0;
   double adx = AdxOf(g_h1);
   double e20 = Ind(g_h1.ema20, 0), e50 = Ind(g_h1.ema50, 0), c = BarC(g_h1, 0);
   double slope = (a > 0.0) ? (Ind(g_h1.ema50, 0) - Ind(g_h1.ema50, 5)) / a : 0.0;
   if(g_atrRatioH1 > 1.8)
      g_regime = REG_VOLATILE;
   else
      if(adx >= 22.0 && e20 > e50 && c > e50 && slope > 0.1)
         g_regime = REG_UP;
      else
         if(adx >= 22.0 && e20 < e50 && c < e50 && slope < -0.1)
            g_regime = REG_DOWN;
         else
            if(g_atrRatioH1 < 0.6)
               g_regime = REG_QUIET;
            else
               g_regime = REG_RANGE;
  }

//--- quanto la strategia si adatta al regime
double RegimeFit(int stype)
  {
   bool trend = (g_regime == REG_UP || g_regime == REG_DOWN);
   if(trend)
     {
      if(stype == STYPE_TREND)
         return 0.15;
      if(stype == STYPE_BREAKOUT)
         return 0.10;
      if(stype == STYPE_REVERSAL)
         return -0.10;
      if(stype == STYPE_MEANREV)
         return -0.15;
      return 0.05;
     }
   if(g_regime == REG_RANGE)
     {
      if(stype == STYPE_TREND)
         return -0.10;
      if(stype == STYPE_REVERSAL)
         return 0.10;
      if(stype == STYPE_MEANREV)
         return 0.15;
      return 0.0;
     }
   if(g_regime == REG_VOLATILE)
     {
      if(stype == STYPE_MEANREV)
         return -0.15;
      if(stype == STYPE_BREAKOUT)
         return 0.05;
      if(stype == STYPE_REVERSAL)
         return -0.05;
      return 0.0;
     }
   //--- calmo
   if(stype == STYPE_BREAKOUT)
      return -0.10;
   if(stype == STYPE_MEANREV)
      return 0.10;
   if(stype == STYPE_REVERSAL)
      return 0.05;
   return -0.05;
  }
//+------------------------------------------------------------------+
//| CAPO "CONTESTO HTF": struttura, ritracciamento, compressione ed  |
//| espansione su W1 / D1 / H4. Dice in che fase e' il mercato e     |
//| quali strategie hanno senso in quel momento.                     |
//+------------------------------------------------------------------+
#define PH_LATERALE       0
#define PH_IMPULSO        1
#define PH_RITRACCIAMENTO 2
#define PH_COMPRESSIONE   3
#define PH_ESPANSIONE     4
#define PH_ESAURIMENTO    5

string g_phName[6] = {"laterale", "impulso", "ritracciamento", "compressione", "espansione", "esaurimento"};

struct TfContext
  {
   bool              valid;
   int               structure;  // +1 massimi e minimi crescenti, -1 decrescenti, 0 misto
   int               bos;        // rottura dell'ultimo swing: +1 sopra il massimo, -1 sotto il minimo
   int               emaDir;     // posizione rispetto alle medie
   int               dir;        // direzione dominante
   double            rangeHi;    // estremi del range di riferimento (dealing range)
   double            rangeLo;
   double            rangePos;   // 0 = sul minimo, 1 = sul massimo
   double            retr;       // profondita' del ritracciamento contro la direzione dominante (0..1)
   double            atrRatio;   // ATR attuale / mediana ATR (volatilita' relativa)
   double            bwPct;      // percentile larghezza Bollinger (0 = compressa, 1 = espansa)
   double            extAtr;     // distanza dalla EMA20 in ATR (con segno)
   bool              nr7;        // barra piu' stretta delle ultime 7
   int               phase;
  };

TfData    g_w1;
TfContext g_cxW1;
TfContext g_cxD1;
TfContext g_cxH4;
double    g_ctxBias = 0.0;     // -1..+1: direzione suggerita dai timeframe alti
string    g_ctxText = "";

void CtxReset(TfContext &c)
  {
   c.valid = false;
   c.structure = 0;
   c.bos = 0;
   c.emaDir = 0;
   c.dir = 0;
   c.rangeHi = 0.0;
   c.rangeLo = 0.0;
   c.rangePos = 0.5;
   c.retr = 0.0;
   c.atrRatio = 1.0;
   c.bwPct = 0.5;
   c.extAtr = 0.0;
   c.nr7 = false;
   c.phase = PH_LATERALE;
  }

//--- mediana degli ultimi 'count' valori di un array
double MedianLast(const double &a[], int count)
  {
   int n = ArraySize(a);
   int m = IMin(count, n);
   if(m <= 0)
      return 0.0;
   double tmp[200];
   if(m > 200)
      m = 200;
   for(int k = 0; k < m; k++)
      tmp[k] = a[n - 1 - k];
   for(int i = 1; i < m; i++)
     {
      double v = tmp[i];
      int j = i - 1;
      while(j >= 0 && tmp[j] > v)
        {
         tmp[j + 1] = tmp[j];
         j--;
        }
      tmp[j + 1] = v;
     }
   return tmp[m / 2];
  }

//--- larghezza relativa delle Bollinger(period,2) chiuse alla barra i
double BollWidthAt(const TfData &d, int i, int period)
  {
   double s = 0.0, s2 = 0.0;
   for(int k = i - period + 1; k <= i; k++)
     {
      s += d.r[k].close;
      s2 += d.r[k].close * d.r[k].close;
     }
   double mean = s / period;
   double var = s2 / period - mean * mean;
   return (mean > 0.0 && var > 0.0) ? 4.0 * MathSqrt(var) / mean : 0.0;
  }

//--- percentile (0..1) della larghezza attuale delle Bollinger sulle ultime 'lookback' barre
double BollWidthPct(const TfData &d, int period, int lookback)
  {
   int n = d.n;
   if(n < period + 10)
      return 0.5;
   double cur = BollWidthAt(d, n - 1, period);
   int start = IMax(period - 1, n - lookback);
   int below = 0, cnt = 0;
   for(int i = start; i < n - 1; i++)
     {
      cnt++;
      if(BollWidthAt(d, i, period) < cur)
         below++;
     }
   return (cnt > 0) ? (double)below / cnt : 0.5;
  }

//--- analisi di un timeframe: strength = barre per lato dei pivot, lookback = barre del range
void AnalyzeTf(const TfData &d, TfContext &c, int strength, int lookback)
  {
   CtxReset(c);
   int n = d.n;
   if(n < 2 * strength + 25)
      return;
   //--- pivot (swing) piu' recenti
   double ph[3];
   double pl[3];
   int nh = 0, nl = 0;
   int maxSh = IMin(lookback * 2, n - strength - 1);
   for(int sh = strength; sh <= maxSh && (nh < 3 || nl < 3); sh++)
     {
      int i = n - 1 - sh;
      bool isH = true, isL = true;
      for(int k = 1; k <= strength; k++)
        {
         if(d.r[i].high <= d.r[i - k].high || d.r[i].high < d.r[i + k].high)
            isH = false;
         if(d.r[i].low >= d.r[i - k].low || d.r[i].low > d.r[i + k].low)
            isL = false;
        }
      if(isH && nh < 3)
        {
         ph[nh] = d.r[i].high;
         nh++;
        }
      if(isL && nl < 3)
        {
         pl[nl] = d.r[i].low;
         nl++;
        }
     }
   double c0 = d.r[n - 1].close;
   if(nh >= 2 && nl >= 2)
     {
      bool hh = ph[0] > ph[1], hl = pl[0] > pl[1];
      bool lh = ph[0] < ph[1], ll = pl[0] < pl[1];
      if(hh && hl)
         c.structure = 1;
      else
         if(lh && ll)
            c.structure = -1;
     }
   if(nh >= 1 && c0 > ph[0])
      c.bos = 1;
   else
      if(nl >= 1 && c0 < pl[0])
         c.bos = -1;
   //--- medie (sui settimanali con poche barre uso solo EMA20)
   double e20 = Ind(d.ema20, 0), e50 = Ind(d.ema50, 0);
   if(n >= 60)
     {
      if(e20 > e50 && c0 > e50)
         c.emaDir = 1;
      else
         if(e20 < e50 && c0 < e50)
            c.emaDir = -1;
     }
   else
      c.emaDir = (c0 > e20) ? 1 : -1;
   c.dir = c.structure;
   if(c.dir == 0)
      c.dir = (c.bos != 0) ? c.bos : c.emaDir;
   //--- range di riferimento e ritracciamento
   int lb = IMin(lookback, n);
   double hi = HighestH(d, 0, lb), lo = LowestL(d, 0, lb);
   c.rangeHi = hi;
   c.rangeLo = lo;
   double rg = hi - lo;
   c.rangePos = (rg > 0.0) ? (c0 - lo) / rg : 0.5;
   if(c.dir > 0)
      c.retr = (rg > 0.0) ? (hi - c0) / rg : 0.0;
   else
      if(c.dir < 0)
         c.retr = (rg > 0.0) ? (c0 - lo) / rg : 0.0;
   //--- volatilita': compressione / espansione
   double a = Ind(d.atr, 0);
   double med = MedianLast(d.atr, 100);
   c.atrRatio = (med > 0.0) ? a / med : 1.0;
   c.bwPct = BollWidthPct(d, 20, 120);
   c.extAtr = (a > 0.0) ? (c0 - e20) / a : 0.0;
   double rg0 = d.r[n - 1].high - d.r[n - 1].low;
   c.nr7 = true;
   for(int k = 1; k < 7 && n - 1 - k >= 0; k++)
      if(d.r[n - 1 - k].high - d.r[n - 1 - k].low <= rg0)
         c.nr7 = false;
   bool comp = (c.bwPct <= 0.20 || c.atrRatio <= 0.75 || (c.nr7 && c.bwPct <= 0.35));
   bool expn = (c.bwPct >= 0.80 || c.atrRatio >= 1.35);
   double rsi = Ind(d.rsi, 0);
   bool exhaust = expn && (MathAbs(c.extAtr) >= 2.5 || (c.extAtr > 0.0 && rsi >= 75.0) || (c.extAtr < 0.0 && rsi <= 25.0));
   if(exhaust)
      c.phase = PH_ESAURIMENTO;
   else
      if(comp)
         c.phase = PH_COMPRESSIONE;
      else
         if(c.dir != 0 && c.structure != 0)
           {
            if(c.retr < 0.382)
               c.phase = expn ? PH_ESPANSIONE : PH_IMPULSO;
            else
               c.phase = PH_RITRACCIAMENTO;
           }
         else
            c.phase = expn ? PH_ESPANSIONE : PH_LATERALE;
   c.valid = true;
  }

double TfCtxScore(const TfContext &c)
  {
   if(!c.valid)
      return 0.0;
   double s = 0.6 * c.structure + 0.4 * c.emaDir;
   if(c.bos != 0 && c.bos != c.structure)
      s += 0.3 * c.bos;
   if(c.phase == PH_RITRACCIAMENTO && c.retr > 0.786)
      s *= 0.5;                              // struttura a rischio
   return Clamp(s, -1.0, 1.0);
  }

string DirWord(int d) { return (d > 0) ? "rialzo" : ((d < 0) ? "ribasso" : "neutro"); }

string TfCtxText(string name, const TfContext &c)
  {
   if(!c.valid)
      return name + " n.d.";
   string t = name + " " + DirWord(c.dir) + ", " + g_phName[c.phase];
   if(c.phase == PH_RITRACCIAMENTO)
      t += " " + DoubleToString(c.retr * 100.0, 0) + "%";
   return t;
  }

//--- ricalcolo (a ogni nuova barra H4 e all'avvio)
//--- T5 (1.24): giorno D1 dell'ultimo esaurimento in basso (crollo esausto)
datetime g_t5CrashDay = 0;

bool T5Active(datetime d1Now)
  {
   if(!InpT5NoShortAfterCrash || g_t5CrashDay <= 0 || d1Now <= 0)
      return false;
   int cal = (int)((d1Now - g_t5CrashDay) / 86400);
   int lim = InpT5Days + 2 * ((InpT5Days + 4) / 5);   // giorni di borsa -> giorni di calendario (weekend)
   return (cal >= 0 && cal <= lim);
  }

void UpdateContext()
  {
   AnalyzeTf(g_w1, g_cxW1, 2, 52);
   AnalyzeTf(g_d1, g_cxD1, 2, 60);
   AnalyzeTf(g_h4, g_cxH4, 3, 90);
   if(g_cxD1.valid && g_cxD1.phase == PH_ESAURIMENTO && g_cxD1.extAtr < 0.0)
      g_t5CrashDay = BarT(g_d1, 0);
   double w = 0.0, s = 0.0;
   if(g_cxW1.valid)
     {
      s += 0.30 * TfCtxScore(g_cxW1);
      w += 0.30;
     }
   if(g_cxD1.valid)
     {
      s += 0.45 * TfCtxScore(g_cxD1);
      w += 0.45;
     }
   if(g_cxH4.valid)
     {
      s += 0.25 * TfCtxScore(g_cxH4);
      w += 0.25;
     }
   g_ctxBias = (w > 0.0) ? Clamp(s / w, -1.0, 1.0) : 0.0;
   g_ctxText = TfCtxText("W1", g_cxW1) + " | " + TfCtxText("D1", g_cxD1) + " | " + TfCtxText("H4", g_cxH4) +
               " -> bias " + DoubleToString(g_ctxBias, 2);
  }

//--- contesto del timeframe "di fase" per ogni motore
int PhaseFor(int engine)
  {
   if(engine == ENG_SWING)
      return g_cxD1.phase;
   return g_cxH4.phase;
  }

int PhaseDirFor(int engine) { return (engine == ENG_SWING) ? g_cxD1.dir : g_cxH4.dir; }
double PhaseRetrFor(int engine) { return (engine == ENG_SWING) ? g_cxD1.retr : g_cxH4.retr; }
double PhaseExtFor(int engine) { return (engine == ENG_SWING) ? g_cxD1.extAtr : g_cxH4.extAtr; }

//--- quali strategie hanno senso adesso (testo per briefing e pannello)
string FavoredText()
  {
   int ph = g_cxH4.phase;
   int phD = g_cxD1.phase;
   string d = (g_ctxBias > 0.2) ? " long" : ((g_ctxBias < -0.2) ? " short" : "");
   if(ph == PH_COMPRESSIONE || phD == PH_COMPRESSIONE)
      return "breakout" + d + " (mercato compresso: in arrivo espansione)";
   if(ph == PH_ESAURIMENTO || phD == PH_ESAURIMENTO)
      return "inversioni / stop run (movimento esausto), niente inseguimenti";
   if(ph == PH_RITRACCIAMENTO && g_cxH4.retr <= 0.786)
      return "pullback" + d + " nella zona di sconto del trend";
   if(ph == PH_IMPULSO || ph == PH_ESPANSIONE)
      return "pullback" + d + " piccoli, evitare di inseguire l'estensione";
   return "range e ritorno alla media (VWAP, value area)";
  }
//+------------------------------------------------------------------+
//| News: calendario MT5 (live), calendario di riserva nel tester,   |
//| vista pre-news, dati macro/AI/GC da GitHub (WebRequest)          |
//+------------------------------------------------------------------+
struct NewsEvent
  {
   datetime          utc;
   int               tier;
   string            title;
   int               preDir;
   double            preConf;
   bool              viewTaken;
   int               viewDir;
   double            preClose;
   double            preAtr;
   double            extreme;
   bool              eUsed;
   int               kind;        // 1.26: 0 = non letto, 1 = inflazione CPI, 2 = lavoro, 3 = inflazione PCE
   int               surp;        // somma dei segni: positivo = dato "caldo" (sopra le attese, pesa sull'oro), negativo = "freddo"
   int               surpN;       // numeri con previsione letti
   datetime          surpAt;      // quando il bot l'ha saputo (UTC)
   string            surpText;
   bool              surpTold;
  };
NewsEvent g_news[MAX_NEWS];
int       g_newsN = 0;
datetime  g_newsRefreshedAt = 0;
int       g_testerNewsDay = 0;

void NewsClearSlot(int i)
  {
   g_news[i].utc = 0;
   g_news[i].tier = 4;
   g_news[i].title = "";
   g_news[i].preDir = 0;
   g_news[i].preConf = 0.0;
   g_news[i].viewTaken = false;
   g_news[i].viewDir = 0;
   g_news[i].preClose = 0.0;
   g_news[i].preAtr = 0.0;
   g_news[i].extreme = 0.0;
   g_news[i].eUsed = false;
   g_news[i].kind = 0;
   g_news[i].surp = 0;
   g_news[i].surpN = 0;
   g_news[i].surpAt = 0;
   g_news[i].surpText = "";
   g_news[i].surpTold = false;
  }

void NewsCopy(int dst, int src)
  {
   g_news[dst].utc = g_news[src].utc;
   g_news[dst].tier = g_news[src].tier;
   g_news[dst].title = g_news[src].title;
   g_news[dst].preDir = g_news[src].preDir;
   g_news[dst].preConf = g_news[src].preConf;
   g_news[dst].viewTaken = g_news[src].viewTaken;
   g_news[dst].viewDir = g_news[src].viewDir;
   g_news[dst].preClose = g_news[src].preClose;
   g_news[dst].preAtr = g_news[src].preAtr;
   g_news[dst].extreme = g_news[src].extreme;
   g_news[dst].eUsed = g_news[src].eUsed;
   g_news[dst].kind = g_news[src].kind;
   g_news[dst].surp = g_news[src].surp;
   g_news[dst].surpN = g_news[src].surpN;
   g_news[dst].surpAt = g_news[src].surpAt;
   g_news[dst].surpText = g_news[src].surpText;
   g_news[dst].surpTold = g_news[src].surpTold;
  }

//--- toglie gli eventi piu' vecchi di 'keepHours'
void NewsPrune(datetime nowUtc, int keepHours)
  {
   int w = 0;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].utc < nowUtc - keepHours * 3600)
         continue;
      if(w != i)
         NewsCopy(w, i);
      w++;
     }
   for(int i = w; i < g_newsN; i++)
      NewsClearSlot(i);
   g_newsN = w;
  }

int NewsFind(datetime utc, string title, int tolSec)
  {
   for(int i = 0; i < g_newsN; i++)
     {
      long d = (long)(g_news[i].utc - utc);
      if(d < 0)
         d = -d;
      if(d <= tolSec && (title == "" || g_news[i].title == title))
         return i;
     }
   return -1;
  }

int NewsUpsert(datetime utc, int tier, string title)
  {
   int i = NewsFind(utc, title, 120);
   if(i >= 0)
     {
      if(tier < g_news[i].tier)
         g_news[i].tier = tier;
      return i;
     }
   if(g_newsN >= MAX_NEWS)
      return -1;
   i = g_newsN;
   NewsClearSlot(i);
   g_news[i].utc = utc;
   g_news[i].tier = tier;
   g_news[i].title = title;
   g_newsN++;
   return i;
  }

//--- 1.19: unisce per orario (+-2 min) le news che arrivano da fonti diverse (MT5, GitHub, date ufficiali):
//--- resta il tier piu' alto; il titolo diventa quello della fonte che alza il tier
int NewsMerge(datetime utc, int tier, string title)
  {
   int i = NewsFind(utc, "", 120);
   if(i >= 0)
     {
      if(tier < g_news[i].tier)
        {
         g_news[i].tier = tier;
         g_news[i].title = title;
        }
      return i;
     }
   return NewsUpsert(utc, tier, title);
  }

//--- testo normalizzato per riconoscere le news: minuscolo, trattini e trattini bassi come spazi
string NewsNorm(string s)
  {
   string t = " " + s + " ";
   StringToLower(t);
   StringReplace(t, "-", " ");
   StringReplace(t, "_", " ");
   return t;
  }

//--- classificazione (come nel servizio Python). 1.19: il terminale in italiano chiama il CPI "IPC m/m",
//--- quindi si guarda anche il codice evento di MT5 (in inglese) e le parole italiane
int TierOf(string name, int importance)
  {
   string t = NewsNorm(name);
   if(importance < (int)CALENDAR_IMPORTANCE_MODERATE)
      return 4;
   bool high = (importance >= (int)CALENDAR_IMPORTANCE_HIGH);
   bool chair = (StringFind(t, "chair") >= 0 || StringFind(t, "presidente") >= 0);
   bool speech = (StringFind(t, "speech") >= 0 || StringFind(t, "speaks") >= 0 || StringFind(t, "testimony") >= 0 ||
                  StringFind(t, "discorso") >= 0 || StringFind(t, "testimonianza") >= 0 || StringFind(t, "interviene") >= 0);
   if(speech && !chair)
      return high ? 2 : 3;
   if(StringFind(t, "nonfarm") >= 0 || StringFind(t, "non farm") >= 0 || StringFind(t, "non agricol") >= 0 ||
      StringFind(t, "fomc") >= 0 || StringFind(t, "interest rate decision") >= 0 || StringFind(t, "federal funds") >= 0 ||
      StringFind(t, "fed interest rate") >= 0 || StringFind(t, "tassi d'interesse della fed") >= 0 ||
      StringFind(t, "tassi di interesse della fed") >= 0 || StringFind(t, "decisione sui tassi") >= 0 ||
      StringFind(t, "tasso di interesse della fed") >= 0 || StringFind(t, "tasso d'interesse della fed") >= 0 ||
      StringFind(t, " cpi ") >= 0 || StringFind(t, "(cpi)") >= 0 || StringFind(t, " ipc ") >= 0 || StringFind(t, "(ipc)") >= 0 ||
      StringFind(t, "consumer price index") >= 0 || StringFind(t, "prezzi al consumo") >= 0 ||
      StringFind(t, " pce ") >= 0 || StringFind(t, "(pce)") >= 0 || chair || StringFind(t, "jackson hole") >= 0)
      return 1;
   return high ? 2 : 3;
  }

//+------------------------------------------------------------------+
//| Calendario di riserva per il tester (il calendario MT5 non       |
//| funziona nel tester): NFP, FOMC e CPI con le date vere 2023-2027 |
//+------------------------------------------------------------------+
int g_fomcDates[41] = {20230201, 20230322, 20230503, 20230614, 20230726, 20230920, 20231101, 20231213,
                       20240131, 20240320, 20240501, 20240612, 20240731, 20240918, 20241107, 20241218,
                       20250129, 20250319, 20250507, 20250618, 20250730, 20250917, 20251029, 20251210,
                       20260128, 20260318, 20260429, 20260617, 20260729, 20260916, 20261028, 20261209,
                       20270127, 20270317, 20270428, 20270609, 20270728, 20270915, 20271027, 20271208,
                       20280126
                      };
//--- CPI: date vere di uscita (ForexFactory e BLS). Nel 2025 lo shutdown ha spostato settembre al 24/10,
//--- ottobre non e' uscito e novembre e' uscito il 18/12
int g_cpiDates[59] = {20230112, 20230214, 20230314, 20230412, 20230510, 20230613, 20230712, 20230810, 20230913, 20231012, 20231114, 20231212,
                      20240111, 20240213, 20240312, 20240410, 20240515, 20240612, 20240711, 20240814, 20240911, 20241010, 20241113, 20241211,
                      20250115, 20250212, 20250312, 20250410, 20250513, 20250611, 20250715, 20250812, 20250911, 20251024, 20251218,
                      20260113, 20260213, 20260311, 20260410, 20260512, 20260610, 20260714, 20260812, 20260911, 20261014, 20261110, 20261210,
                      20270113, 20270211, 20270310, 20270413, 20270512, 20270610, 20270714, 20270811, 20270914, 20271014, 20271110, 20271210
                     };
//--- NFP: date vere di uscita 2023-2027 (fuori da questo intervallo vale la regola del primo venerdi')
int g_nfpDates[59] = {20230106, 20230203, 20230310, 20230407, 20230505, 20230602, 20230707, 20230804, 20230901, 20231006, 20231103, 20231208,
                      20240105, 20240202, 20240308, 20240405, 20240503, 20240607, 20240705, 20240802, 20240906, 20241004, 20241101, 20241206,
                      20250110, 20250207, 20250307, 20250404, 20250502, 20250606, 20250703, 20250801, 20250905, 20251120, 20251216,
                      20260109, 20260211, 20260306, 20260403, 20260508, 20260605, 20260702, 20260807, 20260904, 20261002, 20261106, 20261204,
                      20270108, 20270205, 20270305, 20270402, 20270507, 20270604, 20270702, 20270806, 20270903, 20271008, 20271105, 20271203
                     };

//--- 1.26: sorpresa del CPI (totale m/m + core m/m contro le previsioni, ForexFactory): +2 = tutti e due sopra le attese
//--- (dato caldo), -2 = tutti e due sotto (freddo), 0 = in linea o misti che si annullano. Serve al Tester, dove il
//--- calendario MT5 non funziona; dal vivo il dato e la previsione si leggono dal calendario.
int g_cpiSurpDate[57] = {20220112, 20220210, 20220310, 20220412, 20220511, 20220610, 20220713, 20220810, 20220913, 20221013, 20221110, 20221213,
                         20230112, 20230214, 20230314, 20230412, 20230510, 20230613, 20230712, 20230810, 20230913, 20231012, 20231114, 20231212,
                         20240111, 20240213, 20240312, 20240410, 20240515, 20240612, 20240711, 20240814, 20240911, 20241010, 20241113, 20241211,
                         20250115, 20250212, 20250312, 20250410, 20250513, 20250611, 20250715, 20250812, 20250911, 20251024,
                         20260113, 20260213, 20260311, 20260410, 20260512, 20260610, 20260714, 20260812, 20260911, 20261014, 20261110
                        };
int g_cpiSurpVal[57]  = {2, 2, 0, -1, 2, 2, 2, -2, 2, 2, -2, -2,
                         0, 0, 1, -1, 1, -1, -2, 0, 1, 1, -2, 1,
                         1, 2, 1, 2, -1, -2, -2, 0, 1, 2, 0, 0,
                         -1, 2, -2, -2, -2, -2, -1, 0, 1, -2,
                         -1, -1, 0, -2, 1, -1, -2, 0, 1, 1, 2
                        };

bool InIntList(const int &arr[], int v)
  {
   int n = ArraySize(arr);
   for(int i = 0; i < n; i++)
      if(arr[i] == v)
         return true;
   return false;
  }

//--- ora ET -> UTC per una data (giorno UTC a mezzanotte)
datetime EtToUtc(datetime dayUtc, int hh, int mm)
  {
   datetime t = dayUtc + hh * 3600 + mm * 60 + 5 * 3600;
   if(IsUSDST(t))
      t -= 3600;
   return t;
  }

void BuiltinNewsAdd(int dk)
  {
   for(int k = 0; k <= 7; k++)
     {
      datetime day = (datetime)(dk + k) * 86400;
      int ymd = Ymd(day);
      MqlDateTime d;
      TimeToStruct(day, d);
      bool nfp = (ymd >= 20230101 && ymd <= 20271231) ? InIntList(g_nfpDates, ymd) : (d.day_of_week == 5 && d.day <= 7);
      if(nfp)
         NewsMerge(EtToUtc(day, 8, 30), 1, "Nonfarm Payrolls");
      if(InIntList(g_fomcDates, ymd))
         NewsMerge(EtToUtc(day, 14, 0), 1, "Fed Interest Rate Decision");
      if(InIntList(g_cpiDates, ymd))
         NewsMerge(EtToUtc(day, 8, 30), 1, "CPI m/m");
      //--- 1.26: nel Tester la sorpresa del CPI arriva dalla tabella storica, un minuto dopo l'uscita
      if(g_isTester)
         for(int j = 0; j < ArraySize(g_cpiSurpDate); j++)
            if(g_cpiSurpDate[j] == ymd)
              {
               int kx = NewsMerge(EtToUtc(day, 8, 30), 1, "CPI m/m");
               if(kx >= 0 && g_news[kx].surpN == 0)
                 {
                  g_news[kx].kind = 1;
                  g_news[kx].surp = g_cpiSurpVal[j];
                  g_news[kx].surpN = 2;
                  g_news[kx].surpAt = g_news[kx].utc + 60;
                  g_news[kx].surpText = "CPI totale e core (tabella storica)";
                 }
              }
     }
  }

void TesterNewsRefresh(datetime nowUtc)
  {
   int dk = DayKey(nowUtc);
   if(dk == g_testerNewsDay)
      return;
   g_testerNewsDay = dk;
   NewsPrune(nowUtc, 12);
   BuiltinNewsAdd(dk);
  }

int NextTier1Index(datetime nowUtc);
string g_newsNextLog = "";

//--- 1.19: scrive nel Diario quando cambia la prossima news forte (per controllare il calendario dal vivo)
void NewsLogNext(datetime nowUtc, string src)
  {
   int k = NextTier1Index(nowUtc);
   string s = (k >= 0) ? (g_news[k].title + " " + TimeToString(g_news[k].utc, TIME_DATE | TIME_MINUTES) + " UTC") : "nessuna";
   if(s == g_newsNextLog)
      return;
   g_newsNextLog = s;
   Logf("Calendario news (" + src + ", " + IntegerToString(g_newsN) + " eventi): prossima news forte " + s);
  }

//+------------------------------------------------------------------+
//| 1.26: IL DATO CONTRO LA PREVISIONE                               |
//| Il bot legge dal calendario MT5 il dato uscito e la previsione   |
//| e ne ricava il segno: "caldo" (inflazione o lavoro sopra le      |
//| attese: tassi piu' alti, pesa sull'oro) o "freddo". Sui dati     |
//| 2022-2026 (60 uscite) dopo un CPI caldo l'oro scende nel primo   |
//| minuto 8 volte su 10, dopo uno freddo sale 10 su 10: il verso e' |
//| giusto, ma il grosso del movimento arriva subito.                |
//+------------------------------------------------------------------+
//--- che numero e'? 1 = inflazione CPI mensile (totale e core), 2 = lavoro, 3 = inflazione PCE mensile; hawk = +1 se "sopra le attese" pesa sull'oro
int DataKindOf(string name, int &hawk)
  {
   string t = NewsNorm(name);
   hawk = 1;
   bool monthly = (StringFind(t, "m/m") >= 0 || StringFind(t, " mm ") >= 0 || StringFind(t, "mensile") >= 0);
   bool cpi = (StringFind(t, " cpi ") >= 0 || StringFind(t, "(cpi)") >= 0 || StringFind(t, " ipc ") >= 0 || StringFind(t, "(ipc)") >= 0 ||
               StringFind(t, "consumer price") >= 0 || StringFind(t, "prezzi al consumo") >= 0);
   bool pce = (StringFind(t, " pce ") >= 0 || StringFind(t, "(pce)") >= 0);
   if(cpi && monthly)
      return 1;
   if(StringFind(t, "nonfarm") >= 0 || StringFind(t, "non farm") >= 0 || StringFind(t, "non agricol") >= 0)
      return 2;
   if(StringFind(t, "unemployment rate") >= 0 || StringFind(t, "tasso di disoccupazione") >= 0)
     {
      hawk = -1;
      return 2;
     }
   if(monthly && (StringFind(t, "hourly earnings") >= 0 || StringFind(t, "retribuzion") >= 0 || StringFind(t, "salari") >= 0))
      return 2;
   if(pce && monthly)
      return 3;                                // inflazione PCE: solo avviso (sui dati l'oro reagisce poco)
   return 0;
  }

string DataVerdict(int kind, int surp, int n)
  {
   if(n <= 0)
      return "";
   if(surp == 0)
      return "in linea con le attese: nessuna spinta dal dato";
   bool clear = (MathAbs(surp) >= n);
   string strength = clear ? "" : " (numeri misti)";
   if(kind == 2)
     {
      if(surp > 0)
         return "lavoro FORTE, meglio delle attese" + strength + ": tassi piu' alti, pressione al RIBASSO sull'oro";
      return "lavoro DEBOLE, peggio delle attese" + strength + ": tassi piu' bassi, spinta al RIALZO sull'oro";
     }
   if(surp > 0)
      return "dato CALDO, sopra le attese" + strength + ": tassi piu' alti, pressione al RIBASSO sull'oro";
   return "dato FREDDO, sotto le attese" + strength + ": tassi piu' bassi, spinta al RIALZO sull'oro";
  }

//--- legge dato e previsione dei numeri appena usciti e li somma sull'evento con lo stesso orario
void DataSurpriseRead(MqlCalendarValue &vals[], int n, datetime nowUtc)
  {
   for(int k = 0; k < g_newsN; k++)
     {
      if(g_news[k].utc > nowUtc || nowUtc - g_news[k].utc > 6 * 3600)
         continue;
      //--- i numeri dello stesso dato (totale e core) possono arrivare a pochi secondi l'uno dall'altro:
      //    nel primo minuto dopo la prima lettura si rilegge, e vale la lettura con piu' numeri
      if(g_news[k].surpN > 0 && (g_isTester || g_news[k].surpTold || nowUtc - g_news[k].surpAt > 60))
         continue;
      int sum = 0, cnt = 0, kind = 0;
      string txt = "";
      for(int i = 0; i < n; i++)
        {
         long d = (long)(ToUTC(vals[i].time) - g_news[k].utc);
         if(d < -120 || d > 120)
            continue;
         if(vals[i].actual_value == LONG_MIN || vals[i].forecast_value == LONG_MIN)
            continue;
         MqlCalendarEvent ev;
         if(!CalendarEventById(vals[i].event_id, ev))
            continue;
         int hawk = 1;
         int kd = DataKindOf(ev.event_code + " | " + ev.name, hawk);
         if(kd == 0)
            continue;
         if(kind == 0 || kd < kind)
            kind = kd;
         double a = (double)vals[i].actual_value / 1000000.0, f = (double)vals[i].forecast_value / 1000000.0;
         if(a > f + 0.0000001)
            sum += hawk;
         if(a < f - 0.0000001)
            sum -= hawk;
         cnt++;
         if(StringLen(txt) < 150)
           {
            if(txt != "")
               txt += ", ";
            txt += ev.name + " " + DoubleToString(a, 1) + " (attese " + DoubleToString(f, 1) + ")";
           }
        }
      if(cnt == 0 || cnt <= g_news[k].surpN)
         continue;
      datetime first = (g_news[k].surpN > 0) ? g_news[k].surpAt : nowUtc;
      g_news[k].kind = kind;
      g_news[k].surp = sum;
      g_news[k].surpN = cnt;
      g_news[k].surpAt = first;
      g_news[k].surpText = txt;
     }
  }

//--- ultimo dato letto (per pannello e avvisi): indice dell'evento, -1 se nessuno nelle ultime 'hours' ore
int DataLastIndex(datetime nowUtc, int hours)
  {
   int best = -1;
   for(int k = 0; k < g_newsN; k++)
      if(g_news[k].surpN > 0 && g_news[k].surpAt <= nowUtc && nowUtc - g_news[k].utc <= hours * 3600)
         if(best < 0 || g_news[k].utc > g_news[best].utc)
            best = k;
   return best;
  }

string DataText(int k)
  {
   if(k < 0)
      return "";
   return g_news[k].surpText + ": " + DataVerdict(g_news[k].kind, g_news[k].surp, g_news[k].surpN);
  }

//--- avviso (una volta) quando il dato e' noto
void DataTell(datetime nowUtc)
  {
   if(!InpDataAlerts)
      return;
   for(int k = 0; k < g_newsN; k++)
     {
      if(g_news[k].surpN <= 0 || g_news[k].surpTold || g_news[k].surpAt > nowUtc)
         continue;
      if(!g_isTester && nowUtc - g_news[k].surpAt < 20)
         continue;                              // aspetta gli altri numeri dello stesso dato: l'avviso li porta tutti
      g_news[k].surpTold = true;
      string m = "DATO " + DataText(k);
      if(g_isTester)
         Logf(m);
      else
         Notify(m);
     }
  }

//--- c'e' un dato forte appena uscito che il bot non ha ancora letto? (rilettura veloce del calendario)
bool DataAwaited(datetime nowUtc)
  {
   for(int k = 0; k < g_newsN; k++)
      if(g_news[k].tier == 1 && g_news[k].surpN == 0 && nowUtc >= g_news[k].utc && nowUtc - g_news[k].utc <= 600)
         return true;
   return false;
  }

//+------------------------------------------------------------------+
//| Calendario MT5 (solo live/demo)                                  |
//+------------------------------------------------------------------+
void CalendarRefresh()
  {
   datetime srv = TimeTradeServer();
   g_newsRefreshedAt = TimeCurrent();
   MqlCalendarValue vals[];
   int n = CalendarValueHistory(vals, srv - 6 * 3600, srv + 36 * 3600, "US", "USD");
   NewsPrune(ToUTC(srv), 12);
   for(int i = 0; i < n; i++)
     {
      MqlCalendarEvent ev;
      if(!CalendarEventById(vals[i].event_id, ev))
         continue;
      int tier = TierOf(ev.event_code + " | " + ev.name, (int)ev.importance);
      if(tier > 2)
         continue;
      string title = ev.name;
      if(ev.event_code != "")
         title += " [" + ev.event_code + "]";
      NewsMerge(ToUTC(vals[i].time), tier, title);
     }
   if(InpDataAlerts || InpIN_DATA)
      DataSurpriseRead(vals, n, ToUTC(srv));
   BuiltinNewsAdd(DayKey(ToUTC(srv)));     // 1.19: NFP, CPI e FOMC dalle date ufficiali anche dal vivo
   NewsLogNext(ToUTC(srv), "MT5 + date ufficiali");
  }

//--- minuti alla prossima news tier1 (-1 se nessuna nelle prossime 36 ore)
int MinutesToNextTier1(datetime nowUtc)
  {
   int best = -1;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier != 1)
         continue;
      long d = (long)(g_news[i].utc - nowUtc);
      if(d < 0)
         continue;
      int m = (int)(d / 60);
      if(best < 0 || m < best)
         best = m;
     }
   return best;
  }

int NextTier1Index(datetime nowUtc)
  {
   int bi = -1;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier != 1 || g_news[i].utc < nowUtc)
         continue;
      if(bi < 0 || g_news[i].utc < g_news[bi].utc)
         bi = i;
     }
   return bi;
  }

//--- tipo di evento FOMC: 0 = no, 1 = decisione/comunicato/proiezioni, 2 = conferenza stampa
int FomcKind(string title)
  {
   string t = NewsNorm(title);
   if(StringFind(t, "minutes") >= 0 || StringFind(t, "speak") >= 0 || StringFind(t, "speech") >= 0 ||
      StringFind(t, "testimony") >= 0 || StringFind(t, "member") >= 0 || StringFind(t, "verbal") >= 0 ||
      StringFind(t, "discorso") >= 0 || StringFind(t, "membro") >= 0 || StringFind(t, "testimonianza") >= 0)
      return 0;
   if(StringFind(t, "press conference") >= 0 || StringFind(t, "conferenza stampa") >= 0)
      return (StringFind(t, "fomc") >= 0 || StringFind(t, "fed") >= 0) ? 2 : 0;
   if(StringFind(t, "fomc") >= 0 || StringFind(t, "federal funds") >= 0 || StringFind(t, "fed interest rate") >= 0 ||
      StringFind(t, "tassi d'interesse della fed") >= 0 || StringFind(t, "tassi di interesse della fed") >= 0 ||
      StringFind(t, "tasso di interesse della fed") >= 0 || StringFind(t, "tasso d'interesse della fed") >= 0)
      return 1;
   return 0;
  }

//--- blocco ingressi per news. strat = strategia che chiede (IN-NEWS puo' entrare dopo +5 min).
//--- FOMC (studio banche centrali, 9 nov 2026): la conferenza parte a +30 e raddoppia o ribalta la mossa,
//--- quindi niente ingressi, IN-NEWS compreso, fino a +InpNewsBlockFomcAfter minuti dalla decisione
bool NewsBlocked(int engine, datetime nowUtc, int strat, string &why)
  {
   for(int i = 0; i < g_newsN; i++)
     {
      double dt = (double)(nowUtc - g_news[i].utc) / 60.0;
      double before = 0.0, after = 0.0;
      int fk = (InpNewsBlockFomcAfter > 0) ? FomcKind(g_news[i].title) : 0;
      if(g_news[i].tier == 1 || fk > 0)
        {
         before = (engine == ENG_SWING) ? InpNewsBlockSwingBefore : InpNewsBlockBefore;
         after = (engine == ENG_SWING) ? InpNewsBlockSwingAfter : InpNewsBlockAfter;
         if(fk == 1)
            after = MathMax(after, (double)InpNewsBlockFomcAfter);
         if(fk == 2)
            after = MathMax(after, (double)InpNewsBlockFomcAfter - 30.0);
        }
      else
         if(g_news[i].tier == 2)
           {
            if(IsProvenFam(strat))
               continue;                      // 1.26: i movimenti forti (e dalla 1.27 i ritracciamenti) sono misurati senza questo blocco (resta quello delle news forti)
            before = (engine == ENG_SWING) ? 30.0 : 15.0;
            after = (engine == ENG_SWING) ? 30.0 : 10.0;
           }
         else
            continue;
      if(dt >= -before && dt <= after)
        {
         if(strat == ST_IN_NEWS && dt >= 5.0 && fk == 0)
            continue;
         if(strat == ST_IN_DATA && dt >= 0.0 && fk == 0)
            continue;                         // 1.26: IN-DATO entra proprio dopo il dato
         why = "news " + g_news[i].title + (dt < 0 ? " tra " : " uscita da ") + IntegerToString((int)MathAbs(dt)) + " min";
         return true;
        }
     }
   return false;
  }

//+------------------------------------------------------------------+
//| JSON minimo (solo quello che serve)                              |
//+------------------------------------------------------------------+
ushort JsCh(const string &s, int i) { return StringGetCharacter(s, i); }

int JsSkipSpace(const string &s, int i)
  {
   int n = StringLen(s);
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c != ' ' && c != '\n' && c != '\r' && c != '\t')
         break;
      i++;
     }
   return i;
  }

//--- fine di una stringa che inizia con " in posizione i (ritorna indice del " di chiusura)
int JsStringEnd(const string &s, int i)
  {
   int n = StringLen(s);
   i++;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '\\')
        {
         i += 2;
         continue;
        }
      if(c == '"')
         return i;
      i++;
     }
   return n - 1;
  }

//--- posizione del valore della chiave 'key' al primo livello dell'oggetto in s (-1 se manca)
int JsonTopKey(const string &s, string key)
  {
   int n = StringLen(s);
   int depth = 0;
   int i = 0;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '"')
        {
         int e = JsStringEnd(s, i);
         if(depth == 1)
           {
            int j = JsSkipSpace(s, e + 1);
            if(j < n && JsCh(s, j) == ':')
              {
               if(StringSubstr(s, i + 1, e - i - 1) == key)
                  return JsSkipSpace(s, j + 1);
              }
           }
         i = e + 1;
         continue;
        }
      if(c == '{' || c == '[')
         depth++;
      else
         if(c == '}' || c == ']')
            depth--;
      i++;
     }
   return -1;
  }

double JsonNum(const string &s, string key, double def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0)
      return def;
   int n = StringLen(s);
   int e = p;
   while(e < n)
     {
      ushort c = JsCh(s, e);
      if((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E')
         e++;
      else
         break;
     }
   if(e == p)
      return def;
   return StringToDouble(StringSubstr(s, p, e - p));
  }

bool JsonBool(const string &s, string key, bool def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0)
      return def;
   if(StringSubstr(s, p, 4) == "true")
      return true;
   if(StringSubstr(s, p, 5) == "false")
      return false;
   return def;
  }

string JsonStr(const string &s, string key, string def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0 || JsCh(s, p) != '"')
      return def;
   int e = JsStringEnd(s, p);
   return StringSubstr(s, p + 1, e - p - 1);
  }

//--- oggetti di un array: a partire dalla '[' in posizione p
int JsonArrayObjects(const string &s, int p, string &objs[])
  {
   ArrayResize(objs, 0);
   int n = StringLen(s);
   if(p < 0 || p >= n || JsCh(s, p) != '[')
      return 0;
   int depth = 0;
   int start = -1;
   int cnt = 0;
   int i = p + 1;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '"')
        {
         i = JsStringEnd(s, i) + 1;
         continue;
        }
      if(c == '{')
        {
         if(depth == 0)
            start = i;
         depth++;
        }
      else
         if(c == '}')
           {
            depth--;
            if(depth == 0 && start >= 0)
              {
               ArrayResize(objs, cnt + 1);
               objs[cnt] = StringSubstr(s, start, i - start + 1);
               cnt++;
               start = -1;
              }
           }
         else
            if(c == ']' && depth == 0)
               break;
      i++;
     }
   return cnt;
  }

datetime ParseIsoUtc(string s)
  {
   string t = s;
   StringReplace(t, "-", ".");
   StringReplace(t, "T", " ");
   StringReplace(t, "Z", "");
   return StringToTime(t);
  }

//+------------------------------------------------------------------+
//| Dati esterni da GitHub                                           |
//+------------------------------------------------------------------+
double   g_macroBias = 0.0, g_macroConf = 0.0, g_macroRiskMult = 1.0;
bool     g_macroHalt = false;
string   g_macroHaltReason = "";
//--- macro piu' ricca: stato delle fonti e informazioni extra del servizio (solo da leggere: non cambiano le decisioni)
bool     g_macroIncomplete = false;
string   g_macroMissing = "";
string   g_extraText = "";
string   g_lastDataText = "";
datetime g_lastDataTime = 0;
datetime g_macroTime = 0;
string   g_aiStance = "";
double   g_aiConv = 0.0;
datetime g_aiTime = 0;
datetime g_webLastTry = 0;
double   g_mBias = 0.0;       // macro combinata usata dal comitato (GitHub + storico + intermarket)
double   g_mConf = 0.0;
string   g_mSource = "";
bool     g_webWarned = false;

bool MacroFresh() { return (g_macroTime > 0 && ToUTC(TimeCurrent()) - g_macroTime <= 6 * 3600); }
bool AiFresh()    { return (g_aiTime > 0 && ToUTC(TimeCurrent()) - g_aiTime <= 8 * 3600); }

bool HttpGet(string url, string &body)
  {
   char data[];
   char res[];
   string hdr;
   ResetLastError();
   int code = WebRequest("GET", url, "", 5000, data, res, hdr);
   if(code == -1)
     {
      int err = GetLastError();
      if(!g_webWarned)
        {
         g_webWarned = true;
         Notify("Dati esterni non leggibili (errore " + IntegerToString(err) + "). In MT5: Strumenti > Opzioni > Expert Advisors > spunta 'Consenti WebRequest' e aggiungi https://raw.githubusercontent.com");
        }
      return false;
     }
   if(code != 200)
      return false;
   body = CharArrayToString(res, 0, WHOLE_ARRAY, CP_UTF8);
   return (StringLen(body) > 2);
  }

void ParseMacro(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   g_macroTime = ParseIsoUtc(ts);
   g_macroBias = Clamp(JsonNum(js, "bias", 0.0), -1.0, 1.0);
   g_macroConf = Clamp(JsonNum(js, "confidence", 0.0), 0.0, 1.0);
   g_macroRiskMult = Clamp(JsonNum(js, "risk_multiplier", 1.0), 0.3, 1.5);
   g_macroHalt = JsonBool(js, "halt_trading", false);
   g_macroHaltReason = JsonStr(js, "halt_reason", "");
   g_macroIncomplete = JsonBool(js, "macro_incompleta", false);
   g_macroMissing = JsonStr(js, "fonti_mancanti_testo", "");
   g_extraText = JsonStr(js, "extra_sintesi", "");
   g_lastDataText = JsonStr(js, "ultimo_dato", "");
   string ldt = JsonStr(js, "ultimo_dato_ora_utc", "");
   g_lastDataTime = (ldt != "") ? ParseIsoUtc(ldt) : 0;
   //--- viste pre-news del servizio di ricerca
   string objs[];
   int n = JsonArrayObjects(js, JsonTopKey(js, "pre_news"), objs);
   for(int i = 0; i < n; i++)
     {
      string t = JsonStr(objs[i], "time_utc", "");
      if(t == "")
         continue;
      datetime u = ParseIsoUtc(t);
      int tier = (int)JsonNum(objs[i], "tier", 1.0);
      string title = JsonStr(objs[i], "event", "evento");
      int k = NewsFind(u, "", 600);
      if(k < 0)
         k = NewsUpsert(u, IMax(1, IMin(tier, 2)), title);
      if(k < 0)
         continue;
      g_news[k].preDir = (int)MathRound(Clamp(JsonNum(objs[i], "gold_direction", 0.0), -1.0, 1.0));
      g_news[k].preConf = Clamp(JsonNum(objs[i], "confidence", 0.0), 0.0, 1.0);
     }
  }

void ParseCommittee(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   g_aiTime = ParseIsoUtc(ts);
   g_aiStance = JsonStr(js, "stance", "flat");
   g_aiConv = Clamp(JsonNum(js, "conviction", 0.0), 0.0, 1.0);
  }

void ParseVolumeLevels(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   double last = JsonNum(js, "gc_last", 0.0);
   int p = JsonTopKey(js, "composite");
   if(p < 0 || last <= 0.0)
      return;
   //--- l'oggetto composite: lo isolo e leggo poc/vah/val
   int n = StringLen(js);
   int depth = 0, e = p;
   for(int i = p; i < n; i++)
     {
      ushort c = JsCh(js, i);
      if(c == '"')
        {
         i = JsStringEnd(js, i);
         continue;
        }
      if(c == '{')
         depth++;
      if(c == '}')
        {
         depth--;
         if(depth == 0)
           {
            e = i;
            break;
           }
        }
     }
   string comp = StringSubstr(js, p, e - p + 1);
   g_gcPoc = JsonNum(comp, "poc", 0.0);
   g_gcVah = JsonNum(comp, "vah", 0.0);
   g_gcVal = JsonNum(comp, "val", 0.0);
   g_gcLast = last;
   g_gcDeltaTrend = Clamp(JsonNum(js, "delta_trend", 0.0), -1.0, 1.0);
   g_gcTime = ParseIsoUtc(ts);
  }

//--- calendario di riserva dal JSON (se il calendario MT5 e' vuoto)
void ParseNewsCalendar(const string &js)
  {
   string objs[];
   int n = JsonArrayObjects(js, JsSkipSpace(js, 0), objs);
   for(int i = 0; i < n; i++)
     {
      string t = JsonStr(objs[i], "time_utc", "");
      int tier = (int)JsonNum(objs[i], "tier", 4.0);
      if(t == "" || tier > 2)
         continue;
      NewsMerge(ParseIsoUtc(t), tier, JsonStr(objs[i], "title", "news"));
     }
  }

void WebRefresh()
  {
   if(!InpUseWebData || g_isTester)
      return;
   g_webLastTry = TimeCurrent();
   string body;
   if(InpMacroUrl != "" && HttpGet(InpMacroUrl, body))
      ParseMacro(body);
   if(InpCommitteeUrl != "" && HttpGet(InpCommitteeUrl, body))
      ParseCommittee(body);
   if(InpVolumeUrl != "" && HttpGet(InpVolumeUrl, body))
      ParseVolumeLevels(body);
   if(InpNewsUrl != "" && HttpGet(InpNewsUrl, body))   // 1.19: sempre, anche se MT5 ha gia' dato eventi
     {
      ParseNewsCalendar(body);
      NewsLogNext(ToUTC(TimeCurrent()), "MT5 + GitHub + date ufficiali");
     }
  }

//+------------------------------------------------------------------+
//| Vista pre-news: 30 minuti prima della news il desk news fissa    |
//| la direzione attesa; dopo la news si entra SOLO se conferma      |
//+------------------------------------------------------------------+
void NewsTrack()
  {
   datetime nowU = g_ctx.nowUtc;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier > 2)
         continue;
      long dt = (long)(nowU - g_news[i].utc);
      if(!g_news[i].viewTaken && dt >= -30 * 60 && dt < 0)
        {
         int trend = TrendDir(g_h1);
         int vw = (g_ctx.vwap > 0.0) ? ((BarC(g_m5, 0) > g_ctx.vwap) ? 1 : -1) : 0;
         int macro = 0;
         if(g_mConf >= 0.3 && MathAbs(g_mBias) >= 0.15)
            macro = (g_mBias > 0.0) ? 1 : -1;
         int dir = 0;
         if(g_news[i].preConf >= 0.5 && g_news[i].preDir != 0)
            dir = g_news[i].preDir;
         else
            if(trend != 0 && trend == vw && (macro == 0 || macro == trend))
               dir = trend;
         g_news[i].viewDir = dir;
         g_news[i].preClose = BarC(g_m5, 0);
         g_news[i].preAtr = MathMax(AtrOf(g_m15), g_tick * 10);
         g_news[i].extreme = g_news[i].preClose;
         g_news[i].viewTaken = true;
         string vtxt = (dir > 0) ? "rialzo" : ((dir < 0) ? "ribasso" : "neutra");
         Logf("Vista pre-news su " + g_news[i].title + ": " + vtxt);
        }
      if(g_news[i].viewTaken && g_news[i].viewDir != 0 && dt >= 0 && dt <= 120 * 60)
        {
         if(g_news[i].viewDir > 0)
            g_news[i].extreme = MathMax(g_news[i].extreme, BarH(g_m5, 0));
         else
            g_news[i].extreme = MathMin(g_news[i].extreme, BarL(g_m5, 0));
        }
     }
  }

//--- vista per la prossima news tier1 entro 'horizonMin' (dal servizio di ricerca o dalla vista fissata)
int NextEventView(datetime nowUtc, int horizonMin)
  {
   int k = NextTier1Index(nowUtc);
   if(k < 0)
      return 0;
   if((g_news[k].utc - nowUtc) / 60 > horizonMin)
      return 0;
   if(g_news[k].viewTaken)
      return g_news[k].viewDir;
   if(g_news[k].preConf >= 0.5)
      return g_news[k].preDir;
   return 0;
  }
//+------------------------------------------------------------------+
//| CAPO MACRO sempre informato:                                     |
//| 1) intermarket dai simboli del broker (funziona anche nel tester)|
//|    dollaro sintetico (pesi DXY), USDJPY come proxy dei           |
//|    rendimenti, argento, indice azionario, correlazione oro-dollaro|
//| 2) servizio di ricerca su GitHub (rendimenti reali, Fed, news)   |
//| 3) storico macro (macro_history.csv) per i backtest              |
//+------------------------------------------------------------------+
#define IM_EURUSD 0
#define IM_USDJPY 1
#define IM_GBPUSD 2
#define IM_USDCAD 3
#define IM_USDSEK 4
#define IM_USDCHF 5
#define IM_XAGUSD 6
#define IM_INDEX  7
#define IM_DXY    8
#define IM_N      9

string g_imSym[IM_N];
double g_imDxyW[6] = {-0.576, 0.136, -0.119, 0.091, 0.042, 0.036};

double g_dollarScore = 0.0;   // + dollaro forte
double g_dollarFast = 0.0;    // momento H4 del dollaro
double g_yieldProxy = 0.0;    // + USDJPY in salita (rendimenti USA su)
double g_silverConf = 0.0;    // + argento conferma l'oro
double g_riskOff = 0.0;       // + fuga dal rischio (azionario in calo forte)
double g_goldDxyCorr = 0.0;   // correlazione 60 giorni rendimenti oro / dollaro
double g_imBias = 0.0;
double g_imConf = 0.0;
int    g_imFx = 0;            // quanti cambi disponibili per il dollaro
bool   g_imOk = false;


//--- storico macro (dal servizio GitHub, anche nel tester)
int    g_mhDate[];
double g_mhBias[];
double g_mhConf[];
int    g_mhN = 0;
datetime g_mhLastTry = 0;

bool TrySymbol(string s)
  {
   if(s == "")
      return false;
   if(!SymbolSelect(s, true))
      return false;
   return true;
  }

//--- trova il simbolo del broker (con eventuali prefissi/suffissi come XAUUSD.a o XAUUSDm)
string ResolveSymbol(string base)
  {
   string up = g_sym;
   StringToUpper(up);
   int p = StringFind(up, "XAUUSD");
   string pre = "", suf = "";
   if(p >= 0)
     {
      pre = StringSubstr(g_sym, 0, p);
      suf = StringSubstr(g_sym, p + 6);
     }
   if(TrySymbol(pre + base + suf))
      return pre + base + suf;
   if(suf != "" && TrySymbol(base + suf))
      return base + suf;
   if(TrySymbol(base))
      return base;
   return "";
  }

void IntermarketInit()
  {
   g_imSym[IM_EURUSD] = ResolveSymbol("EURUSD");
   g_imSym[IM_USDJPY] = ResolveSymbol("USDJPY");
   g_imSym[IM_GBPUSD] = ResolveSymbol("GBPUSD");
   g_imSym[IM_USDCAD] = ResolveSymbol("USDCAD");
   g_imSym[IM_USDSEK] = ResolveSymbol("USDSEK");
   g_imSym[IM_USDCHF] = ResolveSymbol("USDCHF");
   g_imSym[IM_XAGUSD] = ResolveSymbol("XAGUSD");
   if(g_imSym[IM_XAGUSD] == "")
      g_imSym[IM_XAGUSD] = ResolveSymbol("SILVER");
   string idx[6];
   idx[0] = "US500";
   idx[1] = "SPX500";
   idx[2] = "SP500";
   idx[3] = "US500Cash";
   idx[4] = "USA500";
   idx[5] = "SPX";
   g_imSym[IM_INDEX] = "";
   for(int i = 0; i < 6 && g_imSym[IM_INDEX] == ""; i++)
      g_imSym[IM_INDEX] = ResolveSymbol(idx[i]);
   string dx[4];
   dx[0] = "USDX";
   dx[1] = "DXY";
   dx[2] = "DX";
   dx[3] = "USDOLLAR";
   g_imSym[IM_DXY] = "";
   for(int i = 0; i < 4 && g_imSym[IM_DXY] == ""; i++)
     {
      string c = ResolveSymbol(dx[i]);
      //--- accetto solo un vero indice del dollaro (DXY intorno a 70-130), non ETF o altri strumenti
      MqlRates t[];
      if(c != "" && CopyRates(c, PERIOD_D1, 1, 1, t) == 1 && t[0].close > 70.0 && t[0].close < 130.0)
         g_imSym[IM_DXY] = c;
     }
   string found = "";
   for(int i = 0; i < IM_N; i++)
      if(g_imSym[i] != "")
         found += g_imSym[i] + " ";
   if(found == "")
      found = "nessuno (la macro usera' GitHub e lo storico)";
   Logf("Macro intermarket: simboli trovati: " + found);
  }

//--- rendimento logaritmico del simbolo per la barra con tempo t (0 se manca)
double LogRetAt(const MqlRates &r[], int n, datetime t, int &pos)
  {
   while(pos < n && r[pos].time < t)
      pos++;
   if(pos >= n || pos == 0 || r[pos].time != t)
      return 0.0;
   if(r[pos - 1].close <= 0.0 || r[pos].close <= 0.0)
      return 0.0;
   return MathLog(r[pos].close / r[pos - 1].close);
  }

double Tanh(double x)
  {
   if(x > 20.0)
      return 1.0;
   if(x < -20.0)
      return -1.0;
   double e = MathExp(2.0 * x);
   return (e - 1.0) / (e + 1.0);
  }

//--- z-score del movimento delle ultime k barre rispetto alla volatilita'
double ZMove(const double &ret[], int n, int k, double vol)
  {
   if(n < k || vol <= 0.0)
      return 0.0;
   double s = 0.0;
   for(int i = n - k; i < n; i++)
      s += ret[i];
   return s / (vol * MathSqrt((double)k));
  }

double StdLast(const double &ret[], int n, int k)
  {
   int m = IMin(k, n);
   if(m < 5)
      return 0.0;
   double s = 0.0, s2 = 0.0;
   for(int i = n - m; i < n; i++)
     {
      s += ret[i];
      s2 += ret[i] * ret[i];
     }
   double mean = s / m;
   double v = s2 / m - mean * mean;
   return (v > 0.0) ? MathSqrt(v) : 0.0;
  }

//--- serie di rendimenti del dollaro sui tempi delle barre dell'oro (tf = D1 o H4)
int DollarReturns(ENUM_TIMEFRAMES tf, const TfData &gold, int bars, double &dret[], double &gret[])
  {
   ArrayResize(dret, 0);
   ArrayResize(gret, 0);
   int gn = gold.n;
   if(gn < bars + 2)
      return 0;
   MqlRates fx[];
   int cnt = 0;
   ArrayResize(dret, bars);
   ArrayResize(gret, bars);
   ArrayInitialize(dret, 0.0);
   ArrayInitialize(gret, 0.0);
   double wsum[];
   ArrayResize(wsum, bars);
   ArrayInitialize(wsum, 0.0);
   //--- preferisco il paniere dei cambi (24 ore, pesi DXY); l'indice del broker solo se mancano i cambi
   int fxAvail = 0;
   for(int s0 = IM_EURUSD; s0 <= IM_USDCHF; s0++)
      if(g_imSym[s0] != "")
         fxAvail++;
   bool useDxy = (g_imSym[IM_DXY] != "" && (g_imSym[IM_EURUSD] == "" || fxAvail < 3));
   int first = useDxy ? IM_DXY : IM_EURUSD;
   int last = useDxy ? IM_DXY : IM_USDCHF;
   for(int s = first; s <= last; s++)
     {
      if(g_imSym[s] == "")
         continue;
      int got = CopyRates(g_imSym[s], tf, 1, bars + 40, fx);
      if(got <= bars / 2)
         continue;
      double w = useDxy ? 1.0 : g_imDxyW[s];
      int pos = 0;
      int ok = 0;
      for(int j = 0; j < bars; j++)
        {
         int gi = gn - bars + j;
         double lr = LogRetAt(fx, got, gold.r[gi].time, pos);
         if(lr != 0.0)
           {
            dret[j] += w * lr;
            wsum[j] += MathAbs(w);
            ok++;
           }
        }
      if(ok > bars / 2)
         cnt++;
     }
   if(cnt == 0)
      return 0;
   double wfull = 0.0;
   if(useDxy)
      wfull = 1.0;
   else
      for(int s = IM_EURUSD; s <= IM_USDCHF; s++)
         if(g_imSym[s] != "")
            wfull += MathAbs(g_imDxyW[s]);
   for(int j = 0; j < bars; j++)
     {
      if(wsum[j] > 0.0 && wfull > 0.0)
         dret[j] *= wfull / wsum[j];       // rinormalizza se manca qualche cambio quel giorno
      int gi = gn - bars + j;
      if(gi >= 1 && gold.r[gi - 1].close > 0.0)
         gret[j] = MathLog(gold.r[gi].close / gold.r[gi - 1].close);
     }
   return useDxy ? 6 : cnt;
  }

double Corr(const double &a[], const double &b[], int n, int k)
  {
   int m = IMin(k, n);
   if(m < 10)
      return 0.0;
   double sa = 0, sb = 0, saa = 0, sbb = 0, sab = 0;
   for(int i = n - m; i < n; i++)
     {
      sa += a[i];
      sb += b[i];
      saa += a[i] * a[i];
      sbb += b[i] * b[i];
      sab += a[i] * b[i];
     }
   double va = saa / m - (sa / m) * (sa / m);
   double vb = sbb / m - (sb / m) * (sb / m);
   if(va <= 0.0 || vb <= 0.0)
      return 0.0;
   return (sab / m - (sa / m) * (sb / m)) / MathSqrt(va * vb);
  }

//--- momento di un singolo simbolo (z-score a 20 barre D1)
double SymbolZ(string sym, ENUM_TIMEFRAMES tf, int k)
  {
   if(sym == "")
      return 0.0;
   MqlRates r[];
   int got = CopyRates(sym, tf, 1, 80, r);
   if(got < k + 25)
      return 0.0;
   double ret[];
   ArrayResize(ret, got - 1);
   for(int i = 1; i < got; i++)
      ret[i - 1] = (r[i - 1].close > 0.0 && r[i].close > 0.0) ? MathLog(r[i].close / r[i - 1].close) : 0.0;
   double vol = StdLast(ret, got - 1, 60);
   return ZMove(ret, got - 1, k, vol);
  }

void IntermarketUpdate()
  {
   double dret[];
   double gret[];
   int bars = 70;
   g_imFx = DollarReturns(PERIOD_D1, g_d1, bars, dret, gret);
   g_imOk = (g_imFx > 0);
   if(!g_imOk)
     {
      g_imBias = 0.0;
      g_imConf = 0.0;
      return;
     }
   double vol = StdLast(dret, bars, 60);
   double z5 = ZMove(dret, bars, 5, vol);
   double z20 = ZMove(dret, bars, 20, vol);
   //--- trend del livello sintetico (somma cumulata) con due medie
   double lvl = 0.0, e10 = 0.0, e30 = 0.0;
   for(int j = 0; j < bars; j++)
     {
      lvl += dret[j];
      if(j == 0)
        {
         e10 = lvl;
         e30 = lvl;
        }
      else
        {
         e10 += (lvl - e10) * 2.0 / 11.0;
         e30 += (lvl - e30) * 2.0 / 31.0;
        }
     }
   double emaSign = (e10 > e30) ? 1.0 : -1.0;
   g_dollarScore = Clamp(0.4 * Tanh(z5 / 1.5) + 0.4 * Tanh(z20 / 1.5) + 0.2 * emaSign, -1.0, 1.0);
   g_goldDxyCorr = Corr(gret, dret, bars, 60);
   //--- dollaro veloce (H4, ultime 6 barre = un giorno)
   double dh[];
   double gh[];
   int hb = DollarReturns(PERIOD_H4, g_h4, 60, dh, gh);
   g_dollarFast = 0.0;
   if(hb > 0)
     {
      double vh = StdLast(dh, 60, 60);
      g_dollarFast = Tanh(ZMove(dh, 60, 6, vh) / 1.5);
     }
   g_yieldProxy = Tanh(SymbolZ(g_imSym[IM_USDJPY], PERIOD_D1, 20) / 1.5);
   //--- argento: conferma se si muove come l'oro
   double zs = SymbolZ(g_imSym[IM_XAGUSD], PERIOD_D1, 10);
   double zg = ZMove(gret, bars, 10, StdLast(gret, bars, 60));
   g_silverConf = 0.0;
   if(g_imSym[IM_XAGUSD] != "")
     {
      if(zs * zg > 0.0)
         g_silverConf = Tanh(MathMin(MathAbs(zs), MathAbs(zg)) / 1.5) * ((zg > 0.0) ? 1.0 : -1.0);
      else
         g_silverConf = -0.3 * ((zg > 0.0) ? 1.0 : -1.0);   // divergenza: l'oro va da solo, meno affidabile
     }
   double zi = SymbolZ(g_imSym[IM_INDEX], PERIOD_D1, 5);
   g_riskOff = (zi < -1.5) ? Tanh((-zi - 1.5)) : 0.0;
   //--- quanto conta il dollaro adesso: dipende dalla correlazione recente
   double wD = (g_goldDxyCorr < -0.2) ? 1.0 : ((g_goldDxyCorr < 0.2) ? 0.6 : 0.3);
   double wRiskOff = InpP3NoRiskOffBonus ? 0.0 : 0.10;   // P3 (1.17): interruttore del bonus fuga dal rischio
   g_imBias = Clamp(-0.55 * wD * g_dollarScore - 0.15 * g_yieldProxy + 0.20 * g_silverConf + wRiskOff * g_riskOff, -1.0, 1.0);
   double avail = MathMin(1.0, g_imFx / 4.0);
   g_imConf = Clamp((0.30 + 0.35 * MathAbs(g_goldDxyCorr)) * avail, 0.0, 0.65);
  }

//+------------------------------------------------------------------+
//| Storico macro (macro_history.csv in Common\Files)                |
//+------------------------------------------------------------------+
void MacroHistLoad()
  {
   g_mhN = 0;
   ArrayResize(g_mhDate, 0);
   ArrayResize(g_mhBias, 0);
   ArrayResize(g_mhConf, 0);
   if(!FileIsExist("macro_history.csv", FILE_COMMON))
      return;
   int h = FileOpen("macro_history.csv", FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      if(StringSplit(l, ',', p) < 3)
         continue;
      if(StringLen(p[0]) < 10 || StringGetCharacter(p[0], 0) < '0' || StringGetCharacter(p[0], 0) > '9')
         continue;
      int ymd = (int)StringToInteger(StringSubstr(p[0], 0, 4)) * 10000 + (int)StringToInteger(StringSubstr(p[0], 5, 2)) * 100 +
                (int)StringToInteger(StringSubstr(p[0], 8, 2));
      ArrayResize(g_mhDate, g_mhN + 1, 4096);
      ArrayResize(g_mhBias, g_mhN + 1, 4096);
      ArrayResize(g_mhConf, g_mhN + 1, 4096);
      g_mhDate[g_mhN] = ymd;
      g_mhBias[g_mhN] = Clamp(StringToDouble(p[1]), -1.0, 1.0);
      g_mhConf[g_mhN] = Clamp(StringToDouble(p[2]), 0.0, 1.0);
      g_mhN++;
     }
   FileClose(h);
   if(g_mhN > 0)
      Logf("Storico macro caricato: " + IntegerToString(g_mhN) + " giorni (" + IntegerToString(g_mhDate[0]) + " - " + IntegerToString(g_mhDate[g_mhN - 1]) + ")");
  }

//--- valore macro di ieri o prima (mai di oggi: nessuna informazione dal futuro), entro 5 giorni
bool MacroHistGet(datetime utc, double &b, double &c)
  {
   if(g_mhN <= 0)
      return false;
   int today = Ymd(utc);
   int lo = 0, hi = g_mhN - 1, best = -1;
   while(lo <= hi)
     {
      int mid = (lo + hi) / 2;
      if(g_mhDate[mid] < today)
        {
         best = mid;
         lo = mid + 1;
        }
      else
         hi = mid - 1;
     }
   if(best < 0)
      return false;
   int y = g_mhDate[best] / 10000, m = (g_mhDate[best] / 100) % 100, d = g_mhDate[best] % 100;
   MqlDateTime dt;
   dt.year = y;
   dt.mon = m;
   dt.day = d;
   dt.hour = 0;
   dt.min = 0;
   dt.sec = 0;
   dt.day_of_week = 0;
   dt.day_of_year = 0;
   if(utc - StructToTime(dt) > 6 * 86400)
      return false;
   b = g_mhBias[best];
   c = g_mhConf[best];
   return true;
  }

//--- in live scarica lo storico da GitHub e lo salva per il tester
void MacroHistDownload(string url)
  {
   if(g_isTester || url == "" || TimeCurrent() - g_mhLastTry < 12 * 3600)
      return;
   g_mhLastTry = TimeCurrent();
   string body;
   if(!HttpGet(url, body))
      return;
   if(StringFind(body, "date,bias") != 0)
      return;
   int h = FileOpen("macro_history.csv", FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   FileWriteString(h, body);
   FileClose(h);
   MacroHistLoad();
  }

//+------------------------------------------------------------------+
//| Macro combinata usata dal comitato                               |
//+------------------------------------------------------------------+
void MacroCombine()
  {
   double hb = 0.0, hc = 0.0;
   bool hist = MacroHistGet(ToUTC(TimeCurrent()), hb, hc);
   if(MacroFresh())
     {
      double wim = g_imOk ? 0.35 : 0.0;
      g_mBias = Clamp((1.0 - wim) * g_macroBias + wim * g_imBias, -1.0, 1.0);
      g_mConf = Clamp(MathMax(g_macroConf, g_imConf) * ((g_macroBias * g_imBias >= 0.0 || !g_imOk) ? 1.0 : 0.7), 0.0, 1.0);
      g_mSource = "GitHub";
      if(g_imOk)
         g_mSource += " + intermarket";
     }
   else
      if(hist && hc > 0.0)
        {
         double wim = g_imOk ? 0.4 : 0.0;
         g_mBias = Clamp((1.0 - wim) * hb + wim * g_imBias, -1.0, 1.0);
         g_mConf = Clamp(MathMax(hc * 0.9, g_imConf) * ((hb * g_imBias >= 0.0 || !g_imOk) ? 1.0 : 0.7), 0.0, 1.0);
         g_mSource = "storico macro";
         if(g_imOk)
            g_mSource += " + intermarket";
        }
      else
         if(g_imOk)
           {
            g_mBias = g_imBias;
            g_mConf = g_imConf * 0.85;
            g_mSource = "intermarket";
           }
         else
           {
            g_mBias = 0.0;
            g_mConf = 0.0;
            g_mSource = "nessuna";
           }
  }

string MacroText()
  {
   string t = "bias " + DoubleToString(g_mBias, 2) + " conf " + DoubleToString(g_mConf, 2) + " (" + g_mSource + ")";
   if(g_macroIncomplete && StringFind(g_mSource, "GitHub") >= 0)
      t += " | INCOMPLETA: manca " + (g_macroMissing != "" ? g_macroMissing : "una fonte");
   if(g_imOk)
     {
      string dw = "neutro";
      if(g_dollarScore > 0.25)
         dw = "forte";
      if(g_dollarScore < -0.25)
         dw = "debole";
      t += " | dollaro " + dw + " " + DoubleToString(g_dollarScore, 2) + ", corr oro-dollaro " + DoubleToString(g_goldDxyCorr, 2);
      if(g_imSym[IM_XAGUSD] != "")
        {
         if(g_silverConf > 0.2)
            t += ", argento conferma";
         else
            if(g_silverConf < -0.2)
               t += ", argento contrario";
            else
               t += ", argento neutro";
        }
      if(g_yieldProxy > 0.3)
         t += ", rendimenti in salita";
      if(g_yieldProxy < -0.3)
         t += ", rendimenti in calo";
     }
   if(MacroFresh() && g_macroHalt)
      t += " | STOP dal servizio: " + g_macroHaltReason;
   return t;
  }

//+------------------------------------------------------------------+
//| Motori del prezzo (1.17): corsa verticale, feste, calendario     |
//| Dallo studio del 9 nov 2026 (proposte P1-P6, ognuna con input)   |
//+------------------------------------------------------------------+
//--- borse USA chiuse 2023-2027 (data di New York)
int g_usHolidays[50] = {20230102, 20230116, 20230220, 20230407, 20230529, 20230619, 20230704, 20230904, 20231123, 20231225,
                        20240101, 20240115, 20240219, 20240329, 20240527, 20240619, 20240704, 20240902, 20241128, 20241225,
                        20250101, 20250120, 20250217, 20250418, 20250526, 20250619, 20250704, 20250901, 20251127, 20251225,
                        20260101, 20260119, 20260216, 20260403, 20260525, 20260619, 20260703, 20260907, 20261126, 20261225,
                        20270101, 20270118, 20270215, 20270326, 20270531, 20270618, 20270705, 20270906, 20271125, 20271224};
//--- Borsa di Tokyo chiusa 2023-2027, solo giorni feriali (data di Tokyo)
int g_jpHolidays[85] = {20230102, 20230103, 20230109, 20230223, 20230321, 20230503, 20230504, 20230505, 20230717, 20230811, 20230918, 20231009, 20231103, 20231123,
                        20240101, 20240102, 20240103, 20240108, 20240212, 20240223, 20240320, 20240429, 20240503, 20240506, 20240715, 20240812, 20240916, 20240923, 20241014, 20241104, 20241231,
                        20250101, 20250102, 20250103, 20250113, 20250211, 20250224, 20250320, 20250429, 20250505, 20250506, 20250721, 20250811, 20250915, 20250923, 20251013, 20251103, 20251124, 20251231,
                        20260101, 20260102, 20260112, 20260211, 20260223, 20260320, 20260429, 20260504, 20260505, 20260506, 20260720, 20260811, 20260921, 20260922, 20260923, 20261012, 20261103, 20261123, 20261231,
                        20270101, 20270111, 20270211, 20270223, 20270322, 20270429, 20270503, 20270504, 20270505, 20270719, 20270811, 20270920, 20270923, 20271011, 20271103, 20271123, 20271231};

int  EtYmd(datetime utc)  { return Ymd(utc - (IsUSDST(utc) ? 4 : 5) * 3600); }
int  JstYmd(datetime utc) { return Ymd(utc + 9 * 3600); }
bool IsUsHoliday(int ymd) { return InIntList(g_usHolidays, ymd); }
bool IsJpHoliday(int ymd) { return InIntList(g_jpHolidays, ymd); }

//--- giorno della settimana da anno/mese/giorno (0 = domenica)
int DowYmd(int y, int m, int d)
  {
   int t[12] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
   if(m < 3)
      y -= 1;
   return (y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7;
  }

int DaysInMonth(int y, int m)
  {
   if(m == 2)
      return ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0) ? 29 : 28;
   if(m == 4 || m == 6 || m == 9 || m == 11)
      return 30;
   return 31;
  }

bool IsTradingYmd(int y, int m, int d)
  {
   int w = DowYmd(y, m, d);
   if(w == 0 || w == 6)
      return false;
   return !IsUsHoliday(y * 10000 + m * 100 + d);
  }

//--- posizione del giorno contando dalla fine del mese (1 = ultimo giorno di borsa); 0 se non si tratta
int TradingPosFromEnd(int ymd)
  {
   int y = ymd / 10000, m = (ymd / 100) % 100, d = ymd % 100;
   if(!IsTradingYmd(y, m, d))
      return 0;
   int pos = 1;
   for(int k = d + 1; k <= DaysInMonth(y, m); k++)
      if(IsTradingYmd(y, m, k))
         pos++;
   return pos;
  }

//--- P4: primo giorno di borsa del mese (data di New York)
bool IsFirstTradingDay(int ymd)
  {
   int y = ymd / 10000, m = (ymd / 100) % 100, d = ymd % 100;
   if(!IsTradingYmd(y, m, d))
      return false;
   for(int k = 1; k < d; k++)
      if(IsTradingYmd(y, m, k))
         return false;
   return true;
  }

//--- P6: scadenza opzioni oro COMEX (4o ultimo giorno di borsa del mese) e il giorno dopo
bool IsExpiryWindow(int ymd)
  {
   int pos = TradingPosFromEnd(ymd);
   return (pos == 4 || pos == 3);
  }

//--- P1: corsa degli ultimi 20 giorni in sigma e distanza dalla media a 200 giorni (barre D1 chiuse)
double   g_runZ = 0.0;
double   g_ma200Dist = 0.0;
bool     g_runBrake = false;
datetime g_runCalcBar = 0;
//--- C1/C3 (1.20): candela D1 di ieri in ATR e ATR D1 a 20 giorni
double   g_d1Atr = 0.0;        // ATR 20 delle ultime 20 barre D1 chiuse
double   g_bigDayAtr = 0.0;    // ampiezza di ieri / ATR 20 dei 20 giorni prima
bool     g_bigDay = false;

void BigDayCompute(const MqlRates &r[], int got)
  {
   g_d1Atr = 0.0;
   g_bigDayAtr = 0.0;
   g_bigDay = false;
   if(got < 23)
      return;
   int L = got - 1;
   double sPrev = 0.0, sAll = 0.0;
   for(int i = L - 20; i <= L; i++)
     {
      double tr = MathMax(r[i].high, r[i - 1].close) - MathMin(r[i].low, r[i - 1].close);
      if(i < L)
         sPrev += tr;
      if(i > L - 20)
         sAll += tr;
     }
   double atrPrev = sPrev / 20.0;
   g_d1Atr = sAll / 20.0;
   if(atrPrev <= 0.0)
      return;
   g_bigDayAtr = (r[L].high - r[L].low) / atrPrev;
   g_bigDay = InpC1BigDayRisk && (g_bigDayAtr > InpC1BigDayAtr);
  }

//--- C3 (1.20): range di Asia stretto rispetto all'ATR D1 (Asia dalle 18 di New York all'apertura di Londra;
//    l'Asia corta 00 UTC -> Londra sotto 0,40 ATR capita l'84% dei giorni e non da' vantaggio: prova sulle M15 del demo)
bool TightAsia()
  {
   if(!g_c3Done || g_d1Atr <= 0.0 || g_c3H <= g_c3L)
      return false;
   return ((g_c3H - g_c3L) < InpC3AsiaAtr * g_d1Atr);
  }

void RunBrakeCompute(const MqlRates &r[], int got)
  {
   g_runZ = 0.0;
   g_ma200Dist = 0.0;
   g_runBrake = false;
   if(got < 82)
      return;
   int L = got - 1;
   //--- volatilita' giornaliera delle 60 sedute prima dell'ultima (come nello studio)
   double sum = 0.0, sum2 = 0.0;
   int n = 0;
   for(int i = L - 60; i <= L - 1; i++)
     {
      if(r[i].close <= 0.0 || r[i - 1].close <= 0.0)
         continue;
      double x = MathLog(r[i].close / r[i - 1].close);
      sum += x;
      sum2 += x * x;
      n++;
     }
   if(n < 40 || r[L].close <= 0.0 || r[L - 20].close <= 0.0)
      return;
   double var = (sum2 - sum * sum / n) / (n - 1);
   if(var <= 0.0)
      return;
   g_runZ = MathLog(r[L].close / r[L - 20].close) / (MathSqrt(var) * MathSqrt(20.0));
   bool dist = false;
   if(got >= 200)
     {
      double ma = 0.0;
      for(int i = L - 199; i <= L; i++)
         ma += r[i].close;
      ma /= 200.0;
      if(ma > 0.0)
        {
         g_ma200Dist = (r[L].close / ma - 1.0) * 100.0;
         dist = (g_ma200Dist > InpP1Ma200DistPct);
        }
     }
   g_runBrake = InpP1RunBrake && (g_runZ > InpP1RunSigma || dist);
  }

void RunBrakeUpdate()
  {
   datetime t = iTime(g_sym, PERIOD_D1, 0);
   if(t == 0 || t == g_runCalcBar)
      return;
   g_runCalcBar = t;
   MqlRates r[];
   int got = CopyRates(g_sym, PERIOD_D1, 1, 230, r);
   bool was = g_runBrake;
   bool wasBig = g_bigDay;
   BigDayCompute(r, got);
   if(g_bigDay != wasBig && !g_isOptim)
      Logf("C1 giorno dopo candela larga " + (g_bigDay ? string("ACCESO") : string("spento")) + ": ieri " +
           DoubleToString(g_bigDayAtr, 2) + " ATR");
   RunBrakeCompute(r, got);
   string stato = g_runBrake ? "ACCESO" : "spento";
   if(g_runBrake != was && !g_isOptim)
      Logf("P1 freno corsa verticale " + stato + ": corsa 20 giorni " + DoubleToString(g_runZ, 2) +
           " sigma, distanza dalla media 200 " + DoubleToString(g_ma200Dist, 1) + "%");
  }

string RunBrakeText()
  {
   return "corsa 20 giorni " + DoubleToString(g_runZ, 1) + " sigma, " + DoubleToString(g_ma200Dist, 1) + "% dalla media 200" +
          (g_runBrake ? " -> FRENO P1 ACCESO (rischio x" + DoubleToString(InpP1RiskMult, 2) + ", niente long in rottura)" : "") +
          "; candela di ieri " + DoubleToString(g_bigDayAtr, 1) + " ATR" +
          (g_bigDay ? " -> C1 giornata larga (rischio scalping/intraday x" + DoubleToString(InpC1RiskMult, 2) + ")" : "");
  }

//--- P2: liquidita' sottile (feste USA tutto il giorno, feste giapponesi nelle ore asiatiche, prima ora dopo una riapertura)
bool ThinLiquidity(datetime nowUtc, double hUtc, double lonOpen, string &why)
  {
   if(!InpP2ThinLiquidity)
      return false;
   int et = EtYmd(nowUtc);
   if(IsUsHoliday(et))
     {
      why = "P2 festa negli USA (" + IntegerToString(et) + "): liquidita' sottile";
      return true;
     }
   if((hUtc >= 21.0 || hUtc < lonOpen) && IsJpHoliday(JstYmd(nowUtc)))
     {
      why = "P2 festa in Giappone, ore asiatiche: liquidita' sottile";
      return true;
     }
   if(InpP2ReopenMin > 0 && g_m1.n > 3)
     {
      int look = IMin(g_m1.n - 2, InpP2ReopenMin + 2);
      datetime nowSrv = ToServer(nowUtc);
      for(int sh = 0; sh < look; sh++)
        {
         datetime t1 = BarT(g_m1, sh);
         datetime t0 = BarT(g_m1, sh + 1);
         if(t1 == 0 || t0 == 0)
            break;
         if(nowSrv - t1 > InpP2ReopenMin * 60)
            break;
         if(t1 - t0 > 3 * 3600)
           {
            why = "P2 prima ora dopo una riapertura: liquidita' sottile";
            return true;
           }
        }
     }
   return false;
  }
//+------------------------------------------------------------------+
//| Segnale comune: tutte le strategie parlano questa lingua         |
//+------------------------------------------------------------------+
struct TSignal
  {
   int               strat;
   int               engine;
   int               stype;
   int               dir;
   double            entry;
   double            sl;
   double            tp;
   double            quality;
   string            why;
   double            desk[NDESK];
   bool              veto;
   string            vetoWhy;
   double            score;
   int               quorum;
   int               devil;
   bool              strong;
   bool              recovery;
   bool              reentry;
   bool              aplus;
   double            cushion;
   double            obstacleR;
   double            cvdRatio;
   bool              passed;
   int               objMask;     // MR (1.25): obiezioni presenti (bit per tipo)
   int               softN;       // obiezioni secondarie che bloccherebbero
   string            softWhy;
   bool              overrideOk;  // passa scavalcando le obiezioni secondarie (conferme forti)
   bool              proven;      // 1.26: strategia provata sui dati: la fermano solo le obiezioni obbligatorie
   datetime          deadline;    // 1.27: tempo massimo (UTC) dell'idea; 0 = regole del motore
   int               rdFav;       // 1.27: letture del mercato a favore (bit per lettura)
   int               rdAg;        // 1.27: letture del mercato contrarie
   int               rdConf;      // 1.27: letture provate a favore meno quelle contrarie
   double            riskX;       // 1.27: moltiplicatore del rischio deciso dalla strategia (1 = nessuno)
   bool              flip;        // 1.27: movimento forte contro ritracciamenti ancora a rischio: prima di entrare li chiude

   void              Reset()
     {
      strat = 0;
      engine = 0;
      stype = 0;
      dir = 0;
      entry = 0.0;
      sl = 0.0;
      tp = 0.0;
      quality = 0.0;
      why = "";
      for(int i = 0; i < NDESK; i++)
         desk[i] = 0.5;
      veto = false;
      vetoWhy = "";
      score = 0.0;
      quorum = 0;
      devil = 0;
      strong = false;
      recovery = false;
      reentry = false;
      aplus = false;
      cushion = 0.0;
      obstacleR = -1.0;
      cvdRatio = 0.0;
      passed = false;
      objMask = 0;
      softN = 0;
      softWhy = "";
      overrideOk = false;
      proven = false;
      deadline = 0;
      rdFav = 0;
      rdAg = 0;
      rdConf = 0;
      riskX = 1.0;
      flip = false;
     }
  };

double RiskPx(const TSignal &s) { return (s.entry - s.sl) * s.dir; }

//--- copia esplicita (piu' sicura dell'assegnazione di struct con stringhe)
void SigCopy(TSignal &d, const TSignal &s)
  {
   d.strat = s.strat;
   d.engine = s.engine;
   d.stype = s.stype;
   d.dir = s.dir;
   d.entry = s.entry;
   d.sl = s.sl;
   d.tp = s.tp;
   d.quality = s.quality;
   d.why = s.why;
   for(int i = 0; i < NDESK; i++)
      d.desk[i] = s.desk[i];
   d.veto = s.veto;
   d.vetoWhy = s.vetoWhy;
   d.score = s.score;
   d.quorum = s.quorum;
   d.devil = s.devil;
   d.strong = s.strong;
   d.recovery = s.recovery;
   d.reentry = s.reentry;
   d.aplus = s.aplus;
   d.cushion = s.cushion;
   d.obstacleR = s.obstacleR;
   d.cvdRatio = s.cvdRatio;
   d.passed = s.passed;
   d.objMask = s.objMask;
   d.softN = s.softN;
   d.softWhy = s.softWhy;
   d.overrideOk = s.overrideOk;
   d.proven = s.proven;
   d.deadline = s.deadline;
   d.rdFav = s.rdFav;
   d.rdAg = s.rdAg;
   d.rdConf = s.rdConf;
   d.riskX = s.riskX;
   d.flip = s.flip;
  }

//--- costruisce il segnale con target in R (mai sotto il minimo 1:2)
bool MakeSignal(TSignal &s, int strat, int dir, double entry, double sl, double rr, double quality, string why)
  {
   s.Reset();
   s.strat = strat;
   s.engine = g_stratEngine[strat];
   s.stype = g_stratType[strat];
   s.dir = dir;
   s.entry = entry;
   s.sl = NormPrice(sl);
   double risk = (entry - s.sl) * dir;
   if(risk <= 2.0 * g_tick)
      return false;
   s.tp = NormPrice(entry + dir * risk * MathMax(rr, InpMinRR));
   s.quality = Clamp(quality, 0.0, 1.0);
   s.why = why;
   return true;
  }

//--- come sopra ma con target strutturale: valido solo se rispetta l'R:R minimo
bool MakeSignalTP(TSignal &s, int strat, int dir, double entry, double sl, double tp, double quality, string why)
  {
   s.Reset();
   s.strat = strat;
   s.engine = g_stratEngine[strat];
   s.stype = g_stratType[strat];
   s.dir = dir;
   s.entry = entry;
   s.sl = NormPrice(sl);
   double risk = (entry - s.sl) * dir;
   if(risk <= 2.0 * g_tick)
      return false;
   if((tp - entry) * dir < InpMinRR * risk)
      return false;
   s.tp = NormPrice(tp);
   s.quality = Clamp(quality, 0.0, 1.0);
   s.why = why;
   return true;
  }

double EntryPx(int dir) { return (dir > 0) ? g_ctx.ask : g_ctx.bid; }

//--- stop strutturale + buffer; per le vendite aggiunge lo spread (lo stop scatta sull'ask)
double StopFrom(double extreme, int dir, double buffer)
  {
   if(dir > 0)
      return extreme - buffer;
   return extreme + buffer + g_ctx.spread;
  }

//--- aggiusta la distanza dello stop dentro [minD, maxD]; false se troppo largo
bool FitStop(double entry, int dir, double &sl, double minD, double maxD)
  {
   double risk = (entry - sl) * dir;
   if(risk < minD)
      sl = entry - dir * minD;
   risk = (entry - sl) * dir;
   return (risk <= maxD);
  }

bool StratEnabled(int st)
  {
   if(InpOnlyStrategy != PICK_ALL && (int)InpOnlyStrategy != st)
      return false;
   switch(st)
     {
      case ST_SC_VWAP:
         return InpSC_VWAP;
      case ST_SC_SWEEP:
         return InpSC_SWEEP;
      case ST_SC_ORB:
         return InpSC_ORB;
      case ST_IN_PULLBACK:
         return InpIN_PULLBACK;
      case ST_IN_SWEEP:
         return InpIN_SWEEP;
      case ST_IN_BREAKOUT:
         return InpIN_BREAKOUT;
      case ST_IN_VALUE:
         return InpIN_VALUE;
      case ST_IN_NEWS:
         return InpIN_NEWS;
      case ST_IN_RANGE:
         return InpIN_RANGE;
      case ST_SW_TREND:
         return InpSW_TREND;
      case ST_SW_WYCKOFF:
         return InpSW_WYCKOFF;
      case ST_IN_TREND:
         return InpIN_TREND;
      case ST_IN_DATA:
         return InpIN_DATA;
      case ST_IN_NIGHT:
         return InpIN_NIGHT;
      case ST_IN_TREND2:
         return InpIN_TREND2;
      case ST_ON_M15:
         return InpON_M15;
      case ST_ON_H1:
         return InpON_H1;
      case ST_ON_H4:
         return InpON_H4;
      case ST_ON_M5:
         return InpON_M5;
     }
   return false;
  }

//+------------------------------------------------------------------+
//| SCALPING                                                         |
//+------------------------------------------------------------------+
//--- SC-VWAP: trend M15+M5, pullback sulla VWAP/EMA20 M5, ripartenza su M1
bool S_ScVwap(TSignal &s)
  {
   int t15 = TrendDir(g_m15), t5 = TrendDir(g_m5);
   if(t15 == 0 || t5 != t15)
      return false;
   int dir = t15;
   double vw = g_ctx.vwap, a5 = g_ctx.atrM5;
   if(vw <= 0.0 || a5 <= 0.0)
      return false;
   double c1 = BarC(g_m1, 0);
   if((c1 - vw) * dir <= 0.0)
      return false;
   double e20m5 = Ind(g_m5.ema20, 0);
   double zone = (dir > 0) ? MathMax(vw, e20m5) : MathMin(vw, e20m5);
   double ext = (dir > 0) ? LowestL(g_m1, 0, 7) : HighestH(g_m1, 0, 7);
   if(dir > 0)
     {
      if(ext > zone + 0.15 * a5 || ext < vw - 0.6 * a5)
         return false;
      if(!(c1 > BarH(g_m1, 1) && c1 > Ind(g_m1.ema20, 0) && c1 > BarO(g_m1, 0)))
         return false;
     }
   else
     {
      if(ext < zone - 0.15 * a5 || ext > vw + 0.6 * a5)
         return false;
      if(!(c1 < BarL(g_m1, 1) && c1 < Ind(g_m1.ema20, 0) && c1 < BarO(g_m1, 0)))
         return false;
     }
   if(MicroDelta(0) * dir < 0.0)
      return false;
   double entry = EntryPx(dir);
   double sl = StopFrom(ext, dir, 0.25 * g_ctx.atrM1);
   if(!FitStop(entry, dir, sl, 0.5 * a5, 2.0 * a5))
      return false;
   double q = 0.55;
   double rsi5 = Ind(g_m5.rsi, 0);
   if((dir > 0 && rsi5 > 45.0 && rsi5 < 68.0) || (dir < 0 && rsi5 < 55.0 && rsi5 > 32.0))
      q += 0.1;
   if(RvolBar(g_m1, 0) >= 1.2)
      q += 0.1;
   if(MicroCvdRatio(30) * dir > 0.0)
      q += 0.1;
   return MakeSignal(s, ST_SC_VWAP, dir, entry, sl, InpScalpRR, q, "pullback sulla VWAP in trend M15/M5");
  }

//--- SC-SWEEP: spazzata di un livello (stop run) e rientro rapido
bool S_ScSweep(TSignal &s)
  {
   double a5 = g_ctx.atrM5;
   if(a5 <= 0.0)
      return false;
   double lv[8];
   string nm[8];
   int n = 0;
   if(g_sess.asiaDone)
     {
      lv[n] = g_sess.asiaH;
      nm[n] = "Asia H";
      n++;
      lv[n] = g_sess.asiaL;
      nm[n] = "Asia L";
      n++;
     }
   if(g_sess.lonDone)
     {
      lv[n] = g_sess.lonH;
      nm[n] = "Londra H";
      n++;
      lv[n] = g_sess.lonL;
      nm[n] = "Londra L";
      n++;
     }
   if(g_d1.n >= 2)
     {
      lv[n] = BarH(g_d1, 0);
      nm[n] = "PDH";
      n++;
      lv[n] = BarL(g_d1, 0);
      nm[n] = "PDL";
      n++;
     }
   if(g_h1.n >= 2)
     {
      lv[n] = BarH(g_h1, 0);
      nm[n] = "max ora prec.";
      n++;
      lv[n] = BarL(g_h1, 0);
      nm[n] = "min ora prec.";
      n++;
     }
   double c = BarC(g_m1, 0), o = BarO(g_m1, 0);
   double lo5 = LowestL(g_m1, 0, 5), hi5 = HighestH(g_m1, 0, 5);
   bool found = false;
   double bestQ = 0.0;
   TSignal tmp;
   for(int i = 0; i < n; i++)
     {
      double L = lv[i];
      if(L <= 0.0)
         continue;
      for(int dir = -1; dir <= 1; dir += 2)
        {
         double ext = (dir > 0) ? lo5 : hi5;
         bool swept = (dir > 0) ? (ext < L - 0.1 * a5 && ext > L - 1.2 * a5) : (ext > L + 0.1 * a5 && ext < L + 1.2 * a5);
         bool reclaim = (dir > 0) ? (c > L && c > o) : (c < L && c < o);
         bool approach = (dir > 0) ? (BarC(g_m1, 6) > L) : (BarC(g_m1, 6) < L);
         if(!swept || !reclaim || !approach)
            continue;
         //--- barra della spazzata
         int sb = 0;
         for(int k = 0; k < 5; k++)
           {
            double x = (dir > 0) ? BarL(g_m1, k) : BarH(g_m1, k);
            if(x == ext)
              {
               sb = k;
               break;
              }
           }
         double wick = WickRatio(g_m1, sb, dir);
         double rv = RvolBar(g_m1, sb);
         if(wick < 0.4 && rv < 1.5)
            continue;
         if((MicroDelta(0) + MicroDelta(1)) * dir <= 0.0)
            continue;
         double entry = EntryPx(dir);
         double sl = StopFrom(ext, dir, 0.2 * g_ctx.atrM1);
         if(!FitStop(entry, dir, sl, 0.4 * a5, 2.0 * a5))
            continue;
         double q = 0.55;
         if(wick >= 0.5)
            q += 0.1;
         if(rv >= 1.5)
            q += 0.1;
         if(nm[i] == "PDH" || nm[i] == "PDL")
            q += 0.05;
         if(q > bestQ && MakeSignal(tmp, ST_SC_SWEEP, dir, entry, sl, InpScalpRR, q, "stop run su " + nm[i] + " e rientro"))
           {
            bestQ = q;
            SigCopy(s, tmp);
            found = true;
           }
        }
     }
   return found;
  }

//--- SC-ORB: range dei primi 15 minuti di Londra/NY, rottura con volume, retest
bool OrbCheck(TSignal &s, OrState &o, double openUtc, string name)
  {
   if(!o.done || o.used)
      return false;
   double h = g_ctx.hUtc;
   double a5 = g_ctx.atrM5;
   if(h > openUtc + 1.5 || a5 <= 0.0)
     {
      o.used = true;
      return false;
     }
   double height = o.h - o.l;
   if(height < 0.4 * a5 || height > 3.0 * a5)
     {
      o.used = true;
      return false;
     }
   double c = BarC(g_m1, 0);
   if(o.brk == 0)
     {
      double rv = RvolBar(g_m1, 0);
      if(c > o.h + 0.05 * a5 && rv >= 1.3)
        {
         o.brk = 1;
         o.brkT = BarT(g_m1, 0);
        }
      else
         if(c < o.l - 0.05 * a5 && rv >= 1.3)
           {
            o.brk = -1;
            o.brkT = BarT(g_m1, 0);
           }
      return false;
     }
   if(BarT(g_m1, 0) - o.brkT > 30 * 60)
     {
      o.used = true;
      return false;
     }
   int dir = o.brk;
   double lvl = (dir > 0) ? o.h : o.l;
   if((dir > 0 && c < o.l) || (dir < 0 && c > o.h))
     {
      o.used = true;
      return false;
     }
   double ext = (dir > 0) ? BarL(g_m1, 0) : BarH(g_m1, 0);
   bool touched = (dir > 0) ? (ext <= lvl + 0.15 * a5) : (ext >= lvl - 0.15 * a5);
   bool held = (dir > 0) ? (c > lvl && c > BarO(g_m1, 0)) : (c < lvl && c < BarO(g_m1, 0));
   if(!touched || !held)
      return false;
   o.used = true;
   double entry = EntryPx(dir);
   double ref = (dir > 0) ? MathMin(ext, lvl) : MathMax(ext, lvl);
   double sl = StopFrom(ref, dir, 0.2 * g_ctx.atrM1);
   if(!FitStop(entry, dir, sl, 0.4 * a5, 2.0 * a5))
      return false;
   double q = 0.6;
   if(height < 1.5 * a5)
      q += 0.05;
   if(MicroCvdRatio(10) * dir > 0.05)
      q += 0.1;
   return MakeSignal(s, ST_SC_ORB, dir, entry, sl, InpScalpRR, q, "range di apertura " + name + ": rottura e retest");
  }

bool S_ScOrb(TSignal &s)
  {
   if(OrbCheck(s, g_sess.orLon, g_ctx.lonOpen, "Londra"))
      return true;
   return OrbCheck(s, g_sess.orNy, g_ctx.nyOpen, "New York");
  }

//+------------------------------------------------------------------+
//| INTRADAY                                                         |
//+------------------------------------------------------------------+
//--- IN-PULLBACK: trend H1, pullback sull'EMA20 M15 con RSI scarico, ripartenza M5
bool S_InPullback(TSignal &s)
  {
   int dir = TrendDir(g_h1);
   if(dir == 0 || AdxOf(g_h1) < 18.0 || EmaDir(g_m15) != dir)
      return false;
   double a15 = g_ctx.atrM15;
   if(a15 <= 0.0)
      return false;
   double e20 = Ind(g_m15.ema20, 0), e50 = Ind(g_m15.ema50, 0);
   double ext = (dir > 0) ? LowestL(g_m15, 0, 4) : HighestH(g_m15, 0, 4);
   if(dir > 0 && (ext > e20 + 0.2 * a15 || ext < e50 - 0.3 * a15))
      return false;
   if(dir < 0 && (ext < e20 - 0.2 * a15 || ext > e50 + 0.3 * a15))
      return false;
   if(dir > 0)
     {
      double rmin = MinInd(g_m15.rsi, 0, 4);
      if(rmin < 35.0 || rmin > 52.0)
         return false;
     }
   else
     {
      double rmax = MaxInd(g_m15.rsi, 0, 4);
      if(rmax > 65.0 || rmax < 48.0)
         return false;
     }
   double c5 = BarC(g_m5, 0);
   if(dir > 0 && !(c5 > HighestH(g_m5, 1, 3) && c5 > Ind(g_m5.ema20, 0) && c5 > BarO(g_m5, 0)))
      return false;
   if(dir < 0 && !(c5 < LowestL(g_m5, 1, 3) && c5 < Ind(g_m5.ema20, 0) && c5 < BarO(g_m5, 0)))
      return false;
   double ext5 = (dir > 0) ? LowestL(g_m5, 0, 12) : HighestH(g_m5, 0, 12);
   double ref = (dir > 0) ? MathMin(ext, ext5) : MathMax(ext, ext5);
   double entry = EntryPx(dir);
   double sl = StopFrom(ref, dir, 0.2 * a15);
   if(!FitStop(entry, dir, sl, 0.6 * a15, 2.0 * a15))
      return false;
   double q = 0.6;
   if(AdxOf(g_h1) > 25.0)
      q += 0.1;
   if(TrendDir(g_h4) == dir)
      q += 0.1;
   if(RvolBar(g_m5, 0) >= 1.1)
      q += 0.05;
   return MakeSignal(s, ST_IN_PULLBACK, dir, entry, sl, InpIntraRR, q, "trend H1, pullback su EMA20 M15");
  }

//--- IN-SWEEP: barra M15 che spazza PDH/PDL/Asia/Londra/settimana e rientra
datetime g_lastInSweepBar = 0;

bool S_InSweep(TSignal &s)
  {
   double a15 = g_ctx.atrM15;
   if(a15 <= 0.0 || BarT(g_m15, 0) == g_lastInSweepBar)
      return false;
   double lv[8];
   string nm[8];
   int n = 0;
   if(g_d1.n >= 2)
     {
      lv[n] = BarH(g_d1, 0);
      nm[n] = "PDH";
      n++;
      lv[n] = BarL(g_d1, 0);
      nm[n] = "PDL";
      n++;
     }
   if(g_pwH > 0.0)
     {
      lv[n] = g_pwH;
      nm[n] = "PWH";
      n++;
      lv[n] = g_pwL;
      nm[n] = "PWL";
      n++;
     }
   if(g_sess.asiaDone)
     {
      lv[n] = g_sess.asiaH;
      nm[n] = "Asia H";
      n++;
      lv[n] = g_sess.asiaL;
      nm[n] = "Asia L";
      n++;
     }
   if(g_sess.lonDone)
     {
      lv[n] = g_sess.lonH;
      nm[n] = "Londra H";
      n++;
      lv[n] = g_sess.lonL;
      nm[n] = "Londra L";
      n++;
     }
   double hb = BarH(g_m15, 0), lb = BarL(g_m15, 0), cb = BarC(g_m15, 0);
   double c5 = BarC(g_m5, 0), o5 = BarO(g_m5, 0);
   bool found = false;
   double bestQ = 0.0;
   TSignal tmp;
   for(int i = 0; i < n; i++)
     {
      double L = lv[i];
      if(L <= 0.0)
         continue;
      for(int dir = -1; dir <= 1; dir += 2)
        {
         double ext = (dir > 0) ? lb : hb;
         bool swept = (dir > 0) ? (ext < L - 0.15 * a15 && ext > L - 1.5 * a15) : (ext > L + 0.15 * a15 && ext < L + 1.5 * a15);
         bool reclaim = (dir > 0) ? (cb > L) : (cb < L);
         bool approach = (dir > 0) ? (BarC(g_m15, 1) > L) : (BarC(g_m15, 1) < L);
         bool trig = (dir > 0) ? (c5 > L && c5 > o5) : (c5 < L && c5 < o5);
         if(!swept || !reclaim || !approach || !trig)
            continue;
         double wick = WickRatio(g_m15, 0, dir);
         double rv = RvolBar(g_m15, 0);
         if(wick < 0.5 && rv < 1.3)
            continue;
         double entry = EntryPx(dir);
         double sl = StopFrom(ext, dir, 0.15 * a15);
         if(!FitStop(entry, dir, sl, 0.5 * a15, 2.2 * a15))
            continue;
         double q = 0.55;
         if(wick >= 0.5)
            q += 0.1;
         if(rv >= 1.3)
            q += 0.1;
         if(nm[i] == "PDH" || nm[i] == "PDL" || nm[i] == "PWH" || nm[i] == "PWL")
            q += 0.05;
         //--- divergenza del delta: prezzo su nuovo estremo ma CVD a favore
         if(MicroCvdRatio(60) * dir > 0.05)
            q += 0.1;
         if(q > bestQ && MakeSignal(tmp, ST_IN_SWEEP, dir, entry, sl, InpIntraRR, q, "stop run M15 su " + nm[i]))
           {
            bestQ = q;
            SigCopy(s, tmp);
            found = true;
           }
        }
     }
   if(found)
      g_lastInSweepBar = BarT(g_m15, 0);
   return found;
  }

//--- IN-BREAKOUT: rottura con volume di un livello chiave su M15, ingresso al retest su M5
struct BrkState
  {
   double            lvl;
   int               dir;
   datetime          brkT;
   bool              used;
   double            rvol;
   string            name;
  };
BrkState g_brk[8];
int      g_brkN = 0;
int      g_brkDay = 0;

void BrkRegister(double L, string name)
  {
   if(L <= 0.0)
      return;
   for(int i = 0; i < g_brkN; i++)
      if(MathAbs(g_brk[i].lvl - L) < g_tick * 0.5)
         return;
   double a15 = g_ctx.atrM15;
   double c = BarC(g_m15, 0), cp = ClosePos(g_m15, 0), rv = RvolBar(g_m15, 0);
   int dir = 0;
   if(c > L + 0.1 * a15 && BarO(g_m15, 0) < L + 0.1 * a15 && cp >= 0.7 && rv >= 1.3)
      dir = 1;
   if(c < L - 0.1 * a15 && BarO(g_m15, 0) > L - 0.1 * a15 && cp <= 0.3 && rv >= 1.3)
      dir = -1;
   if(dir == 0 || g_brkN >= 8)
      return;
   g_brk[g_brkN].lvl = L;
   g_brk[g_brkN].dir = dir;
   g_brk[g_brkN].brkT = BarT(g_m15, 0);
   g_brk[g_brkN].used = false;
   g_brk[g_brkN].rvol = rv;
   g_brk[g_brkN].name = name;
   g_brkN++;
  }

//--- chiamata a ogni nuova barra M15
void BrkOnM15()
  {
   int dk = DayKey(g_ctx.nowUtc);
   if(dk != g_brkDay)
     {
      g_brkDay = dk;
      g_brkN = 0;
     }
   if(g_ctx.atrM15 <= 0.0)
      return;
   if(g_sess.asiaDone && g_ctx.hUtc < 17.0)
     {
      BrkRegister(g_sess.asiaH, "Asia H");
      BrkRegister(g_sess.asiaL, "Asia L");
     }
   if(g_sess.lonDone)
     {
      BrkRegister(g_sess.lonH, "Londra H");
      BrkRegister(g_sess.lonL, "Londra L");
     }
   if(g_d1.n >= 2)
     {
      BrkRegister(BarH(g_d1, 0), "PDH");
      BrkRegister(BarL(g_d1, 0), "PDL");
     }
  }

bool S_InBreakout(TSignal &s)
  {
   double a15 = g_ctx.atrM15;
   if(a15 <= 0.0)
      return false;
   double l5 = BarL(g_m5, 0), h5 = BarH(g_m5, 0), c5 = BarC(g_m5, 0), o5 = BarO(g_m5, 0);
   for(int i = 0; i < g_brkN; i++)
     {
      if(g_brk[i].used)
         continue;
      if(BarT(g_m5, 0) - g_brk[i].brkT > 2 * 3600)
        {
         g_brk[i].used = true;
         continue;
        }
      if(BarT(g_m5, 0) <= g_brk[i].brkT + 15 * 60)
         continue;
      int dir = g_brk[i].dir;
      double L = g_brk[i].lvl;
      if((L - c5) * dir > 0.3 * a15)
        {
         g_brk[i].used = true;
         continue;
        }
      bool touched = (dir > 0) ? (l5 <= L + 0.15 * a15) : (h5 >= L - 0.15 * a15);
      bool held = (dir > 0) ? (c5 > L && c5 > o5) : (c5 < L && c5 < o5);
      if(!touched || !held)
         continue;
      g_brk[i].used = true;
      double entry = EntryPx(dir);
      double ref = (dir > 0) ? MathMin(l5, L) : MathMax(h5, L);
      double sl = StopFrom(ref, dir, 0.25 * a15);
      if(!FitStop(entry, dir, sl, 0.5 * a15, 1.8 * a15))
         continue;
      double q = 0.6;
      if(TrendDir(g_h1) == dir)
         q += 0.1;
      if(g_brk[i].rvol >= 1.8)
         q += 0.1;
      return MakeSignal(s, ST_IN_BREAKOUT, dir, entry, sl, InpIntraRR, q, "breakout " + g_brk[i].name + " con volume e retest");
     }
   return false;
  }

//--- IN-VALUE80: apertura fuori dalla value area di ieri, rientro con 2 chiusure M15 -> lato opposto
int      g_vaDay = 0;
int      g_vaOpenSide = 0;
int      g_vaInside = 0;
bool     g_vaUsed = false;
bool     g_vaNewM15 = false;

void ValueOnM15()
  {
   g_vaNewM15 = true;
   datetime anchor = iTime(g_sym, PERIOD_D1, 0);
   int dk = (int)(anchor / 86400);
   if(dk != g_vaDay)
     {
      g_vaDay = dk;
      g_vaOpenSide = 0;
      g_vaInside = 0;
      g_vaUsed = false;
      if(PrevProfileOk())
        {
         double op = BarO(g_m15, 0);
         if(op > PrevVAH())
            g_vaOpenSide = 1;
         else
            if(op < PrevVAL())
               g_vaOpenSide = -1;
        }
      return;
     }
   if(g_vaOpenSide == 0 || g_vaUsed)
      return;
   double c = BarC(g_m15, 0);
   bool inside = (c < PrevVAH() && c > PrevVAL());
   g_vaInside = inside ? g_vaInside + 1 : 0;
  }

bool S_InValue(TSignal &s)
  {
   if(!g_vaNewM15)
      return false;
   g_vaNewM15 = false;
   if(g_vaOpenSide == 0 || g_vaUsed || g_vaInside < 2 || !PrevProfileOk())
      return false;
   g_vaUsed = true;
   int dir = -g_vaOpenSide;
   double a15 = g_ctx.atrM15;
   double entry = EntryPx(dir);
   double edge = (dir > 0) ? PrevVAL() : PrevVAH();
   double ext = (dir > 0) ? LowestL(g_m15, 0, 3) : HighestH(g_m15, 0, 3);
   double ref = (dir > 0) ? MathMin(ext, edge - 0.3 * a15) : MathMax(ext, edge + 0.3 * a15);
   double sl = StopFrom(ref, dir, 0.1 * a15);
   if(!FitStop(entry, dir, sl, 0.5 * a15, 2.0 * a15))
      return false;
   double tp = (dir > 0) ? PrevVAH() : PrevVAL();
   double q = 0.6;
   if(RvolBar(g_m15, 0) >= 1.0)
      q += 0.05;
   if(MicroCvdRatio(60) * dir > 0.05)
      q += 0.1;
   return MakeSignalTP(s, ST_IN_VALUE, dir, entry, sl, tp, q, "regola 80%: rientro nella value area di ieri");
  }

//--- IN-NEWS: continuation dopo la news SOLO nella direzione della vista pre-news
bool S_InNews(TSignal &s)
  {
   datetime nowU = g_ctx.nowUtc;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier > 2 || !g_news[i].viewTaken || g_news[i].viewDir == 0 || g_news[i].eUsed)
         continue;
      double mins = (double)(nowU - g_news[i].utc) / 60.0;
      if(mins < 5.0 || mins > 90.0)
         continue;
      int dir = g_news[i].viewDir;
      double c = BarC(g_m5, 0);
      double imp = (g_news[i].extreme - g_news[i].preClose) * dir;
      if((c - g_news[i].preClose) * dir < 0.0)
        {
         g_news[i].eUsed = true;   // il mercato ha smentito la vista
         continue;
        }
      if(imp < 1.5 * g_news[i].preAtr)
         continue;
      double barExt = (dir > 0) ? BarL(g_m5, 0) : BarH(g_m5, 0);
      double retr = (g_news[i].extreme - barExt) * dir / imp;
      if(retr < 0.30 || retr > 0.62)
         continue;
      if(!((dir > 0 && c > BarO(g_m5, 0)) || (dir < 0 && c < BarO(g_m5, 0))))
         continue;
      g_news[i].eUsed = true;
      double entry = EntryPx(dir);
      double sl = StopFrom(barExt, dir, 0.25 * g_ctx.atrM5);
      if(!FitStop(entry, dir, sl, 0.5 * g_ctx.atrM15, 2.5 * g_ctx.atrM15))
         continue;
      double q = 0.65;
      if(g_news[i].preConf >= 0.6)
         q += 0.1;
      double tp = g_news[i].extreme + dir * 0.5 * imp;
      if(MakeSignalTP(s, ST_IN_NEWS, dir, entry, sl, tp, q, "continuation dopo " + g_news[i].title + " coerente con la vista"))
         return true;
      return MakeSignal(s, ST_IN_NEWS, dir, entry, sl, InpMinRR, q, "continuation dopo " + g_news[i].title + " coerente con la vista");
     }
   return false;
  }

//--- IN-RANGE: in laterale, rifiuto a VWAP +-2 sigma con RSI estremo, target VWAP
bool S_InRange(TSignal &s)
  {
   if(g_regime != REG_RANGE && g_regime != REG_QUIET)
      return false;
   if(AdxOf(g_h1) > 20.0)
      return false;
   double vw = g_ctx.vwap, sg = g_ctx.vwSig;
   if(vw <= 0.0 || sg <= 0.0)
      return false;
   double l = BarL(g_m5, 0), h = BarH(g_m5, 0), c = BarC(g_m5, 0);
   int dir = 0;
   if(l <= vw - 2.0 * sg && c > vw - 2.0 * sg && WickRatio(g_m5, 0, 1) >= 0.5 && MinInd(g_m5.rsi, 0, 3) <= 30.0)
      dir = 1;
   if(h >= vw + 2.0 * sg && c < vw + 2.0 * sg && WickRatio(g_m5, 0, -1) >= 0.5 && MaxInd(g_m5.rsi, 0, 3) >= 70.0)
      dir = -1;
   if(dir == 0)
      return false;
   double entry = EntryPx(dir);
   double ext = (dir > 0) ? l : h;
   double sl = StopFrom(ext, dir, 0.3 * g_ctx.atrM5);
   if(!FitStop(entry, dir, sl, 0.4 * g_ctx.atrM15, 1.5 * g_ctx.atrM15))
      return false;
   double q = 0.55;
   if(IsAbsorption(g_m5, 0) || RvolBar(g_m5, 0) >= 1.5)
      q += 0.1;
   if(MicroCvdRatio(10) * dir > 0.05)
      q += 0.1;
   return MakeSignalTP(s, ST_IN_RANGE, dir, entry, sl, vw, q, "laterale: rifiuto a VWAP 2 sigma, target VWAP");
  }

//+------------------------------------------------------------------+
//| SWING                                                            |
//+------------------------------------------------------------------+
//--- SW-TREND: trend H4 (D1 non contrario), pullback sull'EMA20 H4, ripartenza H1
bool S_SwTrend(TSignal &s)
  {
   int dir = TrendDir(g_h4);
   if(dir == 0 || AdxOf(g_h4) < 20.0)
      return false;
   int td = EmaDir(g_d1);
   if(td != 0 && td != dir)
      return false;
   double a1 = g_ctx.atrH1, a4 = g_ctx.atrH4;
   if(a1 <= 0.0 || a4 <= 0.0)
      return false;
   double e20 = Ind(g_h4.ema20, 0), e50 = Ind(g_h4.ema50, 0);
   double ext = (dir > 0) ? LowestL(g_h1, 0, 6) : HighestH(g_h1, 0, 6);
   if(dir > 0 && (ext > e20 + 0.3 * a4 || ext < e50 - 0.3 * a4))
      return false;
   if(dir < 0 && (ext < e20 - 0.3 * a4 || ext > e50 + 0.3 * a4))
      return false;
   if(dir > 0)
     {
      double rmin = MinInd(g_h1.rsi, 0, 6);
      if(rmin < 35.0 || rmin > 52.0)
         return false;
     }
   else
     {
      double rmax = MaxInd(g_h1.rsi, 0, 6);
      if(rmax > 65.0 || rmax < 48.0)
         return false;
     }
   double c = BarC(g_h1, 0);
   if(dir > 0 && !(c > HighestH(g_h1, 1, 3) && c > BarO(g_h1, 0)))
      return false;
   if(dir < 0 && !(c < LowestL(g_h1, 1, 3) && c < BarO(g_h1, 0)))
      return false;
   double entry = EntryPx(dir);
   double sl = StopFrom(ext, dir, 0.25 * a1);
   if(!FitStop(entry, dir, sl, 1.0 * a1, 1.2 * a4))
      return false;
   double q = 0.6;
   if(AdxOf(g_h4) > 25.0)
      q += 0.1;
   if(RvolBar(g_h1, 0) >= 1.1)
      q += 0.05;
   if(td == dir)
      q += 0.05;
   return MakeSignal(s, ST_SW_TREND, dir, entry, sl, InpSwingRR, q, "trend H4, pullback su EMA20 H4");
  }

//--- SW-WYCKOFF: range H4, spring (falsa rottura del minimo) o upthrust con volume
datetime g_lastWyckBar = 0;

bool S_SwWyckoff(TSignal &s)
  {
   if(g_h4.n < 40 || BarT(g_h1, 0) == g_lastWyckBar)
      return false;
   double a1 = g_ctx.atrH1, a4 = g_ctx.atrH4;
   if(a1 <= 0.0 || a4 <= 0.0)
      return false;
   double rh = HighestH(g_h4, 1, 30), rl = LowestL(g_h4, 1, 30);
   double height = rh - rl;
   if(height < 2.0 * a4 || height > 7.0 * a4 || AdxOf(g_h4) > 22.0)
      return false;
   double l = BarL(g_h1, 0), h = BarH(g_h1, 0), c = BarC(g_h1, 0);
   double cp = ClosePos(g_h1, 0), rv = RvolBar(g_h1, 0);
   int dir = 0;
   if(l < rl - 0.1 * a4 && l > rl - 1.0 * a4 && c > rl && cp >= 0.5 && rv >= 1.3)
      dir = 1;
   if(h > rh + 0.1 * a4 && h < rh + 1.0 * a4 && c < rh && cp <= 0.5 && rv >= 1.3)
      dir = -1;
   if(dir == 0)
      return false;
   g_lastWyckBar = BarT(g_h1, 0);
   double entry = EntryPx(dir);
   double ext = (dir > 0) ? l : h;
   double sl = StopFrom(ext, dir, 0.2 * a1);
   if(!FitStop(entry, dir, sl, 0.8 * a1, 1.5 * a4))
      return false;
   double tp = (dir > 0) ? rh - 0.1 * a4 : rl + 0.1 * a4;
   double q = 0.6;
   if(rv >= 1.8)
      q += 0.1;
   if(MicroCvdRatio(120) * dir > 0.05)
      q += 0.1;
   string nm = (dir > 0) ? "spring" : "upthrust";
   return MakeSignalTP(s, ST_SW_WYCKOFF, dir, entry, sl, tp, q, "Wyckoff " + nm + " nel range H4");
  }
//+------------------------------------------------------------------+
//| Stato: statistiche per strategia, metadati posizioni, rischio    |
//+------------------------------------------------------------------+
struct StratStat
  {
   int               n;
   int               wins;
   int               losses;
   double            sumR;
   double            sumR2;
   double            grossWinR;
   double            grossLossR;
   double            net;
   double            last[10];
   int               lastN;
   int               lastHead;
   datetime          benchUntil;

   void              Reset()
     {
      n = 0;
      wins = 0;
      losses = 0;
      sumR = 0.0;
      sumR2 = 0.0;
      grossWinR = 0.0;
      grossLossR = 0.0;
      net = 0.0;
      for(int i = 0; i < 10; i++)
         last[i] = 0.0;
      lastN = 0;
      lastHead = 0;
      benchUntil = 0;
     }

   void              Add(double r, double money)
     {
      n++;
      sumR += r;
      sumR2 += r * r;
      net += money;
      if(r > 0.05)
        {
         wins++;
         grossWinR += r;
        }
      else
         if(r < -0.05)
           {
            losses++;
            grossLossR += -r;
           }
      last[lastHead] = r;
      lastHead = (lastHead + 1) % 10;
      if(lastN < 10)
         lastN++;
     }

   double            Expectancy() const { return (n > 0) ? sumR / n : 0.0; }
   double            WinRate() const { return (n > 0) ? 100.0 * wins / n : 0.0; }
   double            ProfitFactor() const { return (grossLossR > 0.0) ? grossWinR / grossLossR : ((grossWinR > 0.0) ? 99.0 : 0.0); }

   //--- perdite negli ultimi k trade
   int               RecentLosses(int k) const
     {
      int c = 0;
      for(int j = 0; j < k && j < lastN; j++)
        {
         int idx = (lastHead - 1 - j + 20) % 10;
         if(last[idx] < -0.05)
            c++;
        }
      return c;
     }

   double            RecentSum(int k) const
     {
      double s = 0.0;
      for(int j = 0; j < k && j < lastN; j++)
        {
         int idx = (lastHead - 1 - j + 20) % 10;
         s += last[idx];
        }
      return s;
     }
  };

StratStat g_ss[NSTRAT];     // statistiche usate dal comitato (si azzerano in panchina)
StratStat g_rep[NSTRAT];    // statistiche complete per il report
StratStat g_es[3];
StratStat g_all;

//+------------------------------------------------------------------+
//| Metadati di ogni posizione/ordine aperto dall'EA                 |
//+------------------------------------------------------------------+
struct PosMeta
  {
   long              id;
   int               strat;
   int               engine;
   int               dir;
   int               tranche;
   int               idea;
   double            entry;
   double            sl0;
   double            tp;
   double            riskPx;
   double            riskMoney;
   double            lots0;
   double            score;
   double            cushion;
   bool              recovery;
   bool              reentry;
   bool              aplus;
   bool              thirdDone;
   bool              beDone;
   bool              partialDone;
   bool              isPending;
   bool              active;
   datetime          openTime;
   int               expiryMin;
   int               sweepTries;
   double            spreadPx;     // K (1.25): spread pagato all'ingresso
   double            slipPx;       // K (1.25): slittamento all'ingresso (positivo = peggio)
   datetime          deadline;     // 1.27: tempo massimo (UTC) della posizione; 0 = regole del motore
   bool              wkDone;       // 1.27: gia' gestita per il weekend (dimezzata o avvisata)

   void              Reset()
     {
      id = 0;
      strat = 0;
      engine = 0;
      dir = 0;
      tranche = 0;
      idea = 0;
      entry = 0.0;
      sl0 = 0.0;
      tp = 0.0;
      riskPx = 0.0;
      riskMoney = 0.0;
      lots0 = 0.0;
      score = 0.0;
      cushion = 0.0;
      recovery = false;
      reentry = false;
      aplus = false;
      thirdDone = false;
      beDone = false;
      partialDone = false;
      isPending = false;
      active = false;
      openTime = 0;
      expiryMin = 0;
      sweepTries = 0;
      spreadPx = 0.0;
      slipPx = 0.0;
      deadline = 0;
      wkDone = false;
     }
  };
PosMeta g_meta[MAX_META];
int     g_ideaSeq = 0;
bool    g_needSweep = false;
bool    g_needFlowScan = false;

int MetaFind(long id)
  {
   for(int i = 0; i < MAX_META; i++)
      if(g_meta[i].active && g_meta[i].id == id)
         return i;
   return -1;
  }

int MetaFree()
  {
   for(int i = 0; i < MAX_META; i++)
      if(!g_meta[i].active)
         return i;
   return -1;
  }

void MetaRemove(int i)
  {
   if(i >= 0 && i < MAX_META)
      g_meta[i].Reset();
  }

bool IsOurMagic(long magic) { return (magic > InpMagicBase && magic <= InpMagicBase + 3); }
int  EngineOfMagic(long magic) { return (int)(magic - InpMagicBase - 1); }
long MagicOfEngine(int e) { return InpMagicBase + 1 + e; }

int StratByName(string name)
  {
   for(int i = 1; i < NSTRAT; i++)
      if(g_stratName[i] == name)
         return i;
   return 0;
  }

//+------------------------------------------------------------------+
//| Conteggi del portafoglio                                         |
//+------------------------------------------------------------------+
int    g_cntAll = 0;
int    g_cntOnda = 0;         // 1.27: quante delle posizioni aperte sono ritracciamenti (fuori da slot e coda)
int    g_cntEng[3];
int    g_cntDir[2];        // [0]=buy [1]=sell (posizioni non a pareggio)
double g_openRiskDir[2];   // S (1.25): rischio aperto per verso [0]=buy [1]=sell
double g_openRiskMoney = 0.0;

bool PositionExistsById(long id)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetInteger(POSITION_IDENTIFIER) == id)
         return true;
     }
   return false;
  }

bool OrderExists(long ticket)
  {
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong tk = OrderGetTicket(i);
      if(tk == 0)
         continue;
      if((long)tk == ticket)
         return true;
     }
   return false;
  }

void PortfolioScan()
  {
   g_cntAll = 0;
   g_cntOnda = 0;
   g_cntEng[0] = 0;
   g_cntEng[1] = 0;
   g_cntEng[2] = 0;
   g_cntDir[0] = 0;
   g_cntDir[1] = 0;
   g_openRiskMoney = 0.0;
   g_openRiskDir[0] = 0.0;
   g_openRiskDir[1] = 0.0;
   double vpu = ValuePerPriceUnit();
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym)
         continue;
      long mg = PositionGetInteger(POSITION_MAGIC);
      if(!IsOurMagic(mg))
         continue;
      int e = EngineOfMagic(mg);
      int dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      double op = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      double vol = PositionGetDouble(POSITION_VOLUME);
      g_cntAll++;
      //--- 1.27: i ritracciamenti non hanno slot: non devono nemmeno togliere il posto alle altre strategie del motore
      int pm = MetaFind(PositionGetInteger(POSITION_IDENTIFIER));
      bool ownSlot = (InpOndaOwnSlots && pm >= 0 && IsOnda(g_meta[pm].strat));
      if(e >= 0 && e < 3 && !ownSlot)
         g_cntEng[e]++;
      if(ownSlot)
         g_cntOnda++;
      double riskPx = (sl > 0.0) ? (op - sl) * dir : AtrOf(g_h1);
      if(riskPx > 0.0)
        {
         g_openRiskMoney += riskPx * vol * vpu;
         g_openRiskDir[(dir > 0) ? 0 : 1] += riskPx * vol * vpu;
         g_cntDir[(dir > 0) ? 0 : 1]++;
        }
     }
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong tk = OrderGetTicket(i);
      if(tk == 0)
         continue;
      if(OrderGetString(ORDER_SYMBOL) != g_sym)
         continue;
      long mg = OrderGetInteger(ORDER_MAGIC);
      if(!IsOurMagic(mg))
         continue;
      int e = EngineOfMagic(mg);
      ENUM_ORDER_TYPE ot = (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      int dir = (ot == ORDER_TYPE_BUY_LIMIT || ot == ORDER_TYPE_BUY_STOP) ? 1 : -1;
      double op = OrderGetDouble(ORDER_PRICE_OPEN);
      double sl = OrderGetDouble(ORDER_SL);
      double vol = OrderGetDouble(ORDER_VOLUME_CURRENT);
      g_cntAll++;
      if(e >= 0 && e < 3)
         g_cntEng[e]++;
      double riskPx = (sl > 0.0) ? (op - sl) * dir : 0.0;
      if(riskPx > 0.0)
        {
         g_openRiskMoney += riskPx * vol * vpu;
         g_openRiskDir[(dir > 0) ? 0 : 1] += riskPx * vol * vpu;
         g_cntDir[(dir > 0) ? 0 : 1]++;
        }
     }
  }

int MaxPositionsEff() { return g_netting ? 1 : InpMaxPositions; }

int EngineMaxPos(int e)
  {
   if(g_netting)
      return 1;
   if(e == ENG_SCALP)
      return 1;
   return 2;
  }

//+------------------------------------------------------------------+
//| Stato del rischio del conto                                      |
//+------------------------------------------------------------------+
double   g_dayStartEq = 0.0;
double   g_weekStartEq = 0.0;
double   g_weekStartBal = 0.0;
double   g_peakEq = 0.0;
datetime g_dayAnchor = 0;
datetime g_weekAnchor = 0;
bool     g_dayHalt = false;
bool     g_weekHalt = false;
bool     g_ddHalt = false;
int      g_tradesToday[3];
int      g_lossesInRowToday = 0;
int      g_lossStreak = 0;
bool     g_recoveryArmed = false;
datetime g_recoveryArmedT = 0;
datetime g_recoveryCooldownUntil = 0;
//--- rientro dopo pareggio (1.17), uno per motore
bool     g_reArmed[3];
int      g_reDir[3];
datetime g_reT[3];

string GvName(string key) { return "XC." + IntegerToString(g_login) + "." + IntegerToString(InpMagicBase) + "." + key; }

void GvSave()
  {
   GlobalVariableSet(GvName("dayEq"), g_dayStartEq);
   GlobalVariableSet(GvName("dayAnchor"), (double)g_dayAnchor);
   GlobalVariableSet(GvName("weekEq"), g_weekStartEq);
   GlobalVariableSet(GvName("weekBal"), g_weekStartBal);
   GlobalVariableSet(GvName("weekAnchor"), (double)g_weekAnchor);
   GlobalVariableSet(GvName("peak"), g_peakEq);
   GlobalVariableSet(GvName("halt"), g_ddHalt ? 1.0 : 0.0);
   GlobalVariableSet(GvName("dayHalt"), g_dayHalt ? 1.0 : 0.0);
   GlobalVariableSet(GvName("weekHalt"), g_weekHalt ? 1.0 : 0.0);
  }

double GvGet(string key, double def)
  {
   string n = GvName(key);
   if(!GlobalVariableCheck(n))
      return def;
   return GlobalVariableGet(n);
  }

//+------------------------------------------------------------------+
//| Capitale virtuale: il bot si comporta come se il conto fosse di  |
//| InpVirtualCapital (+ i profitti/perdite fatti da quando parte)   |
//+------------------------------------------------------------------+
double g_vStartEq = 0.0;
double g_vStartBal = 0.0;

//--- ora del server affidabile anche a mercato chiuso (TimeCurrent si ferma all'ultimo tick del venerdi')
datetime ServerNow()
  {
   datetime t = TimeTradeServer();
   if(t < TimeCurrent())
      t = TimeCurrent();
   return t;
  }

void VirtualInit()
  {
   if(InpVirtualCapital <= 0.0)
      return;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   bool ok = (GvGet("vCap", -1.0) == InpVirtualCapital && GvGet("vStartBal", 0.0) > 0.0);
   if(ok)
     {
      g_vStartEq = GvGet("vStartEq", eq);
      g_vStartBal = GvGet("vStartBal", bal);
      //--- valore impossibile (lo stop al 50% lo avrebbe fermato prima): dati vecchi o sbagliati -> riparto
      double v = InpVirtualCapital + (bal - g_vStartBal);
      if(v < 0.3 * InpVirtualCapital || v > 50.0 * InpVirtualCapital)
        {
         ok = false;
         GlobalVariableDel(GvName("capMode"));
        }
     }
   if(!ok)
     {
      g_vStartEq = eq;
      g_vStartBal = bal;
      GlobalVariableSet(GvName("vCap"), InpVirtualCapital);
      GlobalVariableSet(GvName("vStartEq"), g_vStartEq);
      GlobalVariableSet(GvName("vStartBal"), g_vStartBal);
     }
  }

double AccEquity()
  {
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   if(InpVirtualCapital <= 0.0)
      return eq;
   return InpVirtualCapital + (eq - g_vStartBal);
  }

double AccBalance()
  {
   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   if(InpVirtualCapital <= 0.0)
      return bal;
   return InpVirtualCapital + (bal - g_vStartBal);
  }

#define STATE_VER 115

void RiskStateInit()
  {
   if(!g_isTester && GvGet("stateVer", 0.0) < STATE_VER)
     {
      GlobalVariableDel(GvName("vCap"));
      GlobalVariableDel(GvName("capMode"));
      GlobalVariableDel(GvName("peak"));
      GlobalVariableSet(GvName("flowTo"), (double)ServerNow());
      GlobalVariableSet(GvName("stateVer"), STATE_VER);
      Logf("Stato del rischio azzerato per la versione " + g_version + " (riferimenti ripartono da adesso)");
     }
   VirtualInit();
   double eq = AccEquity();
   double bal = AccBalance();
   datetime dA = iTime(g_sym, PERIOD_D1, 0);
   datetime wA = iTime(g_sym, PERIOD_W1, 0);
   g_peakEq = MathMax(eq, GvGet("peak", eq));
   g_ddHalt = (GvGet("halt", 0.0) > 0.5);
   //--- capitale virtuale attivato/cambiato/tolto: i vecchi riferimenti (picco, inizio giorno/settimana)
   //--- erano su un'altra base e farebbero scattare stop falsi -> riparto da qui
   bool capChanged = (GvGet("capMode", -1.0) != InpVirtualCapital);
   if(capChanged)
     {
      g_peakEq = eq;
      GlobalVariableSet(GvName("capMode"), InpVirtualCapital);
      GlobalVariableDel(GvName("dayAnchor"));
      GlobalVariableDel(GvName("weekAnchor"));
      Logf("Base del capitale cambiata: picco e riferimenti giornalieri/settimanali ripartono da " + Money(eq));
     }
   if(InpResetHalt)
     {
      g_ddHalt = false;
      g_peakEq = eq;
     }
   if((datetime)GvGet("dayAnchor", 0.0) == dA)
     {
      g_dayAnchor = dA;
      g_dayStartEq = GvGet("dayEq", eq);
      g_dayHalt = (GvGet("dayHalt", 0.0) > 0.5);
     }
   else
     {
      g_dayAnchor = dA;
      g_dayStartEq = eq;
      g_dayHalt = false;
     }
   if((datetime)GvGet("weekAnchor", 0.0) == wA)
     {
      g_weekAnchor = wA;
      g_weekStartEq = GvGet("weekEq", eq);
      g_weekStartBal = GvGet("weekBal", bal);
      g_weekHalt = (GvGet("weekHalt", 0.0) > 0.5);
     }
   else
     {
      g_weekAnchor = wA;
      g_weekStartEq = eq;
      g_weekStartBal = bal;
      g_weekHalt = false;
     }
   g_tradesToday[0] = 0;
   g_tradesToday[1] = 0;
   g_tradesToday[2] = 0;
   GvSave();
  }
//--- C3 (1.20): spinta agli stop run quando Asia e' stretta
bool TightAsiaBonus(const TSignal &s)
  {
   if(!InpC3TightAsia)
      return false;
   if(s.strat != ST_SC_SWEEP && s.strat != ST_IN_SWEEP)
      return false;
   return TightAsia();
  }

//+------------------------------------------------------------------+
//| Comitato: ogni desk vota 0..1 (e puo' mettere il veto),          |
//| poi avvocato del diavolo, quorum e punteggio pesato per motore   |
//+------------------------------------------------------------------+
double DeskWeight(int engine, int desk)
  {
   if(engine == ENG_SCALP)
     {
      switch(desk)
        {
         case D_STRAT:   return 0.15;
         case D_TREND:   return 0.08;
         case D_VOLUME:  return 0.16;
         case D_LIQ:     return 0.10;
         case D_MACRO:   return 0.08;
         case D_NEWS:    return 0.05;
         case D_SESSION: return 0.09;
         case D_COST:    return 0.13;
         case D_STATS:   return 0.06;
         case D_CONTEXT: return 0.10;
        }
      return 0.0;
     }
   if(engine == ENG_INTRA)
     {
      switch(desk)
        {
         case D_STRAT:   return 0.16;
         case D_TREND:   return 0.10;
         case D_VOLUME:  return 0.12;
         case D_LIQ:     return 0.10;
         case D_MACRO:   return 0.14;
         case D_NEWS:    return 0.04;
         case D_SESSION: return 0.05;
         case D_COST:    return 0.07;
         case D_STATS:   return 0.08;
         case D_CONTEXT: return 0.14;
        }
      return 0.0;
     }
   switch(desk)
     {
      case D_STRAT:   return 0.14;
      case D_TREND:   return 0.10;
      case D_VOLUME:  return 0.08;
      case D_LIQ:     return 0.08;
      case D_MACRO:   return 0.20;
      case D_NEWS:    return 0.03;
      case D_SESSION: return 0.02;
      case D_COST:    return 0.03;
      case D_STATS:   return 0.10;
      case D_CONTEXT: return 0.22;
     }
   return 0.0;
  }

double MinScoreFor(int engine)
  {
   if(engine == ENG_SCALP)
      return InpMinScoreScalp;
   if(engine == ENG_INTRA)
      return InpMinScoreIntra;
   return InpMinScoreSwing;
  }

//--- OF1 (1.25): prezzo M1 a un orario UTC (apertura della prima barra M1 da quell'orario in poi)
double M1PriceAtUtc(datetime tUtc)
  {
   int lim = MathMin(g_m1.n, 240);
   for(int sh = 0; sh < lim; sh++)
     {
      datetime t = ToUTC(BarT(g_m1, sh));
      if(t <= 0)
         return 0.0;
      if(t < tUtc)
        {
         if(sh == 0)
            return 0.0;
         if(ToUTC(BarT(g_m1, sh - 1)) > tUtc + 300)
            return 0.0;                      // buco nei dati: meglio non decidere
         return BarO(g_m1, sh - 1);
        }
     }
   return 0.0;
  }

//--- ora UTC del fixing LBMA del mattino (10:30 di Londra) nel giorno di 'utc'
datetime FixAmUtc(datetime utc)
  {
   datetime day = utc - (utc % 86400);
   return day + (IsUKDST(utc) ? 9 * 3600 + 1800 : 10 * 3600 + 1800);
  }

//--- OF1 (1.25): nei 15 minuti dopo il fixing delle 10:30 il movimento dei 15 minuti prima si gira
//    (M1 del demo 2022-2026: fade +1,2/+2,2 bp con movimento medio/grande in tutti e 4 i periodi; t -4,4,
//     unico quarto d'ora su 41 della giornata di Londra con questo comportamento)
bool FixChase(const TSignal &s, string &why)
  {
   if(!InpOF1FixNoChase || s.engine == ENG_SWING)
      return false;
   datetime now = g_ctx.nowUtc;
   datetime fx = FixAmUtc(now);
   if(now < fx || now >= fx + 900)
      return false;
   double a = M1PriceAtUtc(fx - 900);
   double b = M1PriceAtUtc(fx);
   if(a <= 0.0 || b <= 0.0)
      return false;
   double mv = (b / a - 1.0) * 10000.0;
   if(MathAbs(mv) < InpOF1MinBp || mv * s.dir <= 0.0)
      return false;
   why = "OF1 fixing di Londra: movimento 10:15-10:30 di " + DoubleToString(mv, 1) + " bp, nei 15 minuti dopo di solito si gira";
   return true;
  }

void Veto(TSignal &s, string why)
  {
   if(!s.veto)
     {
      s.veto = true;
      s.vetoWhy = why;
     }
   else
      if(StringLen(s.vetoWhy) < 120)
         s.vetoWhy += "; " + why;
  }

//+------------------------------------------------------------------+
//| MENO REGOLE (1.25)                                               |
//| - obiezioni obbligatorie (rischio, news, costi, prove vere) e    |
//|   obiezioni secondarie (trend, livelli, macro, contesto,         |
//|   avvocato del diavolo: mai provate contro il caso)              |
//| - conferme forti (7/8 desk, punteggio alto) scavalcano fino a 2  |
//|   obiezioni secondarie, con rischio ridotto                      |
//| - idee fantasma: ogni buona idea, presa o no, viene seguita fino |
//|   a stop/target; per ogni obiezione il bot confronta le idee con |
//|   e senza. Provata (fa perdere) -> blocca da sola; inutile ->    |
//|   non conta piu'. Stessa regola degli studi: 3 periodi su 4.     |
//+------------------------------------------------------------------+
#define NOBJ        16
#define NPER        4
#define OB_TREND2   0
#define OB_LEVEL    1
#define OB_MACROV   2
#define OB_CTXV     3
#define OB_RSIX     4
#define OB_RSIDIV   5
#define OB_LVL1R    6
#define OB_MACRO    7
#define OB_CTX      8
#define OB_EXH      9
#define OB_RANGE    10
#define OB_DELTA    11
#define OB_SESS     12
#define OB_LOST2    13
#define OB_VOLAT    14
#define OB_PRENEWS  15
#define OBS_TEST    0
#define OBS_USEFUL  1
#define OBS_USELESS 2
#define MAX_GHOST   48

string g_obName[NOBJ] = {"contro il trend su due timeframe", "livello forte vicino", "macro contraria forte", "contesto HTF contrario forte",
                         "RSI estremo", "divergenza RSI", "livello prima di 1R", "macro contraria", "contesto HTF contrario", "movimento esausto",
                         "prezzo agli estremi del range", "delta contrario", "sessione debole", "ultime 2 perse", "mercato volatile",
                         "vista pre-news contraria"};
double g_obN[NOBJ * NPER];      // idee fantasma chiuse CON l'obiezione, per periodo (2022, 2023, 2024, 2025-26)
double g_obS[NOBJ * NPER];      // somma dei loro R dopo i costi
double g_obQ[NOBJ * NPER];      // somma dei quadrati (per sapere quanto e' sicuro il confronto)
double g_obTotN[NPER];          // tutte le idee fantasma chiuse
double g_obTotS[NPER];
double g_obTotQ[NPER];
int    g_obState[NOBJ];
string g_devilProven = "";      // obiezioni dell'avvocato del diavolo provate (bloccano da sole)
int    g_overCount = 0;         // idee aperte scavalcando obiezioni secondarie (da quando parte l'EA)

struct TGhost
  {
   bool              active;
   int               strat;
   int               dir;
   int               engine;
   int               mask;
   double            entry;
   double            sl;
   double            tp;
   double            risk;
   double            costR;
   datetime          t0;
   datetime          tEnd;
   bool              passed;      // 1.26: il comitato l'avrebbe aperta (conta per il giudizio sulla strategia)
   bool              stratOnly;   // 1.26: conta solo per la strategia, non per le obiezioni
   int               rdFav;       // 1.27: letture del mercato a favore quando e' nata
   int               rdAg;        // 1.27: letture contrarie
  };
TGhost g_gh[MAX_GHOST];

datetime TmExitUtc(datetime openUtc);
void RdEval(TSignal &s);
void RdAdd(int strat, int fav, int ag, datetime t0, double r, bool passed);
void RdRefresh(bool tell);
void RdSave();

//--- 1.26: le idee fantasma servono alle obiezioni (MR) e alle strategie in osservazione (OS)
bool GhostsOn() { return ((InpObjLearn || InpObserveOn) && !g_isOptim); }

void GhostInit()
  {
   for(int i = 0; i < MAX_GHOST; i++)
     {
      g_gh[i].active = false;
      g_gh[i].strat = 0;
      g_gh[i].dir = 0;
      g_gh[i].engine = 0;
      g_gh[i].mask = 0;
      g_gh[i].entry = 0.0;
      g_gh[i].sl = 0.0;
      g_gh[i].tp = 0.0;
      g_gh[i].risk = 0.0;
      g_gh[i].costR = 0.0;
      g_gh[i].t0 = 0;
      g_gh[i].tEnd = 0;
      g_gh[i].passed = false;
      g_gh[i].stratOnly = false;
      g_gh[i].rdFav = 0;
      g_gh[i].rdAg = 0;
     }
  }

void ObjInit()
  {
   for(int i = 0; i < NOBJ * NPER; i++)
     {
      g_obN[i] = 0.0;
      g_obS[i] = 0.0;
      g_obQ[i] = 0.0;
     }
   for(int p = 0; p < NPER; p++)
     {
      g_obTotN[p] = 0.0;
      g_obTotS[p] = 0.0;
      g_obTotQ[p] = 0.0;
     }
   for(int k = 0; k < NOBJ; k++)
      g_obState[k] = OBS_TEST;
  }

int ObPeriod(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   int p = d.year - 2022;
   return (p < 0) ? 0 : ((p > NPER - 1) ? NPER - 1 : p);
  }

//--- casi e somme con e senza l'obiezione k (p < 0 = tutti i periodi)
void ObSums(int k, int p, double &nw, double &sw, double &no, double &so)
  {
   nw = 0.0;
   sw = 0.0;
   double nt = 0.0, st = 0.0;
   for(int q = 0; q < NPER; q++)
     {
      if(p >= 0 && q != p)
         continue;
      nw += g_obN[k * NPER + q];
      sw += g_obS[k * NPER + q];
      nt += g_obTotN[q];
      st += g_obTotS[q];
     }
   no = nt - nw;
   so = st - sw;
  }

//--- errore standard della differenza tra le medie con e senza l'obiezione
double ObSe(int k)
  {
   double nw = 0.0, sw = 0.0, qw = 0.0, nt = 0.0, st = 0.0, qt = 0.0;
   for(int q = 0; q < NPER; q++)
     {
      nw += g_obN[k * NPER + q];
      sw += g_obS[k * NPER + q];
      qw += g_obQ[k * NPER + q];
      nt += g_obTotN[q];
      st += g_obTotS[q];
      qt += g_obTotQ[q];
     }
   double no = nt - nw, so = st - sw, qo = qt - qw;
   if(nw < 2.0 || no < 2.0)
      return 99.0;
   double vw = MathMax((qw - sw * sw / nw) / (nw - 1.0), 0.0);
   double vo = MathMax((qo - so * so / no) / (no - 1.0), 0.0);
   return MathSqrt(vw / nw + vo / no);
  }

//--- giudizio su un'obiezione: provata, inutile o ancora da provare
//    provata: con l'obiezione si perde, almeno 0,10R peggio che senza, lontano dal caso (t <= -2,5: idee vicine nel tempo e controlli ripetuti), 3 periodi su 4
//    inutile: con l'obiezione si guadagna come senza e il danno possibile e' piccolo (diff - 1 errore >= -0,15R)
int ObjEvaluate(int k)
  {
   double nw, sw, no, so;
   ObSums(k, -1, nw, sw, no, so);
   if(nw < InpObjMinN || no < InpObjMinN)
      return OBS_TEST;
   double rw = sw / nw;
   double diff = rw - so / no;
   double se = ObSe(k);
   int perOk = 0, perWorse = 0, perHarmless = 0;
   for(int p = 0; p < NPER; p++)
     {
      double a, b, c, d;
      ObSums(k, p, a, b, c, d);
      if(a < 8.0 || c < 8.0)
         continue;
      perOk++;
      double dp = b / a - d / c;
      if(dp < 0.0)
         perWorse++;
      if(dp >= -0.05)
         perHarmless++;
     }
   //--- con meno di 3 periodi misurabili (conto vero, un anno solo) servono il doppio dei casi
   if(perOk < 3 && nw < 2.0 * InpObjMinN)
      return OBS_TEST;
   if(diff <= -0.10 && rw < 0.0 && diff <= -2.5 * se && (perOk < 3 || perWorse >= 3))
      return OBS_USEFUL;
   if(diff >= -0.02 && rw >= 0.0 && diff - se >= -0.15 && (perOk < 3 || perHarmless >= 3))
      return OBS_USELESS;
   return OBS_TEST;
  }

int ObjState(int k)
  {
   if(!InpObjLearn || k < 0 || k >= NOBJ)
      return OBS_TEST;
   return g_obState[k];
  }

string ObjStateName(int st)
  {
   if(st == OBS_USEFUL)
      return "provata (blocca da sola)";
   if(st == OBS_USELESS)
      return "inutile (non conta)";
   return "da provare";
  }

string ObjNumbers(int k)
  {
   double nw, sw, no, so;
   ObSums(k, -1, nw, sw, no, so);
   if(nw <= 0.0)
      return "nessun caso";
   return DoubleToString(sw / nw, 2) + "R con, " + (no > 0.0 ? DoubleToString(so / no, 2) : "-") + "R senza, " + DoubleToString(nw, 0) + " casi";
  }

void ObjRefresh(bool tell)
  {
   for(int k = 0; k < NOBJ; k++)
     {
      int st = InpObjLearn ? ObjEvaluate(k) : OBS_TEST;
      if(st != g_obState[k] && tell)
        {
         string m = "Meno regole: obiezione '" + g_obName[k] + "' ora " + ObjStateName(st) + " (" + ObjNumbers(k) + ")";
         if(g_isTester)
            Logf(m);
         else
            Notify(m);
        }
      g_obState[k] = st;
     }
  }

string ObjFile(bool tester) { return tester ? "XauCommittee_tester_obiezioni.csv" : "XauCommittee_" + IntegerToString(g_login) + "_obiezioni.csv"; }

void ObjSave()
  {
   if(g_isOptim || !InpObjLearn || g_obTotN[0] + g_obTotN[1] + g_obTotN[2] + g_obTotN[3] <= 0.0)
      return;
   int h = FileOpen(ObjFile(g_isTester), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   string hd = "obiezione;stato;casi_con;R_medio_con;R_medio_senza;n_2022;somma_R_2022;quad_2022;n_2023;somma_R_2023;quad_2023;";
   hd += "n_2024;somma_R_2024;quad_2024;n_2025_26;somma_R_2025_26;quad_2025_26\r\n";
   FileWriteString(h, hd);
   double nt = 0.0, st = 0.0;
   string per = "";
   for(int p = 0; p < NPER; p++)
     {
      nt += g_obTotN[p];
      st += g_obTotS[p];
      per += ";" + DoubleToString(g_obTotN[p], 0) + ";" + DoubleToString(g_obTotS[p], 3) + ";" + DoubleToString(g_obTotQ[p], 3);
     }
   FileWriteString(h, "tutte le idee;-;" + DoubleToString(nt, 0) + ";" + (nt > 0.0 ? DoubleToString(st / nt, 3) : "0") + ";-" + per + "\r\n");
   for(int k = 0; k < NOBJ; k++)
     {
      double nw, sw, no, so;
      ObSums(k, -1, nw, sw, no, so);
      string l = g_obName[k] + ";" + ObjStateName(g_obState[k]) + ";" + DoubleToString(nw, 0) + ";" + (nw > 0.0 ? DoubleToString(sw / nw, 3) : "0") + ";" +
                 (no > 0.0 ? DoubleToString(so / no, 3) : "0");
      for(int p = 0; p < NPER; p++)
         l += ";" + DoubleToString(g_obN[k * NPER + p], 0) + ";" + DoubleToString(g_obS[k * NPER + p], 3) + ";" + DoubleToString(g_obQ[k * NPER + p], 3);
      FileWriteString(h, l + "\r\n");
     }
   FileClose(h);
  }

//--- legge un file delle obiezioni; restituisce le idee fantasma che contiene
double ObjReadFile(string f)
  {
   ObjInit();
   if(!FileIsExist(f, FILE_COMMON))
      return 0.0;
   int h = FileOpen(f, FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return 0.0;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      int np = StringSplit(l, ';', p);
      if(np < 5 + 3 * NPER)
         continue;
      int k = -2;
      if(p[0] == "tutte le idee")
         k = -1;
      else
         for(int j = 0; j < NOBJ; j++)
            if(p[0] == g_obName[j])
               k = j;
      if(k == -2)
         continue;
      for(int q = 0; q < NPER; q++)
        {
         double n = MathMax(StringToDouble(p[5 + 3 * q]), 0.0);
         double s = StringToDouble(p[6 + 3 * q]);
         double qq = MathMax(StringToDouble(p[7 + 3 * q]), 0.0);
         if(k == -1)
           {
            g_obTotN[q] = n;
            g_obTotS[q] = s;
            g_obTotQ[q] = qq;
           }
         else
           {
            g_obN[k * NPER + q] = n;
            g_obS[k * NPER + q] = s;
            g_obQ[k * NPER + q] = qq;
           }
        }
     }
   FileClose(h);
   //--- un file rovinato non deve far credere al bot di sapere: i casi con l'obiezione mai piu' del totale
   for(int k = 0; k < NOBJ; k++)
      for(int q = 0; q < NPER; q++)
         if(g_obN[k * NPER + q] > g_obTotN[q])
           {
            g_obN[k * NPER + q] = 0.0;
            g_obS[k * NPER + q] = 0.0;
            g_obQ[k * NPER + q] = 0.0;
           }
   return g_obTotN[0] + g_obTotN[1] + g_obTotN[2] + g_obTotN[3];
  }

//--- carica quello che e' gia' stato imparato (conto: il suo file, altrimenti quello del Tester)
void ObjLoad()
  {
   ObjInit();
   if(g_isTester || !InpObjLearn)
      return;                                   // nel Tester si impara da zero, come in una prova vera
   double nt = ObjReadFile(ObjFile(false));
   if(nt <= 0.0 && InpObjFromTester)
     {
      nt = ObjReadFile(ObjFile(true));
      if(nt > 0.0)
         Notify("Meno regole: parto da quello che ha imparato il Tester (" + DoubleToString(nt, 0) + " idee fantasma)");
     }
   ObjRefresh(false);
  }

//+------------------------------------------------------------------+
//| STRATEGIE IN OSSERVAZIONE (1.26)                                 |
//| Una strategia in osservazione lavora sulla carta: le sue idee    |
//| passano dal comitato, finiscono nel diario e vengono seguite     |
//| fino a stop/target come idee fantasma, ma non aprono ordini.     |
//| Il bot tiene il conto per strategia (solo le idee che il         |
//| comitato avrebbe aperto) con la regola degli studi: promossa se  |
//| guadagna dopo i costi lontano dal caso e in 3 periodi su 4;      |
//| una strategia attiva che perde allo stesso modo torna in         |
//| osservazione.                                                    |
//+------------------------------------------------------------------+
double g_stN[NSTRAT * NPER];    // idee fantasma approvate e chiuse, per strategia e periodo
double g_stS[NSTRAT * NPER];    // somma dei loro R dopo i costi
double g_stQ[NSTRAT * NPER];    // somma dei quadrati
int    g_stObs[NSTRAT];         // 1 = in osservazione, 0 = attiva

//--- la strategia parte in osservazione? (elenco dei parametri, nomi separati da virgola)
bool StListed(int k)
  {
   if(k <= 0 || k >= NSTRAT)
      return false;
   string l = "," + InpObserveList + ",";
   StringReplace(l, " ", "");
   StringToUpper(l);
   string nm = "," + g_stratName[k] + ",";
   return (StringFind(l, nm) >= 0);
  }

void StSums(int k, double &n, double &sum, double &q)
  {
   n = 0.0;
   sum = 0.0;
   q = 0.0;
   for(int p = 0; p < NPER; p++)
     {
      n += g_stN[k * NPER + p];
      sum += g_stS[k * NPER + p];
      q += g_stQ[k * NPER + p];
     }
  }

double StSe(int k)
  {
   double n, sum, q;
   StSums(k, n, sum, q);
   if(n < 2.0)
      return 99.0;
   double var = MathMax((q - sum * sum / n) / (n - 1.0), 0.0);
   return MathSqrt(var / n);
  }

//--- giudizio: 1 = in osservazione, 0 = attiva
int StEvaluate(int k)
  {
   if(!InpObserveOn)
      return 0;
   bool listed = StListed(k);
   int start = listed ? 1 : 0;
   if(!InpObserveAuto)
      return start;
   double n, sum, q;
   StSums(k, n, sum, q);
   int perOk = 0, perPos = 0, perNeg = 0;
   for(int p = 0; p < NPER; p++)
     {
      double a = g_stN[k * NPER + p];
      if(a < 8.0)
         continue;
      perOk++;
      if(g_stS[k * NPER + p] > 0.0)
         perPos++;
      if(g_stS[k * NPER + p] < 0.0)
         perNeg++;
     }
   //--- con meno di 3 periodi misurabili (conto vero, un anno solo) servono il doppio dei casi
   if(n < InpObserveMinN || (perOk < 3 && n < 2.0 * InpObserveMinN))
      return start;
   double mean = sum / n;
   double se = StSe(k);
   if(listed)
      return (mean >= InpObservePromoteR && mean >= 2.5 * se && (perOk < 3 || perPos >= 3)) ? 0 : 1;
   return (mean <= InpObserveDemoteR && mean <= -2.5 * se && (perOk < 3 || perNeg >= 3)) ? 1 : 0;
  }

//--- in osservazione adesso? (mai quando nel Tester si prova una strategia sola)
bool StratObserved(int k)
  {
   if(!InpObserveOn || InpOnlyStrategy != PICK_ALL || k <= 0 || k >= NSTRAT)
      return false;
   return (g_stObs[k] == 1);
  }

string StNumbers(int k)
  {
   double n, sum, q;
   StSums(k, n, sum, q);
   if(n <= 0.0)
      return "nessuna idea chiusa";
   return DoubleToString(n, 0) + " idee, " + DoubleToString(sum / n, 2) + "R medio dopo i costi";
  }

void StInit()
  {
   for(int i = 0; i < NSTRAT * NPER; i++)
     {
      g_stN[i] = 0.0;
      g_stS[i] = 0.0;
      g_stQ[i] = 0.0;
     }
   for(int k = 0; k < NSTRAT; k++)
      g_stObs[k] = 0;
  }

void StRefresh(bool tell)
  {
   for(int k = 1; k < NSTRAT; k++)
     {
      int st = StEvaluate(k);
      if(st != g_stObs[k] && tell)
        {
         string m = "Osservazione: " + g_stratName[k];
         if(st == 1)
            m += " torna in osservazione (sulla carta perde: ";
         else
            m += " promossa, da ora apre ordini (sulla carta guadagna: ";
         m += StNumbers(k) + ")";
         if(g_isTester)
            Logf(m);
         else
            Notify(m);
        }
      g_stObs[k] = st;
     }
  }

string StFile(bool tester) { return tester ? "XauCommittee_tester_strategie.csv" : "XauCommittee_" + IntegerToString(g_login) + "_strategie.csv"; }

void StSave()
  {
   if(g_isOptim || !InpObserveOn)
      return;
   double tot = 0.0;
   for(int i = 0; i < NSTRAT * NPER; i++)
      tot += g_stN[i];
   if(tot <= 0.0)
      return;
   int h = FileOpen(StFile(g_isTester), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   string hd = "strategia;stato;idee;R_medio;errore_standard;n_2022;somma_R_2022;quad_2022;n_2023;somma_R_2023;quad_2023;";
   hd += "n_2024;somma_R_2024;quad_2024;n_2025_26;somma_R_2025_26;quad_2025_26\r\n";
   FileWriteString(h, hd);
   for(int k = 1; k < NSTRAT; k++)
     {
      double n, sum, q;
      StSums(k, n, sum, q);
      string stn = (g_stObs[k] == 1) ? "in osservazione" : "attiva";
      string avg = (n > 0.0) ? DoubleToString(sum / n, 3) : "0";
      string se = (n >= 2.0) ? DoubleToString(StSe(k), 3) : "0";
      string l = g_stratName[k] + ";" + stn + ";" + DoubleToString(n, 0) + ";" + avg + ";" + se;
      for(int p = 0; p < NPER; p++)
         l += ";" + DoubleToString(g_stN[k * NPER + p], 0) + ";" + DoubleToString(g_stS[k * NPER + p], 3) + ";" + DoubleToString(g_stQ[k * NPER + p], 3);
      FileWriteString(h, l + "\r\n");
     }
   FileClose(h);
  }

//--- legge un file delle strategie; restituisce le idee che contiene
double StReadFile(string f)
  {
   StInit();
   if(!FileIsExist(f, FILE_COMMON))
      return 0.0;
   int h = FileOpen(f, FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return 0.0;
   double tot = 0.0;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      int np = StringSplit(l, ';', p);
      if(np < 5 + 3 * NPER)
         continue;
      int k = StratByName(p[0]);
      if(k <= 0 || k >= NSTRAT)
         continue;
      for(int q = 0; q < NPER; q++)
        {
         double n = MathMax(StringToDouble(p[5 + 3 * q]), 0.0);
         double sm = StringToDouble(p[6 + 3 * q]);
         double qq = MathMax(StringToDouble(p[7 + 3 * q]), 0.0);
         //--- un file rovinato non deve far credere al bot di sapere: la somma dei quadrati non puo' essere sotto somma^2/n
         if(n > 0.0 && qq + 0.001 < sm * sm / n)
           {
            n = 0.0;
            sm = 0.0;
            qq = 0.0;
           }
         if(n <= 0.0)
           {
            sm = 0.0;
            qq = 0.0;
           }
         g_stN[k * NPER + q] = n;
         g_stS[k * NPER + q] = sm;
         g_stQ[k * NPER + q] = qq;
         tot += n;
        }
     }
   FileClose(h);
   return tot;
  }

//--- carica quello che e' gia' stato misurato (conto: il suo file, altrimenti quello del Tester)
void StLoad()
  {
   StInit();
   if(!g_isTester && InpObserveOn)
     {
      double nt = StReadFile(StFile(false));
      if(nt <= 0.0 && InpObjFromTester)
        {
         nt = StReadFile(StFile(true));
         if(nt > 0.0)
            Notify("Osservazione: parto dai conti del Tester (" + DoubleToString(nt, 0) + " idee sulla carta)");
        }
     }
   StRefresh(false);
  }

string StPanel()
  {
   string act = "", obs = "";
   for(int k = 1; k < NSTRAT; k++)
     {
      if(!StratEnabled(k))
         continue;
      if(StratObserved(k))
         obs += (obs == "" ? "" : ", ") + g_stratName[k];
      else
         act += (act == "" ? "" : ", ") + g_stratName[k];
     }
   if(act == "")
      act = "nessuna";
   if(obs == "")
      obs = "nessuna";
   return "Strategie che aprono ordini: " + act + " | in osservazione (sulla carta): " + obs;
  }

void StReport()
  {
   if(!InpObserveOn)
      return;
   Logf("Strategie (idee sulla carta che il comitato avrebbe aperto, R dopo i costi):");
   for(int k = 1; k < NSTRAT; k++)
     {
      double n, sum, q;
      StSums(k, n, sum, q);
      if(n <= 0.0 && !StratEnabled(k))
         continue;
      string stn = StratObserved(k) ? "in osservazione" : "attiva";
      Logf("  " + g_stratName[k] + ": " + stn + " | " + StNumbers(k));
     }
  }

//--- una buona idea (punteggio e quorum sufficienti), presa o no, diventa un'idea fantasma
//    1.26: le idee di una strategia provata si seguono sempre; un'idea approvata si segue anche se la stessa,
//    respinta poco prima, e' gia' seguita (cosi' il conto per strategia ha tutte le idee che sarebbero state aperte)
void GhostAdd(const TSignal &s)
  {
   if(!GhostsOn())
      return;
   double risk = RiskPx(s);
   bool good = (s.score >= MinScoreFor(s.engine) && s.quorum >= InpQuorum);
   if(risk <= 0.0 || s.tp == 0.0 || (!good && !s.proven))
      return;
   int fr = -1;
   bool sameOpen = false, samePassed = false;
   for(int i = 0; i < MAX_GHOST; i++)
     {
      if(g_gh[i].active)
        {
         if(g_gh[i].strat == s.strat && g_gh[i].dir == s.dir)
           {
            sameOpen = true;                    // la stessa idea ripetuta conta una volta sola
            if(g_gh[i].passed)
               samePassed = true;
           }
        }
      else
         if(fr < 0)
            fr = i;
     }
   if(sameOpen && (samePassed || !s.passed))
      return;
   if(fr < 0)
      return;
   datetime now = TimeCurrent();
   int life = (s.engine == ENG_SCALP) ? 240 : ((s.engine == ENG_INTRA) ? 1440 : 7200);
   if(IsTrendMove(s.strat))
      life = (int)MathMax((double)(TmExitUtc(g_ctx.nowUtc) - g_ctx.nowUtc) / 60.0, 5.0);   // seguita fino alla fine della tenuta
   if(s.deadline > 0)
      life = (int)MathMax((double)(s.deadline - g_ctx.nowUtc) / 60.0, 5.0);                // 1.27: seguita fino al suo tempo massimo
   g_gh[fr].active = true;
   g_gh[fr].strat = s.strat;
   g_gh[fr].dir = s.dir;
   g_gh[fr].engine = s.engine;
   g_gh[fr].mask = s.objMask;
   g_gh[fr].entry = s.entry;
   g_gh[fr].sl = s.sl;
   g_gh[fr].tp = s.tp;
   g_gh[fr].risk = risk;
   g_gh[fr].costR = (g_ctx.spread + CommissionPx() + SlipEstPx(g_ctx.spread)) / risk;
   g_gh[fr].t0 = (datetime)((long)now - (long)now % 60);
   g_gh[fr].tEnd = now + life * 60;
   g_gh[fr].passed = s.passed;
   g_gh[fr].stratOnly = (sameOpen || s.proven || !good);
   g_gh[fr].rdFav = s.rdFav;
   g_gh[fr].rdAg = s.rdAg;
  }

void GhostClose(int i, double r)
  {
   int p = ObPeriod(g_gh[i].t0);
   int st = g_gh[i].strat;
   RdAdd(st, g_gh[i].rdFav, g_gh[i].rdAg, g_gh[i].t0, r, g_gh[i].passed);   // 1.27: conto delle letture del mercato
   if(g_gh[i].passed && st > 0 && st < NSTRAT)
     {
      g_stN[st * NPER + p] += 1.0;              // 1.26: conto per strategia (solo le idee che sarebbero state aperte)
      g_stS[st * NPER + p] += r;
      g_stQ[st * NPER + p] += r * r;
     }
   if(!g_gh[i].stratOnly)
     {
      g_obTotN[p] += 1.0;
      g_obTotS[p] += r;
      g_obTotQ[p] += r * r;
      for(int k = 0; k < NOBJ; k++)
         if((g_gh[i].mask & (1 << k)) != 0)
           {
            g_obN[k * NPER + p] += 1.0;
            g_obS[k * NPER + p] += r;
            g_obQ[k * NPER + p] += r * r;
           }
     }
   g_gh[i].active = false;
  }

//--- a ogni nuova M1: le idee fantasma toccano stop (prima, se nella stessa barra) o target, o scadono
void GhostUpdate()
  {
   if(!GhostsOn())
      return;
   datetime bt = BarT(g_m1, 1);
   if(bt <= 0)
      return;
   double hi = BarH(g_m1, 1), lo = BarL(g_m1, 1), cl = BarC(g_m1, 1);
   bool changed = false;
   for(int i = 0; i < MAX_GHOST; i++)
     {
      if(!g_gh[i].active || bt <= g_gh[i].t0)
         continue;                              // la barra in cui e' nata l'idea non conta
      int d = g_gh[i].dir;
      bool hitSl = (d > 0) ? (lo <= g_gh[i].sl) : (hi >= g_gh[i].sl);
      bool hitTp = (d > 0) ? (hi >= g_gh[i].tp) : (lo <= g_gh[i].tp);
      double r = 0.0;
      bool done = false;
      if(hitSl)
        {
         r = -1.0;
         done = true;
        }
      else
         if(hitTp)
           {
            r = (g_gh[i].tp - g_gh[i].entry) * d / g_gh[i].risk;
            done = true;
           }
         else
            if(bt + 60 >= g_gh[i].tEnd)
              {
               r = (cl - g_gh[i].entry) * d / g_gh[i].risk;
               done = true;
              }
      if(!done)
         continue;
      GhostClose(i, Clamp(r, -1.5, 10.0) - g_gh[i].costR);
      changed = true;
     }
   if(changed)
     {
      ObjRefresh(true);
      StRefresh(true);
      RdRefresh(true);
      if(!g_isTester)
        {
         ObjSave();
         StSave();
         RdSave();
        }
     }
  }

int GhostOpen()
  {
   int c = 0;
   for(int i = 0; i < MAX_GHOST; i++)
      if(g_gh[i].active)
         c++;
   return c;
  }

//--- obiezione secondaria: blocca solo se non ci sono conferme forti (deciso alla fine del comitato)
void SoftVeto(TSignal &s, int k, string why)
  {
   s.objMask |= (1 << k);
   if(s.proven)
      return;                                   // 1.26: strategia provata sui dati, le obiezioni secondarie restano solo nel diario
   int st = ObjState(k);
   if(st == OBS_USELESS)
      return;                                   // misurata: non serve, non blocca
   if(st == OBS_USEFUL)
     {
      Veto(s, why + " (obiezione provata)");
      return;
     }
   s.softN++;
   s.softWhy += (s.softWhy == "" ? "" : "; ") + why;
  }

//--- elenco leggibile delle obiezioni presenti (per il diario)
string ObjList(int mask)
  {
   string t = "";
   for(int k = 0; k < NOBJ; k++)
      if((mask & (1 << k)) != 0)
        {
         int st = ObjState(k);
         t += (t == "" ? "" : ", ") + g_obName[k] + (st == OBS_USEFUL ? " (provata)" : (st == OBS_USELESS ? " (inutile)" : ""));
        }
   return t;
  }

string ObjPanel()
  {
   int u = 0, z = 0, t = 0;
   for(int k = 0; k < NOBJ; k++)
     {
      int st = ObjState(k);
      if(st == OBS_USEFUL)
         u++;
      else
         if(st == OBS_USELESS)
            z++;
         else
            t++;
     }
   double nt = g_obTotN[0] + g_obTotN[1] + g_obTotN[2] + g_obTotN[3];
   return "Meno regole: obiezioni provate " + IntegerToString(u) + ", inutili " + IntegerToString(z) + ", da provare " + IntegerToString(t) +
          " | idee fantasma chiuse " + DoubleToString(nt, 0) + ", in corso " + IntegerToString(GhostOpen()) +
          " | scavalcate " + IntegerToString(g_overCount);
  }

void ObjReport()
  {
   if(!InpObjLearn)
      return;
   double nt = g_obTotN[0] + g_obTotN[1] + g_obTotN[2] + g_obTotN[3];
   double st = g_obTotS[0] + g_obTotS[1] + g_obTotS[2] + g_obTotS[3];
   Logf("Meno regole: " + DoubleToString(nt, 0) + " idee fantasma, R medio " + (nt > 0.0 ? DoubleToString(st / nt, 3) : "-") + " dopo i costi");
   for(int k = 0; k < NOBJ; k++)
     {
      double nw, sw, no, so;
      ObSums(k, -1, nw, sw, no, so);
      if(nw > 0.0)
         Logf("  " + g_obName[k] + ": " + ObjStateName(g_obState[k]) + " | " + ObjNumbers(k));
     }
  }

//--- trend del timeframe di contesto (which=1 vicino, 2 superiore) per ogni motore
int CtxTrend(int engine, int which)
  {
   if(engine == ENG_SCALP)
      return (which == 1) ? TrendDir(g_m15) : TrendDir(g_h1);
   if(engine == ENG_INTRA)
      return (which == 1) ? TrendDir(g_h1) : TrendDir(g_h4);
   return (which == 1) ? TrendDir(g_h4) : EmaDir(g_d1);
  }

double CtxAdx(int engine)
  {
   if(engine == ENG_SCALP)
      return AdxOf(g_m15);
   if(engine == ENG_INTRA)
      return AdxOf(g_h1);
   return AdxOf(g_h4);
  }

double CtxRsi(int engine)
  {
   if(engine == ENG_SCALP)
      return Ind(g_m15.rsi, 0);
   if(engine == ENG_INTRA)
      return Ind(g_h1.rsi, 0);
   return Ind(g_h4.rsi, 0);
  }

double ExecRvol(int engine)
  {
   if(engine == ENG_SCALP)
      return RvolBar(g_m1, 0);
   if(engine == ENG_INTRA)
      return RvolBar(g_m5, 0);
   return RvolBar(g_h1, 0);
  }

int CvdWindow(int engine)
  {
   if(engine == ENG_SCALP)
      return 20;
   if(engine == ENG_INTRA)
      return 60;
   return 240;
  }

bool IsTrendLike(int stype) { return (stype == STYPE_TREND || stype == STYPE_BREAKOUT || stype == STYPE_NEWS); }

//--- climax contrario nelle ultime 3 barre del timeframe di esecuzione
bool ClimaxAgainst(int engine, int dir)
  {
   for(int sh = 0; sh < 3; sh++)
     {
      if(engine == ENG_SCALP && IsClimax(g_m1, sh, -dir))
         return true;
      if(engine == ENG_INTRA && IsClimax(g_m5, sh, -dir))
         return true;
      if(engine == ENG_SWING && IsClimax(g_h1, sh, -dir))
         return true;
     }
   return false;
  }

//--- DESK TREND
double DeskTrend(TSignal &s)
  {
   int a1 = CtxTrend(s.engine, 1) * s.dir;
   int a2 = CtxTrend(s.engine, 2) * s.dir;
   double adx = CtxAdx(s.engine);
   double sc;
   if(IsTrendLike(s.stype))
     {
      sc = 0.5 + 0.2 * a1 + 0.15 * a2;
      if(a1 > 0 && adx > 25.0)
         sc += 0.1;
      if(a1 < 0 && a2 < 0)
         SoftVeto(s, OB_TREND2, "contro il trend su due timeframe");
     }
   else
     {
      sc = 0.55;
      if(adx < 20.0)
         sc += 0.1;
      if(a1 < 0 && adx > 30.0)
         sc -= 0.25;
      if(a2 > 0)
         sc += 0.15;
      if(a2 < 0 && a1 < 0)
         sc -= 0.1;
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK VOLUMI (delta, VWAP, RVOL, VSA, DOM, order flow GC)
double DeskVolume(TSignal &s)
  {
   double sc = 0.5;
   double cr = MicroCvdRatio(CvdWindow(s.engine));
   s.cvdRatio = cr;
   if(InpOF2VolumeNeutral)
     {
      //--- OF2 (1.25): sul demo il volume tick non segue il volume vero del COMEX (correlazione 0,03 a parita' di ora)
      //    e delta, VWAP, climax e profilo non battono il caso: resta solo l'attivita' (RVOL), che prevede la volatilita'
      double rvn = ExecRvol(s.engine);
      if(rvn >= 1.2)
         sc += 0.1;
      else
         if(rvn < 0.6)
            sc -= 0.1;
      if(GcFresh() && MathAbs(g_gcDeltaTrend) > 0.2)
         sc += (g_gcDeltaTrend * s.dir > 0.0) ? 0.05 : -0.05;   // dati veri CME (solo con Databento)
      return Clamp(sc, 0.0, 1.0);
     }
   if(IsTrendLike(s.stype))
     {
      if(cr * s.dir > 0.05)
         sc += 0.15;
      else
         if(cr * s.dir < -0.05)
            sc -= 0.15;
     }
   else
     {
      double crs = MicroCvdRatio(5);
      if(crs * s.dir > 0.1)
         sc += 0.15;
      else
         if(crs * s.dir < -0.1)
            sc -= 0.1;
     }
   double vw = g_ctx.vwap, sg = g_ctx.vwSig;
   if(vw > 0.0)
     {
      if(IsTrendLike(s.stype))
         sc += ((s.entry - vw) * s.dir > 0.0) ? 0.1 : -0.1;
      else
         if(sg > 0.0 && (vw - s.entry) * s.dir >= sg)
            sc += 0.1;
     }
   double rv = ExecRvol(s.engine);
   if(rv >= 1.2)
      sc += 0.1;
   else
      if(rv < 0.6)
         sc -= 0.1;
   if(ClimaxAgainst(s.engine, s.dir))
      sc += IsTrendLike(s.stype) ? -0.15 : 0.1;
   //--- profilo di ieri: comprare vicino a VAL/POC (o vendere vicino a VAH/POC) e' un supporto
   if(PrevProfileOk())
     {
      double tol = 0.3 * g_ctx.atrM15;
      if(s.dir > 0 && (MathAbs(s.entry - PrevVAL()) < tol || MathAbs(s.entry - PrevPOC()) < tol))
         sc += 0.05;
      if(s.dir < 0 && (MathAbs(s.entry - PrevVAH()) < tol || MathAbs(s.entry - PrevPOC()) < tol))
         sc += 0.05;
     }
   if(s.engine == ENG_SCALP && DomFresh())
     {
      if(g_domImb * s.dir > 0.2)
         sc += 0.05;
      else
         if(g_domImb * s.dir < -0.2)
            sc -= 0.05;
     }
   if(GcFresh() && MathAbs(g_gcDeltaTrend) > 0.2)
      sc += (g_gcDeltaTrend * s.dir > 0.0) ? 0.05 : -0.05;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK LIQUIDITA' (strada libera verso il target, stop protetto)
double DeskLiquidity(TSignal &s)
  {
   double risk = RiskPx(s);
   double reward = (s.tp - s.entry) * s.dir;
   double sc = 0.5;
   int t = -1;
   double d = NearestLevelDist(s.entry, s.dir, 0.25 * risk, t);
   //--- ritorno alla media: il target E' un livello (VWAP/value area), i livelli intermedi fanno parte del percorso
   if(s.stype == STYPE_MEANREV)
     {
      s.obstacleR = 99.0;
      sc = 0.6;
      int tm = -1;
      double dm = NearestLevelDist(s.entry, -s.dir, 0.0, tm);
      if(dm > 0.0 && dm < risk * 0.95)
         sc += 0.1;
      return Clamp(sc, 0.0, 1.0);
     }
   if(d < 0.0)
     {
      sc += 0.2;
      s.obstacleR = 99.0;
     }
   else
     {
      double dR = d / risk;
      s.obstacleR = dR;
      if(dR >= reward / risk)
         sc += 0.2;
      else
         if(dR >= 1.5)
            sc += 0.1;
         else
            if(dR < 1.0)
              {
               sc -= 0.2;
               if(IsMajorLevel(t) && dR < 0.7)
                  SoftVeto(s, OB_LEVEL, "livello forte (" + g_lvName[t] + ") a " + DoubleToString(dR, 2) + "R");
              }
     }
   int t2 = -1;
   double ds = NearestLevelDist(s.entry, -s.dir, 0.0, t2);
   if(ds > 0.0 && ds < risk * 0.95)
      sc += 0.1;
   if(PriceOnMajorLevel(s.sl, 0.05 * g_ctx.atrM15))
      sc -= 0.1;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK MACRO (servizio GitHub + storico + intermarket dai simboli del broker)
double DeskMacro(TSignal &s)
  {
   if(MacroFresh() && g_macroHalt)
     {
      Veto(s, "servizio macro: stop (" + g_macroHaltReason + ")");
      return 0.0;
     }
   if(g_mConf <= 0.0)
      return 0.5;
   double al = g_mBias * s.dir;
   double sc = 0.5 + 0.45 * al * Clamp(g_mConf * 1.4, 0.0, 1.0);
   //--- il dollaro di oggi conta per chi lavora intraday
   if(s.engine != ENG_SWING && g_imOk)
      sc -= 0.08 * g_dollarFast * s.dir;
   if(AiFresh())
     {
      if(g_aiStance == "long")
         sc += 0.1 * g_aiConv * s.dir;
      else
         if(g_aiStance == "short")
            sc -= 0.1 * g_aiConv * s.dir;
         else
            if(g_aiStance == "stand_aside")
               sc -= 0.05;
     }
   //--- macro forte e contraria: niente trade di trend intraday/swing contro
   if(s.engine != ENG_SCALP && al <= -InpMacroVetoLevel && g_mConf >= 0.45)
     {
      if(IsTrendLike(s.stype) || s.engine == ENG_SWING)
         SoftVeto(s, OB_MACROV, "macro contraria (" + DoubleToString(g_mBias, 2) + ", " + g_mSource + ")");
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK CONTESTO HTF (struttura, ritracciamento, compressione/espansione)
double DeskContext(TSignal &s)
  {
   if(!g_cxD1.valid && !g_cxH4.valid)
      return 0.5;
   if(s.dir < 0 && IsTrendLike(s.stype) && T5Active(BarT(g_d1, 0)))
      Veto(s, "T5: crollo esausto sul D1, niente short di trend per " + IntegerToString(InpT5Days) + " giorni");
   double al = g_ctxBias * s.dir;
   int ph = PhaseFor(s.engine);
   int pdir = PhaseDirFor(s.engine);
   double retr = PhaseRetrFor(s.engine);
   double ext = PhaseExtFor(s.engine);
   double sc = 0.5;
   if(s.stype == STYPE_TREND || s.stype == STYPE_NEWS)
     {
      sc += 0.3 * al;
      if(!InpT2NoDiscountBonus && pdir == s.dir && ph == PH_RITRACCIAMENTO && retr >= 0.382 && retr <= 0.786)
         sc += 0.12;                                    // compra lo sconto dentro il trend (spento da T2)
      if(!InpT2NoDiscountBonus && pdir == s.dir && (ph == PH_IMPULSO || ph == PH_ESPANSIONE) && retr < 0.236)
         sc -= 0.08;                                    // inseguire l'estensione (spento da T2)
      if(ph == PH_ESAURIMENTO && ext * s.dir > 0.0)
         sc -= 0.15;                                    // entrare nel verso di un movimento esausto
      if(s.engine != ENG_SCALP && al <= -InpContextVetoLevel)
         SoftVeto(s, OB_CTXV, "contesto dei timeframe alti contrario (" + DoubleToString(g_ctxBias, 2) + ")");
     }
   else
      if(s.stype == STYPE_BREAKOUT)
        {
         sc += 0.2 * al;
         if(ph == PH_COMPRESSIONE || g_cxD1.phase == PH_COMPRESSIONE)
            sc += 0.15;                                 // energia accumulata: la rottura ha piu' benzina
         if(ph == PH_ESAURIMENTO)
            sc -= 0.15;
         if(s.engine != ENG_SCALP && al <= -InpContextVetoLevel)
            SoftVeto(s, OB_CTXV, "contesto dei timeframe alti contrario (" + DoubleToString(g_ctxBias, 2) + ")");
        }
      else
        {
         sc += 0.1 * al;
         if(ph == PH_ESAURIMENTO && ext * s.dir < 0.0)
            sc += 0.15;                                 // inversione contro un movimento esausto
         if((ph == PH_IMPULSO || ph == PH_ESPANSIONE) && pdir == -s.dir)
            sc -= 0.15;                                 // contro un impulso fresco
         if(ph == PH_LATERALE || ph == PH_COMPRESSIONE)
            sc += 0.05;
        }
   //--- premium / discount del range giornaliero
   double rp = g_cxD1.rangePos;
   if(g_cxD1.valid)
     {
      if((s.dir > 0 && rp < 0.35) || (s.dir < 0 && rp > 0.65))
         sc += 0.06;
      else
         if((s.dir > 0 && rp > 0.85) || (s.dir < 0 && rp < 0.15))
            sc -= 0.08;
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK NEWS
double DeskNews(TSignal &s)
  {
   string why = "";
   if(NewsBlocked(s.engine, g_ctx.nowUtc, s.strat, why))
     {
      Veto(s, why);
      return 0.0;
     }
   if(s.strat == ST_IN_NEWS)
      return 0.75;
   double sc = 0.6;
   int mins = MinutesToNextTier1(g_ctx.nowUtc);
   int horizon = (s.engine == ENG_SWING) ? 720 : 120;
   if(mins >= 0 && mins < horizon)
      sc = 0.4;
   int v = NextEventView(g_ctx.nowUtc, 600);
   if(v != 0)
      sc += (v == s.dir) ? 0.1 : -0.15;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK SESSIONE
double DeskSession(TSignal &s)
  {
   double h = g_ctx.hUtc;
   double lo = g_ctx.lonOpen, nyd = g_ctx.nyData, nyo = g_ctx.nyOpen, nyc = g_ctx.nyClose;
   double sc = 0.6;
   if(s.engine == ENG_SCALP)
     {
      if(h >= nyd - 0.25 && h < nyo + 2.5)
         sc = 0.8;
      else
         if(h >= lo && h < lo + 3.0)
            sc = 0.75;
         else
            if(h >= lo && h < nyd)
               sc = 0.55;
            else
               if(h < lo)
                  sc = 0.25;
               else
                  sc = 0.4;
     }
   else
      if(s.engine == ENG_INTRA)
        {
         if(h >= lo && h < nyc - 2.0)
            sc = 0.7;
         else
            if(h < lo)
               sc = 0.35;
            else
               sc = 0.4;
        }
   if(g_ctx.dow == 5 && h >= 16.0)
      sc -= 0.2;
   if(g_ctx.dow == 1 && h < lo)
      sc -= 0.1;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK COSTI (spread + commissione rispetto allo stop)
double DeskCost(TSignal &s)
  {
   double risk = RiskPx(s);
   if(risk <= 0.0)
      return 0.0;
   double cost = g_ctx.spread + CommissionPx() + SlipEstPx(g_ctx.spread);   // K (1.25): slittamento e commissioni misurati
   double cr = cost / risk;
   if(cr > InpMaxCostR)
      Veto(s, "costi " + DoubleToString(cr * 100.0, 0) + "% di R");
   if(SpreadAbnormal())
      Veto(s, "spread anomalo");
   return Clamp(1.0 - cr * 4.0, 0.0, 1.0);
  }

//--- DESK STATISTICA (risultati reali della strategia + adattamento al regime)
double DeskStats(TSignal &s)
  {
   double sc = 0.5;
   int k = s.strat;
   if(g_ss[k].n >= 10)
      sc += Clamp(g_ss[k].Expectancy(), -0.5, 0.5) * 0.6;
   int rl = g_ss[k].RecentLosses(5);
   if(rl >= 4)
      sc -= 0.15;
   else
      if(rl >= 3)
         sc -= 0.1;
   sc += RegimeFit(s.stype);
   if(InpUseBench && InpOnlyStrategy == PICK_ALL && g_ss[k].benchUntil > TimeCurrent())
      Veto(s, "strategia in panchina fino al " + TimeToString(g_ss[k].benchUntil, TIME_DATE));
   return Clamp(sc, 0.0, 1.0);
  }

//--- 1.27: ritracciamenti (ONDA) ancora a rischio aperti nel verso opposto a 'dir'
int OppOndaAtRisk(int dir)
  {
   int c = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym || !IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      int pd = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      if(pd == dir)
         continue;
      double op = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      double riskPx = (sl > 0.0) ? (op - sl) * pd : AtrOf(g_h1);
      if(riskPx <= 0.0)
         continue;
      int mi = MetaFind(PositionGetInteger(POSITION_IDENTIFIER));
      if(mi >= 0 && IsOnda(g_meta[mi].strat))
         c++;
     }
   return c;
  }

//--- controlli di portafoglio (slot, direzione, limiti giornalieri)
void PortfolioChecks(TSignal &s)
  {
   PortfolioScan();
   int opp = (s.dir > 0) ? g_cntDir[1] : g_cntDir[0];
   bool tm = IsTrendMove(s.strat);
   //--- 1.27: un movimento forte che parte contro ritracciamenti ancora a rischio (e solo quelli) li chiude ed entra:
   //    il movimento forte dice che il ritracciamento ha sbagliato verso
   int freed = 0;
   s.flip = false;
   if(opp > 0 && tm && InpTDFlipOnda && !g_netting)
     {
      int no = OppOndaAtRisk(s.dir);
      if(no > 0 && no == opp)
        {
         s.flip = true;
         freed = no;
        }
     }
   if(g_cntAll - freed >= MaxPositionsEff())
      Veto(s, "posizioni massime (" + IntegerToString(MaxPositionsEff()) + ")");
   //--- 1.27: i ritracciamenti nel trend non hanno tetto di ingressi al giorno ne' slot del motore:
   //    li fermano le 4 posizioni, il rischio aperto (totale e per verso) e gli stop giornalieri
   bool noLimit = (IsOnda(s.strat) && InpOndaNoDayLimit);
   //--- un movimento forte di ieri ancora aperto (tenuta di un giorno) non deve togliere il posto a quello di oggi o al secondo ingresso
   bool noSlot = (noLimit || (tm && InpTDNoSlot));
   if(!noSlot && g_cntEng[s.engine] >= EngineMaxPos(s.engine))
      Veto(s, "slot del motore " + g_engName[s.engine] + " pieni");
   if(opp > 0 && !s.flip)
      Veto(s, "c'e' una posizione opposta a rischio");
   int maxDay = (s.engine == ENG_SCALP) ? InpScalpMaxTradesDay : ((s.engine == ENG_INTRA) ? InpIntraMaxTradesDay : InpSwingMaxTradesDay);
   if(!noLimit && g_tradesToday[s.engine] >= maxDay)
      Veto(s, "trade massimi di oggi per " + g_engName[s.engine]);
   //--- 1.27: le perdite di fila di oggi (quasi sempre dei ritracciamenti corti) non fermano i movimenti forti
   if(g_lossesInRowToday >= InpMaxLossesInRowDay && !(tm && InpTDNoStreak))
      Veto(s, IntegerToString(g_lossesInRowToday) + " perdite di fila oggi");
  }

//--- AVVOCATO DEL DIAVOLO: conta gli argomenti contrari
//    MR (1.25): un argomento misurato come inutile non conta; uno provato blocca da solo
void DevilItem(TSignal &s, int k, int &c, string &list)
  {
   s.objMask |= (1 << k);
   int st = ObjState(k);
   if(st == OBS_USELESS)
      return;
   if(st == OBS_USEFUL)
      g_devilProven += (g_devilProven == "" ? "" : ", ") + g_obName[k];
   c++;
   list += g_obName[k] + "; ";
  }

int DevilsAdvocate(TSignal &s, string &list)
  {
   int c = 0;
   list = "";
   g_devilProven = "";
   double rsi = CtxRsi(s.engine);
   if(IsTrendLike(s.stype) && ((s.dir > 0 && rsi > 75.0) || (s.dir < 0 && rsi < 25.0)))
      DevilItem(s, OB_RSIX, c, list);
   bool div = false;
   if(s.engine == ENG_SCALP)
      div = RsiDivergenceAgainst(g_m5, s.dir, 20);
   else
      if(s.engine == ENG_INTRA)
         div = RsiDivergenceAgainst(g_m15, s.dir, 20);
      else
         div = RsiDivergenceAgainst(g_h4, s.dir, 20);
   if(IsTrendLike(s.stype) && div)
      DevilItem(s, OB_RSIDIV, c, list);
   if(s.obstacleR >= 0.0 && s.obstacleR < 1.0)
      DevilItem(s, OB_LVL1R, c, list);
   if(g_mBias * s.dir < -0.3 && g_mConf >= 0.4)
      DevilItem(s, OB_MACRO, c, list);
   if(g_ctxBias * s.dir < -0.3)
      DevilItem(s, OB_CTX, c, list);
   if(IsTrendLike(s.stype) && PhaseFor(s.engine) == PH_ESAURIMENTO && PhaseExtFor(s.engine) * s.dir > 0.0)
      DevilItem(s, OB_EXH, c, list);
   if(!InpT3NoRangeEdgeObj && IsTrendLike(s.stype) && g_cxD1.valid && ((s.dir > 0 && g_cxD1.rangePos > 0.9) || (s.dir < 0 && g_cxD1.rangePos < 0.1)))
      DevilItem(s, OB_RANGE, c, list);
   if(!InpOF2VolumeNeutral && s.cvdRatio * s.dir < -0.1)
      DevilItem(s, OB_DELTA, c, list);
   if(s.desk[D_SESSION] < 0.4)
      DevilItem(s, OB_SESS, c, list);
   if(g_ss[s.strat].RecentLosses(2) >= 2)
      DevilItem(s, OB_LOST2, c, list);
   if(g_regime == REG_VOLATILE)
      DevilItem(s, OB_VOLAT, c, list);
   int v = NextEventView(g_ctx.nowUtc, 600);
   if(v != 0 && v != s.dir)
      DevilItem(s, OB_PRENEWS, c, list);
   return c;
  }

//--- P5 (1.17): nelle ore asiatiche lo stop non resta appoggiato su un livello ovvio
bool ObviousLevel(int type)
  {
   return (type == LV_PDH || type == LV_PDL || type == LV_PWH || type == LV_PWL || type == LV_ASIAH || type == LV_ASIAL ||
           type == LV_ROUND || type == LV_ROUNDM);
  }

void AsiaStopAdjust(TSignal &s)
  {
   if(!InpP5AsiaStopBuffer)
      return;
   double h = g_ctx.hUtc;
   if(!(h >= 21.0 || h < g_ctx.lonOpen))
      return;
   double buf = InpP5BufferAtrH1 * g_ctx.atrH1;
   double risk = RiskPx(s);
   if(buf <= 0.0 || risk <= 0.0)
      return;
   double rr = (s.tp - s.entry) * s.dir / risk;
   double sl = s.sl;
   string moved = "";
   for(int pass = 0; pass < 3; pass++)
     {
      bool any = false;
      for(int i = 0; i < g_lvN; i++)
        {
         if(!ObviousLevel(g_lv[i].type))
            continue;
         double L = g_lv[i].price;
         if((s.entry - L) * s.dir <= 0.0)
            continue;                       // il livello deve stare dalla parte dello stop
         if(MathAbs(sl - L) > buf)
            continue;
         double target = (s.dir > 0) ? L - buf : L + buf + g_ctx.spread;
         if((sl - target) * s.dir > 0.0)
           {
            sl = target;
            any = true;
            moved = g_lvName[g_lv[i].type];
           }
        }
      if(!any)
         break;
     }
   if(moved == "")
      return;
   s.sl = NormPrice(sl);
   double nrisk = RiskPx(s);
   s.tp = NormPrice(s.entry + s.dir * nrisk * rr);
   s.why += " | P5 stop oltre " + moved + " (ore asiatiche)";
  }

//--- P6 (1.17): alla scadenza opzioni COMEX e il giorno dopo i breakout hanno meno strada
void ExpiryTargetAdjust(TSignal &s)
  {
   if(!InpP6ExpiryTargets || s.stype != STYPE_BREAKOUT)
      return;
   if(!IsExpiryWindow(EtYmd(g_ctx.nowUtc)))
      return;
   double risk = RiskPx(s);
   if(risk <= 0.0)
      return;
   double rr = (s.tp - s.entry) * s.dir / risk;
   double nr = MathMax(InpMinRR, rr * Clamp(InpP6TargetMult, 0.5, 1.0));
   if(nr >= rr)
      return;
   s.tp = NormPrice(s.entry + s.dir * risk * nr);
   s.why += " | P6 scadenza opzioni: target " + DoubleToString(nr, 2) + "R";
  }

//--- ritocchi del segnale prima del voto (P5, P6)
void SignalAdjust(TSignal &s)
  {
   AsiaStopAdjust(s);
   ExpiryTargetAdjust(s);
  }

//--- MR (1.25): le obiezioni secondarie bloccano, a meno di conferme forti
//    (nessun veto obbligatorio, 7/8 desk, punteggio sopra la soglia, strategia buona, al massimo 2 obiezioni)
bool StrongConfirm(const TSignal &s, double score)
  {
   return (InpOverrideOn && !s.veto && s.softN <= InpOverrideMaxSoft && s.quorum >= InpOverrideQuorum &&
           score >= MinScoreFor(s.engine) + InpOverrideExtraScore - 0.000001 && s.desk[D_STRAT] >= 0.6 && s.devil <= InpDevilMax + 1);
  }

void ResolveSoft(TSignal &s, double score)
  {
   s.overrideOk = false;
   if(s.softN <= 0)
      return;
   if(StrongConfirm(s, score))
      s.overrideOk = true;
   else
      Veto(s, s.softWhy);
  }

//--- il comitato vota il segnale
void Committee(TSignal &s)
  {
   //--- 1.26: i movimenti forti hanno regole proprie, misurate sui dati 2022-2026 senza i filtri del comitato:
   //    li fermano solo le obiezioni obbligatorie (limiti di rischio, news, costi, liquidita', T5).
   //    Punteggio e desk restano nel diario. Chi di loro apre ordini lo decide l'osservazione (OS).
   s.proven = ((IsTrendMove(s.strat) && InpTDProven) || (IsOnda(s.strat) && InpOndaProven));
   RdEval(s);                               // 1.27: letture del mercato a favore e contro (diario, misura, rischio)
   double risk = RiskPx(s);
   double reward = (s.tp - s.entry) * s.dir;
   if(risk <= 0.0 || reward < InpMinRR * risk - g_tick)
      Veto(s, "R:R sotto 1:" + DoubleToString(InpMinRR, 1));
   //--- motori del prezzo (1.17)
   string thin = "";
   if(ThinLiquidity(g_ctx.nowUtc, g_ctx.hUtc, g_ctx.lonOpen, thin))
      Veto(s, thin);
   if(g_runBrake && s.dir > 0 && s.stype == STYPE_BREAKOUT)
      Veto(s, "P1 corsa verticale (" + DoubleToString(g_runZ, 1) + " sigma, distanza dalla media 200 " + DoubleToString(g_ma200Dist, 0) + "%): niente long in rottura");
   string fixWhy = "";
   if(FixChase(s, fixWhy))
      Veto(s, fixWhy);
   s.desk[D_STRAT] = s.quality;
   s.desk[D_TREND] = DeskTrend(s);
   s.desk[D_VOLUME] = DeskVolume(s);
   s.desk[D_LIQ] = DeskLiquidity(s);
   s.desk[D_MACRO] = DeskMacro(s);
   s.desk[D_NEWS] = DeskNews(s);
   s.desk[D_SESSION] = DeskSession(s);
   s.desk[D_COST] = DeskCost(s);
   s.desk[D_STATS] = DeskStats(s);
   s.desk[D_CONTEXT] = DeskContext(s);
   PortfolioChecks(s);
   string objections = "";
   s.devil = DevilsAdvocate(s, objections);
   if(g_devilProven != "" && !s.proven)
      Veto(s, "obiezione provata: " + g_devilProven);
   if(s.devil >= InpDevilMax && !s.proven)
     {
      s.softN++;                            // MR (1.25): l'avvocato del diavolo e' un'obiezione secondaria
      if(s.softWhy != "")
         s.softWhy += "; ";
      s.softWhy += "avvocato del diavolo: " + objections;
     }
   //--- quorum sugli 8 desk principali
   s.quorum = 0;
   if(s.desk[D_CONTEXT] >= 0.5)
      s.quorum++;
   if(s.desk[D_MACRO] >= 0.5)
      s.quorum++;
   if(s.desk[D_STRAT] >= 0.5)
      s.quorum++;
   if(s.desk[D_TREND] >= 0.5)
      s.quorum++;
   if(s.desk[D_VOLUME] >= 0.5)
      s.quorum++;
   if(s.desk[D_LIQ] >= 0.5)
      s.quorum++;
   if(s.desk[D_NEWS] >= 0.5)
      s.quorum++;
   if(s.desk[D_COST] >= 0.5)
      s.quorum++;
   double score = 0.0;
   bool unanimous = true;
   for(int d = 0; d < NDESK; d++)
     {
      score += DeskWeight(s.engine, d) * s.desk[d];
      if(s.desk[d] < 0.55)
         unanimous = false;
     }
   if(unanimous)
      score += 0.03;
   if(InpP4FirstDayLong && s.dir > 0 && IsFirstTradingDay(EtYmd(g_ctx.nowUtc)))
      score += InpP4Bonus;                  // P4 (1.17): primo giorno di borsa del mese
   if(TightAsiaBonus(s))
      score += InpC3Bonus;                  // C3 (1.20): Asia stretta, piu' probabile la spazzata dei due lati
   s.score = score;
   ResolveSoft(s, score);
   //--- coda (1.17): con altre posizioni o ordini aperti, la nuova idea deve essere piu' sicura
   //    (solo per le idee che passerebbero da sole: le altre restano respinte con il loro motivo)
   //    1.27: i ritracciamenti aperti non fanno coda per le altre strategie (sono quasi sempre aperti)
   if(InpQueueOn && !s.proven && !s.veto && g_cntAll - g_cntOnda > 0 && score >= MinScoreFor(s.engine) && s.quorum >= InpQuorum &&
      (score < MinScoreFor(s.engine) + InpQueueExtraScore || s.quorum < InpQuorum + 1))
      Veto(s, "coda: c'e' gia' una posizione aperta, servono punteggio " + DoubleToString(MinScoreFor(s.engine) + InpQueueExtraScore, 2) +
           " e quorum " + IntegerToString(InpQuorum + 1) + "/8");
   s.strong = (!s.veto && !s.overrideOk && !s.proven && score >= InpStrongScore && s.quorum >= 7);
   s.passed = (!s.veto && s.quorum >= InpQuorum && score >= MinScoreFor(s.engine));
   if(s.proven)
      s.passed = !s.veto;
  }

string DeskLine(const TSignal &s)
  {
   string t = "";
   for(int d = 0; d < NDESK; d++)
      t += g_deskShort[d] + " " + DoubleToString(s.desk[d], 2) + (d < NDESK - 1 ? " | " : "");
   return t;
  }
//+------------------------------------------------------------------+
//| Risk manager: limiti del conto, lotti dinamici, profit cushion,  |
//| recupero, scaglioni, esecuzione                                  |
//+------------------------------------------------------------------+
bool TradingHalted(string &why)
  {
   if(g_ddHalt)
     {
      why = "STOP per drawdown massimo: per ripartire imposta 'Sblocca' = true";
      return true;
     }
   if(g_weekHalt)
     {
      why = "stop settimanale raggiunto (-" + DoubleToString(InpWeeklyLossPct, 1) + "%)";
      return true;
     }
   if(g_dayHalt)
     {
      why = "stop giornaliero raggiunto (-" + DoubleToString(InpDailyLossPct, 1) + "%)";
      return true;
     }
   if(!g_isTester && (!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED)))
     {
      why = "trading automatico disattivato (pulsante Algo Trading)";
      return true;
     }
   return false;
  }

void CloseAll(string why)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym || !IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      g_trade.PositionClose(tk);
     }
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong tk = OrderGetTicket(i);
      if(tk == 0)
         continue;
      if(OrderGetString(ORDER_SYMBOL) != g_sym || !IsOurMagic(OrderGetInteger(ORDER_MAGIC)))
         continue;
      g_trade.OrderDelete(tk);
     }
   g_needSweep = true;
   Notify("CHIUSO TUTTO: " + why);
  }

//--- nuovo giorno / nuova settimana del broker
void RiskPeriodCheck()
  {
   datetime dA = iTime(g_sym, PERIOD_D1, 0);
   datetime wA = iTime(g_sym, PERIOD_W1, 0);
   bool changed = false;
   if(dA != 0 && dA != g_dayAnchor)
     {
      g_dayAnchor = dA;
      g_dayStartEq = AccEquity();
      g_dayHalt = false;
      g_tradesToday[0] = 0;
      g_tradesToday[1] = 0;
      g_tradesToday[2] = 0;
      g_lossesInRowToday = 0;
      changed = true;
     }
   if(wA != 0 && wA != g_weekAnchor)
     {
      g_weekAnchor = wA;
      g_weekStartEq = AccEquity();
      g_weekStartBal = AccBalance();
      g_weekHalt = false;
      changed = true;
     }
   if(changed)
      GvSave();
  }

//+------------------------------------------------------------------+
//| Depositi e prelievi: il bot si adatta al nuovo saldo ma NON li   |
//| scambia per guadagni o perdite (niente falsi stop giornalieri)   |
//+------------------------------------------------------------------+
datetime g_flowCheckedTo = 0;
double   g_lastRealBal = 0.0;

void ApplyCashFlow(double amount, datetime when)
  {
   if(amount == 0.0)
      return;
   if(InpVirtualCapital > 0.0)
     {
      //--- con il capitale virtuale i movimenti del conto vero non lo cambiano
      g_vStartBal += amount;
      g_vStartEq += amount;
      GlobalVariableSet(GvName("vStartBal"), g_vStartBal);
      GlobalVariableSet(GvName("vStartEq"), g_vStartEq);
     }
   else
     {
      //--- conto vero: i riferimenti si spostano insieme al saldo (non e' un guadagno ne' una perdita)
      g_dayStartEq += amount;
      g_weekStartEq += amount;
      g_weekStartBal += amount;
      g_peakEq = MathMax(g_peakEq + amount, AccEquity());
     }
   GvSave();
   string what = (amount > 0.0) ? "Deposito" : "Prelievo";
   Notify(what + " di " + Money(MathAbs(amount)) + ": lotti e limiti ricalcolati sul nuovo saldo (" + Money(AccEquity()) + ")");
  }

//--- cerca depositi/prelievi nello storico dall'ultimo controllo
void CashFlowScan()
  {
   if(g_isTester)
      return;
   datetime now = ServerNow();
   datetime from = g_flowCheckedTo;
   if(from <= 0)
     {
      from = (datetime)GvGet("flowTo", 0.0);
      if(from <= 0)
        {
         g_flowCheckedTo = now;
         GlobalVariableSet(GvName("flowTo"), (double)now);
         return;
        }
     }
   if(!HistorySelect(from + 1, now + 60))
      return;
   int n = HistoryDealsTotal();
   for(int i = 0; i < n; i++)
     {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0)
         continue;
      if(HistoryDealGetInteger(d, DEAL_TYPE) != DEAL_TYPE_BALANCE)
         continue;
      ApplyCashFlow(HistoryDealGetDouble(d, DEAL_PROFIT), (datetime)HistoryDealGetInteger(d, DEAL_TIME));
     }
   g_flowCheckedTo = now;
   GlobalVariableSet(GvName("flowTo"), (double)now);
  }

//--- il saldo vero e' cambiato: prima di tutto controllo se e' un deposito/prelievo
void FlowCheck()
  {
   if(g_isTester)
      return;
   double rb = AccountInfoDouble(ACCOUNT_BALANCE);
   if(rb != g_lastRealBal)
     {
      g_lastRealBal = rb;
      CashFlowScan();
     }
  }

//--- controllato a ogni tick
void RiskCheckLimits()
  {
   FlowCheck();
   double eq = AccEquity();
   if(eq <= 0.0)
      return;
   if(eq > g_peakEq)
     {
      g_peakEq = eq;
      if(!g_isTester && MathRand() % 50 == 0)
         GlobalVariableSet(GvName("peak"), g_peakEq);
     }
   if(!g_ddHalt && g_peakEq > 0.0 && eq <= g_peakEq * (1.0 - InpMaxDrawdownPct / 100.0))
     {
      g_ddHalt = true;
      CloseAll("drawdown " + Pct(InpMaxDrawdownPct) + " dal picco. L'EA si ferma.");
      GvSave();
      return;
     }
   if(!g_weekHalt && g_weekStartEq > 0.0 && eq <= g_weekStartEq * (1.0 - InpWeeklyLossPct / 100.0))
     {
      g_weekHalt = true;
      CloseAll("stop settimanale -" + Pct(InpWeeklyLossPct));
      GvSave();
      return;
     }
   if(!g_dayHalt && g_dayStartEq > 0.0 && eq <= g_dayStartEq * (1.0 - InpDailyLossPct / 100.0))
     {
      g_dayHalt = true;
      CloseAll("stop giornaliero -" + Pct(InpDailyLossPct));
      GvSave();
     }
  }

//--- perdita per 1 lotto fino allo stop, commissione inclusa (valuta del conto)
double LossPerLot(int dir, double entry, double sl)
  {
   double p = 0.0;
   ENUM_ORDER_TYPE t = (dir > 0) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   if(!OrderCalcProfit(t, g_sym, 1.0, entry, sl, p) || p == 0.0)
      p = -(entry - sl) * dir * ValuePerPriceUnit();
   return MathAbs(p) + CommPerLotEff();   // K (1.25): commissione misurata se disponibile
  }

//--- V (1.25): volatilita' prevista per le prossime ore rispetto al normale.
//    ATR H1 rispetto alla sua mediana, corretto con l'attivita' dell'ultima ora (studio order flow: piu' tick del
//    solito -> ora dopo piu' ampia, elasticita' circa 0,3 in tutti i periodi 2022-2026)
double VolForecast()
  {
   double a = (g_atrRatioH1 > 0.0) ? g_atrRatioH1 : 1.0;
   double rv = RvolBar(g_h1, 1);
   if(rv <= 0.0)
      rv = 1.0;                              // senza dati di volume: nessuna correzione
   rv = Clamp(rv, 0.5, 3.0);
   return Clamp(a * MathPow(rv, 0.3), 0.3, 5.0);
  }

//--- V (1.25): moltiplicatore del rischio (Moreira-Muir: esposizione inversa alla volatilita' prevista),
//    solo verso il basso: sotto 1,2 volte il normale non cambia nulla
double VolTargetMult()
  {
   if(!InpVolTarget)
      return 1.0;
   double fc = VolForecast();
   if(fc <= 1.2)
      return 1.0;
   return Clamp(1.2 / fc, Clamp(InpVolMinMult, 0.1, 1.0), 1.0);
  }

double BaseCapital()
  {
   return MathMin(AccEquity(), AccBalance());
  }

//--- recupero: una sola volta dopo una perdita, solo con idee di altissima qualita'
bool RecoveryEligible(const TSignal &s)
  {
   if(!InpRecoveryEnabled || !g_recoveryArmed)
      return false;
   if(TimeCurrent() - g_recoveryArmedT > 24 * 3600)
      return false;
   if(!(s.strat == ST_SC_VWAP || s.strat == ST_IN_PULLBACK || s.strat == ST_SW_TREND))
      return false;
   if(s.score < InpRecoveryMinScore || s.desk[D_VOLUME] < 0.6 || s.desk[D_MACRO] < 0.5 || s.desk[D_CONTEXT] < 0.55)
      return false;
   int conf = 0;
   if(s.desk[D_TREND] >= 0.6)
      conf++;
   if(s.desk[D_VOLUME] >= 0.6)
      conf++;
   if(s.desk[D_LIQ] >= 0.6)
      conf++;
   if(s.desk[D_SESSION] >= 0.6)
      conf++;
   if(conf < 3)
      return false;
   int m = MinutesToNextTier1(g_ctx.nowUtc);
   int need = (s.engine == ENG_SWING) ? 720 : 240;
   if(m >= 0 && m < need)
      return false;
   if(g_regime == REG_VOLATILE)
      return false;
   return true;
  }

//--- rientro (1.17): il trade di prima e' tornato a pareggio e le conferme ci sono ancora
bool ReentryEligible(const TSignal &s)
  {
   int e = s.engine;
   if(!InpReentryOn || s.recovery || e < 0 || e > 2 || !g_reArmed[e] || s.dir != g_reDir[e])
      return false;
   int win = (e == ENG_SCALP) ? 60 : ((e == ENG_INTRA) ? 240 : 1440);
   if(TimeCurrent() - g_reT[e] > win * 60)
      return false;
   if(s.score < MinScoreFor(e) + 0.03 || s.quorum < InpQuorum + 1 || s.devil > 1)
      return false;
   if(s.desk[D_CONTEXT] < 0.55 || s.desk[D_MACRO] < 0.5)
      return false;
   return true;
  }

//--- idea A+ (1.18): tutte le conferme insieme -> rischio piu' alto, lotti fino a InpAplusMaxLots
bool AplusEligible(const TSignal &s, int against)
  {
   if(!InpAplusOn || s.recovery || against > 0 || g_regime == REG_VOLATILE || g_runBrake || g_lossStreak >= 2)
      return false;
   double need = MathMax(InpAplusMinScore, MinScoreFor(s.engine) + 0.05);
   if(s.score < need - 0.000001 || s.quorum < 7 || s.devil > 1)
      return false;
   if(s.desk[D_CONTEXT] < 0.55 || s.desk[D_MACRO] < 0.5)
      return false;
   return true;
  }

//--- riduce i lotti finche' il margine resta sopra il livello minimo
double FitMargin(int dir, double entry, double lots, string &why)
  {
   double m1 = 0.0;
   ENUM_ORDER_TYPE t = (dir > 0) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   if(!OrderCalcMargin(t, g_sym, 1.0, entry, m1) || m1 <= 0.0)
      return lots;
   double eq = AccEquity();
   double used = AccountInfoDouble(ACCOUNT_MARGIN);
   double allow = eq * 100.0 / MathMax(InpMinMarginLevel, 100.0) - used;
   double maxLots = FloorLot(allow / m1);
   if(maxLots < lots)
     {
      lots = maxLots;
      if(lots < g_minLot)
         why = "margine insufficiente: con questa leva 0.01 lotti richiedono " + Money(m1 * g_minLot);
     }
   return lots;
  }

//--- lotti per il segnale: rischio % -> denaro -> lotti, con tutti i limiti
//--- 1.26: rischio massimo accettato con il lotto minimo (i movimenti forti hanno stop larghi: tetto proprio, mai oltre il massimo per trade)
double OndaMinLotCap();
double ReadRiskMult(const TSignal &s);

double MinLotCapFor(const TSignal &s)
  {
   if(IsOnda(s.strat))
      return OndaMinLotCap();                   // 1.27: tetto proprio dei ritracciamenti
   if(s.proven)
      return MathMax(MathMin(InpTDMinLotRiskPct, InpMaxRiskPerTrade), InpMinLotMaxRiskPct);
   return InpMinLotMaxRiskPct;
  }

double LotsFor(TSignal &s, double &riskMoneyOut, string &why)
  {
   riskMoneyOut = 0.0;
   double base = BaseCapital();
   if(base <= 0.0)
     {
      why = "conto senza capitale";
      return 0.0;
     }
   double pct = InpRiskPercent;
   if(s.engine == ENG_SCALP)
      pct *= InpScalpRiskMult;
   else
      if(s.engine == ENG_SWING)
         pct *= InpSwingRiskMult;
   //--- regime volatile (x0,5) e C1 giornata larga (1.20) sono gia' tagli per volatilita':
   //    V (1.25) prende il taglio piu' forte tra quelli e la volatilita' prevista, senza sommarli
   double c1f = (g_bigDay && s.engine != ENG_SWING) ? Clamp(InpC1RiskMult, 0.0, 1.0) : 1.0;
   double oldVol = ((g_regime == REG_VOLATILE) ? 0.5 : 1.0) * c1f;
   double vmult = VolTargetMult();
   pct *= MathMin(oldVol, vmult);
   if(g_runBrake)
      pct *= Clamp(InpP1RiskMult, 0.0, 1.0);   // P1 (1.17): corsa verticale, rischio ridotto
   if(MacroFresh())
      pct *= Clamp(g_macroRiskMult, 0.5, 1.2);
   //--- macro o contesto contrari (ma non abbastanza per il veto): posizione piu' piccola
   int against = 0;
   if(g_mConf >= 0.3 && g_mBias * s.dir < -0.2)
      against++;
   if(g_ctxBias * s.dir < -0.2)
      against++;
   pct *= (1.0 - 0.25 * against);
   s.recovery = RecoveryEligible(s);
   if(s.recovery)
      pct *= InpRecoveryMult;
   else
      if(g_lossStreak >= 3)
         pct *= 0.5;
      else
         if(g_lossStreak == 2)
            pct *= 0.75;
   s.reentry = ReentryEligible(s);
   if(s.reentry)
      pct *= Clamp(InpReentryMult, 1.0, 2.0);
   if(s.overrideOk)
      pct *= Clamp(InpOverrideRiskMult, 0.2, 1.0);   // MR (1.25): passa scavalcando obiezioni secondarie, rischio ridotto
   s.aplus = !s.overrideOk && AplusEligible(s, against);
   if(s.aplus)
      pct = MathMax(pct, Clamp(InpAplusRiskPct, 0.0, InpMaxRiskPerTrade) * (s.reentry ? Clamp(InpReentryMult, 1.0, 2.0) : 1.0) *
                    MathMin(c1f, vmult));   // C1 e V valgono anche per le A+
   if(s.proven)
     {
      //--- 1.26: movimenti forti: rischio base x moltiplicatore, ridotto solo dopo le perdite di fila.
      //    Macro, contesto e volatilita' non lo cambiano (sui dati non spostano il risultato); niente recupero, rientro o A+.
      pct = InpRiskPercent * TmRiskMult(s.strat) * Clamp(s.riskX, 0.25, 2.0);
      if(g_lossStreak >= 3)
         pct *= 0.5;
      else
         if(g_lossStreak == 2)
            pct *= 0.75;
      s.recovery = false;
      s.reentry = false;
      s.aplus = false;
     }
   pct *= ReadRiskMult(s);                      // 1.27: letture del mercato provate (contrarie: meno rischio)
   pct = MathMin(pct, InpMaxRiskPerTrade);
   double money = base * pct / 100.0;
   //--- profit cushion: le idee forti possono rischiare in piu' SOLO profitti gia' incassati in settimana
   double extra = 0.0;
   if(InpUseProfitCushion && s.strong && !s.recovery && !s.aplus)
     {
      double cushion = AccBalance() - g_weekStartBal;
      if(cushion > 0.0)
         extra = MathMin(cushion * InpCushionUse, money * InpCushionMaxMult);
     }
   s.cushion = extra;
   money += extra;
   PortfolioScan();
   double room = base * InpMaxOpenRiskPct / 100.0 + extra - g_openRiskMoney;
   if(room <= 0.0)
     {
      why = "rischio aperto gia' al massimo (" + Pct(InpMaxOpenRiskPct) + ")";
      return 0.0;
     }
   money = MathMin(money, room);
   //--- S (1.25): le posizioni sono tutte oro, quindi lo stesso verso e' una scommessa sola
   double roomDir = base * InpMaxDirRiskPct / 100.0 + extra - g_openRiskDir[(s.dir > 0) ? 0 : 1];
   if(InpMaxDirRiskPct > 0.0 && roomDir <= 0.0)
     {
      why = "rischio aperto nello stesso verso gia' al massimo (" + Pct(InpMaxDirRiskPct) + ")";
      return 0.0;
     }
   if(InpMaxDirRiskPct > 0.0)
     {
      money = MathMin(money, roomDir);
      room = MathMin(room, roomDir);
     }
   double lpl = LossPerLot(s.dir, s.entry, s.sl);
   if(InpCostTrack)
      lpl += SlipEstPx(g_ctx.spread) * ValuePerPriceUnit();   // K (1.25): lo slittamento medio fa parte del rischio vero
   if(lpl <= 0.0)
     {
      why = "calcolo della perdita per lotto fallito";
      return 0.0;
     }
   double lots = FloorLot(money / lpl);
   if(lots < g_minLot)
     {
      double minRisk = lpl * g_minLot;
      double minPct = 100.0 * minRisk / base;
      double capMin = MinLotCapFor(s);
      if(minPct <= capMin && minRisk <= room + base * 0.005)
         lots = g_minLot;
      else
        {
         why = "conto piccolo per questo stop: " + DoubleToString(g_minLot, g_lotDigits) + " lotti = " + Pct(minPct) +
               " di rischio (max " + Pct(capMin) + ", servono circa " + DoubleToString(minRisk * 100.0 / MathMax(capMin, 0.1), 0) + " " + g_currency + ")";
         return 0.0;
        }
     }
   lots = MathMin(lots, MathMin(InpMaxLots, g_maxLot));
   if(s.aplus && InpAplusMaxLots > 0.0)
      lots = MathMin(lots, MathMax(FloorLot(InpAplusMaxLots), g_minLot));
   lots = FitMargin(s.dir, s.entry, lots, why);
   if(lots < g_minLot)
     {
      if(why == "")
         why = "lotti sotto il minimo";
      return 0.0;
     }
   riskMoneyOut = lots * lpl;
   return lots;
  }

//--- distanza minima dello stop dal prezzo imposta dal broker
double StopsMinDist()
  {
   long lvl = SymbolInfoInteger(g_sym, SYMBOL_TRADE_STOPS_LEVEL);
   long frz = SymbolInfoInteger(g_sym, SYMBOL_TRADE_FREEZE_LEVEL);
   long m = (lvl > frz) ? lvl : frz;
   return (double)m * g_point + g_tick;
  }

double g_sendReqPx = 0.0, g_sendSpread = 0.0;
string g_execWhy = "";

bool RetOk(uint rc) { return (rc == TRADE_RETCODE_DONE || rc == TRADE_RETCODE_PLACED || rc == TRADE_RETCODE_DONE_PARTIAL); }

int MetaRecord(const TSignal &s, long id, int tranche, double lots, double entry, bool pending, int expiryMin)
  {
   int k = MetaFree();
   if(k < 0)
      return -1;
   g_meta[k].Reset();
   g_meta[k].active = true;
   g_meta[k].id = id;
   g_meta[k].strat = s.strat;
   g_meta[k].engine = s.engine;
   g_meta[k].dir = s.dir;
   g_meta[k].tranche = tranche;
   g_meta[k].idea = g_ideaSeq;
   g_meta[k].entry = entry;
   g_meta[k].sl0 = s.sl;
   g_meta[k].tp = s.tp;
   g_meta[k].riskPx = (entry - s.sl) * s.dir;
   g_meta[k].riskMoney = lots * LossPerLot(s.dir, entry, s.sl);
   g_meta[k].lots0 = lots;
   g_meta[k].score = s.score;
   g_meta[k].cushion = s.cushion;
   g_meta[k].recovery = s.recovery;
   g_meta[k].reentry = s.reentry;
   g_meta[k].aplus = s.aplus;
   g_meta[k].isPending = pending;
   g_meta[k].openTime = TimeCurrent();
   g_meta[k].expiryMin = expiryMin;
   g_meta[k].deadline = s.deadline;
   return k;
  }

bool SendMarket(const TSignal &s, double lots, long &idOut)
  {
   double sl = NormPrice(s.sl), tp = NormPrice(s.tp);
   double px = (s.dir > 0) ? PxAsk() : PxBid();
   double md = StopsMinDist();
   if((px - sl) * s.dir < md || (tp - px) * s.dir < md)
     {
      Logf("Ordine saltato: stop o target troppo vicini al prezzo per il broker");
      return false;
     }
   g_trade.SetExpertMagicNumber((ulong)MagicOfEngine(s.engine));
   g_sendReqPx = px;                       // K (1.25): prezzo visto all'invio e spread pagato
   g_sendSpread = PxAsk() - PxBid();
   string cmt = "XC " + g_stratName[s.strat];
   bool ok = (s.dir > 0) ? g_trade.Buy(lots, g_sym, 0.0, sl, tp, cmt) : g_trade.Sell(lots, g_sym, 0.0, sl, tp, cmt);
   uint rc = g_trade.ResultRetcode();
   if(!ok || !RetOk(rc))
     {
      Logf("Ordine rifiutato: " + IntegerToString((int)rc) + " " + g_trade.ResultRetcodeDescription());
      return false;
     }
   idOut = (long)g_trade.ResultOrder();
   ulong deal = g_trade.ResultDeal();
   if(deal > 0 && HistoryDealSelect(deal))
     {
      long pid = HistoryDealGetInteger(deal, DEAL_POSITION_ID);
      if(pid > 0)
         idOut = pid;
     }
   return true;
  }

bool SendLimit(const TSignal &s, double lots, double price, long &idOut)
  {
   price = NormPrice(price);
   double sl = NormPrice(s.sl), tp = NormPrice(s.tp);
   double px = (s.dir > 0) ? PxAsk() : PxBid();
   double md = StopsMinDist();
   if((px - price) * s.dir < md || (price - sl) * s.dir < md)
      return false;
   g_trade.SetExpertMagicNumber((ulong)MagicOfEngine(s.engine));
   string cmt = "XC " + g_stratName[s.strat] + " T";
   bool ok = (s.dir > 0) ? g_trade.BuyLimit(lots, price, g_sym, sl, tp, ORDER_TIME_GTC, 0, cmt)
             : g_trade.SellLimit(lots, price, g_sym, sl, tp, ORDER_TIME_GTC, 0, cmt);
   if(!ok || !RetOk(g_trade.ResultRetcode()))
      return false;
   idOut = (long)g_trade.ResultOrder();
   return true;
  }

int ExpiryFor(int engine)
  {
   if(engine == ENG_SCALP)
      return 10;
   if(engine == ENG_INTRA)
      return 60;
   return 480;
  }

string TmHoldText();

//--- esegue un segnale approvato (con eventuali ingressi scaglionati)
int CloseOppOnda(int dir, string why);

bool Execute(TSignal &s)
  {
   double riskMoney = 0.0;
   string why = "";
   g_execWhy = "";
   //--- 1.27: movimento forte contro ritracciamenti ancora a rischio: prima li chiude (liberano posto e rischio)
   if(s.flip)
     {
      int nc = CloseOppOnda(s.dir, "movimento forte " + DirName(s.dir) + " contro il ritracciamento");
      if(nc > 0)
         Notify(g_stratName[s.strat] + " " + DirName(s.dir) + ": chiusi " + IntegerToString(nc) + " ritracciamenti aperti nel verso opposto prima di entrare");
     }
   double lots = LotsFor(s, riskMoney, why);
   if(lots <= 0.0)
     {
      g_execWhy = why;
      string line = "[" + g_engName[s.engine] + "] " + g_stratName[s.strat] + " " + DirName(s.dir) + " approvato ma NON eseguito: " + why;
      Logf(line);
      RememberDecision(line);
      return false;
     }
   g_ideaSeq++;
   double w[3];
   w[0] = 1.0;
   w[1] = 0.0;
   w[2] = 0.0;
   double depth[3];
   depth[0] = 0.0;
   depth[1] = 0.25;
   depth[2] = 0.5;
   int nTr = 1;
   PortfolioScan();
   int slots = MaxPositionsEff() - g_cntAll;
   //--- coda (1.17): gli ingressi scaglionati lasciano un posto a ogni altro motore attivo e vuoto
   if(InpQueueOn)
     {
      if(s.engine != ENG_SCALP && InpEnableScalping && g_cntEng[ENG_SCALP] == 0)
         slots--;
      if(s.engine != ENG_INTRA && InpEnableIntraday && g_cntEng[ENG_INTRA] == 0)
         slots--;
      if(s.engine != ENG_SWING && InpEnableSwing && g_cntEng[ENG_SWING] == 0)
         slots--;
     }
   if(InpAllowTranches && s.strong && s.engine != ENG_SCALP && !g_netting && !s.recovery && !s.aplus)
     {
      if(slots >= 3 && FloorLot(lots * 0.3) >= g_minLot)
        {
         nTr = 3;
         w[0] = 0.4;
         w[1] = 0.3;
         w[2] = 0.3;
        }
      else
         if(slots >= 2 && FloorLot(lots * 0.4) >= g_minLot)
           {
            nTr = 2;
            w[0] = 0.6;
            w[1] = 0.4;
           }
     }
   double risk = RiskPx(s);
   int opened = 0;
   double total = 0.0;
   for(int k = 0; k < nTr; k++)
     {
      double lk = (nTr == 1) ? lots : FloorLot(lots * w[k]);
      if(lk < g_minLot)
         continue;
      long id = 0;
      if(k == 0)
        {
         if(!SendMarket(s, lk, id))
            break;
         double fill = g_trade.ResultPrice();
         if(fill <= 0.0)
            fill = s.entry;
         int mk = MetaRecord(s, id, 0, lk, fill, false, 0);
         //--- K (1.25): slittamento e spread di questo ingresso
         double slip = (g_sendReqPx > 0.0) ? (fill - g_sendReqPx) * s.dir : 0.0;
         if(mk >= 0)
           {
            g_meta[mk].spreadPx = g_sendSpread;
            g_meta[mk].slipPx = slip;
           }
         if(InpCostTrack && g_sendReqPx > 0.0)
           {
            g_costSlipPx = CostAvg(g_costSlipPx, g_costSlipN, slip);
            g_costSlipN++;
            g_costSpreadPx = CostAvg(g_costSpreadPx, g_costSpreadN, g_sendSpread);
            g_costSpreadN++;
           }
        }
      else
        {
         double price = s.entry - s.dir * depth[k] * risk;
         if(!SendLimit(s, lk, price, id))
            continue;
         MetaRecord(s, id, k, lk, price, true, ExpiryFor(s.engine));
        }
      opened++;
      total += lk;
     }
   if(opened == 0)
     {
      g_execWhy = "ordine non eseguito dal broker";
      return false;
     }
   g_execWhy = "aperto";
   if(!(IsOnda(s.strat) && InpOndaNoDayLimit))
      g_tradesToday[s.engine]++;
   if(s.recovery)
      g_recoveryArmed = false;
   if(s.reentry)
      g_reArmed[s.engine] = false;
   string extra = "";
   if(s.recovery)
      extra += " | RECUPERO x" + DoubleToString(InpRecoveryMult, 2);
   if(s.reentry)
      extra += " | RIENTRO dopo pareggio x" + DoubleToString(InpReentryMult, 2);
   if(s.aplus)
      extra += " | A+ tutte le conferme";
   if(s.cushion > 0.0)
      extra += " | extra dai profitti " + Money(s.cushion);
   if(s.overrideOk)
      extra += " | conferme forti, scavalca: " + StringSubstr(s.softWhy, 0, 90) + " (rischio x" + DoubleToString(InpOverrideRiskMult, 2) + ")";
   if(opened > 1)
      extra += " | " + IntegerToString(opened) + " ingressi scaglionati";
   if(s.proven && IsOnda(s.strat))
      extra += " | ritracciamento nel trend, tempo massimo fino al " + TimeToString(s.deadline, TIME_DATE | TIME_MINUTES) + " UTC";
   else
      if(s.proven)
         extra += " | movimento forte: " + TmHoldText();
   if(ReadRiskMult(s) != 1.0)
     {
      string rdw = (s.rdConf < 0) ? "contrarie" : "a favore";
      extra += " | letture provate " + rdw + ": rischio x" + DoubleToString(ReadRiskMult(s), 2);
     }
   if(!s.proven && VolTargetMult() < 0.999)
      extra += " | volatilita' prevista x" + DoubleToString(VolForecast(), 1) + ": rischio x" + DoubleToString(VolTargetMult(), 2);
   double base = BaseCapital();
   string msg = "APERTO [" + g_engName[s.engine] + "] " + g_stratName[s.strat] + " " + DirName(s.dir) + " " +
                DoubleToString(total, g_lotDigits) + " lotti @ " + DoubleToString(s.entry, g_digits) +
                " SL " + DoubleToString(s.sl, g_digits) + " TP " + DoubleToString(s.tp, g_digits) +
                " | rischio " + Money(riskMoney) + " (" + Pct(100.0 * riskMoney / MathMax(base, 0.01)) + ")" +
                " | score " + DoubleToString(s.score, 2) + extra;
   Notify(msg);
   RememberDecision(msg);
   return true;
  }
//+------------------------------------------------------------------+
//| MOVIMENTI FORTI (1.26)                                           |
//|                                                                  |
//| Studio sulle M1 2022-2026 (4 periodi, costi inclusi):            |
//| - IN-TREND, giornata di tendenza: quando tra le 8:05 e le 11:00  |
//|   di New York l'oro chiude una M1 a 0,8 escursioni medie dal     |
//|   prezzo delle 8:00, il movimento di solito continua. Stop 0,4   |
//|   escursioni, tenuto fino a sera: +0,31R a trade (t 2,7, 4/4);   |
//|   tenuto fino alla sera del giorno dopo con il pareggio a 1,5R:  |
//|   +0,43R (4/4). Giocato dall'EA sulle candele vere: 109 trade,   |
//|   +0,35R, positivo in 4 periodi su 4. Macro, trend D1 e verso di |
//|   Asia/Londra non cambiano il risultato: passa senza quei filtri.|
//| - IN-DATO: dopo un CPI che sorprende in modo netto (totale e     |
//|   core dalla stessa parte) entra nel verso del dato: caldo =     |
//|   vende, freddo = compra, stessa tenuta. Il verso e' giusto 8-10 |
//|   volte su 10 ma buona parte del movimento arriva nel primo      |
//|   minuto. Giocato dall'EA sulle candele vere: 20 casi, +0,67R a  |
//|   trade, positivo in 4 periodi su 4, ma pochi casi (t 1,3):      |
//|   apre ordini a meta' rischio. NFP, PCE, PPI e vendite al        |
//|   dettaglio non reggono: solo avviso.                            |
//| - IN-NOTTE: lo stesso segnale di notte e a Londra (dal prezzo    |
//|   delle 18:00 di New York): sulla carta +0,17R ma non lontano    |
//|   dal caso -> parte in osservazione.                             |
//| Escursione media = media di (massimo - minimo) delle ultime 20   |
//| giornate chiuse.                                                 |
//+------------------------------------------------------------------+
bool InRollover();

#define TM_TREND 0
#define TM_DATA  1
#define TM_NIGHT 2
#define TM_TREND2 3
#define TM_N     4

int    g_tmDoneKey[TM_N];     // giornata (yyyymmdd) in cui la strategia ha gia' aperto, sulla carta o davvero
string g_tmDoneWhy[TM_N];
string g_tmText[TM_N];        // riga del pannello
double g_tdAnchor[2];         // prezzo delle 8:00 di New York di oggi (per il pannello); [0] primo ingresso, [1] secondo
int    g_tdCacheDay[2];
int    g_tdCrossDir[2];
datetime g_tdCrossUtc[2];

int TmSlot(int strat)
  {
   if(strat == ST_IN_DATA)
      return TM_DATA;
   if(strat == ST_IN_NIGHT)
      return TM_NIGHT;
   if(strat == ST_IN_TREND2)
      return TM_TREND2;
   return TM_TREND;
  }

void TmInit()
  {
   string keys[TM_N] = {"tmDay0", "tmDay1", "tmDay2", "tmDay3"};
   for(int v = 0; v < 2; v++)
     {
      g_tdAnchor[v] = 0.0;
      g_tdCacheDay[v] = 0;
      g_tdCrossDir[v] = 0;
      g_tdCrossUtc[v] = 0;
     }
   for(int i = 0; i < TM_N; i++)
     {
      g_tmDoneKey[i] = 0;
      g_tmDoneWhy[i] = "";
      g_tmText[i] = "";
      if(!g_isTester)
         g_tmDoneKey[i] = (int)GvGet(keys[i], 0.0);
      if(g_tmDoneKey[i] > 0)
         g_tmDoneWhy[i] = "gia' fatto (prima del riavvio)";
     }
  }

//--- la strategia ha fatto la sua mossa di oggi: non riprova (resta anche dopo un riavvio)
void TmMarkDone(int strat, int key, string why)
  {
   string keys[TM_N] = {"tmDay0", "tmDay1", "tmDay2", "tmDay3"};
   int k = TmSlot(strat);
   g_tmDoneKey[k] = key;
   g_tmDoneWhy[k] = why;
   if(!g_isTester)
      GlobalVariableSet(GvName(keys[k]), (double)key);
  }

//--- escursione media: massimo - minimo delle ultime 20 giornate chiuse
double TdAtr()
  {
   double sum = 0.0;
   int n = 0;
   for(int k = 0; k < 20; k++)
     {
      int i = TfIdx(g_d1, k);
      if(i < 0)
         break;
      double r = g_d1.r[i].high - g_d1.r[i].low;
      if(r > 0.0)
        {
         sum += r;
         n++;
        }
     }
   return (n >= 10) ? sum / n : 0.0;
  }

datetime DayStartUtc(datetime utc) { return (datetime)((long)utc - (long)utc % 86400); }

//--- le 8:00 di New York del giorno UTC di 'nowUtc'
datetime Ny8Utc(datetime nowUtc)
  {
   return DayStartUtc(nowUtc) + (datetime)MathRound((NYDataUTC(nowUtc) - 0.5) * 3600.0);
  }

//--- fine della tenuta: la sera (EveCloseUTC) dello stesso giorno o del giorno di borsa dopo
datetime TmExitUtc(datetime openUtc)
  {
   datetime d = DayStartUtc(openUtc);
   if(DowOf(openUtc) == 5 && HourOf(openUtc) < FridayEveUTC(openUtc))
      return d + (datetime)MathRound(FridayEveUTC(openUtc) * 3600.0);   // aperto di venerdi': chiude il venerdi' sera
   if(HourOf(openUtc) >= EveCloseUTC(openUtc))
      d += 86400;                              // aperto dopo la chiusura serale (notte): conta come il giorno dopo
   int hold = IMax(0, IMin(InpTDHoldDays, 5));
   int guard = 0;
   while(hold > 0 && guard < 12)
     {
      d += 86400;
      guard++;
      int dw = DowOf(d);
      if(dw != 0 && dw != 6)
         hold--;
     }
   return d + (datetime)MathRound(EveCloseUTC(d + 43200) * 3600.0);
  }

string TmHoldText()
  {
   if(InpTDHoldDays <= 0)
      return "tenuto fino a stasera";
   if(InpTDHoldDays == 1)
      return "swing tenuto fino alla sera del giorno di borsa dopo (venerdi' chiude la sera)";
   return "swing tenuto " + IntegerToString(InpTDHoldDays) + " giorni di borsa (venerdi' chiude la sera)";
  }

bool TmHasPosition(int strat)
  {
   for(int i = 0; i < MAX_META; i++)
      if(g_meta[i].active && g_meta[i].strat == strat)
         return true;
   return false;
  }

//--- finestra comune: mai nel weekend, nel rollover o il venerdi' sera
bool TmWindow()
  {
   if(g_ctx.dow == 0 || g_ctx.dow == 6 || InRollover())
      return false;
   if(g_ctx.dow == 5 && g_ctx.hUtc >= FridayEveUTC(g_ctx.nowUtc) - 2.0)
      return false;
   return true;
  }

//--- primo superamento: prima barra chiusa tra fromU e untilU con chiusura a 'thr' dal prezzo di partenza.
//    Prezzo di partenza: ultima chiusura nei 30 minuti prima di aU, altrimenti la prima apertura dopo.
bool TmScan(const TfData &d, int barSec, datetime aU, datetime fromU, datetime untilU, double thr,
            double &anchor, int &dir, datetime &crossU)
  {
   anchor = 0.0;
   dir = 0;
   crossU = 0;
   for(int i = 0; i < d.n; i++)
     {
      datetime tU = ToUTC(d.r[i].time);
      if(tU < aU)
        {
         if(tU >= aU - 1800)
            anchor = d.r[i].close;
         continue;
        }
      if(anchor <= 0.0)
        {
         if(tU >= aU + 1800)
            return false;                      // niente prezzi intorno all'ora di partenza: oggi non si guarda
         anchor = d.r[i].open;
        }
      if(tU < fromU || tU >= untilU)
         continue;
      double c = d.r[i].close;
      if(c >= anchor + thr)
        {
         dir = 1;
         crossU = tU + barSec;
         return true;
        }
      if(c <= anchor - thr)
        {
         dir = -1;
         crossU = tU + barSec;
         return true;
        }
     }
   return (anchor > 0.0);
  }

//--- segnale comune: stop in escursioni medie (piu' stretto, fino al minimo, se il conto non regge quello pieno:
//    stesso rischio in denaro, lotti piu' alti), target lontano
bool TmSignal(TSignal &s, int strat, int dir, double A, string why)
  {
   double entry = EntryPx(dir);
   double stopD = InpTDStopAtr * A;
   double minD = MathMin(InpTDStopMinAtr, InpTDStopAtr) * A;
   double base = BaseCapital();
   if(base > 0.0 && g_minLot > 0.0)
     {
      double cap = MathMax(MathMin(InpTDMinLotRiskPct, InpMaxRiskPerTrade), InpMinLotMaxRiskPct);
      double want = MathMin(InpRiskPercent * TmRiskMult(strat), InpMaxRiskPerTrade);
      for(int pass = 0; pass < 3; pass++)
        {
         double lpl = LossPerLot(dir, entry, entry - dir * stopD);
         if(InpCostTrack)
            lpl += SlipEstPx(g_ctx.spread) * ValuePerPriceUnit();
         double pctMin = 100.0 * lpl * g_minLot / base;
         if(pctMin <= want || pctMin <= cap || stopD <= minD)
            break;
         stopD = MathMax(minD, stopD * cap / pctMin * 0.98);
        }
     }
   double sl = entry - dir * stopD;
   double tp = entry + dir * MathMax(InpTDTargetAtr * A, InpMinRR * stopD + 3.0 * g_tick);
   string w = why + ", stop " + DoubleToString(stopD / A, 2) + " escursioni (" + DoubleToString(stopD, 1) + " $), " + TmHoldText();
   if(!MakeSignalTP(s, strat, dir, entry, sl, tp, 0.70, w))
      return false;
   s.proven = InpTDProven;
   return true;
  }

//--- IN-TREND: giornata di tendenza di New York (v = 0 primo ingresso; v = 1 secondo ingresso, soglia piu' lontana, 1.27)
bool S_InTrendV(TSignal &s, int v)
  {
   int strat = (v == 0) ? ST_IN_TREND : ST_IN_TREND2;
   int slot = (v == 0) ? TM_TREND : TM_TREND2;
   double thrAtr = (v == 0) ? InpTDThreshAtr : MathMax(InpTD2ThreshAtr, InpTDThreshAtr + 0.05);
   double A = TdAtr();
   if(A <= 0.0 || g_m1.n < 30)
     {
      g_tmText[slot] = "dati insufficienti";
      return false;
     }
   datetime now = g_ctx.nowUtc;
   int today = Ymd(now);
   datetime aU = Ny8Utc(now);
   int until = IMax(10, IMin(InpTDUntilMin, 200));
   int from = IMax(1, IMin(InpTDFromMin, until - 1));
   double thr = thrAtr * A;
   string win = TimeToString(aU + from * 60, TIME_MINUTES) + "-" + TimeToString(aU + until * 60, TIME_MINUTES) + " UTC";
   if(g_tdCacheDay[v] != today)
     {
      g_tdCacheDay[v] = today;
      g_tdAnchor[v] = 0.0;
      g_tdCrossDir[v] = 0;
      g_tdCrossUtc[v] = 0;
     }
   if(g_ctx.dow == 0 || g_ctx.dow == 6)
     {
      g_tmText[slot] = "mercato chiuso";
      return false;
     }
   if(now < aU + 60)
     {
      g_tmText[slot] = "guarda oggi " + win + " | soglia " + DoubleToString(thr, 1) + " $ dal prezzo delle 8:00 di New York";
      return false;
     }
   //--- finche' le barre delle 8:00 sono nel buffer M1 si ricalcola tutto dalle barre chiuse (regge i riavvii);
   //    dopo resta l'ultima lettura, solo per il pannello
   if(now <= aU + (until + InpTDMaxDelayMin + 2) * 60)
     {
      double an = 0.0;
      int dr = 0;
      datetime cu = 0;
      TmScan(g_m1, 60, aU, aU + from * 60, aU + until * 60, thr, an, dr, cu);
      g_tdAnchor[v] = an;
      g_tdCrossDir[v] = dr;
      g_tdCrossUtc[v] = cu;
     }
   double anchor = g_tdAnchor[v];
   int dir = g_tdCrossDir[v];
   datetime crossU = g_tdCrossUtc[v];
   if(anchor <= 0.0)
     {
      g_tmText[slot] = "oggi niente prezzi intorno alle 8:00 di New York";
      return false;
     }
   double c0 = BarC(g_m1, 0);
   double dist = (c0 - anchor) / A;
   string sign = (dist >= 0.0) ? "+" : "";
   string basic = "prezzo delle 8:00 NY " + DoubleToString(anchor, g_digits) + " | soglie " + DoubleToString(anchor + thr, g_digits) + " / " +
                  DoubleToString(anchor - thr, g_digits) + " | adesso " + sign + DoubleToString(dist, 2) + " escursioni";
   if(g_tmDoneKey[slot] == today)
     {
      g_tmText[slot] = "oggi " + g_tmDoneWhy[slot] + " | " + basic;
      return false;
     }
   if(dir == 0)
     {
      string wait = (now < aU + until * 60) ? "in attesa (" + win + ")" : "oggi nessun movimento forte";
      g_tmText[slot] = wait + " | " + basic;
      return false;
     }
   string dn = (dir > 0) ? "al rialzo" : "al ribasso";
   if(now > crossU + InpTDMaxDelayMin * 60 + 59)
     {
      g_tmText[slot] = "superamento " + dn + " alle " + TimeToString(crossU, TIME_MINUTES) + " UTC, ingresso non riuscito in tempo | " + basic;
      return false;
     }
   if((c0 - anchor) * dir < 0.75 * thr)
     {
      g_tmText[slot] = "superamento " + dn + " alle " + TimeToString(crossU, TIME_MINUTES) + " UTC, poi rientrato: aspetto | " + basic;
      return false;
     }
   string why = "giornata di tendenza " + dn + ": " + DoubleToString(MathAbs(dist), 2) + " escursioni medie dal prezzo delle 8:00 di New York (soglia " +
                DoubleToString(thrAtr, 2) + ")" + ((v == 1) ? ", secondo ingresso" : "");
   if(!TmSignal(s, strat, dir, A, why))
      return false;
   g_tmText[slot] = "superamento " + dn + ": ingresso | " + basic;
   return true;
  }

bool S_InTrendDay(TSignal &s) { return S_InTrendV(s, 0); }
bool S_InTrend2(TSignal &s) { return S_InTrendV(s, 1); }

//--- IN-DATO: dato d'inflazione con sorpresa netta -> nel verso del dato (caldo = vende, freddo = compra)
bool S_InData(TSignal &s)
  {
   double A = TdAtr();
   if(A <= 0.0)
      return false;
   datetime now = g_ctx.nowUtc;
   int today = Ymd(now);
   g_tmText[TM_DATA] = "";
   for(int k = 0; k < g_newsN; k++)
     {
      if(g_news[k].kind != 1 || g_news[k].surpN <= 0 || g_news[k].surpAt <= 0)
         continue;
      if(now < g_news[k].surpAt || now - g_news[k].utc > 6 * 3600)
         continue;
      int sp = g_news[k].surp;
      bool clear = (sp != 0 && MathAbs(sp) >= g_news[k].surpN);
      string verdict = DataVerdict(1, sp, g_news[k].surpN);
      if(!clear)
        {
         g_tmText[TM_DATA] = verdict + ": niente ingresso";
         continue;
        }
      if(g_tmDoneKey[TM_DATA] == today)
        {
         g_tmText[TM_DATA] = "oggi " + g_tmDoneWhy[TM_DATA];
         continue;
        }
      long late = (long)(now - g_news[k].surpAt);
      if(!g_isTester && late < 20)
        {
         g_tmText[TM_DATA] = verdict + ": dato appena letto, aspetto che i numeri siano completi";
         continue;
        }
      if(late > InpDataMaxDelayMin * 60 + 59 || now - g_news[k].utc > 15 * 60)
        {
         g_tmText[TM_DATA] = verdict + ": dato letto troppo tardi per entrare";
         continue;
        }
      int dir = (sp > 0) ? -1 : 1;
      string hot = (sp > 0) ? "caldo (sopra le attese): vendita" : "freddo (sotto le attese): acquisto";
      if(!TmSignal(s, ST_IN_DATA, dir, A, "dato d'inflazione " + hot + " | " + StringSubstr(g_news[k].surpText, 0, 80)))
         return false;
      g_tmText[TM_DATA] = verdict;
      return true;
     }
   return false;
  }

//--- IN-NOTTE: lo stesso movimento forte tra le 19:00 e le 8:00 di New York, dal prezzo delle 18:00 (barre M5)
bool S_InNight(TSignal &s)
  {
   double A = TdAtr();
   g_tmText[TM_NIGHT] = "";
   if(A <= 0.0 || g_m5.n < 60)
      return false;
   datetime now = g_ctx.nowUtc;
   datetime ny8 = Ny8Utc(now);
   if(now >= ny8 + 10 * 3600)
      ny8 += 86400;                            // dopo le 18:00 di New York la notte appartiene al giorno dopo
   datetime start = ny8 - 14 * 3600;           // le 18:00 di New York
   int key = Ymd(ny8);
   if(now < start + 3600 || now > ny8 + InpTDMaxDelayMin * 60 + 300)
      return false;
   if(g_tmDoneKey[TM_NIGHT] == key)
     {
      g_tmText[TM_NIGHT] = "stanotte " + g_tmDoneWhy[TM_NIGHT];
      return false;
     }
   double thr = InpTDThreshAtr * A;
   double anchor = 0.0;
   int dir = 0;
   datetime crossU = 0;
   if(!TmScan(g_m5, 300, start, start + 3600, ny8, thr, anchor, dir, crossU) || anchor <= 0.0)
      return false;
   double c0 = BarC(g_m1, 0);
   double dist = (c0 - anchor) / A;
   if(dir == 0)
     {
      g_tmText[TM_NIGHT] = "in attesa | dal prezzo delle 18:00 NY " + DoubleToString(dist, 2) + " escursioni";
      return false;
     }
   if(now > crossU + InpTDMaxDelayMin * 60 + 59 || (c0 - anchor) * dir < 0.75 * thr)
      return false;
   string dn = (dir > 0) ? "al rialzo" : "al ribasso";
   string why = "movimento forte fuori orario " + dn + ": " + DoubleToString(MathAbs(dist), 2) + " escursioni medie dal prezzo delle 18:00 di New York";
   if(!TmSignal(s, ST_IN_NIGHT, dir, A, why))
      return false;
   g_tmText[TM_NIGHT] = "superamento " + dn;
   return true;
  }

//--- righe del pannello
string TmPanel()
  {
   string t = "";
   if(StratEnabled(ST_IN_TREND))
     {
      string st = StratObserved(ST_IN_TREND) ? " (sulla carta)" : "";
      t += "Giornata di tendenza" + st + ": " + g_tmText[TM_TREND] + "\n";
     }
   if(StratEnabled(ST_IN_TREND2) && g_tdCrossDir[1] != 0)
     {
      string st2 = StratObserved(ST_IN_TREND2) ? " (sulla carta)" : "";
      t += "Secondo ingresso" + st2 + ": " + StringSubstr(g_tmText[TM_TREND2], 0, 110) + "\n";
     }
   int k = DataLastIndex(g_ctx.nowUtc, 12);
   if(k >= 0)
      t += "Ultimo dato: " + StringSubstr(DataText(k), 0, 200) + "\n";
   return t;
  }
//+------------------------------------------------------------------+
//| RITRACCIAMENTI NEL VERSO DEL TREND - "ONDA" (1.27)               |
//|                                                                  |
//| Studio sulle M1 2022-2026 (4 periodi, costi inclusi) e sull'oro  |
//| giornaliero 1975-2026:                                           |
//| - il prezzo si muove a onde. Un punto di svolta e' confermato    |
//|   quando una barra chiude a k escursioni medie dall'estremo.     |
//|   Entrare alla conferma di un minimo quando il trend giornaliero |
//|   (EMA20 sopra EMA50 sulle giornate chiuse) e' al rialzo, o di   |
//|   un massimo quando e' al ribasso, rende; fare il contrario      |
//|   perde (-0,24R su H1). Stop oltre il punto di svolta, target    |
//|   2R, pareggio a 1,5R, tempo massimo 3 volte la durata dell'onda.|
//| - H1 onde 0,8: 305 trade, +0,39R, 56% vincenti, 4 periodi su 4;  |
//|   con anche H4 e H1 nel verso (direzione chiara): +0,67R, 61%.   |
//| - M15 onde 0,4, stop max 0,4: 1204 trade (~280 l'anno), +0,16R,  |
//|   4 su 4. H4 onde 1,5: 77 trade, +0,53R, 60%, 4 su 4.            |
//| - M5 onde 0,3, stop max 0,3: regge solo con direzione chiara     |
//|   (D1, H4 e H1 d'accordo): 1122 trade (~260 l'anno), +0,12R,     |
//|   4 su 4. Su M1 la regola non regge: non c'e'.                   |
//| - Oro giornaliero dal 1975: positiva in tutti i blocchi di 5     |
//|   anni. Su EURUSD e' negativa: vale per l'oro, non in generale.  |
//| - La macro non migliora questi ingressi: resta una lettura       |
//|   misurata (vedi LETTURA DEL MERCATO), non un filtro.            |
//| - Chiudere il venerdi' sera dimezza il risultato di H1 e azzera  |
//|   quello di H4; M5 e M15 quasi non cambiano.                     |
//| Target vicino con lotti piu' alti (M5, M15: stop stretto) e      |
//| target lontano con lotti piu' bassi (H1, H4: stop largo).        |
//+------------------------------------------------------------------+
bool MarketShouldBeOpen(datetime utc);

#define ON_N 4

struct ZzState
  {
   bool              ok;        // almeno tre punti di svolta nel buffer
   int               n;         // punti di svolta trovati
   int               t0;        // indice della barra del punto due prima dell'ultimo
   double            p0;
   int               t1;
   double            p1;
   int               t2;        // indice della barra dell'ultimo punto confermato
   double            p2;
   int               type2;     // +1 massimo, -1 minimo
   int               c2;        // indice della barra che lo ha confermato
   datetime          time2;     // ora (server) della barra del punto
   datetime          conf2;     // ora (server) di apertura della barra di conferma
   double            a2;        // escursione media alla conferma
   int               legDir;    // verso della gamba in corso (+1 sale)
   double            legExt;    // estremo della gamba in corso
   int               nbars;     // barre nel buffer al momento del calcolo
  };
ZzState  g_zz[ON_N];
datetime g_ondaDone[ON_N];      // punto di svolta (ora della sua barra) gia' giocato: aperto, sulla carta o respinto
string   g_ondaDoneWhy[ON_N];
string   g_ondaText[ON_N];      // riga del pannello
double   g_ondaDayA[];          // per ogni giornata del buffer D1: escursione media delle 20 giornate chiuse prima
bool     g_ondaReady = false;

int    OndaStrat(int sc)  { return (sc == 0) ? ST_ON_M5 : ((sc == 1) ? ST_ON_M15 : ((sc == 2) ? ST_ON_H1 : ST_ON_H4)); }
int    OndaBarSec(int sc) { return (sc == 0) ? 300 : ((sc == 1) ? 900 : ((sc == 2) ? 3600 : 14400)); }
string OndaTfName(int sc) { return (sc == 0) ? "M5" : ((sc == 1) ? "M15" : ((sc == 2) ? "H1" : "H4")); }

double OndaK(int sc)
  {
   double k = (sc == 0) ? InpOndaM5K : ((sc == 1) ? InpOndaM15K : ((sc == 2) ? InpOndaH1K : InpOndaH4K));
   return Clamp(k, 0.05, 5.0);
  }

double OndaStopMax(int sc) { return (sc == 0) ? InpOndaM5StopMax : ((sc == 1) ? InpOndaM15StopMax : 0.0); }

double OndaStopMin(int sc)
  {
   double m = (sc == 0) ? InpOndaM5StopMin : ((sc == 1) ? InpOndaM15StopMin : ((sc == 2) ? InpOndaH1StopMin : InpOndaH4StopMin));
   return MathMax(m, 0.05);
  }

//--- con il lotto minimo: rischio massimo accettato per un ritracciamento
double OndaMinLotCap() { return MathMin(MathMax(InpOndaMinLotRiskPct, 0.5), InpMaxRiskPerTrade); }

void OndaInit()
  {
   string keys[ON_N] = {"ondaK0", "ondaK1", "ondaK2", "ondaK3"};
   for(int i = 0; i < ON_N; i++)
     {
      g_zz[i].ok = false;
      g_zz[i].n = 0;
      g_zz[i].t0 = 0;
      g_zz[i].p0 = 0.0;
      g_zz[i].t1 = 0;
      g_zz[i].p1 = 0.0;
      g_zz[i].t2 = 0;
      g_zz[i].p2 = 0.0;
      g_zz[i].type2 = 0;
      g_zz[i].c2 = 0;
      g_zz[i].time2 = 0;
      g_zz[i].conf2 = 0;
      g_zz[i].a2 = 0.0;
      g_zz[i].legDir = 0;
      g_zz[i].legExt = 0.0;
      g_zz[i].nbars = 0;
      g_ondaDone[i] = 0;
      g_ondaDoneWhy[i] = "";
      g_ondaText[i] = "";
      if(!g_isTester)
         g_ondaDone[i] = (datetime)GvGet(keys[i], 0.0);
      if(g_ondaDone[i] > 0)
         g_ondaDoneWhy[i] = "gia' giocato (prima del riavvio)";
     }
   g_ondaReady = false;
  }

//--- questo punto di svolta ha avuto la sua mossa: non si riprova (resta anche dopo un riavvio)
void OndaMarkDone(int sc, string why)
  {
   string keys[ON_N] = {"ondaK0", "ondaK1", "ondaK2", "ondaK3"};
   if(sc < 0 || sc >= ON_N)
      return;
   g_ondaDone[sc] = g_zz[sc].time2;
   g_ondaDoneWhy[sc] = why;
   if(!g_isTester)
      GlobalVariableSet(GvName(keys[sc]), (double)g_ondaDone[sc]);
  }

//--- escursione media nota all'inizio di ogni giornata del buffer D1 (indice n = la giornata in corso)
void OndaDayAtr()
  {
   int n = g_d1.n;
   ArrayResize(g_ondaDayA, n + 1);
   for(int j = 0; j <= n; j++)
     {
      double sum = 0.0;
      int c = 0;
      for(int q = j - 1; q >= 0 && q >= j - 20; q--)
        {
         double r = g_d1.r[q].high - g_d1.r[q].low;
         if(r > 0.0)
           {
            sum += r;
            c++;
           }
        }
      g_ondaDayA[j] = (c >= 10) ? sum / c : 0.0;
     }
  }

//--- escursione media valida per una barra con ora 't' (server); 'j' e' un puntatore che avanza con le barre
double OndaAtrAt(datetime t, int &j)
  {
   int n = g_d1.n;
   while(j < n && g_d1.r[j].time + 86400 <= t)
      j++;
   if(j < n && g_d1.r[j].time > t)
      return 0.0;                              // barra piu' vecchia del buffer giornaliero
   if(j < 0 || j >= ArraySize(g_ondaDayA))
      return 0.0;
   return g_ondaDayA[j];
  }

//--- onde sul buffer di un timeframe: estremi su massimi/minimi, svolta confermata da una chiusura a k escursioni dall'estremo.
//    Ricalcolato da capo a ogni barra nuova: sui dati da' le stesse conferme della storia intera (regge i riavvii).
void ZzCompute(const TfData &d, double k, ZzState &z)
  {
   z.ok = false;
   z.n = 0;
   z.legDir = 0;
   z.legExt = 0.0;
   int n = d.n;
   z.nbars = n;
   if(n < 30 || ArraySize(g_ondaDayA) < g_d1.n + 1)
      return;
   int dj = 0;
   int dir = 1, ei = 0;
   double ep = d.r[0].high;
   int pi0 = -1, pi1 = -1, pi2 = -1, pt2 = 0, pc2 = -1, cnt = 0;
   double pp0 = 0.0, pp1 = 0.0, pp2 = 0.0, pa2 = 0.0;
   for(int j = 1; j < n; j++)
     {
      double A = OndaAtrAt(d.r[j].time, dj);
      double thr = k * A;
      if(thr <= 0.0)
         continue;
      bool turn = false;
      if(dir > 0)
        {
         if(d.r[j].high > ep)
           {
            ep = d.r[j].high;
            ei = j;
           }
         else
            if(ep - d.r[j].close >= thr)
               turn = true;
        }
      else
        {
         if(d.r[j].low < ep)
           {
            ep = d.r[j].low;
            ei = j;
           }
         else
            if(d.r[j].close - ep >= thr)
               turn = true;
        }
      if(!turn)
         continue;
      pi0 = pi1;
      pp0 = pp1;
      pi1 = pi2;
      pp1 = pp2;
      pi2 = ei;
      pp2 = ep;
      pt2 = dir;
      pc2 = j;
      pa2 = A;
      cnt++;
      dir = -dir;
      ep = (dir > 0) ? d.r[j].high : d.r[j].low;
      ei = j;
     }
   z.n = cnt;
   z.legDir = dir;
   z.legExt = ep;
   if(cnt < 3 || pi0 < 0 || pi2 < 0 || pc2 < 0)
      return;
   z.ok = true;
   z.t0 = pi0;
   z.p0 = pp0;
   z.t1 = pi1;
   z.p1 = pp1;
   z.t2 = pi2;
   z.p2 = pp2;
   z.type2 = pt2;
   z.c2 = pc2;
   z.time2 = d.r[pi2].time;
   z.conf2 = d.r[pc2].time;
   z.a2 = pa2;
  }

void OndaCompute(int sc)
  {
   if(sc == 0)
      ZzCompute(g_m5, OndaK(0), g_zz[0]);
   else
      if(sc == 1)
         ZzCompute(g_m15, OndaK(1), g_zz[1]);
      else
         if(sc == 2)
            ZzCompute(g_h1, OndaK(2), g_zz[2]);
         else
            ZzCompute(g_h4, OndaK(3), g_zz[3]);
  }

//--- a ogni M1: ricalcola solo le scale che hanno una barra nuova (tutte alla partenza e a ogni giornata nuova)
void OndaRefresh(bool n5, bool n15, bool nh1, bool nh4, bool nd1)
  {
   bool all = (!g_ondaReady || nd1);
   if(all)
      OndaDayAtr();
   if(all || n5)
      OndaCompute(0);
   if(all || n15)
      OndaCompute(1);
   if(all || nh1)
      OndaCompute(2);
   if(all || nh4)
      OndaCompute(3);
   g_ondaReady = true;
  }

//--- direzione chiara: H4 e H1 vanno nello stesso verso del trend giornaliero
bool OndaClear(int td) { return (td != 0 && EmaDir(g_h4) == td && EmaDir(g_h1) == td); }

//--- tempo massimo: 'bars' barre di mercato aperto a partire da adesso (weekend, pausa serale e feste non contano)
datetime OndaDeadline(datetime fromUtc, int bars, int barSec)
  {
   long left = (long)bars * barSec;
   datetime t = fromUtc;
   int guard = 0;
   while(left > 0 && guard < 20000)
     {
      guard++;
      t += 900;
      if(MarketShouldBeOpen(t))
         left -= 900;
     }
   return t;
  }

//--- ONDA: ritracciamento finito nel verso del trend giornaliero, sulla scala 'sc'
bool S_Onda(TSignal &s, int sc)
  {
   int strat = OndaStrat(sc);
   string tfn = OndaTfName(sc);
   double A = TdAtr();
   if(A <= 0.0 || !g_zz[sc].ok)
     {
      g_ondaText[sc] = "dati insufficienti";
      return false;
     }
   int td = EmaDir(g_d1);
   if(td == 0)
     {
      g_ondaText[sc] = "trend incerto";
      return false;
     }
   int pdir = (g_zz[sc].type2 < 0) ? 1 : -1;      // ultimo punto = minimo -> idea al rialzo
   string want = (td > 0) ? "minimo" : "massimo";
   string ptw = (pdir > 0) ? "minimo " : "massimo ";
   string pt = ptw + DoubleToString(g_zz[sc].p2, g_digits);
   if(pdir != td)
     {
      g_ondaText[sc] = "aspetta un " + want;
      return false;
     }
   if(g_ondaDone[sc] == g_zz[sc].time2)
     {
      g_ondaText[sc] = pt + " " + g_ondaDoneWhy[sc];
      return false;
     }
   datetime now = g_ctx.nowUtc;
   datetime confClose = ToUTC(g_zz[sc].conf2) + OndaBarSec(sc);
   bool fresh = (g_zz[sc].c2 == g_zz[sc].nbars - 1);
   if(!fresh || now > confClose + IMax(1, InpOndaMaxDelayMin) * 60 + 59)
     {
      g_ondaText[sc] = pt + " gia' passato";
      return false;
     }
   bool clear = OndaClear(td);
   if(sc == 0 && InpOndaM5NeedAll && !clear)
     {
      g_ondaText[sc] = pt + ": H4/H1 non d'accordo";
      return false;
     }
   double A2 = (g_zz[sc].a2 > 0.0) ? g_zz[sc].a2 : A;
   double entry = EntryPx(pdir);
   double sl0 = StopFrom(g_zz[sc].p2, pdir, MathMax(InpOndaBufAtr, 0.0) * A2);
   double S = (entry - sl0) * pdir;
   //--- ingresso in ritardo (news, spread) con il prezzo tornato a ridosso del punto di svolta: lo stop sarebbe cosi'
   //    vicino che spread e slittamento si mangiano l'idea. Alla conferma lo stop e' sempre piu' largo di cosi'.
   if(S <= 3.0 * g_tick || S < 0.5 * OndaStopMin(sc) * A2)
     {
      g_ondaText[sc] = pt + ": tornato sul punto";
      return false;
     }
   double cap = OndaStopMax(sc);
   if(cap > 0.0 && S > cap * A2)
      S = cap * A2;
   //--- conto piccolo: stop piu' stretto, fino al minimo della scala (stesso rischio in denaro, lotti piu' alti)
   double minD = MathMin(OndaStopMin(sc) * A2, S);
   double base = BaseCapital();
   if(base > 0.0 && g_minLot > 0.0)
     {
      double capPct = OndaMinLotCap();
      double wantPct = MathMin(InpRiskPercent * TmRiskMult(strat), InpMaxRiskPerTrade);
      for(int pass = 0; pass < 3; pass++)
        {
         double lpl = LossPerLot(pdir, entry, entry - pdir * S);
         if(InpCostTrack)
            lpl += SlipEstPx(g_ctx.spread) * ValuePerPriceUnit();
         double pctMin = 100.0 * lpl * g_minLot / base;
         if(pctMin <= wantPct || pctMin <= capPct || S <= minD)
            break;
         S = MathMax(minD, S * capPct / pctMin * 0.98);
        }
     }
   double sl = entry - pdir * S;
   double rr = MathMax((sc >= 2) ? InpOndaTargetRLong : InpOndaTargetR, InpMinRR);
   double tp = entry + pdir * (rr * S + 3.0 * g_tick);
   int wave = IMax(1, g_zz[sc].t2 - g_zz[sc].t0);
   int limBars = (int)MathRound(Clamp(InpOndaHoldMult, 0.5, 10.0) * wave) + 5;
   datetime dl = OndaDeadline(now, limBars, OndaBarSec(sc));
   string dn = (td > 0) ? "al rialzo" : "al ribasso";
   string clw = clear ? ", direzione chiara (H4 e H1 d'accordo)" : "";
   string why = "ritracciamento finito su " + tfn + " nel trend giornaliero " + dn + ": " + pt + " confermato" + clw + ", stop " + DoubleToString(S / A2, 2) + " escursioni (" +
                DoubleToString(S, 1) + " $), target " + DoubleToString(rr, 1) + "R, tempo massimo " + IntegerToString((int)((dl - now) / 3600)) + " ore";
   if(!MakeSignalTP(s, strat, pdir, entry, sl, tp, 0.70, why))
      return false;
   s.proven = InpOndaProven;
   s.deadline = dl;
   if(sc == 2 && clear)
      s.riskX = Clamp(InpOndaClearMult, 0.5, 2.0);
   g_ondaText[sc] = pt + " confermato: ingresso";
   return true;
  }

//--- riga del pannello: una voce per scala accesa
string OndaPanel()
  {
   int td = EmaDir(g_d1);
   string tdw = (td > 0) ? "rialzo" : ((td < 0) ? "ribasso" : "incerto");
   string clw = OndaClear(td) ? ", direzione chiara" : "";
   string t = "Ritracciamenti (D1 " + tdw + clw + "):";
   int shown = 0;
   for(int sc = 0; sc < ON_N; sc++)
     {
      int st = OndaStrat(sc);
      if(!StratEnabled(st))
         continue;
      string ob = StratObserved(st) ? " (carta)" : "";
      t += " " + OndaTfName(sc) + ob + " " + StringSubstr(g_ondaText[sc], 0, 40) + ";";
      shown++;
     }
   return (shown > 0) ? t + "\n" : "";
  }
//+------------------------------------------------------------------+
//| LETTURA DEL MERCATO (1.27)                                       |
//|                                                                  |
//| Il bot guarda il grafico come lo guarda un operatore: trend sui  |
//| timeframe alti, macro, liquidita' presa, zone di domanda e       |
//| offerta, sbilanciamenti, sconto/premio, falsa partenza di New    |
//| York, mediana della forchetta H4, VWAP, euro e argento, candele  |
//| di rifiuto, volumi. Ogni lettura dice "a favore dei rialzi", "a  |
//| favore dei ribassi" o "neutra".                                  |
//|                                                                  |
//| Come ingressi da soli questi concetti sui dati 2022-2026 NON     |
//| battono il caso (presa di liquidita', sbilanciamenti, zone,      |
//| livelli: provati in oltre 150 varianti). Per questo qui sono     |
//| CONOSCENZA, non regole: ogni idea di ogni strategia viene        |
//| etichettata con le letture a favore e contro, finisce nel        |
//| diario, e il bot misura per famiglia di strategie se le idee     |
//| vanno meglio con la lettura a favore che contro. Solo una        |
//| lettura che passa la regola degli studi (casi sufficienti, 2,5   |
//| errori standard, 3 periodi su 4) comincia a contare: riduce il   |
//| rischio quando e' contraria (e lo alza, se lo si accende, quando |
//| e' a favore).                                                    |
//|                                                                  |
//| Collegamento con le vecchie strategie: il bot tiene anche il     |
//| conto delle loro idee nel solo verso del trend giornaliero. Se   |
//| quelle guadagnano lontano dal caso, la strategia resta in        |
//| osservazione per le idee contro trend ma apre quelle nel trend.  |
//+------------------------------------------------------------------+
#define NREAD       14
#define RD_D1       0
#define RD_H4       1
#define RD_H1       2
#define RD_MACRO    3
#define RD_LIQ      4
#define RD_ZONE     5
#define RD_FVG      6
#define RD_DISC     7
#define RD_FALSE    8
#define RD_FORK     9
#define RD_VWAP     10
#define RD_XMKT     11
#define RD_WICK     12
#define RD_FLOW     13
#define NFAM        4
#define FAM_ONDA    0
#define FAM_MF      1
#define FAM_TREND   2
#define FAM_REV     3
#define RDS_TEST    0
#define RDS_USEFUL  1
#define RDS_INVERSE 2

string g_rdName[NREAD] = {"trend giornaliero", "trend H4", "trend H1", "macro", "liquidita' presa", "zona di domanda/offerta", "sbilanciamento M15",
                          "sconto/premio", "falsa partenza di New York", "mediana della forchetta H4", "VWAP", "euro e argento",
                          "candela di rifiuto H1", "volumi"
                         };
string g_famName[NFAM] = {"ritracciamenti", "movimenti forti", "vecchie di tendenza", "vecchie di inversione"};
int    g_rdDir[NREAD];                        // +1 a favore dei rialzi, -1 dei ribassi, 0 neutra
string g_rdNote = "";                         // dettagli per il pannello (livelli, zone)
double g_rdN[NFAM * NREAD * 2 * NPER];        // idee chiuse: famiglia, lettura, lato (0 a favore, 1 contro), periodo
double g_rdS[NFAM * NREAD * 2 * NPER];        // somma dei loro R dopo i costi
double g_rdQ[NFAM * NREAD * 2 * NPER];        // somma dei quadrati
int    g_rdState[NFAM * NREAD];
double g_rdTot = 0.0;                         // idee contate in tutto
//--- vecchie strategie nel solo verso del trend giornaliero
double g_stTN[NSTRAT * NPER];
double g_stTS[NSTRAT * NPER];
double g_stTQ[NSTRAT * NPER];
bool   g_stCond[NSTRAT];                      // promossa per le sole idee nel verso del trend giornaliero
//--- stato delle letture che hanno memoria
int      g_liqDir = 0;
datetime g_liqUtc = 0;
double   g_liqExt = 0.0;
string   g_liqName = "";
double   g_zoneDemLo = 0.0, g_zoneDemHi = 0.0, g_zoneSupLo = 0.0, g_zoneSupHi = 0.0;
double   g_fvgUpLo = 0.0, g_fvgUpHi = 0.0, g_fvgDnLo = 0.0, g_fvgDnHi = 0.0;
int      g_fsDir = 0;
double   g_xmEur = 0.0, g_xmXag = 0.0;
bool     g_rdReady = false;

int RdIdx(int f, int k, int side, int p) { return ((f * NREAD + k) * 2 + side) * NPER + p; }

int RdFamily(int strat)
  {
   if(IsOnda(strat))
      return FAM_ONDA;
   if(IsTrendMove(strat))
      return FAM_MF;
   if(strat > 0 && strat < NSTRAT && (g_stratType[strat] == STYPE_REVERSAL || g_stratType[strat] == STYPE_MEANREV))
      return FAM_REV;
   return FAM_TREND;
  }

void RdInit()
  {
   for(int i = 0; i < NFAM * NREAD * 2 * NPER; i++)
     {
      g_rdN[i] = 0.0;
      g_rdS[i] = 0.0;
      g_rdQ[i] = 0.0;
     }
   for(int i = 0; i < NFAM * NREAD; i++)
      g_rdState[i] = RDS_TEST;
   for(int i = 0; i < NSTRAT * NPER; i++)
     {
      g_stTN[i] = 0.0;
      g_stTS[i] = 0.0;
      g_stTQ[i] = 0.0;
     }
   for(int i = 0; i < NSTRAT; i++)
      g_stCond[i] = false;
   for(int i = 0; i < NREAD; i++)
      g_rdDir[i] = 0;
   g_rdTot = 0.0;
  }

//+------------------------------------------------------------------+
//| Le letture                                                       |
//+------------------------------------------------------------------+
//--- liquidita' presa e recuperata: il prezzo buca un minimo importante (Asia, Londra, ieri, settimana scorsa)
//    e richiude sopra entro due barre M5 -> a favore dei rialzi per 4 ore, finche' non chiude sotto l'estremo
void RdLiqLevel(double L, int side, string name, double tol, double lo, double hi, double c0, double c2)
  {
   if(L <= 0.0)
      return;
   if(side < 0 && lo < L - tol && c0 > L && c2 > L)
     {
      g_liqDir = 1;
      g_liqUtc = g_ctx.nowUtc;
      g_liqExt = lo;
      g_liqName = "preso " + name + " e recuperato";
     }
   if(side > 0 && hi > L + tol && c0 < L && c2 < L)
     {
      g_liqDir = -1;
      g_liqUtc = g_ctx.nowUtc;
      g_liqExt = hi;
      g_liqName = "preso " + name + " e respinto";
     }
  }

void RdLiqOnM5(double A)
  {
   if(g_m5.n < 5 || A <= 0.0)
      return;
   double tol = 0.02 * A;
   double c0 = BarC(g_m5, 0), c2 = BarC(g_m5, 2);
   double lo = MathMin(BarL(g_m5, 0), BarL(g_m5, 1)), hi = MathMax(BarH(g_m5, 0), BarH(g_m5, 1));
   if(g_sess.asiaDone)
     {
      RdLiqLevel(g_sess.asiaL, -1, "il minimo di Asia", tol, lo, hi, c0, c2);
      RdLiqLevel(g_sess.asiaH, 1, "il massimo di Asia", tol, lo, hi, c0, c2);
     }
   if(g_sess.lonDone)
     {
      RdLiqLevel(g_sess.lonL, -1, "il minimo di Londra", tol, lo, hi, c0, c2);
      RdLiqLevel(g_sess.lonH, 1, "il massimo di Londra", tol, lo, hi, c0, c2);
     }
   if(g_d1.n >= 2)
     {
      RdLiqLevel(BarL(g_d1, 0), -1, "il minimo di ieri", tol, lo, hi, c0, c2);
      RdLiqLevel(BarH(g_d1, 0), 1, "il massimo di ieri", tol, lo, hi, c0, c2);
     }
   RdLiqLevel(g_pwL, -1, "il minimo della settimana scorsa", tol, lo, hi, c0, c2);
   RdLiqLevel(g_pwH, 1, "il massimo della settimana scorsa", tol, lo, hi, c0, c2);
   if(g_liqDir > 0 && c0 < g_liqExt)
      g_liqDir = 0;
   if(g_liqDir < 0 && c0 > g_liqExt)
      g_liqDir = 0;
   if(g_liqDir != 0 && g_ctx.nowUtc - g_liqUtc > 4 * 3600)
      g_liqDir = 0;
  }

//--- zone di domanda e offerta su H1: l'ultima candela contraria prima di una spinta forte (corpo >= 1,5 ATR),
//    finche' il prezzo non ci chiude oltre
void RdZonesOnH1()
  {
   g_zoneDemLo = 0.0;
   g_zoneDemHi = 0.0;
   g_zoneSupLo = 0.0;
   g_zoneSupHi = 0.0;
   int n = g_h1.n;
   if(n < 60 || ArraySize(g_h1.atr) < n)
      return;
   bool dem = false, sup = false;
   for(int i = n - 2; i >= 3 && i >= n - 80 && !(dem && sup); i--)
     {
      double body = g_h1.r[i].close - g_h1.r[i].open;
      double atr = g_h1.atr[i];
      if(atr <= 0.0)
         continue;
      if(!dem && body >= 1.5 * atr)
        {
         for(int j = i - 1; j >= i - 3 && j >= 0; j--)
           {
            if(g_h1.r[j].close >= g_h1.r[j].open)
               continue;
            double zl = g_h1.r[j].low, zh = g_h1.r[j].open;
            bool valid = (zh > zl);
            for(int q = i + 1; q < n && valid; q++)
               if(g_h1.r[q].close < zl)
                  valid = false;
            if(valid)
              {
               g_zoneDemLo = zl;
               g_zoneDemHi = zh;
               dem = true;
              }
            break;
           }
        }
      if(!sup && body <= -1.5 * atr)
        {
         for(int j = i - 1; j >= i - 3 && j >= 0; j--)
           {
            if(g_h1.r[j].close <= g_h1.r[j].open)
               continue;
            double zl = g_h1.r[j].open, zh = g_h1.r[j].high;
            bool valid = (zh > zl);
            for(int q = i + 1; q < n && valid; q++)
               if(g_h1.r[q].close > zh)
                  valid = false;
            if(valid)
              {
               g_zoneSupLo = zl;
               g_zoneSupHi = zh;
               sup = true;
              }
            break;
           }
        }
     }
  }

//--- sbilanciamenti su M15 (vuoto tra il massimo di due barre prima e il minimo della barra, o il contrario) non ancora riempiti
void RdFvgOnM15(double A)
  {
   g_fvgUpLo = 0.0;
   g_fvgUpHi = 0.0;
   g_fvgDnLo = 0.0;
   g_fvgDnHi = 0.0;
   int n = g_m15.n;
   if(n < 10 || A <= 0.0)
      return;
   double minGap = 0.05 * A;
   bool up = false, dn = false;
   for(int i = n - 1; i >= 2 && i >= n - 60 && !(up && dn); i--)
     {
      if(!up && g_m15.r[i].low - g_m15.r[i - 2].high >= minGap)
        {
         double bot = g_m15.r[i - 2].high;
         bool filled = false;
         for(int q = i + 1; q < n && !filled; q++)
            if(g_m15.r[q].low <= bot)
               filled = true;
         if(!filled)
           {
            g_fvgUpLo = bot;
            g_fvgUpHi = g_m15.r[i].low;
            up = true;
           }
        }
      if(!dn && g_m15.r[i - 2].low - g_m15.r[i].high >= minGap)
        {
         double top = g_m15.r[i - 2].low;
         bool filled = false;
         for(int q = i + 1; q < n && !filled; q++)
            if(g_m15.r[q].high >= top)
               filled = true;
         if(!filled)
           {
            g_fvgDnLo = g_m15.r[i].high;
            g_fvgDnHi = top;
            dn = true;
           }
        }
     }
  }

//--- falsa partenza di New York: nella prima mezz'ora dall'apertura (9:30) il prezzo va da una parte di almeno
//    0,15 escursioni, poi torna oltre il prezzo d'apertura dall'altra -> a favore del verso opposto (per 4 ore)
void RdFalseStartOnM5(double A)
  {
   g_fsDir = 0;
   if(A <= 0.0 || g_m5.n < 20)
      return;
   datetime now = g_ctx.nowUtc;
   datetime openU = DayStartUtc(now) + (datetime)MathRound(g_ctx.nyOpen * 3600.0);
   if(now < openU + 2100 || now > openU + 4 * 3600)
      return;
   double O = 0.0, up = 0.0, dn = 0.0;
   for(int i = 0; i < g_m5.n; i++)
     {
      datetime tU = ToUTC(g_m5.r[i].time);
      if(tU < openU)
         continue;
      if(O <= 0.0)
        {
         if(tU >= openU + 900)
            return;                            // niente barre all'apertura: oggi non si legge
         O = g_m5.r[i].open;
        }
      if(tU < openU + 1800)
        {
         up = MathMax(up, g_m5.r[i].high - O);
         dn = MathMax(dn, O - g_m5.r[i].low);
        }
     }
   if(O <= 0.0)
      return;
   double c0 = BarC(g_m5, 0);
   if(up >= 0.15 * A && up > dn && c0 < O - 0.05 * A)
      g_fsDir = -1;
   if(dn >= 0.15 * A && dn > up && c0 > O + 0.05 * A)
      g_fsDir = 1;
  }

//--- movimento dell'ultima ora di un altro mercato rispetto alla sua misura tipica (barre M5); 0 se il simbolo manca o e' fermo
double RdSymZ(string sym)
  {
   if(sym == "")
      return 0.0;
   MqlRates r[];
   int got = CopyRates(sym, PERIOD_M5, 1, 300, r);
   if(got < 150)
      return 0.0;
   if(TimeCurrent() - r[got - 1].time > 1200)
      return 0.0;
   double mv = r[got - 1].close - r[got - 13].close;
   double s2 = 0.0;
   int c = 0;
   for(int i = 12; i < got - 1; i += 12)
     {
      double d = r[i].close - r[i - 12].close;
      s2 += d * d;
      c++;
     }
   if(c < 8 || s2 <= 0.0)
      return 0.0;
   return mv / MathSqrt(s2 / c);
  }

//--- a ogni M1: aggiorna tutte le letture (le piu' pesanti solo alla barra nuova del loro timeframe)
void RdUpdate(bool n5, bool n15, bool nh1)
  {
   if(!InpReadOn)
      return;
   double A = TdAtr();
   bool first = !g_rdReady;
   g_rdReady = true;
   if(n5 || first)
     {
      RdLiqOnM5(A);
      RdFalseStartOnM5(A);
      g_xmEur = RdSymZ(g_imSym[IM_EURUSD]);
      g_xmXag = RdSymZ(g_imSym[IM_XAGUSD]);
     }
   if(n15 || first)
      RdFvgOnM15(A);
   if(nh1 || first)
      RdZonesOnH1();
   double px = 0.5 * (g_ctx.bid + g_ctx.ask);
   string note = "";
   g_rdDir[RD_D1] = EmaDir(g_d1);
   g_rdDir[RD_H4] = EmaDir(g_h4);
   g_rdDir[RD_H1] = EmaDir(g_h1);
   g_rdDir[RD_MACRO] = 0;
   if(g_mConf >= 0.3 && MathAbs(g_mBias) >= 0.15)
      g_rdDir[RD_MACRO] = (g_mBias > 0.0) ? 1 : -1;
   g_rdDir[RD_LIQ] = g_liqDir;
   if(g_liqDir != 0)
      note += g_liqName + "; ";
   //--- zona: il prezzo e' tornato dentro (o appena sopra/sotto) una zona valida
   g_rdDir[RD_ZONE] = 0;
   bool inDem = (g_zoneDemHi > 0.0 && px >= g_zoneDemLo && px <= g_zoneDemHi + 0.1 * A);
   bool inSup = (g_zoneSupHi > 0.0 && px <= g_zoneSupHi && px >= g_zoneSupLo - 0.1 * A);
   if(inDem && !inSup)
     {
      g_rdDir[RD_ZONE] = 1;
      note += "in zona di domanda H1 " + DoubleToString(g_zoneDemLo, g_digits) + "-" + DoubleToString(g_zoneDemHi, g_digits) + "; ";
     }
   if(inSup && !inDem)
     {
      g_rdDir[RD_ZONE] = -1;
      note += "in zona di offerta H1 " + DoubleToString(g_zoneSupLo, g_digits) + "-" + DoubleToString(g_zoneSupHi, g_digits) + "; ";
     }
   //--- sbilanciamento: il prezzo sta ritracciando dentro un vuoto non riempito
   g_rdDir[RD_FVG] = 0;
   bool inUp = (g_fvgUpHi > 0.0 && px >= g_fvgUpLo && px <= g_fvgUpHi);
   bool inDn = (g_fvgDnHi > 0.0 && px >= g_fvgDnLo && px <= g_fvgDnHi);
   if(inUp && !inDn)
     {
      g_rdDir[RD_FVG] = 1;
      note += "dentro uno sbilanciamento rialzista M15; ";
     }
   if(inDn && !inUp)
     {
      g_rdDir[RD_FVG] = -1;
      note += "dentro uno sbilanciamento ribassista M15; ";
     }
   //--- sconto/premio: posizione del prezzo tra massimo e minimo delle ultime 60 barre H4 (10 giorni)
   g_rdDir[RD_DISC] = 0;
   double hh = HighestH(g_h4, 0, 60), ll = LowestL(g_h4, 0, 60);
   if(hh > ll && ll > 0.0)
     {
      double pos = (px - ll) / (hh - ll);
      if(pos < 0.4)
         g_rdDir[RD_DISC] = 1;
      if(pos > 0.6)
         g_rdDir[RD_DISC] = -1;
      string dw = (pos < 0.4) ? "prezzo in sconto" : ((pos > 0.6) ? "prezzo in premio" : "prezzo a meta'");
      note += dw + " (" + DoubleToString(100.0 * pos, 0) + "% dei 10 giorni); ";
     }
   g_rdDir[RD_FALSE] = g_fsDir;
   if(g_fsDir != 0)
     {
      string fw = (g_fsDir > 0) ? "al ribasso" : "al rialzo";
      note += "falsa partenza di New York " + fw + "; ";
     }
   //--- mediana della forchetta H4: linea dal primo punto al centro degli ultimi due; conta se il prezzo deve ancora raggiungerla
   g_rdDir[RD_FORK] = 0;
   if(g_zz[3].ok)
     {
      int d = (g_zz[3].type2 < 0) ? 1 : -1;
      double mt = 0.5 * (g_zz[3].t1 + g_zz[3].t2), mp = 0.5 * (g_zz[3].p1 + g_zz[3].p2);
      if(mt > g_zz[3].t0)
        {
         double ml = g_zz[3].p0 + (mp - g_zz[3].p0) / (mt - g_zz[3].t0) * (g_zz[3].nbars - g_zz[3].t0);
         if((ml - px) * d > 0.0)
           {
            g_rdDir[RD_FORK] = d;
            note += "mediana H4 a " + DoubleToString(ml, g_digits) + "; ";
           }
        }
     }
   g_rdDir[RD_VWAP] = 0;
   if(g_ctx.vwap > 0.0 && g_ctx.wvwap > 0.0)
     {
      if(px > g_ctx.vwap && px > g_ctx.wvwap)
         g_rdDir[RD_VWAP] = 1;
      if(px < g_ctx.vwap && px < g_ctx.wvwap)
         g_rdDir[RD_VWAP] = -1;
     }
   g_rdDir[RD_XMKT] = 0;
   if(g_xmEur > 1.0 && g_xmXag > 1.0)
      g_rdDir[RD_XMKT] = 1;
   if(g_xmEur < -1.0 && g_xmXag < -1.0)
      g_rdDir[RD_XMKT] = -1;
   if(g_rdDir[RD_XMKT] != 0)
     {
      string xw = (g_rdDir[RD_XMKT] > 0) ? "salgono" : "scendono";
      note += "euro e argento " + xw + " insieme; ";
     }
   g_rdDir[RD_WICK] = 0;
   if(g_h1.n > 20 && BarH(g_h1, 0) - BarL(g_h1, 0) >= 0.7 * g_ctx.atrH1 && g_ctx.atrH1 > 0.0)
     {
      double wu = WickRatio(g_h1, 0, 1), wd = WickRatio(g_h1, 0, -1);
      if(wu >= 0.5 && wd < 0.3)
         g_rdDir[RD_WICK] = 1;
      if(wd >= 0.5 && wu < 0.3)
         g_rdDir[RD_WICK] = -1;
     }
   g_rdDir[RD_FLOW] = 0;
   double cv = MicroCvdRatio(60);
   if(cv > 0.15)
      g_rdDir[RD_FLOW] = 1;
   if(cv < -0.15)
      g_rdDir[RD_FLOW] = -1;
   g_rdNote = note;
  }

//--- etichetta un'idea con le letture a favore e contro, e conta quelle provate
void RdEval(TSignal &s)
  {
   s.rdFav = 0;
   s.rdAg = 0;
   s.rdConf = 0;
   if(!InpReadOn || s.dir == 0)
      return;
   int f = RdFamily(s.strat);
   for(int k = 0; k < NREAD; k++)
     {
      int v = g_rdDir[k] * s.dir;
      if(v == 0)
         continue;
      if(v > 0)
         s.rdFav |= (1 << k);
      else
         s.rdAg |= (1 << k);
      int st = g_rdState[f * NREAD + k];
      if(st == RDS_USEFUL)
         s.rdConf += (v > 0) ? 1 : -1;
      if(st == RDS_INVERSE)
         s.rdConf += (v > 0) ? -1 : 1;
     }
  }

//--- le letture provate cambiano il rischio dell'idea: meno se sono contrarie, di piu' (se acceso) se sono a favore
double ReadRiskMult(const TSignal &s)
  {
   if(!InpReadOn || !InpReadLearn)
      return 1.0;
   int cut = IMax(1, InpReadCutN);
   if(s.rdConf <= -cut)
      return Clamp(InpReadCutMult, 0.1, 1.0);
   if(s.rdConf >= cut)
      return Clamp(InpReadBoostMult, 1.0, 1.5);
   return 1.0;
  }

string RdList(int mask)
  {
   string t = "";
   for(int k = 0; k < NREAD; k++)
      if((mask & (1 << k)) != 0)
         t += (t == "" ? "" : ", ") + g_rdName[k];
   return t;
  }

//+------------------------------------------------------------------+
//| Misura: ogni idea chiusa (seguita sulla carta) aggiorna i conti  |
//+------------------------------------------------------------------+
int RdEvaluate(int f, int k)
  {
   if(!InpReadLearn)
      return RDS_TEST;
   double nf = 0.0, sf = 0.0, qf = 0.0, na = 0.0, sa = 0.0, qa = 0.0;
   int perOk = 0, perPos = 0, perNeg = 0;
   for(int p = 0; p < NPER; p++)
     {
      double a = g_rdN[RdIdx(f, k, 0, p)], b = g_rdN[RdIdx(f, k, 1, p)];
      nf += a;
      sf += g_rdS[RdIdx(f, k, 0, p)];
      qf += g_rdQ[RdIdx(f, k, 0, p)];
      na += b;
      sa += g_rdS[RdIdx(f, k, 1, p)];
      qa += g_rdQ[RdIdx(f, k, 1, p)];
      if(a < 5.0 || b < 5.0)
         continue;
      perOk++;
      double df = g_rdS[RdIdx(f, k, 0, p)] / a - g_rdS[RdIdx(f, k, 1, p)] / b;
      if(df > 0.0)
         perPos++;
      if(df < 0.0)
         perNeg++;
     }
   double minN = (double)IMax(10, InpReadMinN);
   if(nf < minN || na < minN)
      return RDS_TEST;
   //--- con meno di 3 periodi misurabili (conto vero, un anno solo) servono il doppio dei casi
   if(perOk < 3 && (nf < 2.0 * minN || na < 2.0 * minN))
      return RDS_TEST;
   double mf = sf / nf, ma = sa / na;
   double vf = MathMax(qf / nf - mf * mf, 0.0), va = MathMax(qa / na - ma * ma, 0.0);
   double se = MathSqrt(vf / nf + va / na);
   double diff = mf - ma;
   if(diff >= 2.5 * se && diff >= 0.10 && (perOk < 3 || perPos >= 3))
      return RDS_USEFUL;
   if(diff <= -2.5 * se && diff <= -0.10 && (perOk < 3 || perNeg >= 3))
      return RDS_INVERSE;
   return RDS_TEST;
  }

//--- vecchia strategia nel solo verso del trend giornaliero: guadagna lontano dal caso?
bool StTrendEvaluate(int k)
  {
   if(!InpReadOn || !InpReadTrendGate || !InpObserveOn || !InpObserveAuto || IsProvenFam(k))
      return false;
   double n = 0.0, sum = 0.0, q = 0.0;
   int perOk = 0, perPos = 0;
   for(int p = 0; p < NPER; p++)
     {
      double a = g_stTN[k * NPER + p];
      n += a;
      sum += g_stTS[k * NPER + p];
      q += g_stTQ[k * NPER + p];
      if(a < 8.0)
         continue;
      perOk++;
      if(g_stTS[k * NPER + p] > 0.0)
         perPos++;
     }
   if(n < InpObserveMinN || (perOk < 3 && n < 2.0 * InpObserveMinN))
      return false;
   double mean = sum / n;
   double se = MathSqrt(MathMax(q / n - mean * mean, 0.0) / n);
   return (mean >= InpObservePromoteR && mean >= 2.5 * se && (perOk < 3 || perPos >= 3));
  }

string RdStateName(int st) { return (st == RDS_USEFUL) ? "provata" : ((st == RDS_INVERSE) ? "provata al contrario" : "in prova"); }

void RdRefresh(bool tell)
  {
   for(int f = 0; f < NFAM; f++)
      for(int k = 0; k < NREAD; k++)
        {
         int st = RdEvaluate(f, k);
         if(st != g_rdState[f * NREAD + k])
           {
            g_rdState[f * NREAD + k] = st;
            if(tell && st != RDS_TEST)
               Notify("Lettura del mercato: '" + g_rdName[k] + "' " + RdStateName(st) + " per " + g_famName[f] +
                      ((st == RDS_USEFUL) ? ": le idee vanno meglio con la lettura a favore, da adesso conta" : ": le idee vanno meglio con la lettura contro, da adesso conta al contrario"));
           }
        }
   for(int k = 1; k < NSTRAT; k++)
     {
      bool c = StTrendEvaluate(k);
      if(c != g_stCond[k])
        {
         g_stCond[k] = c;
         if(tell && c && StratObserved(k))
            Notify(g_stratName[k] + ": le idee nel verso del trend giornaliero guadagnano sulla carta lontano dal caso: da adesso quelle aprono ordini, le altre restano in osservazione");
        }
     }
  }

//--- chiamata alla chiusura di ogni idea seguita sulla carta
void RdAdd(int strat, int fav, int ag, datetime t0, double r, bool passed)
  {
   if(!InpReadOn || !InpReadLearn || strat <= 0 || strat >= NSTRAT)
      return;
   int p = ObPeriod(t0);
   int f = RdFamily(strat);
   for(int k = 0; k < NREAD; k++)
     {
      int side = -1;
      if((fav & (1 << k)) != 0)
         side = 0;
      else
         if((ag & (1 << k)) != 0)
            side = 1;
      if(side < 0)
         continue;
      g_rdN[RdIdx(f, k, side, p)] += 1.0;
      g_rdS[RdIdx(f, k, side, p)] += r;
      g_rdQ[RdIdx(f, k, side, p)] += r * r;
     }
   g_rdTot += 1.0;
   if(passed && (fav & (1 << RD_D1)) != 0)
     {
      g_stTN[strat * NPER + p] += 1.0;
      g_stTS[strat * NPER + p] += r;
      g_stTQ[strat * NPER + p] += r * r;
     }
  }

//--- una strategia in osservazione puo' aprire le sole idee nel verso del trend giornaliero, se quelle sono promosse
bool IdeaObserved(const TSignal &s)
  {
   if(!StratObserved(s.strat))
      return false;
   if(InpReadOn && InpReadTrendGate && s.strat > 0 && s.strat < NSTRAT && g_stCond[s.strat] && (s.rdFav & (1 << RD_D1)) != 0)
      return false;
   return true;
  }

string RdFile(bool tester) { return tester ? "XauCommittee_tester_letture.csv" : "XauCommittee_" + IntegerToString(g_login) + "_letture.csv"; }

void RdSave()
  {
   if(g_isOptim || !InpReadOn || !InpReadLearn || g_rdTot <= 0.0)
      return;
   int h = FileOpen(RdFile(g_isTester), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   string hd = "tipo;famiglia_o_strategia;lettura;stato;casi_favore;R_medio_favore;casi_contro;R_medio_contro";
   string pn[NPER] = {"2022", "2023", "2024", "2025_26"};
   for(int p = 0; p < NPER; p++)
      hd += ";n_fav_" + pn[p] + ";R_fav_" + pn[p] + ";q_fav_" + pn[p] + ";n_con_" + pn[p] + ";R_con_" + pn[p] + ";q_con_" + pn[p];
   FileWriteString(h, hd + "\r\n");
   FileWriteString(h, "totale;-;-;-;" + DoubleToString(g_rdTot, 0) + ";0;0;0\r\n");
   for(int f = 0; f < NFAM; f++)
      for(int k = 0; k < NREAD; k++)
        {
         double nf = 0.0, sf = 0.0, na = 0.0, sa = 0.0;
         string per = "";
         for(int p = 0; p < NPER; p++)
           {
            nf += g_rdN[RdIdx(f, k, 0, p)];
            sf += g_rdS[RdIdx(f, k, 0, p)];
            na += g_rdN[RdIdx(f, k, 1, p)];
            sa += g_rdS[RdIdx(f, k, 1, p)];
            for(int side = 0; side < 2; side++)
               per += ";" + DoubleToString(g_rdN[RdIdx(f, k, side, p)], 0) + ";" + DoubleToString(g_rdS[RdIdx(f, k, side, p)], 3) + ";" +
                      DoubleToString(g_rdQ[RdIdx(f, k, side, p)], 3);
           }
         if(nf + na <= 0.0)
            continue;
         FileWriteString(h, "lettura;" + g_famName[f] + ";" + g_rdName[k] + ";" + RdStateName(g_rdState[f * NREAD + k]) + ";" + DoubleToString(nf, 0) + ";" +
                         (nf > 0.0 ? DoubleToString(sf / nf, 3) : "0") + ";" + DoubleToString(na, 0) + ";" + (na > 0.0 ? DoubleToString(sa / na, 3) : "0") + per + "\r\n");
        }
   for(int k = 1; k < NSTRAT; k++)
     {
      double n = 0.0, sum = 0.0;
      string per = "";
      for(int p = 0; p < NPER; p++)
        {
         n += g_stTN[k * NPER + p];
         sum += g_stTS[k * NPER + p];
         per += ";" + DoubleToString(g_stTN[k * NPER + p], 0) + ";" + DoubleToString(g_stTS[k * NPER + p], 3) + ";" + DoubleToString(g_stTQ[k * NPER + p], 3) + ";0;0;0";
        }
      if(n <= 0.0)
         continue;
      FileWriteString(h, "trend;" + g_stratName[k] + ";idee nel verso del trend giornaliero;" + (g_stCond[k] ? "promosse" : "in prova") + ";" + DoubleToString(n, 0) + ";" +
                      DoubleToString(sum / n, 3) + ";0;0" + per + "\r\n");
     }
   FileClose(h);
  }

double RdReadFile(string fname)
  {
   RdInit();
   if(!FileIsExist(fname, FILE_COMMON))
      return 0.0;
   int h = FileOpen(fname, FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return 0.0;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      int np = StringSplit(l, ';', p);
      if(np >= 5 && p[0] == "totale")
        {
         g_rdTot = MathMax(StringToDouble(p[4]), 0.0);
         continue;
        }
      if(np < 8 + 6 * NPER)
         continue;
      if(p[0] == "lettura")
        {
         int f = -1, k = -1;
         for(int j = 0; j < NFAM; j++)
            if(p[1] == g_famName[j])
               f = j;
         for(int j = 0; j < NREAD; j++)
            if(p[2] == g_rdName[j])
               k = j;
         if(f < 0 || k < 0)
            continue;
         for(int q = 0; q < NPER; q++)
            for(int side = 0; side < 2; side++)
              {
               int b = 8 + 6 * q + 3 * side;
               g_rdN[RdIdx(f, k, side, q)] = MathMax(StringToDouble(p[b]), 0.0);
               g_rdS[RdIdx(f, k, side, q)] = StringToDouble(p[b + 1]);
               g_rdQ[RdIdx(f, k, side, q)] = MathMax(StringToDouble(p[b + 2]), 0.0);
              }
        }
      if(p[0] == "trend")
        {
         int k = StratByName(p[1]);
         if(k <= 0)
            continue;
         for(int q = 0; q < NPER; q++)
           {
            int b = 8 + 6 * q;
            g_stTN[k * NPER + q] = MathMax(StringToDouble(p[b]), 0.0);
            g_stTS[k * NPER + q] = StringToDouble(p[b + 1]);
            g_stTQ[k * NPER + q] = MathMax(StringToDouble(p[b + 2]), 0.0);
           }
        }
     }
   FileClose(h);
   //--- un file rovinato non deve far credere al bot di sapere: nessun conto oltre il totale
   for(int i = 0; i < NFAM * NREAD * 2 * NPER; i++)
      if(g_rdN[i] > g_rdTot)
        {
         g_rdN[i] = 0.0;
         g_rdS[i] = 0.0;
         g_rdQ[i] = 0.0;
        }
   for(int i = 0; i < NSTRAT * NPER; i++)
      if(g_stTN[i] > g_rdTot)
        {
         g_stTN[i] = 0.0;
         g_stTS[i] = 0.0;
         g_stTQ[i] = 0.0;
        }
   return g_rdTot;
  }

//--- carica quello che e' gia' stato misurato (conto: il suo file, altrimenti quello del Tester)
void RdLoad()
  {
   RdInit();
   if(g_isTester || !InpReadOn || !InpReadLearn)
      return;                                   // nel Tester si misura da zero, come in una prova vera
   double nt = RdReadFile(RdFile(false));
   if(nt <= 0.0 && InpObjFromTester)
     {
      nt = RdReadFile(RdFile(true));
      if(nt > 0.0)
         Notify("Lettura del mercato: parto da quello che ha misurato il Tester (" + DoubleToString(nt, 0) + " idee)");
     }
   RdRefresh(false);
  }

//--- righe del pannello: cosa vede adesso (part 0), i dettagli (part 1), quali letture contano (part 2)
string RdPanelPart(int part)
  {
   if(!InpReadOn)
      return "";
   if(part == 0)
     {
      int up = 0, dn = 0;
      for(int k = 0; k < NREAD; k++)
        {
         if(g_rdDir[k] > 0)
            up++;
         if(g_rdDir[k] < 0)
            dn++;
        }
      return "Lettura del mercato: " + IntegerToString(up) + " letture al rialzo, " + IntegerToString(dn) + " al ribasso | D1 " + DirWord(g_rdDir[RD_D1]) +
             ", H4 " + DirWord(g_rdDir[RD_H4]) + ", H1 " + DirWord(g_rdDir[RD_H1]) + ", macro " + DirWord(g_rdDir[RD_MACRO]) + "\n";
     }
   if(part == 1)
      return (g_rdNote != "") ? "  " + StringSubstr(g_rdNote, 0, 170) + "\n" : "";
   string pr = "";
   int np = 0;
   for(int f = 0; f < NFAM; f++)
      for(int k = 0; k < NREAD; k++)
         if(g_rdState[f * NREAD + k] != RDS_TEST)
           {
            np++;
            if(np <= 4)
               pr += (pr == "" ? "" : ", ") + g_rdName[k] + " (" + g_famName[f] + (g_rdState[f * NREAD + k] == RDS_INVERSE ? ", al contrario" : "") + ")";
           }
   if(np > 0)
      return "  Letture provate (" + IntegerToString(np) + "): " + StringSubstr(pr, 0, 170) + "\n";
   if(InpReadLearn)
      return "  Letture in prova: " + DoubleToString(g_rdTot, 0) + " idee misurate, nessuna ancora provata (non cambiano il rischio)\n";
   return "";
  }

string RdPanel() { return RdPanelPart(0) + RdPanelPart(1) + RdPanelPart(2); }

//--- report a fine test: per famiglia, le letture con abbastanza casi
void RdReport()
  {
   if(!InpReadOn || !InpReadLearn || g_rdTot <= 0.0)
      return;
   Print("LETTURA DEL MERCATO - idee seguite sulla carta: ", DoubleToString(g_rdTot, 0), " (R medio con la lettura a favore / contro)");
   for(int f = 0; f < NFAM; f++)
      for(int k = 0; k < NREAD; k++)
        {
         double nf = 0.0, sf = 0.0, na = 0.0, sa = 0.0;
         for(int p = 0; p < NPER; p++)
           {
            nf += g_rdN[RdIdx(f, k, 0, p)];
            sf += g_rdS[RdIdx(f, k, 0, p)];
            na += g_rdN[RdIdx(f, k, 1, p)];
            sa += g_rdS[RdIdx(f, k, 1, p)];
           }
         if(nf < 10.0 && na < 10.0)
            continue;
         Print("  ", g_famName[f], " | ", g_rdName[k], ": a favore ", DoubleToString(nf, 0), " idee ", (nf > 0.0 ? DoubleToString(sf / nf, 2) : "-"), "R, contro ",
               DoubleToString(na, 0), " idee ", (na > 0.0 ? DoubleToString(sa / na, 2) : "-"), "R -> ", RdStateName(g_rdState[f * NREAD + k]));
        }
   for(int k = 1; k < NSTRAT; k++)
     {
      double n = 0.0, sum = 0.0;
      for(int p = 0; p < NPER; p++)
        {
         n += g_stTN[k * NPER + p];
         sum += g_stTS[k * NPER + p];
        }
      if(n >= 10.0 && !IsProvenFam(k))
         Print("  ", g_stratName[k], " nel verso del trend giornaliero: ", DoubleToString(n, 0), " idee, ", DoubleToString(sum / n, 2), "R -> ", (g_stCond[k] ? "promosse" : "in prova"));
     }
  }
//+------------------------------------------------------------------+
//| Gestione: pareggio a +1.5R con parziale, trailing, uscite a      |
//| tempo, news, venerdi', ordini scaglionati, chiusure e statistica |
//+------------------------------------------------------------------+
double BeOffsetPx() { return CommissionPx() + g_tick; }

bool ModifySL(ulong tk, double sl, double tp)
  {
   sl = NormPrice(sl);
   if(!g_trade.PositionModify(tk, sl, tp))
      return false;
   return RetOk(g_trade.ResultRetcode());
  }

bool CloseTicket(ulong tk, string why)
  {
   bool ok = g_trade.PositionClose(tk);
   if(ok && RetOk(g_trade.ResultRetcode()))
     {
      Logf("Chiusura: " + why);
      g_needSweep = true;
      return true;
     }
   return false;
  }

//--- 1.27: chiude i ritracciamenti (ONDA) ancora a rischio aperti nel verso opposto a 'dir'
int CloseOppOnda(int dir, string why)
  {
   int c = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym || !IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      int pd = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      if(pd == dir)
         continue;
      double op = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      if(sl > 0.0 && (op - sl) * pd <= 0.0)
         continue;                              // gia' a pareggio: non e' a rischio, resta
      int mi = MetaFind(PositionGetInteger(POSITION_IDENTIFIER));
      if(mi < 0 || !IsOnda(g_meta[mi].strat))
         continue;
      if(CloseTicket(tk, g_stratName[g_meta[mi].strat] + ": " + why))
         c++;
     }
   return c;
  }

double TrailLevel(int eng, int dir)
  {
   if(eng == ENG_SCALP)
     {
      double ext = (dir > 0) ? HighestH(g_m1, 0, 10) : LowestL(g_m1, 0, 10);
      return ext - dir * 2.0 * g_ctx.atrM1;
     }
   if(eng == ENG_INTRA)
     {
      double ext = (dir > 0) ? HighestH(g_m15, 0, 8) : LowestL(g_m15, 0, 8);
      return ext - dir * 2.0 * g_ctx.atrM15;
     }
   double ext = (dir > 0) ? HighestH(g_h4, 0, 6) : LowestL(g_h4, 0, 6);
   return ext - dir * 2.5 * g_ctx.atrH4;
  }

//--- uscite obbligate (tempo, fine giornata, venerdi', news)
bool ForcedExit(int mi, string &why)
  {
   int eng = g_meta[mi].engine;
   bool be = g_meta[mi].beDone;
   int ageMin = (int)((TimeCurrent() - g_meta[mi].openTime) / 60);
   double h = HourOf(ToUTC(TimeCurrent()));
   int dow = DowOf(ToUTC(TimeCurrent()));
   //--- 1.26: i movimenti forti sono misurati tenendoli fino alla fine della tenuta (la sera stessa o del giorno dopo):
   //    niente uscita a tempo senza pareggio e niente chiusura prima delle news; il venerdi' sera chiudono come gli altri
   //--- 1.27: i ritracciamenti nel trend hanno il loro tempo massimo (3 volte la durata dell'onda); niente uscita prima
   //    delle news. Venerdi' sera: M5 e M15 chiudono, H1 e H4 secondo InpOndaWeekend (0 tiene, 1 dimezza, 2 chiude)
   if(IsOnda(g_meta[mi].strat))
     {
      datetime nowU = ToUTC(TimeCurrent());
      datetime dl = g_meta[mi].deadline;
      if(dl <= 0)                                // posizione adottata dopo un riavvio senza il suo file: tempo massimo di riserva (150 barre della scala)
         dl = ToUTC(g_meta[mi].openTime) + 150 * OndaBarSec(OndaScale(g_meta[mi].strat));
      if(nowU >= dl)
        {
         why = "ritracciamento: tempo massimo";
         return true;
        }
      if(FridayEvening(nowU))
        {
         if(OndaScale(g_meta[mi].strat) <= 1 || InpOndaWeekend >= 2)
           {
            why = "venerdi' sera";
            return true;
           }
         if(InpOndaWeekend == 1 && InpOndaFriCloseMinLot && !g_meta[mi].wkDone &&
            PositionGetDouble(POSITION_VOLUME) < 2.0 * g_minLot - 0.0000001)
           {
            why = "venerdi' sera: un solo lotto minimo, non si puo' dimezzare";
            return true;
           }
        }
      return false;
     }
   bool tm = IsTrendMove(g_meta[mi].strat);
   if(tm)
     {
      if(ToUTC(TimeCurrent()) >= TmExitUtc(ToUTC(g_meta[mi].openTime)))
        {
         why = "movimento forte: fine della tenuta";
         return true;
        }
      if(FridayEvening(ToUTC(TimeCurrent())))
        {
         why = "venerdi' sera";
         return true;
        }
      return false;
     }
   if(eng == ENG_SCALP)
     {
      if(ageMin >= InpScalpMaxMinutes && !be)
        {
         why = "scalp: tempo scaduto senza pareggio";
         return true;
        }
      if(ageMin >= 3 * InpScalpMaxMinutes)
        {
         why = "scalp: tempo massimo";
         return true;
        }
     }
   if(eng == ENG_INTRA && ageMin >= InpIntraMaxHours * 60 && !be)
     {
      why = "intraday: tempo scaduto senza pareggio";
      return true;
     }
   if(eng != ENG_SWING && h >= EveCloseUTC(ToUTC(TimeCurrent())))
     {
      why = "fine sessione intraday";
      return true;
     }
   if(eng == ENG_SWING)
     {
      int bars = ageMin / 240;
      if(bars >= InpSwingMaxBarsH4 && !be)
        {
         why = "swing: " + IntegerToString(bars) + " barre H4 senza pareggio";
         return true;
        }
      if(bars >= 2 * InpSwingMaxBarsH4)
        {
         why = "swing: tempo massimo";
         return true;
        }
      if(FridayEvening(ToUTC(TimeCurrent())) && !be && !InpSwingHoldWeekend)
        {
         why = "swing non a pareggio prima del weekend";
         return true;
        }
     }
   if(FridayEvening(ToUTC(TimeCurrent())) && eng != ENG_SWING)
     {
      why = "venerdi' sera";
      return true;
     }
   if(InpCloseBeforeNews)
     {
      int m = MinutesToNextTier1(ToUTC(TimeCurrent()));
      if(m >= 0 && m <= 5 && (eng == ENG_SCALP || (eng == ENG_INTRA && !be)))
        {
         why = "news tier1 tra " + IntegerToString(m) + " minuti";
         return true;
        }
     }
   return false;
  }

//--- posizione dell'EA senza metadati (riavvio, file perso): la adotto
int MetaAdopt(ulong tk)
  {
   int k = MetaFree();
   if(k < 0)
      return -1;
   long mg = PositionGetInteger(POSITION_MAGIC);
   int dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
   double op = PositionGetDouble(POSITION_PRICE_OPEN);
   double sl = PositionGetDouble(POSITION_SL);
   double vol = PositionGetDouble(POSITION_VOLUME);
   string cmt = PositionGetString(POSITION_COMMENT);
   g_meta[k].Reset();
   g_meta[k].active = true;
   g_meta[k].id = PositionGetInteger(POSITION_IDENTIFIER);
   g_meta[k].engine = IMax(0, IMin(2, EngineOfMagic(mg)));
   g_meta[k].dir = dir;
   g_meta[k].entry = op;
   g_meta[k].sl0 = sl;
   g_meta[k].tp = PositionGetDouble(POSITION_TP);
   g_meta[k].lots0 = vol;
   g_meta[k].openTime = (datetime)PositionGetInteger(POSITION_TIME);
   if(StringFind(cmt, "XC ") == 0)
     {
      string nm = StringSubstr(cmt, 3);
      int sp = StringFind(nm, " ");
      if(sp > 0)
         nm = StringSubstr(nm, 0, sp);
      g_meta[k].strat = StratByName(nm);
     }
   double r = (sl > 0.0) ? (op - sl) * dir : 0.0;
   if(r <= 0.0)
     {
      g_meta[k].beDone = (sl > 0.0);
      r = MathMax(AtrOf(g_m15), 10.0 * g_tick);
     }
   g_meta[k].riskPx = r;
   g_meta[k].riskMoney = vol * (r * ValuePerPriceUnit() + MathMax(InpCommissionPerLot, 0.0));
   return k;
  }

void MetaSave();

void ManageOne(ulong tk, int mi)
  {
   int dir = g_meta[mi].dir;
   double open = PositionGetDouble(POSITION_PRICE_OPEN);
   double sl = PositionGetDouble(POSITION_SL);
   double tp = PositionGetDouble(POSITION_TP);
   double vol = PositionGetDouble(POSITION_VOLUME);
   double px = (dir > 0) ? PxBid() : PxAsk();
   double r = g_meta[mi].riskPx;
   if(r <= 0.0)
      return;
   string why = "";
   if(ForcedExit(mi, why))
     {
      CloseTicket(tk, why);
      return;
     }
   double pr = (px - open) * dir / r;
   double md = StopsMinDist();
   //--- S (1.25): il venerdi' sera (FridayEvening) uno swing non ancora a pareggio si dimezza (il gap del weekend salta lo stop)
   if(InpWeekendHalfSwing && g_meta[mi].engine == ENG_SWING && !IsOnda(g_meta[mi].strat) && !g_meta[mi].beDone && FridayEvening(g_ctx.nowUtc) &&
      vol >= g_meta[mi].lots0 - g_minLot * 0.5)
     {
      double half = FloorLot(vol * 0.5);
      if(half >= g_minLot && vol - half >= g_minLot - 0.0000001)
        {
         if(g_trade.PositionClosePartial(tk, half))
           {
            vol -= half;
            Notify(g_stratName[g_meta[mi].strat] + ": swing dimezzato prima del weekend (" + DoubleToString(half, g_lotDigits) + " lotti chiusi a " +
                   DoubleToString(pr, 2) + "R)");
           }
        }
     }
   //--- 1.27: ritracciamenti lunghi (H1, H4): il venerdi' sera si dimezzano, una volta sola; se resta un solo lotto
   //    minimo non si puo' dividere: resta aperto e il bot avvisa di quanto rischio passa il weekend
   if(IsOnda(g_meta[mi].strat) && OndaScale(g_meta[mi].strat) >= 2 && InpOndaWeekend == 1 && !g_meta[mi].wkDone && FridayEvening(g_ctx.nowUtc))
     {
      g_meta[mi].wkDone = true;
      double half = FloorLot(vol * 0.5);
      bool cut = false;
      if(half >= g_minLot && vol - half >= g_minLot - 0.0000001)
         if(g_trade.PositionClosePartial(tk, half))
           {
            vol -= half;
            cut = true;
           }
      double left = (sl > 0.0) ? MathMax((open - sl) * dir, 0.0) * vol * ValuePerPriceUnit() : 0.0;
      Notify(g_stratName[g_meta[mi].strat] + (cut ? ": dimezzato prima del weekend (" + DoubleToString(half, g_lotDigits) + " lotti chiusi a " + DoubleToString(pr, 2) + "R)" :
             ": resta intero nel weekend (un solo lotto minimo non si divide)") + ", restano " + DoubleToString(vol, g_lotDigits) +
             " lotti, rischio fino allo stop " + Money(left));
      MetaSave();
     }
   //--- A+ (1.18): gestione attiva a terzi, il primo terzo si chiude a +InpAplusPartialR
   if(g_meta[mi].aplus && !g_meta[mi].thirdDone && !g_meta[mi].beDone && InpAplusPartialR > 0.0 &&
      InpAplusPartialR < InpBE_R && pr >= InpAplusPartialR)
     {
      g_meta[mi].thirdDone = true;
      double third = MathMax(FloorLot(g_meta[mi].lots0 / 3.0), g_minLot);
      if(vol >= g_meta[mi].lots0 - g_minLot * 0.5 && vol - third >= g_minLot - 0.0000001)
         if(g_trade.PositionClosePartial(tk, third))
           {
            vol -= third;
            Logf(g_stratName[g_meta[mi].strat] + ": A+ primo terzo chiuso a +" + DoubleToString(pr, 2) + "R (" +
                 DoubleToString(third, g_lotDigits) + " lotti)");
           }
     }
   //--- regola fissa: a +1.5R lo stop va al prezzo di entrata (+ commissione)
   if(!g_meta[mi].beDone && pr >= InpBE_R)
     {
      double be = open + dir * (BeOffsetPx() + MathMax(InpBeLockR, 0.0) * r);   // 1.17: cuscinetto oltre l'entrata
      bool better = (sl <= 0.0) || ((be - sl) * dir > g_tick * 0.5);
      bool roomOk = ((px - be) * dir >= md);
      if(!better)
         g_meta[mi].beDone = true;
      else
         if(roomOk && ModifySL(tk, be, tp))
           {
            g_meta[mi].beDone = true;
            sl = be;
            Logf(g_stratName[g_meta[mi].strat] + ": stop a pareggio a +" + DoubleToString(pr, 2) + "R");
           }
      double ppct = g_meta[mi].aplus ? 50.0 : InpPartialPct;   // A+: al pareggio meta' di quello che resta
      if(g_meta[mi].beDone && !g_meta[mi].partialDone && ppct > 0.0)
        {
         g_meta[mi].partialDone = true;
         double pv = FloorLot(vol * ppct / 100.0);
         if(pv >= g_minLot && vol - pv >= g_minLot - 0.0000001)
            if(g_trade.PositionClosePartial(tk, pv))
               Logf(g_stratName[g_meta[mi].strat] + ": chiusura parziale " + DoubleToString(pv, g_lotDigits) + " lotti");
        }
     }
   //--- trailing da +2R
   if(g_meta[mi].beDone && pr >= InpTrailStartR && !IsOnda(g_meta[mi].strat) && (InpTDTrail || !IsTrendMove(g_meta[mi].strat)))
     {
      double ns = NormPrice(TrailLevel(g_meta[mi].engine, dir));
      if(ns > 0.0 && (ns - sl) * dir > g_tick && (px - ns) * dir >= md && (ns - open) * dir > 0.0)
         ModifySL(tk, ns, tp);
     }
  }

void ManagePending()
  {
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong ot = OrderGetTicket(i);
      if(ot == 0)
         continue;
      if(OrderGetString(ORDER_SYMBOL) != g_sym || !IsOurMagic(OrderGetInteger(ORDER_MAGIC)))
         continue;
      int mi = MetaFind((long)ot);
      bool kill = false;
      if(mi < 0)
         kill = true;
      else
        {
         int age = (int)((TimeCurrent() - g_meta[mi].openTime) / 60);
         if(age >= g_meta[mi].expiryMin)
            kill = true;
         //--- se il primo ingresso dell'idea e' gia' chiuso, gli scaglioni non servono piu'
         bool mainAlive = false;
         for(int j = 0; j < MAX_META; j++)
            if(g_meta[j].active && g_meta[j].idea == g_meta[mi].idea && g_meta[j].tranche == 0)
               mainAlive = true;
         if(!mainAlive)
            kill = true;
         double px = (g_meta[mi].dir > 0) ? PxBid() : PxAsk();
         if((px - g_meta[mi].tp) * g_meta[mi].dir >= 0.0)
            kill = true;
         int m = MinutesToNextTier1(ToUTC(TimeCurrent()));
         if(m >= 0 && m <= 15)
            kill = true;
        }
      if(kill && g_trade.OrderDelete(ot))
        {
         if(mi >= 0)
            MetaRemove(mi);
        }
     }
  }

void ManagePositions()
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym)
         continue;
      if(!IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      long id = PositionGetInteger(POSITION_IDENTIFIER);
      int mi = MetaFind(id);
      if(mi < 0)
         mi = MetaAdopt(tk);
      if(mi < 0)
         continue;
      if(g_meta[mi].isPending)
        {
         //--- scaglione eseguito: ricalcolo rischio reale
         g_meta[mi].isPending = false;
         g_meta[mi].openTime = (datetime)PositionGetInteger(POSITION_TIME);
         double op = PositionGetDouble(POSITION_PRICE_OPEN);
         g_meta[mi].entry = op;
         g_meta[mi].riskPx = (op - g_meta[mi].sl0) * g_meta[mi].dir;
         g_meta[mi].riskMoney = PositionGetDouble(POSITION_VOLUME) * LossPerLot(g_meta[mi].dir, op, g_meta[mi].sl0);
        }
      if(!PositionSelectByTicket(tk))
         continue;
      ManageOne(tk, mi);
     }
   ManagePending();
  }

//+------------------------------------------------------------------+
//| Chiusure: risultato in R dallo storico, statistiche, giornale    |
//+------------------------------------------------------------------+
void BenchCheck(int k)
  {
   if(!InpUseBench || InpOnlyStrategy != PICK_ALL || k <= 0)
      return;
   if(g_ss[k].n >= 25 && g_ss[k].Expectancy() < -0.2 && g_ss[k].RecentSum(10) < 0.0)
     {
      g_ss[k].Reset();
      g_ss[k].benchUntil = TimeCurrent() + 7 * 86400;
      Notify("Strategia " + g_stratName[k] + " in panchina per 7 giorni (aspettativa negativa)");
     }
  }

//--- K (1.25): commissioni+fee e swap di una posizione dallo storico
bool PositionCostsFromHistory(long id, double &comm, double &swap)
  {
   comm = 0.0;
   swap = 0.0;
   if(!HistorySelectByPosition(id))
      return false;
   int n = HistoryDealsTotal();
   for(int i = 0; i < n; i++)
     {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0)
         continue;
      comm += HistoryDealGetDouble(d, DEAL_COMMISSION) + HistoryDealGetDouble(d, DEAL_FEE);
      swap += HistoryDealGetDouble(d, DEAL_SWAP);
     }
   return true;
  }

double g_lastCostR = 0.0, g_lastComm = 0.0, g_lastSwap = 0.0;

//--- K (1.25): le medie dei costi sopravvivono ai riavvii (variabili globali del terminale, solo live)
void CostSave()
  {
   if(g_isTester)
      return;
   GlobalVariableSet(GvName("cSlip"), g_costSlipPx);
   GlobalVariableSet(GvName("cSlipN"), (double)g_costSlipN);
   GlobalVariableSet(GvName("cSpr"), g_costSpreadPx);
   GlobalVariableSet(GvName("cSprN"), (double)g_costSpreadN);
   GlobalVariableSet(GvName("cComm"), g_costCommLot);
   GlobalVariableSet(GvName("cCommN"), (double)g_costCommN);
   for(int e = 0; e < 3; e++)
     {
      GlobalVariableSet(GvName("cR" + IntegerToString(e)), g_costR[e]);
      GlobalVariableSet(GvName("cRN" + IntegerToString(e)), (double)g_costRN[e]);
     }
  }

void CostLoad()
  {
   for(int e = 0; e < 3; e++)
     {
      g_costR[e] = 0.0;
      g_costRN[e] = 0;
     }
   if(g_isTester)
      return;
   g_costSlipPx = GvGet("cSlip", 0.0);
   g_costSlipN = (int)GvGet("cSlipN", 0.0);
   g_costSpreadPx = GvGet("cSpr", 0.0);
   g_costSpreadN = (int)GvGet("cSprN", 0.0);
   g_costCommLot = GvGet("cComm", 0.0);
   g_costCommN = (int)GvGet("cCommN", 0.0);
   for(int e = 0; e < 3; e++)
     {
      g_costR[e] = GvGet("cR" + IntegerToString(e), 0.0);
      g_costRN[e] = (int)GvGet("cRN" + IntegerToString(e), 0.0);
     }
  }

//--- K (1.25): costo vero del trade appena chiuso (spread + slittamento all'ingresso + commissioni + swap negativo), in R
void CostOnClose(int mi)
  {
   double comm = 0.0, swap = 0.0;
   PositionCostsFromHistory(g_meta[mi].id, comm, swap);
   double vpu = ValuePerPriceUnit();
   double lots = g_meta[mi].lots0;
   double money = (g_meta[mi].spreadPx + MathMax(g_meta[mi].slipPx, 0.0)) * lots * vpu + MathAbs(comm) + MathMax(-swap, 0.0);
   g_lastComm = comm;
   g_lastSwap = swap;
   g_lastCostR = (g_meta[mi].riskMoney > 0.0) ? money / g_meta[mi].riskMoney : 0.0;
   if(!InpCostTrack || g_meta[mi].isPending)
      return;
   if(lots > 0.0)
     {
      g_costCommLot = CostAvg(g_costCommLot, g_costCommN, MathAbs(comm) / lots);
      g_costCommN++;
     }
   int e = g_meta[mi].engine;
   if(e >= 0 && e < 3)
     {
      g_costR[e] = CostAvg(g_costR[e], g_costRN[e], g_lastCostR);
      g_costRN[e]++;
      if(g_costRN[e] == 10 || (g_costRN[e] > 10 && g_costRN[e] % 20 == 0))
         if(g_costR[e] > InpMaxCostR)
            Notify("Costi veri alti nel motore " + g_engName[e] + ": in media " + DoubleToString(g_costR[e] * 100.0, 0) +
                   "% del rischio su " + IntegerToString(g_costRN[e]) + " trade (limite " + DoubleToString(InpMaxCostR * 100.0, 0) + "%)");
     }
   CostSave();
  }

void JournalWrite(int mi, double R, double net)
  {
   if(g_isOptim)
      return;
   string fn = g_isTester ? "XauCommittee_tester_trades.csv" : "XauCommittee_" + IntegerToString(g_login) + "_trades_costi.csv";
   int h = FileOpen(fn, FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return;
   if(FileSize(h) == 0)
      FileWriteString(h, "chiusura;motore;strategia;direzione;lotti;entrata;stop;target;R;netto;score;recupero;extra_profitti;idea;spread;slittamento;commissioni;swap;costi_R\r\n");
   FileSeek(h, 0, SEEK_END);
   string line = TimeToString(TimeCurrent(), TIME_DATE | TIME_MINUTES) + ";" + g_engName[g_meta[mi].engine] + ";" +
                 g_stratName[g_meta[mi].strat] + ";" + DirName(g_meta[mi].dir) + ";" + DoubleToString(g_meta[mi].lots0, g_lotDigits) + ";" +
                 DoubleToString(g_meta[mi].entry, g_digits) + ";" + DoubleToString(g_meta[mi].sl0, g_digits) + ";" +
                 DoubleToString(g_meta[mi].tp, g_digits) + ";" + DoubleToString(R, 2) + ";" + DoubleToString(net, 2) + ";" +
                 DoubleToString(g_meta[mi].score, 2) + ";" + (g_meta[mi].recovery ? "si" : "no") + ";" + DoubleToString(g_meta[mi].cushion, 2) + ";" +
                 IntegerToString(g_meta[mi].idea) + ";" + DoubleToString(g_meta[mi].spreadPx, g_digits) + ";" + DoubleToString(g_meta[mi].slipPx, g_digits) + ";" +
                 DoubleToString(g_lastComm, 2) + ";" + DoubleToString(g_lastSwap, 2) + ";" + DoubleToString(g_lastCostR, 3) + "\r\n";
   FileWriteString(h, line);
   FileClose(h);
  }

void StatsSave();

void FinalizeTrade(int mi, double net)
  {
   double R = (g_meta[mi].riskMoney > 0.0) ? net / g_meta[mi].riskMoney : 0.0;
   int k = g_meta[mi].strat;
   int e = g_meta[mi].engine;
   if(k > 0)
     {
      g_ss[k].Add(R, net);
      g_rep[k].Add(R, net);
     }
   if(e >= 0 && e < 3)
      g_es[e].Add(R, net);
   g_all.Add(R, net);
   //--- rientro (1.17): idea tornata a pareggio dopo aver toccato +BE_R -> si puo' rientrare una volta
   if(e >= 0 && e < 3)
     {
      if(R < -0.3)
         g_reArmed[e] = false;
      else
         if(InpReentryOn && g_meta[mi].beDone && g_meta[mi].tranche == 0 && !g_meta[mi].reentry && !g_meta[mi].recovery && R < 1.0)
           {
            g_reArmed[e] = true;
            g_reDir[e] = g_meta[mi].dir;
            g_reT[e] = TimeCurrent();
           }
     }
   if(R < -0.3)
     {
      g_lossStreak++;
      g_lossesInRowToday++;
      if(g_meta[mi].recovery)
        {
         g_recoveryArmed = false;
         g_recoveryCooldownUntil = TimeCurrent() + 24 * 3600;
        }
      else
         if(InpRecoveryEnabled && TimeCurrent() >= g_recoveryCooldownUntil)
           {
            g_recoveryArmed = true;
            g_recoveryArmedT = TimeCurrent();
           }
     }
   else
      if(R > 0.3)
        {
         g_lossStreak = 0;
         g_lossesInRowToday = 0;
         g_recoveryArmed = false;
        }
   BenchCheck(k);
   CostOnClose(mi);
   JournalWrite(mi, R, net);
   string msg = "CHIUSO [" + g_engName[e] + "] " + g_stratName[k] + " " + DirName(g_meta[mi].dir) + ": " +
                (net >= 0.0 ? "+" : "") + Money(net) + " (" + (R >= 0.0 ? "+" : "") + DoubleToString(R, 2) + "R)";
   Notify(msg);
   RememberDecision(msg);
   MetaRemove(mi);
   StatsSave();
  }

//--- somma netta di tutti i deal di una posizione (entrata + uscite + commissioni + swap)
bool PositionNetFromHistory(long id, double &net, int &deals)
  {
   net = 0.0;
   deals = 0;
   if(!HistorySelectByPosition(id))
      return false;
   int n = HistoryDealsTotal();
   for(int i = 0; i < n; i++)
     {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0)
         continue;
      net += HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_COMMISSION) +
             HistoryDealGetDouble(d, DEAL_SWAP) + HistoryDealGetDouble(d, DEAL_FEE);
      deals++;
     }
   return true;
  }

//--- metadati senza piu' posizione/ordine -> trade chiuso (o ordine scaduto)
void MetaSweep()
  {
   g_needSweep = false;
   for(int i = 0; i < MAX_META; i++)
     {
      if(!g_meta[i].active)
         continue;
      long id = g_meta[i].id;
      if(g_meta[i].isPending)
        {
         if(OrderExists(id) || PositionExistsById(id))
            continue;
        }
      else
         if(PositionExistsById(id))
            continue;
      double net = 0.0;
      int deals = 0;
      PositionNetFromHistory(id, net, deals);
      if(deals >= 2)
         FinalizeTrade(i, net);
      else
        {
         //--- lo storico puo' arrivare con un attimo di ritardo: riprovo prima di arrendermi
         g_meta[i].sweepTries++;
         if(!g_meta[i].isPending && g_meta[i].sweepTries < 20)
            continue;
         MetaRemove(i);
        }
     }
  }

//+------------------------------------------------------------------+
//| Salvataggio su file (solo live): metadati e statistiche          |
//+------------------------------------------------------------------+
string MetaFile() { return "XauCommittee_" + IntegerToString(g_login) + "_" + IntegerToString(InpMagicBase) + "_meta.txt"; }
string StatsFile() { return "XauCommittee_" + IntegerToString(g_login) + "_" + IntegerToString(InpMagicBase) + "_stats.txt"; }

void MetaSave()
  {
   if(g_isTester)
      return;
   int h = FileOpen(MetaFile(), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   for(int i = 0; i < MAX_META; i++)
     {
      if(!g_meta[i].active)
         continue;
      string l = IntegerToString(g_meta[i].id) + ";" + IntegerToString(g_meta[i].strat) + ";" + IntegerToString(g_meta[i].engine) + ";" +
                 IntegerToString(g_meta[i].dir) + ";" + IntegerToString(g_meta[i].tranche) + ";" + IntegerToString(g_meta[i].idea) + ";" +
                 DoubleToString(g_meta[i].entry, 5) + ";" + DoubleToString(g_meta[i].sl0, 5) + ";" + DoubleToString(g_meta[i].tp, 5) + ";" +
                 DoubleToString(g_meta[i].riskPx, 5) + ";" + DoubleToString(g_meta[i].riskMoney, 2) + ";" + DoubleToString(g_meta[i].lots0, 2) + ";" +
                 DoubleToString(g_meta[i].score, 3) + ";" + IntegerToString(g_meta[i].recovery ? 1 : 0) + ";" +
                 IntegerToString(g_meta[i].beDone ? 1 : 0) + ";" + IntegerToString(g_meta[i].partialDone ? 1 : 0) + ";" +
                 IntegerToString(g_meta[i].isPending ? 1 : 0) + ";" + IntegerToString((long)g_meta[i].openTime) + ";" +
                 IntegerToString(g_meta[i].expiryMin) + ";" + IntegerToString(g_meta[i].reentry ? 1 : 0) + ";" +
                 IntegerToString(g_meta[i].aplus ? 1 : 0) + ";" + IntegerToString((long)g_meta[i].deadline) + ";" +
                 IntegerToString(g_meta[i].wkDone ? 1 : 0) + "\r\n";
      FileWriteString(h, l);
     }
   FileClose(h);
  }

void MetaLoad()
  {
   if(g_isTester || !FileIsExist(MetaFile(), FILE_COMMON))
      return;
   int h = FileOpen(MetaFile(), FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      int np = StringSplit(l, ';', p);
      if(np < 19)
         continue;
      int k = MetaFree();
      if(k < 0)
         break;
      g_meta[k].Reset();
      g_meta[k].active = true;
      g_meta[k].id = StringToInteger(p[0]);
      g_meta[k].strat = (int)StringToInteger(p[1]);
      g_meta[k].engine = (int)StringToInteger(p[2]);
      g_meta[k].dir = (int)StringToInteger(p[3]);
      g_meta[k].tranche = (int)StringToInteger(p[4]);
      g_meta[k].idea = (int)StringToInteger(p[5]);
      g_meta[k].entry = StringToDouble(p[6]);
      g_meta[k].sl0 = StringToDouble(p[7]);
      g_meta[k].tp = StringToDouble(p[8]);
      g_meta[k].riskPx = StringToDouble(p[9]);
      g_meta[k].riskMoney = StringToDouble(p[10]);
      g_meta[k].lots0 = StringToDouble(p[11]);
      g_meta[k].score = StringToDouble(p[12]);
      g_meta[k].recovery = (StringToInteger(p[13]) != 0);
      g_meta[k].beDone = (StringToInteger(p[14]) != 0);
      g_meta[k].partialDone = (StringToInteger(p[15]) != 0);
      g_meta[k].isPending = (StringToInteger(p[16]) != 0);
      g_meta[k].openTime = (datetime)StringToInteger(p[17]);
      g_meta[k].expiryMin = (int)StringToInteger(p[18]);
      g_meta[k].reentry = (np >= 20 && StringToInteger(p[19]) != 0);
      g_meta[k].aplus = (np >= 21 && StringToInteger(p[20]) != 0);
      if(np >= 22)
         g_meta[k].deadline = (datetime)StringToInteger(p[21]);
      g_meta[k].wkDone = (np >= 23 && StringToInteger(p[22]) != 0);
      if(g_meta[k].strat < 0 || g_meta[k].strat >= NSTRAT || g_meta[k].engine < 0 || g_meta[k].engine > 2)
         g_meta[k].Reset();
      else
         if(g_meta[k].idea > g_ideaSeq)
            g_ideaSeq = g_meta[k].idea;
     }
   FileClose(h);
  }

void StatsSave()
  {
   if(g_isTester)
      return;
   int h = FileOpen(StatsFile(), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   for(int k = 1; k < NSTRAT; k++)
     {
      string l = IntegerToString(k) + ";" + IntegerToString(g_ss[k].n) + ";" + IntegerToString(g_ss[k].wins) + ";" +
                 IntegerToString(g_ss[k].losses) + ";" + DoubleToString(g_ss[k].sumR, 4) + ";" + DoubleToString(g_ss[k].sumR2, 4) + ";" +
                 DoubleToString(g_ss[k].grossWinR, 4) + ";" + DoubleToString(g_ss[k].grossLossR, 4) + ";" +
                 DoubleToString(g_ss[k].net, 2) + ";" + IntegerToString((long)g_ss[k].benchUntil);
      for(int j = 0; j < 10; j++)
         l += ";" + DoubleToString(g_ss[k].last[j], 3);
      l += ";" + IntegerToString(g_ss[k].lastN) + ";" + IntegerToString(g_ss[k].lastHead) + "\r\n";
      FileWriteString(h, l);
     }
   FileClose(h);
   MetaSave();
  }

void StatsLoad()
  {
   for(int k = 0; k < NSTRAT; k++)
     {
      g_ss[k].Reset();
      g_rep[k].Reset();
     }
   for(int e = 0; e < 3; e++)
      g_es[e].Reset();
   g_all.Reset();
   if(g_isTester || !FileIsExist(StatsFile(), FILE_COMMON))
      return;
   int h = FileOpen(StatsFile(), FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      if(StringSplit(l, ';', p) < 22)
         continue;
      int k = (int)StringToInteger(p[0]);
      if(k <= 0 || k >= NSTRAT)
         continue;
      g_ss[k].n = (int)StringToInteger(p[1]);
      g_ss[k].wins = (int)StringToInteger(p[2]);
      g_ss[k].losses = (int)StringToInteger(p[3]);
      g_ss[k].sumR = StringToDouble(p[4]);
      g_ss[k].sumR2 = StringToDouble(p[5]);
      g_ss[k].grossWinR = StringToDouble(p[6]);
      g_ss[k].grossLossR = StringToDouble(p[7]);
      g_ss[k].net = StringToDouble(p[8]);
      g_ss[k].benchUntil = (datetime)StringToInteger(p[9]);
      for(int j = 0; j < 10; j++)
         g_ss[k].last[j] = StringToDouble(p[10 + j]);
      g_ss[k].lastN = IMin(10, IMax(0, (int)StringToInteger(p[20])));
      g_ss[k].lastHead = IMin(9, IMax(0, (int)StringToInteger(p[21])));
     }
   FileClose(h);
  }
//+------------------------------------------------------------------+
//| Motori, pannello, eventi MT5                                     |
//+------------------------------------------------------------------+
void CtxUpdate()
  {
   g_ctx.bid = PxBid();
   g_ctx.ask = PxAsk();
   g_ctx.spread = MathMax(g_ctx.ask - g_ctx.bid, 0.0);
   g_ctx.atrM1 = AtrOf(g_m1);
   g_ctx.atrM5 = AtrOf(g_m5);
   g_ctx.atrM15 = AtrOf(g_m15);
   g_ctx.atrH1 = AtrOf(g_h1);
   g_ctx.atrH4 = AtrOf(g_h4);
   g_ctx.atrD1 = AtrOf(g_d1);
   g_ctx.vwap = VwapVal(g_vwD);
   g_ctx.vwSig = VwapSigma(g_vwD);
   g_ctx.wvwap = VwapVal(g_vwW);
   g_ctx.nowSrv = TimeCurrent();
   g_ctx.nowUtc = ToUTC(g_ctx.nowSrv);
   g_ctx.hUtc = HourOf(g_ctx.nowUtc);
   g_ctx.lonOpen = LondonOpenUTC(g_ctx.nowUtc);
   g_ctx.nyData = NYDataUTC(g_ctx.nowUtc);
   g_ctx.nyOpen = NYOpenUTC(g_ctx.nowUtc);
   g_ctx.nyClose = NYCloseUTC(g_ctx.nowUtc);
   g_ctx.dow = DowOf(g_ctx.nowUtc);
  }

//--- finestre operative dei motori (UTC, con ora legale)
bool InRollover()
  {
   double h = g_ctx.hUtc, c = g_ctx.nyClose;
   double d = h - c;
   if(d < -12.0)
      d += 24.0;
   return (d >= -0.25 && d <= 1.25);
  }

bool EngineWindow(int e)
  {
   double h = g_ctx.hUtc;
   int dow = g_ctx.dow;
   if(dow == 0 || dow == 6 || InRollover())
      return false;
   if(dow == 5 && h >= 18.0)
      return false;
   if(e == ENG_SCALP)
     {
      bool lon = (h >= g_ctx.lonOpen && h < g_ctx.lonOpen + 3.0);
      bool ny = (h >= g_ctx.nyData - 0.25 && h < g_ctx.nyOpen + 2.5);
      return ((lon || ny) && h < EveCloseUTC(g_ctx.nowUtc) - 0.5);
     }
   if(e == ENG_INTRA)
      return (h >= g_ctx.lonOpen && h < EveCloseUTC(g_ctx.nowUtc) - 1.0);
   if(dow == 1 && h < 2.0)
      return false;
   return true;
  }

bool EngineEnabled(int e)
  {
   if(e == ENG_SCALP)
      return InpEnableScalping;
   if(e == ENG_INTRA)
      return InpEnableIntraday;
   return InpEnableSwing;
  }

string DecisionLine(const TSignal &s)
  {
   string verdict = s.passed ? "APPROVATO" : "RESPINTO";
   string t = "[" + g_engName[s.engine] + "] " + g_stratName[s.strat] + " " + DirName(s.dir) +
              " score " + DoubleToString(s.score, 2) + " quorum " + IntegerToString(s.quorum) + "/8 diavolo " +
              IntegerToString(s.devil) + " -> " + verdict;
   if(s.veto)
      t += " (" + s.vetoWhy + ")";
   return t;
  }

//--- D (1.25): diario CSV di ogni idea valutata dal comitato (per capire dopo 4-8 settimane quali desk e strategie rendono)
//    1.27: tre colonne in piu' (letture del mercato a favore, contro e saldo di quelle provate): sul conto il diario
//    continua in un file nuovo (_decisioni2.csv), quello vecchio resta com'e'
string DecisionFile() { return g_isTester ? "XauCommittee_tester_decisioni.csv" : "XauCommittee_" + IntegerToString(g_login) + "_decisioni2.csv"; }

string CsvClean(string t)
  {
   string r = t;
   StringReplace(r, ";", ",");
   StringReplace(r, "\r", " ");
   StringReplace(r, "\n", " ");
   return r;
  }

void DecisionLog(const TSignal &s, string esito, int idea)
  {
   if(!InpDecisionLog || g_isOptim)
      return;
   int h = FileOpen(DecisionFile(), FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return;
   if(FileSize(h) == 0)
     {
      string hd = "tempo_utc;motore;strategia;direzione;entrata;stop;target;rr";
      for(int d = 0; d < NDESK; d++)
         hd += ";" + g_deskName[d];
      hd += ";punteggio;quorum;diavolo;veto;approvato;esito;idea;vol_prevista;rischio_x_vol;spread;costo_R;macro;contesto;obiezioni;scavalcate;motivo;letture_favore;letture_contro;letture_provate\r\n";
      FileWriteString(h, hd);
     }
   FileSeek(h, 0, SEEK_END);
   double risk = RiskPx(s);
   double rr = (risk > 0.0) ? (s.tp - s.entry) * s.dir / risk : 0.0;
   double costR = (risk > 0.0) ? (g_ctx.spread + CommissionPx() + SlipEstPx(g_ctx.spread)) / risk : 0.0;
   string l = TimeToString(g_ctx.nowUtc, TIME_DATE | TIME_MINUTES) + ";" + g_engName[s.engine] + ";" + g_stratName[s.strat] + ";" + DirName(s.dir) + ";" +
              DoubleToString(s.entry, g_digits) + ";" + DoubleToString(s.sl, g_digits) + ";" + DoubleToString(s.tp, g_digits) + ";" + DoubleToString(rr, 2);
   for(int d = 0; d < NDESK; d++)
      l += ";" + DoubleToString(s.desk[d], 2);
   l += ";" + DoubleToString(s.score, 3) + ";" + IntegerToString(s.quorum) + ";" + IntegerToString(s.devil) + ";" + CsvClean(s.vetoWhy) + ";" +
        (s.passed ? "si" : "no") + ";" + CsvClean(esito) + ";" + IntegerToString(idea) + ";" + DoubleToString(VolForecast(), 2) + ";" +
        DoubleToString(VolTargetMult(), 2) + ";" + DoubleToString(g_ctx.spread, g_digits) + ";" + DoubleToString(costR, 3) + ";" +
        DoubleToString(g_mBias, 2) + ";" + DoubleToString(g_ctxBias, 2) + ";" + CsvClean(ObjList(s.objMask)) + ";" +
        (s.overrideOk ? "si: " + CsvClean(s.softWhy) : "no") + ";" + CsvClean(StringSubstr(s.why, 0, 160)) + ";" + CsvClean(RdList(s.rdFav)) + ";" +
        CsvClean(RdList(s.rdAg)) + ";" + IntegerToString(s.rdConf) + "\r\n";
   FileWriteString(h, l);
   FileClose(h);
  }

//--- giornata a cui appartiene la mossa di un movimento forte (la notte dopo le 18:00 di New York conta per il giorno dopo)
int TmDayKey(int strat)
  {
   if(strat == ST_IN_NIGHT && g_ctx.nowUtc >= Ny8Utc(g_ctx.nowUtc) + 10 * 3600)
      return Ymd(g_ctx.nowUtc + 86400);
   return Ymd(g_ctx.nowUtc);
  }

//--- valuta i segnali di un motore e esegue il migliore approvato
//    1.26: le strategie in osservazione votano, finiscono nel diario e vengono seguite sulla carta, ma non aprono ordini
void RunEngine(int e, TSignal &cands[], int n)
  {
   int best = -1;
   for(int i = 0; i < n; i++)
     {
      SignalAdjust(cands[i]);
      Committee(cands[i]);
      GhostAdd(cands[i]);                    // MR (1.25): ogni buona idea, presa o no, viene seguita
      bool obs = IdeaObserved(cands[i]);   // 1.27: una strategia in osservazione puo' aprire le sole idee nel verso del trend giornaliero
      string line = DecisionLine(cands[i]);
      if(cands[i].passed && !obs)
        {
         if(best < 0 || cands[i].score > cands[best].score)
            best = i;
        }
      if(InpVerboseLog)
         Logf(line + " | " + DeskLine(cands[i]) + " | " + cands[i].why);
      if(!cands[i].passed)
        {
         RememberDecision(line);
         //--- 1.27: un ritracciamento respinto si riprova solo se il motivo puo' passare in pochi minuti (news, spread, costi)
         if(IsOnda(cands[i].strat) && StringFind(cands[i].vetoWhy, "news") < 0 && StringFind(cands[i].vetoWhy, "spread") < 0 &&
            StringFind(cands[i].vetoWhy, "costi") < 0)
            OndaMarkDone(OndaScale(cands[i].strat), "respinto (" + StringSubstr(cands[i].vetoWhy, 0, 40) + ")");
        }
      else
         if(obs)
           {
            RememberDecision(line + " | IN OSSERVAZIONE: seguita sulla carta, nessun ordine");
            if(IsTrendMove(cands[i].strat))
               TmMarkDone(cands[i].strat, TmDayKey(cands[i].strat), "seguita sulla carta " + DirName(cands[i].dir));
            if(IsOnda(cands[i].strat))
               OndaMarkDone(OndaScale(cands[i].strat), "seguito sulla carta");
           }
     }
   for(int i = 0; i < n; i++)
      if(i != best)
        {
         string esito = "respinto";
         if(cands[i].passed)
            esito = IdeaObserved(cands[i]) ? "in osservazione: seguita sulla carta, nessun ordine" : "approvato, scelto un altro piu' forte";
         DecisionLog(cands[i], esito, 0);
        }
   if(best < 0)
      return;
   Logf(DecisionLine(cands[best]) + " | " + cands[best].why + " | " + DeskLine(cands[best]));
   bool done = Execute(cands[best]);
   if(done && cands[best].overrideOk)
      g_overCount++;
   if(IsTrendMove(cands[best].strat))
     {
      //--- una mossa al giorno: aperta, oppure il conto non la regge (inutile riprovare ogni minuto)
      string dw = done ? "aperto " + DirName(cands[best].dir) : "non eseguito: " + g_execWhy;
      TmMarkDone(cands[best].strat, TmDayKey(cands[best].strat), dw);
     }
   if(IsOnda(cands[best].strat))
      OndaMarkDone(OndaScale(cands[best].strat), done ? "aperto " + DirName(cands[best].dir) : "non eseguito: " + StringSubstr(g_execWhy, 0, 40));
   DecisionLog(cands[best], done ? "aperto" : "non eseguito: " + g_execWhy, done ? g_ideaSeq : 0);
  }

void AddCand(TSignal &cands[], int &n, const TSignal &s)
  {
   ArrayResize(cands, n + 1);
   SigCopy(cands[n], s);
   n++;
  }

void EvalScalping()
  {
   if(!EngineEnabled(ENG_SCALP) || !EngineWindow(ENG_SCALP))
      return;
   TSignal cands[];
   int n = 0;
   TSignal s;
   if(StratEnabled(ST_SC_VWAP) && S_ScVwap(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_SC_SWEEP) && S_ScSweep(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_SC_ORB) && S_ScOrb(s))
      AddCand(cands, n, s);
   if(n > 0)
      RunEngine(ENG_SCALP, cands, n);
  }

void EvalIntraday(bool newM15)
  {
   if(!EngineEnabled(ENG_INTRA) || !EngineWindow(ENG_INTRA))
     {
      g_vaNewM15 = false;
      return;
     }
   TSignal cands[];
   int n = 0;
   TSignal s;
   if(StratEnabled(ST_IN_PULLBACK) && S_InPullback(s))
      AddCand(cands, n, s);
   if(newM15 && StratEnabled(ST_IN_SWEEP) && S_InSweep(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_BREAKOUT) && S_InBreakout(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_VALUE) && S_InValue(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_NEWS) && S_InNews(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_RANGE) && S_InRange(s))
      AddCand(cands, n, s);
   g_vaNewM15 = false;
   if(n > 0)
      RunEngine(ENG_INTRA, cands, n);
  }

//--- 1.26: movimenti forti (giornata di tendenza, dato d'inflazione, notte): si guardano a ogni M1 con la loro finestra
void EvalTrendMoves()
  {
   TSignal cands[];
   int n = 0;
   TSignal s;
   if(StratEnabled(ST_IN_TREND) && S_InTrendDay(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_DATA) && S_InData(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_NIGHT) && S_InNight(s))
      AddCand(cands, n, s);
   if(n > 0 && EngineEnabled(ENG_INTRA) && TmWindow())
      RunEngine(ENG_INTRA, cands, n);
   //--- 1.27: secondo ingresso della giornata di tendenza: valutato da solo, cosi' puo' aprire anche nel minuto del primo
   TSignal s2;
   if(StratEnabled(ST_IN_TREND2) && S_InTrend2(s2) && EngineEnabled(ENG_INTRA) && TmWindow())
     {
      TSignal c2[];
      int n2 = 0;
      AddCand(c2, n2, s2);
      RunEngine(ENG_INTRA, c2, n2);
     }
  }

//--- 1.27: ritracciamenti nel verso del trend (ONDA): ogni scala e' valutata da sola, cosi' possono aprire piu' ingressi
void EvalOnda()
  {
   for(int sc = 0; sc < ON_N; sc++)
     {
      int st = OndaStrat(sc);
      if(!StratEnabled(st))
        {
         g_ondaText[sc] = "";
         continue;
        }
      TSignal s;
      if(!S_Onda(s, sc))
         continue;
      if(!EngineEnabled(g_stratEngine[st]) || !TmWindow())
         continue;
      TSignal cands[];
      int n = 0;
      AddCand(cands, n, s);
      RunEngine(g_stratEngine[st], cands, n);
     }
  }

void EvalSwing()
  {
   if(!EngineEnabled(ENG_SWING) || !EngineWindow(ENG_SWING))
      return;
   TSignal cands[];
   int n = 0;
   TSignal s;
   if(StratEnabled(ST_SW_TREND) && S_SwTrend(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_SW_WYCKOFF) && S_SwWyckoff(s))
      AddCand(cands, n, s);
   if(n > 0)
      RunEngine(ENG_SWING, cands, n);
  }

//+------------------------------------------------------------------+
//| Pannello sul grafico                                             |
//+------------------------------------------------------------------+
string EngineStatus(int e)
  {
   if(!EngineEnabled(e))
      return g_engName[e] + ": spento";
   //--- 1.26: quali strategie del motore aprono ordini davvero (le altre lavorano sulla carta)
   int act = 0, obs = 0, actTm = 0;
   double pvStop = 0.0, pvCap = 0.0;          // tra le regole provate attive: lo stop piu' accessibile e il suo tetto con il lotto minimo
   for(int k = 1; k < NSTRAT; k++)
     {
      if(g_stratEngine[k] != e || !StratEnabled(k))
         continue;
      if(StratObserved(k))
         obs++;
      else
        {
         act++;
         if(IsProvenFam(k))
           {
            actTm++;
            double sp = MathMin(InpTDStopMinAtr, InpTDStopAtr) * TdAtr();
            double cp = MathMax(MathMin(InpTDMinLotRiskPct, InpMaxRiskPerTrade), InpMinLotMaxRiskPct);
            if(IsOnda(k))
              {
               sp = OndaStopMin(OndaScale(k)) * TdAtr();
               cp = OndaMinLotCap();
              }
            if(cp > 0.0 && (pvCap <= 0.0 || sp / cp < pvStop / pvCap))
              {
               pvStop = sp;
               pvCap = cp;
              }
           }
        }
     }
   if(act == 0)
      return g_engName[e] + ((obs > 0) ? ": in osservazione (sulla carta)" : ": nessuna strategia accesa");
   double slPx = (e == ENG_SCALP) ? g_ctx.atrM5 : ((e == ENG_INTRA) ? g_ctx.atrM15 : g_ctx.atrH4);
   double cap = InpMinLotMaxRiskPct;
   bool onlyTm = (actTm > 0 && actTm == act);
   if(onlyTm)
     {
      //--- aprono solo i movimenti forti: conta il loro stop piu' stretto e il loro tetto con il lotto minimo
      slPx = pvStop;
      cap = pvCap;
     }
   double base = BaseCapital();
   if(slPx > 0.0 && base > 0.0)
     {
      double lpl = LossPerLot(1, g_ctx.ask, g_ctx.ask - slPx);
      double minRisk = lpl * g_minLot;
      double pct = 100.0 * minRisk / base;
      if(pct > cap)
         return g_engName[e] + ": in attesa (serve conto ~" + DoubleToString(minRisk * 100.0 / cap, 0) + " " + g_currency + ")";
     }
   string tail = (obs > 0) ? " (" + IntegerToString(act) + " strategie, " + IntegerToString(obs) + " sulla carta)" : "";
   if(onlyTm)
      return g_engName[e] + ": attivo" + tail;
   return g_engName[e] + (EngineWindow(e) ? ": attivo" : ": fuori orario") + tail;
  }

string SessionName()
  {
   double h = g_ctx.hUtc;
   if(InRollover())
      return "rollover";
   if(h < g_ctx.lonOpen)
      return "Asia";
   if(h < g_ctx.nyData)
      return "Londra";
   if(h < g_ctx.nyClose - 4.0)
      return "Londra+New York";
   return "New York";
  }

//--- 1.27: il commento sul grafico di MT5 tiene 2045 caratteri e taglia il resto senza avvisare. Ogni riga del
//    pannello ha una priorita' (0 = resta sempre); se il testo non ci sta si tolgono le righe meno importanti,
//    cosi' le ultime decisioni non spariscono mai dal fondo.
#define PN_MAX    40
#define PN_BUDGET 2040
string g_pnText[PN_MAX];
int    g_pnPrio[PN_MAX];
int    g_pnN = 0;

void PnAdd(string t, int prio)
  {
   if(t == "" || g_pnN >= PN_MAX)
      return;
   g_pnText[g_pnN] = t;
   g_pnPrio[g_pnN] = prio;
   g_pnN++;
  }

string PnBuild(int budget)
  {
   int len = 0;
   for(int i = 0; i < g_pnN; i++)
      len += StringLen(g_pnText[i]);
   for(int p = 9; p >= 1 && len > budget; p--)
      for(int i = g_pnN - 1; i >= 0 && len > budget; i--)
         if(g_pnPrio[i] == p)
           {
            len -= StringLen(g_pnText[i]);
            g_pnText[i] = "";
           }
   string t = "";
   for(int i = 0; i < g_pnN; i++)
      t += g_pnText[i];
   if(StringLen(t) > budget)
      t = StringSubstr(t, 0, budget);
   return t;
  }

void Panel()
  {
   if(g_isOptim)
      return;
   double eq = AccEquity();
   double dayPct = (g_dayStartEq > 0.0) ? 100.0 * (eq / g_dayStartEq - 1.0) : 0.0;
   double weekPct = (g_weekStartEq > 0.0) ? 100.0 * (eq / g_weekStartEq - 1.0) : 0.0;
   double dd = (g_peakEq > 0.0) ? 100.0 * (1.0 - eq / g_peakEq) : 0.0;
   string why = "";
   string st = TradingHalted(why) ? "FERMO - " + why : "operativo";
   string macro = MacroText();
   if(AiFresh())
      macro += " | comitato AI: " + g_aiStance + " " + DoubleToString(g_aiConv, 2);
   int k = NextTier1Index(g_ctx.nowUtc);
   string nx = "nessuna nelle prossime 36 ore";
   if(k >= 0)
      nx = g_news[k].title + " alle " + TimeToString(g_news[k].utc, TIME_MINUTES) + " UTC (tra " + IntegerToString(MinutesToNextTier1(g_ctx.nowUtc)) + " min)";
   PortfolioScan();
   g_pnN = 0;
   PnAdd("XAU COMMITTEE EA " + g_version + "  [" + g_sym + "]" + (g_netting ? "  ATTENZIONE: conto netting (1 posizione)" : "") + "\n", 0);
   PnAdd("Stato: " + StringSubstr(st, 0, 150) + "\n", 0);
   if(InpVirtualCapital > 0.0)
      PnAdd("Capitale virtuale " + Money(InpVirtualCapital) + " (conto vero " + Money(AccountInfoDouble(ACCOUNT_EQUITY)) + "): lotti e limiti calcolati sul virtuale\n", 0);
   PnAdd("Equity " + Money(eq) + " | oggi " + DoubleToString(dayPct, 2) + "% | settimana " + DoubleToString(weekPct, 2) + "% | drawdown " + DoubleToString(dd, 1) + "%\n", 0);
   PnAdd("Regime H1: " + g_regName[g_regime] + " | sessione: " + SessionName() + " | spread " + DoubleToString(g_ctx.spread, g_digits) + "\n", 0);
   PnAdd("Macro: " + StringSubstr(macro, 0, 190) + "\n", 0);
   if(g_extraText != "" && StringFind(g_mSource, "GitHub") >= 0)
      PnAdd("Extra (solo info): " + StringSubstr(g_extraText, 0, 160) + "\n", 8);
   if(g_lastDataText != "" && g_lastDataTime > 0 && g_ctx.nowUtc - g_lastDataTime <= 6 * 3600)
      PnAdd("Dopo il dato: " + StringSubstr(g_lastDataText, 0, 170) + "\n", 2);
   PnAdd("Contesto: " + StringSubstr(g_ctxText, 0, 150) + "\n", 0);
   PnAdd("Favoriti adesso: " + StringSubstr(FavoredText(), 0, 120) + "\n", 5);
   PnAdd("Prossima news forte: " + StringSubstr(nx, 0, 110) + "\n", 0);
   PnAdd(EngineStatus(ENG_SCALP) + " | " + EngineStatus(ENG_INTRA) + " | " + EngineStatus(ENG_SWING) + "\n", 0);
   PnAdd("Posizioni " + IntegerToString(g_cntAll) + "/" + IntegerToString(MaxPositionsEff()) + " | rischio aperto " + Money(g_openRiskMoney) +
         " | serie perdite " + IntegerToString(g_lossStreak) + (g_recoveryArmed ? " | recupero pronto" : "") +
         ((g_reArmed[0] || g_reArmed[1] || g_reArmed[2]) ? " | rientro pronto" : "") + "\n", 0);
   PnAdd("Volatilita' prevista x" + DoubleToString(VolForecast(), 2) + " del normale" + (VolTargetMult() < 0.999 ? " -> rischio x" + DoubleToString(VolTargetMult(), 2) : "") +
         " | rischio long " + Money(g_openRiskDir[0]) + " short " + Money(g_openRiskDir[1]) + " (max " + Pct(InpMaxDirRiskPct) + " per verso)\n", 6);
   if(InpCostTrack)
      PnAdd("Costi veri: spread " + DoubleToString(g_costSpreadPx, g_digits) + " slittamento " + DoubleToString(g_costSlipPx, g_digits) +
            " (" + IntegerToString(g_costSlipN) + " ingressi) | commissioni " + Money(CommPerLotEff()) + "/lotto | in R: scalp " +
            DoubleToString(g_costR[0], 2) + " intra " + DoubleToString(g_costR[1], 2) + " swing " + DoubleToString(g_costR[2], 2) + "\n", 7);
   if(InpObjLearn || InpOverrideOn)
      PnAdd(ObjPanel() + "\n", 7);
   PnAdd(TmPanel(), 0);
   PnAdd(OndaPanel(), 0);
   PnAdd(RdPanelPart(0), 0);
   PnAdd(RdPanelPart(1), 4);
   PnAdd(RdPanelPart(2), 6);
   if(InpObserveOn)
      PnAdd(StPanel() + "\n", 4);
   PnAdd("Ultime decisioni:\n", 0);
   int shown = 0;
   for(int i = 0; i < 6; i++)
     {
      int idx = (g_lastDecisionHead - 1 - i + 12) % 6;
      if(g_lastDecision[idx] == "")
         continue;
      //--- la decisione piu' recente resta quasi sempre; le piu' vecchie lasciano il posto per prime
      int pr = (shown == 0) ? 1 : ((shown == 1) ? 3 : ((shown == 2) ? 5 : 9));
      PnAdd("  " + StringSubstr(g_lastDecision[idx], 0, 150) + "\n", pr);
      shown++;
     }
   Comment(PnBuild(PN_BUDGET));
  }

//+------------------------------------------------------------------+
//| Report statistico (tester e chiusura EA)                         |
//+------------------------------------------------------------------+
string StatRow(string name, const StratStat &st)
  {
   return name + ": trade " + IntegerToString(st.n) + " | win " + DoubleToString(st.WinRate(), 1) + "% | aspettativa " +
          DoubleToString(st.Expectancy(), 2) + "R | PF " + DoubleToString(st.ProfitFactor(), 2) + " | netto " + DoubleToString(st.net, 2);
  }

void PrintReport()
  {
   if(g_isOptim)
      return;
   Print("===== REPORT XAU COMMITTEE (per strategia) =====");
   for(int k = 1; k < NSTRAT; k++)
      if(g_rep[k].n > 0)
         Print(StatRow(g_stratName[k], g_rep[k]));
   for(int e = 0; e < 3; e++)
      if(g_es[e].n > 0)
         Print(StatRow("MOTORE " + g_engName[e], g_es[e]));
   Print(StatRow("TOTALE", g_all));
   if(!g_isTester)
      return;
   int h = FileOpen("XauCommittee_tester_report.csv", FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   FileWriteString(h, "strategia;trade;win%;aspettativa_R;profit_factor;netto\r\n");
   for(int k = 1; k < NSTRAT; k++)
      FileWriteString(h, g_stratName[k] + ";" + IntegerToString(g_rep[k].n) + ";" + DoubleToString(g_rep[k].WinRate(), 1) + ";" +
                      DoubleToString(g_rep[k].Expectancy(), 3) + ";" + DoubleToString(g_rep[k].ProfitFactor(), 2) + ";" + DoubleToString(g_rep[k].net, 2) + "\r\n");
   FileClose(h);
  }

//+------------------------------------------------------------------+
//| Eventi                                                           |
//+------------------------------------------------------------------+
//--- briefing giornaliero: il quadro che il comitato usa per tutto il giorno
datetime g_lastBriefing = 0;

void Briefing()
  {
   if(g_isOptim)
      return;
   datetime d = iTime(g_sym, PERIOD_D1, 0);
   if(d == g_lastBriefing)
      return;
   g_lastBriefing = d;
   double tot = Clamp(0.5 * g_ctxBias + 0.5 * g_mBias * Clamp(g_mConf * 1.4, 0.0, 1.0), -1.0, 1.0);
   string verso = (tot > 0.25) ? "preferenza LONG" : ((tot < -0.25) ? "preferenza SHORT" : "nessuna direzione netta: solo setup molto puliti");
   string msg = "BRIEFING ORO " + TimeToString(TimeCurrent(), TIME_DATE) + "\n" +
                "Contesto: " + g_ctxText + "\n" +
                "Macro: " + MacroText() + "\n" +
                (g_extraText != "" ? "Extra (solo info): " + g_extraText + "\n" : "") +
                "Quadro: " + verso + " (" + DoubleToString(tot, 2) + ") | favoriti: " + FavoredText() + "\n" +
                "Motori del prezzo: " + RunBrakeText();
   Logf(msg);
   if(InpPushNotify && !g_isTester)
      SendNotification(StringSubstr("Oro: " + verso + " | " + FavoredText() + " | se domani non arriva questo messaggio, controlla Mac e MT5", 0, 250));
  }

void OnNewM1(datetime m1open)
  {
   MicroFinalize();
   g_tkDelta = 0.0;
   g_tkCount = 0.0;
   g_tkBarOpen = m1open;
   g_m1.lastOpen = m1open;
   TfRefresh(g_m1);
   GhostUpdate();
   bool n5 = TfNewBar(g_m5);
   bool n15 = TfNewBar(g_m15);
   bool nh1 = TfNewBar(g_h1);
   bool nh4 = TfNewBar(g_h4);
   bool nd1 = TfNewBar(g_d1);
   bool nw1 = TfNewBar(g_w1);
   if(n5)
      TfRefresh(g_m5);
   if(n15)
      TfRefresh(g_m15);
   if(nh1)
      TfRefresh(g_h1);
   if(nh4)
      TfRefresh(g_h4);
   if(nd1)
     {
      TfRefresh(g_d1);
      UpdateWeekly();
     }
   if(nw1)
      TfRefresh(g_w1);
   if(nh1)
     {
      UpdateGmtOffset();
      UpdateRegime();
     }
   if(nh4 || nd1)
     {
      UpdateContext();
      IntermarketUpdate();
     }
   if(nh1 || nh4 || nd1)
      MacroCombine();
   CtxUpdate();
   OndaRefresh(n5, n15, nh1, nh4, nd1);        // 1.27: onde sulle quattro scale
   RunBrakeUpdate();
   if(g_isTester)
      TesterNewsRefresh(g_ctx.nowUtc);
   DataTell(g_ctx.nowUtc);
   //--- barra M1 appena chiusa -> VWAP del giorno e sessioni
   datetime dAnchor = iTime(g_sym, PERIOD_D1, 0);
   int i1 = TfIdx(g_m1, 0);
   if(i1 >= 0)
     {
      VwapFeed(g_vwD, dAnchor, g_m1.r[i1].time, g_m1.r[i1].high, g_m1.r[i1].low, g_m1.r[i1].close, (double)g_m1.r[i1].tick_volume);
      SessFeed(g_m1.r[i1].time, g_m1.r[i1].high, g_m1.r[i1].low);
     }
   if(n5)
     {
      int i5 = TfIdx(g_m5, 0);
      if(i5 >= 0)
        {
         RvolAdd(g_m5.r[i5].time, (double)g_m5.r[i5].tick_volume);
         ProfileFeed(dAnchor, g_m5.r[i5].time, g_m5.r[i5].low, g_m5.r[i5].high, (double)g_m5.r[i5].tick_volume);
         VwapFeed(g_vwW, iTime(g_sym, PERIOD_W1, 0), g_m5.r[i5].time, g_m5.r[i5].high, g_m5.r[i5].low, g_m5.r[i5].close, (double)g_m5.r[i5].tick_volume);
        }
     }
   CtxUpdate();
   if(n5)
     {
      NewsTrack();
      BuildLevels();
     }
   if(n15)
     {
      BrkOnM15();
      ValueOnM15();
     }
   RdUpdate(n5, n15, nh1);                     // 1.27: lettura del mercato (dopo livelli, sessioni e VWAP)
   RiskPeriodCheck();
   MetaSweep();
   if(nd1)
      Briefing();
   if(!DataReady())
      return;
   string why = "";
   if(TradingHalted(why))
      return;
   EvalScalping();
   EvalTrendMoves();
   EvalOnda();
   if(n5)
      EvalIntraday(n15);
   if(nh1)
      EvalSwing();
  }

int OnInit()
  {
   g_isTester = (MQLInfoInteger(MQL_TESTER) != 0);
   g_isOptim = (MQLInfoInteger(MQL_OPTIMIZATION) != 0);
   g_isVisual = (MQLInfoInteger(MQL_VISUAL_MODE) != 0);
   g_sym = (InpSymbolOverride != "") ? InpSymbolOverride : _Symbol;
   if(!SymbolSelect(g_sym, true))
     {
      Print("Simbolo non trovato: ", g_sym);
      return INIT_FAILED;
     }
   if(InpRiskPercent <= 0.0 || InpRiskPercent > 10.0 || InpMinRR < 1.0 || InpBE_R <= 0.0 || InpMaxPositions < 1 ||
      InpDailyLossPct <= 0.0 || InpWeeklyLossPct <= 0.0 || InpMaxDrawdownPct <= 0.0 || InpMaxDrawdownPct > 100.0)
     {
      Print("Parametri non validi: controlla rischio, R:R, pareggio e limiti");
      return INIT_PARAMETERS_INCORRECT;
     }
   g_point = SymbolInfoDouble(g_sym, SYMBOL_POINT);
   g_tick = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_SIZE);
   if(g_tick <= 0.0)
      g_tick = g_point;
   g_digits = (int)SymbolInfoInteger(g_sym, SYMBOL_DIGITS);
   g_minLot = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_MIN);
   g_maxLot = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_MAX);
   g_lotStep = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_STEP);
   g_contract = SymbolInfoDouble(g_sym, SYMBOL_TRADE_CONTRACT_SIZE);
   g_lotDigits = (g_lotStep >= 1.0) ? 0 : ((g_lotStep >= 0.1) ? 1 : ((g_lotStep >= 0.01) ? 2 : 3));
   g_currency = AccountInfoString(ACCOUNT_CURRENCY);
   g_login = AccountInfoInteger(ACCOUNT_LOGIN);
   g_netting = (AccountInfoInteger(ACCOUNT_MARGIN_MODE) != ACCOUNT_MARGIN_MODE_RETAIL_HEDGING);
   string up = g_sym;
   StringToUpper(up);
   if(StringFind(up, "XAU") < 0 && StringFind(up, "GOLD") < 0)
      Print("ATTENZIONE: ", g_sym, " non sembra l'oro. L'EA e' pensato per XAUUSD.");
   g_trade.SetDeviationInPoints((ulong)MathMax(10.0, MathRound(0.30 / MathMax(g_point, 0.00001))));
   g_trade.SetTypeFillingBySymbol(g_sym);
   g_trade.LogLevel(LOG_LEVEL_ERRORS);
   UpdateGmtOffset();
   TfInit(g_m1, PERIOD_M1, 240);
   TfInit(g_m5, PERIOD_M5, 400);
   TfInit(g_m15, PERIOD_M15, 400);
   TfInit(g_h1, PERIOD_H1, 400);
   TfInit(g_h4, PERIOD_H4, 300);
   TfInit(g_d1, PERIOD_D1, 160);
   TfInit(g_w1, PERIOD_W1, 150);
   TfNewBar(g_m1);
   TfNewBar(g_m5);
   TfNewBar(g_m15);
   TfNewBar(g_h1);
   TfNewBar(g_h4);
   TfNewBar(g_d1);
   TfNewBar(g_w1);
   TfRefresh(g_m1);
   TfRefresh(g_m5);
   TfRefresh(g_m15);
   TfRefresh(g_h1);
   TfRefresh(g_h4);
   TfRefresh(g_d1);
   TfRefresh(g_w1);
   g_tkBarOpen = g_m1.lastOpen;
   MicroInit();
   RvolInit();
   VwapInit();
   ProfileInit();
   SessInit();
   UpdateWeekly();
   CtxUpdate();
   UpdateRegime();
   BuildLevels();
   IntermarketInit();
   MacroHistLoad();
   UpdateContext();
   IntermarketUpdate();
   StatsLoad();
   for(int i = 0; i < MAX_META; i++)
      g_meta[i].Reset();
   MetaLoad();
   RiskStateInit();
   CostLoad();
   GhostInit();
   ObjLoad();
   StLoad();
   TmInit();
   OndaInit();
   RdLoad();
   CashFlowScan();
   g_lastRealBal = AccountInfoDouble(ACCOUNT_BALANCE);
   //--- nel tester il giornale dei trade riparte vuoto a ogni test
   if(g_isTester && !g_isOptim)
     {
      int fh = FileOpen("XauCommittee_tester_trades.csv", FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
      if(fh != INVALID_HANDLE)
         FileClose(fh);
      fh = FileOpen("XauCommittee_tester_decisioni.csv", FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
      if(fh != INVALID_HANDLE)
         FileClose(fh);
     }
   g_newsN = 0;
   if(g_isTester)
      TesterNewsRefresh(g_ctx.nowUtc);
   else
     {
      CalendarRefresh();
      WebRefresh();
      MacroHistDownload(InpMacroHistUrl);
      EventSetTimer(5);
      if(InpUseDOM)
         g_domOn = MarketBookAdd(g_sym);
     }
   MacroCombine();
   g_ready = true;
   double base = BaseCapital();
   Logf("XAU Committee EA " + g_version + " avviato su " + g_sym + " | conto " + Money(base) + " | lotto minimo " +
        DoubleToString(g_minLot, g_lotDigits) + " | contratto " + DoubleToString(g_contract, 0) + " | fuso server GMT" +
        (g_gmtOffset >= 0 ? "+" : "") + IntegerToString(g_gmtOffset) + (g_netting ? " | conto NETTING: massimo 1 posizione" : " | conto hedging"));
   Logf(EngineStatus(ENG_SCALP) + " | " + EngineStatus(ENG_INTRA) + " | " + EngineStatus(ENG_SWING));
   if(!g_isTester && (!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED)))
      Notify("Attiva il pulsante 'Algo Trading' e la spunta 'Consenti trading algoritmico' nelle proprieta' dell'EA");
   if(g_ddHalt)
      Notify("EA fermo per drawdown massimo raggiunto. Per ripartire: proprieta' EA > 'Sblocca' = true");
   Briefing();
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   if(!g_isTester)
     {
      EventKillTimer();
      if(g_domOn)
         MarketBookRelease(g_sym);
      StatsSave();
      GvSave();
     }
   ObjSave();
   StSave();
   RdSave();
   if(g_isTester && !g_isOptim)
     {
      ObjReport();
      StReport();
      RdReport();
     }
   PrintReport();
   Comment("");
  }

void OnTick()
  {
   if(!g_ready)
      return;
   MqlTick tk;
   if(!SymbolInfoTick(g_sym, tk))
      return;
   FlowCheck();
   datetime m1open = iTime(g_sym, PERIOD_M1, 0);
   bool newM1 = (m1open != 0 && m1open != g_m1.lastOpen);
   if(newM1)
      OnNewM1(m1open);
   TickDelta(tk.bid);
   SpreadTrack(tk.ask - tk.bid);
   RiskCheckLimits();
   if(g_needSweep)
      MetaSweep();
   if(g_needFlowScan)
     {
      g_needFlowScan = false;
      CashFlowScan();
     }
   ManagePositions();
   if(newM1 && g_isTester && g_isVisual)
      Panel();
  }

//--- S (1.25): avvisi sul telefono quando il bot non puo' lavorare bene
datetime g_alAlgo = 0, g_alStale = 0, g_alMacro = 0, g_alSpread = 0, g_spreadBadSince = 0, g_discSince = 0, g_alWeekend = 0;

bool MarketShouldBeOpen(datetime utc)
  {
   int dow = DowOf(utc);
   double h = HourOf(utc);
   if(dow == 0 || dow == 6)
      return false;
   if(dow == 5 && h >= FridayEveUTC(utc) + 0.5)
      return false;
   if(h >= 20.75 && h < 22.5)        // pausa giornaliera del metallo (21-22 o 22-23 UTC secondo l'ora legale)
      return false;
   if(IsUsHoliday(EtYmd(utc)))
      return false;
   return true;
  }

void SafetyCheck()
  {
   if(!InpSafetyAlerts || g_isTester)
      return;
   datetime srv = ServerNow();
   datetime utc = ToUTC(srv);
   bool open = MarketShouldBeOpen(utc);
   //--- Algo Trading spento
   if(open && (!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED)) && srv - g_alAlgo >= 3600)
     {
      g_alAlgo = srv;
      Notify("ATTENZIONE: Algo Trading spento, il bot non puo' aprire ne' gestire i trade");
     }
   //--- connessione persa e ritrovata
   if(!TerminalInfoInteger(TERMINAL_CONNECTED))
     {
      if(g_discSince == 0)
         g_discSince = srv;
     }
   else
      if(g_discSince > 0)
        {
         int mins = (int)((srv - g_discSince) / 60);
         if(mins >= 5)
            Notify("Connessione al broker persa per " + IntegerToString(mins) + " minuti, ora ripristinata: controlla le posizioni");
         g_discSince = 0;
        }
   //--- nessun prezzo nuovo a mercato aperto
   long stale = (long)(srv - TimeCurrent());
   if(open && TerminalInfoInteger(TERMINAL_CONNECTED) && stale >= 15 * 60 && srv - g_alStale >= 3600)
     {
      g_alStale = srv;
      Notify("Nessun prezzo nuovo da " + IntegerToString((int)(stale / 60)) + " minuti a mercato aperto: controlla MT5 e la connessione");
     }
   //--- servizio macro fermo
   if(InpMacroUrl != "" && open)
     {
      long age = (g_macroTime > 0) ? (long)(utc - g_macroTime) : 999999;
      if(age > 6 * 3600 && srv - g_alMacro >= 6 * 3600)
        {
         g_alMacro = srv;
         Notify("Servizio macro fermo: ultimo dato " + (g_macroTime > 0 ? IntegerToString((int)(age / 3600)) + " ore fa" : "mai ricevuto") +
                ". Controlla GitHub Actions (research.yml) e cron-job.org");
        }
     }
   //--- spread esploso per piu' di 2 minuti
   if(open && SpreadAbnormal())
     {
      if(g_spreadBadSince == 0)
         g_spreadBadSince = srv;
      if(srv - g_spreadBadSince >= 120 && srv - g_alSpread >= 3600)
        {
         g_alSpread = srv;
         Notify("Spread esploso: " + DoubleToString(PxAsk() - PxBid(), g_digits) + " contro " + DoubleToString(g_spreadAvg, g_digits) +
                " di media. Ingressi bloccati finche' non rientra");
        }
     }
   else
      g_spreadBadSince = 0;
   //--- venerdi' sera: quanto rischio resta aperto nel weekend
   if(DowOf(utc) == 5 && HourOf(utc) >= FridayEveUTC(utc) + 0.25 && HourOf(utc) < FridayEveUTC(utc) + 1.0 && srv - g_alWeekend >= 12 * 3600)
     {
      g_alWeekend = srv;
      PortfolioScan();
      if(g_cntAll > 0)
         Notify("Weekend: restano aperte " + IntegerToString(g_cntAll) + " posizioni con rischio " + Money(g_openRiskMoney) + " (" +
                Pct(100.0 * g_openRiskMoney / MathMax(BaseCapital(), 0.01)) + "). Un gap puo' saltare gli stop");
     }
  }

void OnTimer()
  {
   if(TimeCurrent() - g_gmtCheckedAt >= 3600)
      UpdateGmtOffset();
   if(TimeCurrent() - g_newsRefreshedAt >= 15 * 60)
      CalendarRefresh();
   else
      if((InpDataAlerts || InpIN_DATA) && TimeCurrent() - g_newsRefreshedAt >= 10 && DataAwaited(ToUTC(ServerNow())))
         CalendarRefresh();                 // 1.26: un dato forte e' appena uscito: rilegge il calendario ogni 10 secondi finche' lo trova
   if(TimeCurrent() - g_webLastTry >= InpWebRefreshMin * 60)
     {
      WebRefresh();
      MacroHistDownload(InpMacroHistUrl);
      MacroCombine();
     }
   CtxUpdate();
   DataTell(ToUTC(ServerNow()));
   SafetyCheck();
   Panel();
  }

void OnTradeTransaction(const MqlTradeTransaction &trans, const MqlTradeRequest &request, const MqlTradeResult &result)
  {
   if(trans.type == TRADE_TRANSACTION_DEAL_ADD)
     {
      g_needSweep = true;
      g_needFlowScan = true;
     }
  }

void OnBookEvent(const string &symbol)
  {
   if(symbol == g_sym && g_domOn)
      DomUpdate();
  }

//--- criterio per l'ottimizzazione: SQN in R corretto per il drawdown
double OnTester()
  {
   int n = g_all.n;
   if(n < 20)
      return 0.0;
   double mean = g_all.sumR / n;
   double var = g_all.sumR2 / n - mean * mean;
   double sd = MathSqrt(MathMax(var, 0.000001));
   double sqn = mean / sd * MathSqrt((double)IMin(n, 100));
   double dd = TesterStatistics(STAT_EQUITY_DDREL_PERCENT);
   return NormalizeDouble(sqn * (1.0 - MathMin(dd, 90.0) / 100.0), 4);
  }
//+------------------------------------------------------------------+
