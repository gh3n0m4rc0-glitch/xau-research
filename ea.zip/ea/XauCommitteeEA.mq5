//+------------------------------------------------------------------+
//|                                              XauCommitteeEA.mq5  |
//|        Comitato per l'oro (XAUUSD): scalping + intraday + swing  |
//|                                                                  |
//|  Tre motori con segnali diversi che parlano la stessa lingua:    |
//|  ogni idea diventa un TSignal, passa dallo stesso comitato di    |
//|  desk (trend, volumi, liquidita, macro, news, sessione, costi,   |
//|  statistica), dallo stesso avvocato del diavolo e dallo stesso   |
//|  risk manager con lotti dinamici in base al conto.               |
//+------------------------------------------------------------------+
#property copyright   "Progetto XAU Committee"
#property version     "1.18"
#property description "EA per l'oro con 3 motori (scalping, intraday, swing) e un comitato comune."
#property description "Lotti dinamici in base al conto, R:R minimo 1:2, pareggio a +1.5R, stop -7% giorno / -10% settimana / 50% drawdown."

#include <Trade\Trade.mqh>

//--- scelta della strategia da testare (per l'ottimizzazione una alla volta)
enum ENUM_STRAT_PICK
  {
   PICK_ALL = 0,          // Tutte le strategie
   PICK_SC_VWAP = 1,      // Solo SC-VWAP (scalping pullback su VWAP)
   PICK_SC_SWEEP = 2,     // Solo SC-SWEEP (scalping stop run)
   PICK_SC_ORB = 3,       // Solo SC-ORB (scalping range di apertura)
   PICK_IN_PULLBACK = 4,  // Solo IN-PULLBACK (intraday trend pullback)
   PICK_IN_SWEEP = 5,     // Solo IN-SWEEP (intraday stop run sui livelli)
   PICK_IN_BREAKOUT = 6,  // Solo IN-BREAKOUT (intraday breakout + retest)
   PICK_IN_VALUE = 7,     // Solo IN-VALUE80 (regola 80% value area)
   PICK_IN_NEWS = 8,      // Solo IN-NEWS (continuation dopo news)
   PICK_IN_RANGE = 9,     // Solo IN-RANGE (ritorno alla VWAP in laterale)
   PICK_SW_TREND = 10,    // Solo SW-TREND (swing trend pullback H4)
   PICK_SW_WYCKOFF = 11   // Solo SW-WYCKOFF (spring/upthrust H4)
  };

//+------------------------------------------------------------------+
//| Input                                                            |
//+------------------------------------------------------------------+
input group "=== Generale ==="
input string InpSymbolOverride   = "";       // Simbolo oro (vuoto = simbolo del grafico)
input long   InpMagicBase        = 260800;   // Magic base (scalping +1, intraday +2, swing +3)
input bool   InpEnableScalping   = true;     // Motore SCALPING attivo
input bool   InpEnableIntraday   = true;     // Motore INTRADAY attivo
input bool   InpEnableSwing      = true;     // Motore SWING attivo
input ENUM_STRAT_PICK InpOnlyStrategy = PICK_ALL; // Test: usa solo questa strategia
input bool   InpPushNotify       = true;     // Notifiche push sul telefono (app MT5)
input bool   InpVerboseLog       = false;    // Log dettagliato (anche i segnali respinti)

input group "=== Rischio e lotti ==="
input double InpVirtualCapital   = 0.0;      // Capitale virtuale di partenza (0 = conto vero; poi cresce/cala con i risultati)
input double InpRiskPercent      = 1.0;      // Rischio base per trade (% del conto)
input double InpScalpRiskMult    = 0.75;     // Moltiplicatore rischio scalping
input double InpSwingRiskMult    = 1.0;      // Moltiplicatore rischio swing
input double InpMaxRiskPerTrade  = 3.0;      // Rischio massimo per trade (%), recupero incluso
input double InpMinLotMaxRiskPct = 2.5;      // Se serve il lotto minimo: rischio massimo accettato (%)
input double InpMaxOpenRiskPct   = 4.0;      // Rischio aperto totale massimo (%) (posizioni a pareggio = 0)
input int    InpMaxPositions     = 4;        // Posizioni massime contemporanee (tutti i motori)
input double InpMinMarginLevel   = 120.0;    // Livello di margine minimo dopo l'apertura (%)
input double InpMaxLots          = 5.0;      // Lotti massimi per singolo ordine
input double InpDailyLossPct     = 7.0;      // Stop giornaliero (% dall'equity di inizio giorno)
input double InpWeeklyLossPct    = 10.0;     // Stop settimanale (% dall'equity di inizio settimana)
input double InpMaxDrawdownPct   = 50.0;     // Drawdown massimo dal picco: chiude tutto e si ferma (%)
input bool   InpResetHalt        = false;    // Sblocca l'EA dopo lo stop per drawdown massimo
input int    InpMaxLossesInRowDay = 3;       // Perdite di fila nello stesso giorno prima di fermarsi
input double InpCommissionPerLot = 7.0;      // Commissione andata+ritorno per 1 lotto (valuta del conto)

input group "=== Crescita del conto e recupero ==="
input bool   InpUseProfitCushion = true;     // Idee forti: rischio extra pagato con i profitti della settimana
input double InpCushionUse       = 0.5;      // Quota del profitto settimanale usabile come rischio extra
input double InpCushionMaxMult   = 1.0;      // Rischio extra massimo (x rischio base)
input bool   InpRecoveryEnabled  = true;     // Trade di recupero dopo una perdita (una volta sola)
input double InpRecoveryMult     = 1.75;     // Moltiplicatore lotti del trade di recupero
input double InpRecoveryMinScore = 0.75;     // Punteggio minimo del comitato per il recupero
input bool   InpAllowTranches    = true;     // Idee forti: fino a 3 ingressi scaglionati (40/30/30)
input bool   InpUseBench         = true;     // Mette in panchina le strategie con aspettativa negativa

input group "=== Regole fisse dei trade ==="
input double InpMinRR            = 2.0;      // Rischio/rendimento minimo (1:2)
input double InpBE_R             = 1.5;      // Stop a pareggio quando il trade arriva a +R (1.5-1.75)
input double InpPartialPct       = 40.0;     // Chiusura parziale al pareggio (% volume, se il lotto lo permette)
input double InpTrailStartR      = 2.0;      // Trailing stop da +R
input double InpMaxCostR         = 0.15;     // Costi massimi (spread+commissione) come frazione di R

input group "=== Comitato ==="
input double InpMinScoreScalp    = 0.62;     // Punteggio minimo comitato scalping
input double InpMinScoreIntra    = 0.62;     // Punteggio minimo comitato intraday
input double InpMinScoreSwing    = 0.65;     // Punteggio minimo comitato swing
input double InpStrongScore      = 0.78;     // Soglia "idea forte"
input int    InpQuorum           = 6;        // Desk principali favorevoli richiesti (su 8)
input int    InpDevilMax         = 3;        // Obiezioni dell'avvocato del diavolo che bloccano

input group "=== Scalping (M1-M5) ==="
input int    InpScalpMaxTradesDay = 6;       // Trade scalping massimi al giorno
input int    InpScalpMaxMinutes  = 60;       // Chiude lo scalp dopo N minuti se non e' a pareggio
input double InpScalpRR          = 2.2;      // Target scalping (R)
input bool   InpSC_VWAP          = true;     // SC-VWAP: pullback su VWAP in trend
input bool   InpSC_SWEEP         = true;     // SC-SWEEP: stop run sui livelli e rientro
input bool   InpSC_ORB           = true;     // SC-ORB: breakout range di apertura + retest

input group "=== Intraday (M5-M15) ==="
input int    InpIntraMaxTradesDay = 4;       // Trade intraday massimi al giorno
input int    InpIntraMaxHours    = 8;        // Chiude l'intraday dopo N ore se non e' a pareggio
input double InpIntraRR          = 2.5;      // Target intraday (R)
input bool   InpIN_PULLBACK      = true;     // IN-PULLBACK: trend H1 + pullback M15
input bool   InpIN_SWEEP         = true;     // IN-SWEEP: stop run su PDH/PDL/Asia/Londra
input bool   InpIN_BREAKOUT      = true;     // IN-BREAKOUT: breakout con volume + retest
input bool   InpIN_VALUE         = true;     // IN-VALUE80: rientro nella value area di ieri
input bool   InpIN_NEWS          = true;     // IN-NEWS: continuation dopo news coerente con la vista
input bool   InpIN_RANGE         = true;     // IN-RANGE: da VWAP +-2 sigma alla VWAP in laterale

input group "=== Swing (H1-H4) ==="
input int    InpSwingMaxTradesDay = 2;       // Trade swing massimi al giorno
input int    InpSwingMaxBarsH4   = 30;       // Chiude lo swing dopo N barre H4 se non e' a pareggio
input double InpSwingRR          = 3.0;      // Target swing (R)
input bool   InpSwingHoldWeekend = false;    // Tiene lo swing nel weekend anche se non e' a pareggio
input bool   InpSW_TREND         = true;     // SW-TREND: trend H4 + pullback H1
input bool   InpSW_WYCKOFF       = true;     // SW-WYCKOFF: spring/upthrust nel range H4

input group "=== Orari e news ==="
input int    InpGmtOffsetLive    = -99;      // Fuso del server live (ore, -99 = automatico)
input int    InpGmtOffsetTester  = -99;      // Fuso del server nel tester (-99 = GMT+2 inverno / +3 estate)
input int    InpIntraCloseUTC    = 20;       // Ora UTC di chiusura di scalping e intraday
input int    InpNewsBlockBefore  = 30;       // Minuti senza ingressi prima di una news tier1 (scalp/intraday)
input int    InpNewsBlockAfter   = 15;       // Minuti senza ingressi dopo una news tier1 (scalp/intraday)
input int    InpNewsBlockSwingBefore = 90;   // Minuti senza ingressi swing prima di una news tier1
input int    InpNewsBlockSwingAfter  = 60;   // Minuti senza ingressi swing dopo una news tier1
input int    InpNewsBlockFomcAfter   = 90;   // Minuti senza ingressi (anche IN-NEWS) dopo la decisione FOMC, conferenza inclusa (0 = come le altre tier1)
input bool   InpCloseBeforeNews  = true;     // Chiude scalp (e intraday non a pareggio) 5 min prima di news tier1

input group "=== Motori del prezzo (studio 9 nov 2026) ==="
input bool   InpP1RunBrake       = true;     // P1: freno dopo le corse verticali (rischio ridotto, niente long in rottura)
input double InpP1RunSigma       = 2.5;      // P1: corsa degli ultimi 20 giorni oltre questi sigma
input double InpP1Ma200DistPct   = 20.0;     // P1: oppure prezzo oltre questa % sopra la media a 200 giorni
input double InpP1RiskMult       = 0.5;      // P1: moltiplicatore del rischio con il freno acceso
input bool   InpP2ThinLiquidity  = true;     // P2: niente ingressi con liquidita' sottile (feste USA, Asia nelle feste giapponesi, riaperture)
input int    InpP2ReopenMin      = 60;       // P2: minuti senza ingressi dopo una riapertura (pausa oltre 3 ore)
input bool   InpP3NoRiskOffBonus = false;    // P3: azzera il bonus "fuga dal rischio" del desk intermarket
input bool   InpP4FirstDayLong   = false;    // P4: spinta ai long il primo giorno di borsa del mese
input double InpP4Bonus          = 0.02;     // P4: punti aggiunti al punteggio dei long
input bool   InpP5AsiaStopBuffer = false;    // P5: nelle ore asiatiche stop oltre i livelli ovvi (PDH/PDL, settimana, Asia, numeri tondi)
input double InpP5BufferAtrH1    = 0.25;     // P5: margine oltre il livello (x ATR H1)
input bool   InpP6ExpiryTargets  = false;    // P6: target dei breakout piu' corti alla scadenza opzioni COMEX e il giorno dopo
input double InpP6TargetMult     = 0.85;     // P6: moltiplicatore del target in R (mai sotto il minimo 1:2)

input group "=== Coda, pareggio e rientro ==="
input bool   InpQueueOn          = true;     // Coda: con altre posizioni aperte, una nuova idea deve essere piu' sicura
input double InpQueueExtraScore  = 0.04;     // Coda: punti in piu' sul punteggio minimo (e quorum +1)
input double InpBeLockR          = 0.10;     // Pareggio: stop all'entrata + costi + questa quota di R (cuscinetto)
input bool   InpReentryOn        = true;     // Rientro: se un trade torna a pareggio, nuovo ingresso nella stessa direzione se le conferme restano
input double InpReentryMult      = 1.25;     // Rientro: moltiplicatore del rischio (una volta sola per idea)
input group "=== Idee A+ (tutte le conferme) ==="
input bool   InpAplusOn          = true;     // A+: con tutte le conferme rischio piu' alto e gestione attiva a terzi
input double InpAplusRiskPct     = 3.0;      // A+: rischio per trade (% del conto, mai oltre il rischio massimo per trade)
input double InpAplusMaxLots     = 0.03;     // A+: lotti massimi per idea (0 = solo il limite di rischio)
input double InpAplusMinScore    = 0.70;     // A+: punteggio minimo (e almeno il minimo del motore + 0.05)
input double InpAplusPartialR    = 1.0;      // A+: a questo +R chiude un terzo, il secondo al pareggio, il resto segue il trailing

input group "=== Dati esterni (solo conto live/demo) ==="
input bool   InpUseWebData       = true;     // Legge macro, comitato AI e livelli GC da GitHub
input string InpMacroUrl         = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/macro_bias.json"; // URL macro_bias.json
input string InpCommitteeUrl     = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/ai_committee.json"; // URL ai_committee.json
input string InpVolumeUrl        = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/volume_levels.json"; // URL volume_levels.json
input string InpNewsUrl          = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/news_calendar.json"; // URL news_calendar.json (riserva)
input string InpMacroHistUrl     = "https://raw.githubusercontent.com/gh3n0m4rc0-glitch/xau-research/main/public/macro_history.csv"; // URL storico macro (salvato anche per il tester)
input double InpMacroVetoLevel   = 0.45;     // Macro contraria oltre questo livello: veto per intraday e swing
input double InpContextVetoLevel = 0.60;     // Contesto HTF contrario oltre questo livello: veto per intraday e swing
input int    InpWebRefreshMin    = 15;       // Ogni quanti minuti rilegge i dati esterni
input bool   InpUseDOM           = true;     // Usa il book (DOM) se il broker lo fornisce

//+------------------------------------------------------------------+
//| Costanti                                                         |
//+------------------------------------------------------------------+
#define EA_VERSION     "1.18"
#define ENG_SCALP      0
#define ENG_INTRA      1
#define ENG_SWING      2

#define NSTRAT         12
#define ST_SC_VWAP     1
#define ST_SC_SWEEP    2
#define ST_SC_ORB      3
#define ST_IN_PULLBACK 4
#define ST_IN_SWEEP    5
#define ST_IN_BREAKOUT 6
#define ST_IN_VALUE    7
#define ST_IN_NEWS     8
#define ST_IN_RANGE    9
#define ST_SW_TREND    10
#define ST_SW_WYCKOFF  11

#define STYPE_TREND    0
#define STYPE_REVERSAL 1
#define STYPE_BREAKOUT 2
#define STYPE_MEANREV  3
#define STYPE_NEWS     4

#define REG_UP         0
#define REG_DOWN       1
#define REG_RANGE      2
#define REG_VOLATILE   3
#define REG_QUIET      4

#define NDESK          10
#define D_STRAT        0
#define D_TREND        1
#define D_VOLUME       2
#define D_LIQ          3
#define D_MACRO        4
#define D_NEWS         5
#define D_SESSION      6
#define D_COST         7
#define D_STATS        8
#define D_CONTEXT      9

#define MAX_META       64
#define MAX_NEWS       64
#define MAX_LEVELS     64
#define MICRO_N        1440

string g_stratName[NSTRAT]  = {"-", "SC-VWAP", "SC-SWEEP", "SC-ORB", "IN-PULLBACK", "IN-SWEEP", "IN-BREAKOUT", "IN-VALUE80", "IN-NEWS", "IN-RANGE", "SW-TREND", "SW-WYCKOFF"};
int    g_stratEngine[NSTRAT] = {-1, ENG_SCALP, ENG_SCALP, ENG_SCALP, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_INTRA, ENG_SWING, ENG_SWING};
int    g_stratType[NSTRAT]   = {STYPE_TREND, STYPE_TREND, STYPE_REVERSAL, STYPE_BREAKOUT, STYPE_TREND, STYPE_REVERSAL, STYPE_BREAKOUT, STYPE_MEANREV, STYPE_NEWS, STYPE_MEANREV, STYPE_TREND, STYPE_REVERSAL};
string g_engName[3]          = {"Scalping", "Intraday", "Swing"};
string g_deskName[NDESK]     = {"Strategia", "Trend", "Volumi", "Liquidita", "Macro", "News", "Sessione", "Costi", "Statistica", "Contesto HTF"};
string g_deskShort[NDESK]    = {"Str", "Trd", "Vol", "Liq", "Mac", "New", "Ses", "Cst", "Sta", "Ctx"};
string g_regName[5]          = {"trend rialzista", "trend ribassista", "laterale", "volatile", "calmo"};

//+------------------------------------------------------------------+
//| Globali di base                                                  |
//+------------------------------------------------------------------+
CTrade   g_trade;
string   g_sym = "";
string   g_version = EA_VERSION;
double   g_point = 0.0;
double   g_tick = 0.0;
double   g_minLot = 0.0;
double   g_maxLot = 0.0;
double   g_lotStep = 0.0;
double   g_contract = 0.0;
int      g_digits = 2;
int      g_lotDigits = 2;
bool     g_isTester = false;
bool     g_isOptim = false;
bool     g_isVisual = false;
bool     g_netting = false;
bool     g_ready = false;
long     g_login = 0;
int      g_gmtOffset = 2;
datetime g_gmtCheckedAt = 0;
string   g_currency = "";
string   g_lastDecision[6];
int      g_lastDecisionHead = 0;

//+------------------------------------------------------------------+
//| Utilita'                                                         |
//+------------------------------------------------------------------+
double Clamp(double v, double lo, double hi)
  {
   if(v < lo)
      return lo;
   if(v > hi)
      return hi;
   return v;
  }

int IMax(int a, int b) { return (a > b) ? a : b; }
int IMin(int a, int b) { return (a < b) ? a : b; }

double PxBid() { return SymbolInfoDouble(g_sym, SYMBOL_BID); }
double PxAsk() { return SymbolInfoDouble(g_sym, SYMBOL_ASK); }

double NormPrice(double p)
  {
   if(g_tick <= 0.0)
      return NormalizeDouble(p, g_digits);
   return NormalizeDouble(MathRound(p / g_tick) * g_tick, g_digits);
  }

double FloorLot(double lots)
  {
   if(g_lotStep <= 0.0)
      return 0.0;
   double steps = MathFloor(lots / g_lotStep + 0.0000001);
   return NormalizeDouble(steps * g_lotStep, g_lotDigits);
  }

string DirName(int dir) { return (dir > 0) ? "BUY" : "SELL"; }

string Pct(double v) { return DoubleToString(v, 1) + "%"; }

string Money(double v) { return DoubleToString(v, 2) + " " + g_currency; }

//--- valore di 1.0 di prezzo per 1 lotto, in valuta del conto
double ValuePerPriceUnit()
  {
   double tv = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_VALUE);
   double ts = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_SIZE);
   if(tv <= 0.0 || ts <= 0.0)
      return g_contract;
   return tv / ts;
  }

//--- commissione andata+ritorno espressa in prezzo
double CommissionPx()
  {
   if(InpCommissionPerLot <= 0.0)
      return 0.0;
   double v = ValuePerPriceUnit();
   if(v <= 0.0)
      return 0.0;
   return InpCommissionPerLot / v;
  }

void Logf(string msg)
  {
   if(g_isOptim)
      return;
   Print(msg);
  }

void Notify(string msg)
  {
   Logf(msg);
   if(InpPushNotify && !g_isTester)
     {
      string m = msg;
      if(StringLen(m) > 250)
         m = StringSubstr(m, 0, 250);
      SendNotification(m);
     }
  }

void RememberDecision(string line)
  {
   g_lastDecision[g_lastDecisionHead] = line;
   g_lastDecisionHead = (g_lastDecisionHead + 1) % 6;
  }

//+------------------------------------------------------------------+
//| Tempo: fusi orari, ora legale, sessioni                          |
//+------------------------------------------------------------------+
int YearOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.year;
  }

//--- data (00:00 UTC) della n-esima domenica del mese (n=-1 ultima)
datetime NthSunday(int year, int mon, int n)
  {
   MqlDateTime d;
   d.year = year;
   d.mon = mon;
   d.day = 1;
   d.hour = 0;
   d.min = 0;
   d.sec = 0;
   d.day_of_week = 0;
   d.day_of_year = 0;
   datetime first = StructToTime(d);
   MqlDateTime f;
   TimeToStruct(first, f);
   int toSun = (7 - f.day_of_week) % 7;
   datetime firstSun = first + toSun * 86400;
   if(n > 0)
      return firstSun + (n - 1) * 7 * 86400;
   //--- ultima domenica
   datetime s = firstSun;
   while(true)
     {
      datetime nx = s + 7 * 86400;
      MqlDateTime x;
      TimeToStruct(nx, x);
      if(x.mon != mon)
         break;
      s = nx;
     }
   return s;
  }

//--- ora legale USA: seconda domenica di marzo -> prima domenica di novembre (circa 07:00/06:00 UTC)
bool IsUSDST(datetime utc)
  {
   int y = YearOf(utc);
   datetime a = NthSunday(y, 3, 2) + 7 * 3600;
   datetime b = NthSunday(y, 11, 1) + 6 * 3600;
   return (utc >= a && utc < b);
  }

//--- ora legale UK: ultima domenica di marzo -> ultima domenica di ottobre (01:00 UTC)
bool IsUKDST(datetime utc)
  {
   int y = YearOf(utc);
   datetime a = NthSunday(y, 3, -1) + 3600;
   datetime b = NthSunday(y, 10, -1) + 3600;
   return (utc >= a && utc < b);
  }

void UpdateGmtOffset()
  {
   if(g_isTester)
     {
      if(InpGmtOffsetTester != -99)
         g_gmtOffset = InpGmtOffsetTester;
      else
         g_gmtOffset = IsUSDST(TimeCurrent() - 2 * 3600) ? 3 : 2;
     }
   else
     {
      if(InpGmtOffsetLive != -99)
         g_gmtOffset = InpGmtOffsetLive;
      else
        {
         long diff = (long)(TimeTradeServer() - TimeGMT());
         g_gmtOffset = (int)MathRound((double)diff / 3600.0);
        }
     }
   g_gmtCheckedAt = TimeCurrent();
  }

datetime ToUTC(datetime server) { return server - g_gmtOffset * 3600; }
datetime ToServer(datetime utc) { return utc + g_gmtOffset * 3600; }

double HourOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.hour + d.min / 60.0 + d.sec / 3600.0;
  }

int DowOf(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.day_of_week;
  }

int DayKey(datetime t) { return (int)(t / 86400); }

double LondonOpenUTC(datetime utc) { return IsUKDST(utc) ? 7.0 : 8.0; }
double NYDataUTC(datetime utc)     { return IsUSDST(utc) ? 12.5 : 13.5; }
double NYOpenUTC(datetime utc)     { return IsUSDST(utc) ? 13.5 : 14.5; }
double NYCloseUTC(datetime utc)    { return IsUSDST(utc) ? 21.0 : 22.0; }

//--- yyyymmdd di una data UTC
int Ymd(datetime t)
  {
   MqlDateTime d;
   TimeToStruct(t, d);
   return d.year * 10000 + d.mon * 100 + d.day;
  }
//+------------------------------------------------------------------+
//| Dati di mercato e indicatori calcolati internamente              |
//| (stessi numeri nel tester e dal vivo, nessun handle esterno)     |
//+------------------------------------------------------------------+
struct TfData
  {
   ENUM_TIMEFRAMES   tf;
   int               want;
   int               n;
   datetime          lastOpen;
   MqlRates          r[];
   double            ema20[];
   double            ema50[];
   double            ema200[];
   double            atr[];
   double            rsi[];
   double            adx[];
   double            pdi[];
   double            mdi[];
  };

TfData g_m1;
TfData g_m5;
TfData g_m15;
TfData g_h1;
TfData g_h4;
TfData g_d1;

void CalcEMA(const MqlRates &r[], int n, int period, double &out[])
  {
   ArrayResize(out, n);
   if(n <= 0)
      return;
   double k = 2.0 / (period + 1.0);
   //--- seme: media semplice delle prime barre disponibili
   int seed = IMin(period, n);
   double s = 0.0;
   for(int i = 0; i < seed; i++)
      s += r[i].close;
   double v = s / seed;
   for(int i = 0; i < n; i++)
     {
      if(i < seed)
         out[i] = v;
      else
        {
         v = r[i].close * k + v * (1.0 - k);
         out[i] = v;
        }
     }
  }

void CalcATR(const MqlRates &r[], int n, int period, double &out[])
  {
   ArrayResize(out, n);
   if(n <= 0)
      return;
   out[0] = r[0].high - r[0].low;
   for(int i = 1; i < n; i++)
     {
      double tr = MathMax(r[i].high, r[i - 1].close) - MathMin(r[i].low, r[i - 1].close);
      if(i < period)
         out[i] = (out[i - 1] * i + tr) / (i + 1);
      else
         out[i] = (out[i - 1] * (period - 1) + tr) / period;
     }
  }

void CalcRSI(const MqlRates &r[], int n, int period, double &out[])
  {
   ArrayResize(out, n);
   if(n <= 0)
      return;
   double ag = 0.0, al = 0.0;
   out[0] = 50.0;
   for(int i = 1; i < n; i++)
     {
      double ch = r[i].close - r[i - 1].close;
      double g = (ch > 0.0) ? ch : 0.0;
      double l = (ch < 0.0) ? -ch : 0.0;
      if(i <= period)
        {
         ag = (ag * (i - 1) + g) / i;
         al = (al * (i - 1) + l) / i;
        }
      else
        {
         ag = (ag * (period - 1) + g) / period;
         al = (al * (period - 1) + l) / period;
        }
      if(al <= 0.0000000001)
         out[i] = (ag > 0.0) ? 100.0 : 50.0;
      else
         out[i] = 100.0 - 100.0 / (1.0 + ag / al);
     }
  }

void CalcADX(const MqlRates &r[], int n, int period, double &adx[], double &pdi[], double &mdi[])
  {
   ArrayResize(adx, n);
   ArrayResize(pdi, n);
   ArrayResize(mdi, n);
   if(n <= 0)
      return;
   adx[0] = 0.0;
   pdi[0] = 0.0;
   mdi[0] = 0.0;
   double trS = 0.0, pS = 0.0, mS = 0.0, av = 0.0;
   for(int i = 1; i < n; i++)
     {
      double up = r[i].high - r[i - 1].high;
      double dn = r[i - 1].low - r[i].low;
      double pdm = (up > dn && up > 0.0) ? up : 0.0;
      double mdm = (dn > up && dn > 0.0) ? dn : 0.0;
      double tr = MathMax(r[i].high, r[i - 1].close) - MathMin(r[i].low, r[i - 1].close);
      if(i <= period)
        {
         trS += tr;
         pS += pdm;
         mS += mdm;
        }
      else
        {
         trS = trS - trS / period + tr;
         pS = pS - pS / period + pdm;
         mS = mS - mS / period + mdm;
        }
      double p = (trS > 0.0) ? 100.0 * pS / trS : 0.0;
      double m = (trS > 0.0) ? 100.0 * mS / trS : 0.0;
      double dx = (p + m > 0.0) ? 100.0 * MathAbs(p - m) / (p + m) : 0.0;
      if(i <= period)
         av = (av * (i - 1) + dx) / i;
      else
         av = (av * (period - 1) + dx) / period;
      adx[i] = av;
      pdi[i] = p;
      mdi[i] = m;
     }
  }

void TfInit(TfData &d, ENUM_TIMEFRAMES tf, int want)
  {
   d.tf = tf;
   d.want = want;
   d.n = 0;
   d.lastOpen = 0;
  }

bool TfRefresh(TfData &d)
  {
   int got = CopyRates(g_sym, d.tf, 1, d.want, d.r);
   if(got <= 0)
     {
      d.n = 0;
      return false;
     }
   d.n = IMin(got, ArraySize(d.r));
   CalcEMA(d.r, d.n, 20, d.ema20);
   CalcEMA(d.r, d.n, 50, d.ema50);
   CalcEMA(d.r, d.n, 200, d.ema200);
   CalcATR(d.r, d.n, 14, d.atr);
   CalcRSI(d.r, d.n, 14, d.rsi);
   CalcADX(d.r, d.n, 14, d.adx, d.pdi, d.mdi);
   return true;
  }

bool TfNewBar(TfData &d)
  {
   datetime t = iTime(g_sym, d.tf, 0);
   if(t == 0)
      return false;
   if(t != d.lastOpen)
     {
      d.lastOpen = t;
      return true;
     }
   return false;
  }

//--- accesso alle barre chiuse: sh=0 ultima barra chiusa
int TfIdx(const TfData &d, int sh)
  {
   int i = d.n - 1 - sh;
   if(i < 0 || i >= d.n)
      return -1;
   return i;
  }

double BarO(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].open; }
double BarH(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].high; }
double BarL(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].low; }
double BarC(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : d.r[i].close; }
double BarV(const TfData &d, int sh) { int i = TfIdx(d, sh); return (i < 0) ? 0.0 : (double)d.r[i].tick_volume; }
datetime BarT(const TfData &d, int sh) { int i = TfIdx(d, sh); if(i < 0) return 0; return d.r[i].time; }

double Ind(const double &a[], int sh)
  {
   int n = ArraySize(a);
   int i = n - 1 - sh;
   if(i < 0 || i >= n)
      return 0.0;
   return a[i];
  }

double MinInd(const double &a[], int fromSh, int count)
  {
   double m = 1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = ArraySize(a) - 1 - k;
      if(i < 0)
         break;
      if(a[i] < m)
         m = a[i];
     }
   return (m > 1.0e299) ? 0.0 : m;
  }

double MaxInd(const double &a[], int fromSh, int count)
  {
   double m = -1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = ArraySize(a) - 1 - k;
      if(i < 0)
         break;
      if(a[i] > m)
         m = a[i];
     }
   return (m < -1.0e299) ? 0.0 : m;
  }

double HighestH(const TfData &d, int fromSh, int count)
  {
   double m = -1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = TfIdx(d, k);
      if(i < 0)
         break;
      if(d.r[i].high > m)
         m = d.r[i].high;
     }
   return (m < -1.0e299) ? 0.0 : m;
  }

double LowestL(const TfData &d, int fromSh, int count)
  {
   double m = 1.0e300;
   for(int k = fromSh; k < fromSh + count; k++)
     {
      int i = TfIdx(d, k);
      if(i < 0)
         break;
      if(d.r[i].low < m)
         m = d.r[i].low;
     }
   return (m > 1.0e299) ? 0.0 : m;
  }

double AtrOf(const TfData &d) { return Ind(d.atr, 0); }
double AdxOf(const TfData &d) { return Ind(d.adx, 0); }

//--- +1 rialzo, -1 ribasso, 0 misto (EMA20/EMA50 e chiusura rispetto a EMA50)
int TrendDir(const TfData &d)
  {
   if(d.n < 60)
      return 0;
   double e20 = Ind(d.ema20, 0), e50 = Ind(d.ema50, 0), c = BarC(d, 0);
   if(e20 > e50 && c > e50)
      return 1;
   if(e20 < e50 && c < e50)
      return -1;
   return 0;
  }

int EmaDir(const TfData &d)
  {
   if(d.n < 60)
      return 0;
   double e20 = Ind(d.ema20, 0), e50 = Ind(d.ema50, 0);
   if(e20 > e50)
      return 1;
   if(e20 < e50)
      return -1;
   return 0;
  }

//--- posizione della chiusura nella barra (0 = minimo, 1 = massimo)
double ClosePos(const TfData &d, int sh)
  {
   double h = BarH(d, sh), l = BarL(d, sh);
   if(h - l <= 0.0)
      return 0.5;
   return (BarC(d, sh) - l) / (h - l);
  }

//--- quota di spike nella direzione contraria (rifiuto): long = spike in basso
double WickRatio(const TfData &d, int sh, int dir)
  {
   double h = BarH(d, sh), l = BarL(d, sh), o = BarO(d, sh), c = BarC(d, sh);
   double rg = h - l;
   if(rg <= 0.0)
      return 0.0;
   if(dir > 0)
      return (MathMin(o, c) - l) / rg;
   return (h - MathMax(o, c)) / rg;
  }

//--- divergenza RSI: nuovo estremo di prezzo ma RSI piu' debole (contro la direzione dir)
bool RsiDivergenceAgainst(const TfData &d, int dir, int lookback)
  {
   if(d.n < lookback + 5)
      return false;
   if(dir > 0)
     {
      double hNow = HighestH(d, 0, 3), hPrev = HighestH(d, 3, lookback);
      double rNow = MaxInd(d.rsi, 0, 3), rPrev = MaxInd(d.rsi, 3, lookback);
      return (hNow > hPrev && rNow < rPrev - 3.0);
     }
   double lNow = LowestL(d, 0, 3), lPrev = LowestL(d, 3, lookback);
   double rNow2 = MinInd(d.rsi, 0, 3), rPrev2 = MinInd(d.rsi, 3, lookback);
   return (lNow < lPrev && rNow2 > rPrev2 + 3.0);
  }

bool DataReady()
  {
   return (g_m1.n >= 60 && g_m5.n >= 120 && g_m15.n >= 120 && g_h1.n >= 120 && g_h4.n >= 60 && g_d1.n >= 20);
  }

//+------------------------------------------------------------------+
//| Contesto del momento (calcolato una volta per barra M1)          |
//+------------------------------------------------------------------+
struct Ctx
  {
   double            bid;
   double            ask;
   double            spread;
   double            atrM1;
   double            atrM5;
   double            atrM15;
   double            atrH1;
   double            atrH4;
   double            atrD1;
   double            vwap;
   double            vwSig;
   double            wvwap;
   datetime          nowSrv;
   datetime          nowUtc;
   double            hUtc;
   double            lonOpen;
   double            nyData;
   double            nyOpen;
   double            nyClose;
   int               dow;
  };
Ctx g_ctx;
//+------------------------------------------------------------------+
//| Motore volumi: delta tick (tick rule), RVOL per orario, VWAP,    |
//| volume profile (POC/VAH/VAL), VSA, DOM                           |
//+------------------------------------------------------------------+
struct MicroBar
  {
   datetime          t;
   double            o;
   double            h;
   double            l;
   double            c;
   double            vol;
   double            delta;
  };

MicroBar g_micro[MICRO_N];
int      g_microHead = -1;
int      g_microCount = 0;

//--- accumulatori del delta tick della barra M1 in formazione
double   g_tkLastBid = 0.0;
int      g_tkLastDir = 0;
double   g_tkDelta = 0.0;
double   g_tkCount = 0.0;
datetime g_tkBarOpen = 0;

//--- spread medio (per riconoscere spread anomali)
double   g_spreadAvg = 0.0;

void MicroPush(datetime t, double o, double h, double l, double c, double vol, double delta)
  {
   g_microHead = (g_microHead + 1) % MICRO_N;
   g_micro[g_microHead].t = t;
   g_micro[g_microHead].o = o;
   g_micro[g_microHead].h = h;
   g_micro[g_microHead].l = l;
   g_micro[g_microHead].c = c;
   g_micro[g_microHead].vol = vol;
   g_micro[g_microHead].delta = delta;
   if(g_microCount < MICRO_N)
      g_microCount++;
  }

int MicroIdx(int sh)
  {
   if(sh < 0 || sh >= g_microCount || g_microHead < 0)
      return -1;
   return (g_microHead - sh + MICRO_N) % MICRO_N;
  }

double ClvDelta(double h, double l, double c, double vol)
  {
   double rg = h - l;
   if(rg <= 0.0)
      return 0.0;
   double clv = ((c - l) - (h - c)) / rg;
   return clv * vol;
  }

double MicroDelta(int sh)
  {
   int i = MicroIdx(sh);
   return (i < 0) ? 0.0 : g_micro[i].delta;
  }

double MicroCvd(int nBars)
  {
   double s = 0.0;
   for(int k = 0; k < nBars; k++)
     {
      int i = MicroIdx(k);
      if(i < 0)
         break;
      s += g_micro[i].delta;
     }
   return s;
  }

double MicroVolSum(int nBars)
  {
   double s = 0.0;
   for(int k = 0; k < nBars; k++)
     {
      int i = MicroIdx(k);
      if(i < 0)
         break;
      s += g_micro[i].vol;
     }
   return s;
  }

//--- CVD normalizzato (-1..+1) sulle ultime n barre M1
double MicroCvdRatio(int nBars)
  {
   double v = MicroVolSum(nBars);
   if(v <= 0.0)
      return 0.0;
   return MicroCvd(nBars) / v;
  }

void TickDelta(double bid)
  {
   if(g_tkLastBid > 0.0)
     {
      if(bid > g_tkLastBid)
         g_tkLastDir = 1;
      else
         if(bid < g_tkLastBid)
            g_tkLastDir = -1;
      g_tkDelta += g_tkLastDir;
      g_tkCount += 1.0;
     }
   g_tkLastBid = bid;
  }

void SpreadTrack(double sp)
  {
   if(sp <= 0.0)
      return;
   if(g_spreadAvg <= 0.0)
      g_spreadAvg = sp;
   else
      g_spreadAvg += (sp - g_spreadAvg) * 0.002;
  }

bool SpreadAbnormal()
  {
   double sp = PxAsk() - PxBid();
   return (g_spreadAvg > 0.0 && sp > 2.5 * g_spreadAvg && sp > 3.0 * g_tick);
  }

//--- chiude la barra M1 appena finita nel buffer micro
void MicroFinalize()
  {
   MqlRates b[];
   if(CopyRates(g_sym, PERIOD_M1, 1, 1, b) != 1)
      return;
   if(g_microHead >= 0 && g_micro[g_microHead].t >= b[0].time)
      return;
   double vol = (double)b[0].tick_volume;
   double delta;
   if(g_tkBarOpen == b[0].time && g_tkCount >= 3.0)
      delta = (g_tkDelta / g_tkCount) * vol;
   else
      delta = ClvDelta(b[0].high, b[0].low, b[0].close, vol);
   MicroPush(b[0].time, b[0].open, b[0].high, b[0].low, b[0].close, vol, delta);
  }

void MicroInit()
  {
   MqlRates b[];
   int got = CopyRates(g_sym, PERIOD_M1, 1, 600, b);
   g_microHead = -1;
   g_microCount = 0;
   for(int i = 0; i < got; i++)
      MicroPush(b[i].time, b[i].open, b[i].high, b[i].low, b[i].close, (double)b[i].tick_volume,
                ClvDelta(b[i].high, b[i].low, b[i].close, (double)b[i].tick_volume));
  }

//+------------------------------------------------------------------+
//| RVOL: volume rispetto alla media della stessa fascia oraria      |
//+------------------------------------------------------------------+
double g_rvolAvg[288];
int    g_rvolCnt[288];

int SlotOf(datetime serverTime)
  {
   datetime u = ToUTC(serverTime);
   int sec = (int)(u % 86400);
   if(sec < 0)
      sec += 86400;
   return (sec / 300) % 288;
  }

void RvolAdd(datetime barTime, double vol)
  {
   int s = SlotOf(barTime);
   if(g_rvolCnt[s] < 20)
     {
      g_rvolAvg[s] = (g_rvolAvg[s] * g_rvolCnt[s] + vol) / (g_rvolCnt[s] + 1);
      g_rvolCnt[s]++;
     }
   else
      g_rvolAvg[s] += (vol - g_rvolAvg[s]) / 20.0;
  }

void RvolInit()
  {
   ArrayInitialize(g_rvolAvg, 0.0);
   ArrayInitialize(g_rvolCnt, 0);
   MqlRates b[];
   int got = CopyRates(g_sym, PERIOD_M5, 1, 6000, b);
   for(int i = 0; i < got; i++)
      RvolAdd(b[i].time, (double)b[i].tick_volume);
  }

//--- volume atteso per una barra di timeframe tf che inizia a barTime
double RvolExpected(datetime barTime, ENUM_TIMEFRAMES tf)
  {
   int secs = PeriodSeconds(tf);
   int s0 = SlotOf(barTime);
   if(secs < 300)
      return g_rvolAvg[s0] * secs / 300.0;
   int m = secs / 300;
   if(m > 288)
      m = 288;
   double e = 0.0;
   for(int k = 0; k < m; k++)
      e += g_rvolAvg[(s0 + k) % 288];
   return e;
  }

double RvolBar(const TfData &d, int sh)
  {
   int i = TfIdx(d, sh);
   if(i < 0)
      return 1.0;
   double e = RvolExpected(d.r[i].time, d.tf);
   if(e <= 0.0)
      return 1.0;
   return (double)d.r[i].tick_volume / e;
  }

//+------------------------------------------------------------------+
//| VWAP giornaliera (barre M1) e settimanale (barre M5)             |
//+------------------------------------------------------------------+
struct VwapAcc
  {
   datetime          anchor;
   double            sv;
   double            spv;
   double            sp2v;
  };
VwapAcc g_vwD;
VwapAcc g_vwW;

void VwapReset(VwapAcc &a, datetime anchor)
  {
   a.anchor = anchor;
   a.sv = 0.0;
   a.spv = 0.0;
   a.sp2v = 0.0;
  }

void VwapAdd(VwapAcc &a, double tp, double v)
  {
   if(v <= 0.0)
      v = 1.0;
   a.sv += v;
   a.spv += tp * v;
   a.sp2v += tp * tp * v;
  }

double VwapVal(const VwapAcc &a)
  {
   if(a.sv <= 0.0)
      return 0.0;
   return a.spv / a.sv;
  }

double VwapSigma(const VwapAcc &a)
  {
   if(a.sv <= 0.0)
      return 0.0;
   double m = a.spv / a.sv;
   double var = a.sp2v / a.sv - m * m;
   return (var > 0.0) ? MathSqrt(var) : 0.0;
  }

//--- aggiunge una barra chiusa all'accumulatore ancorato a 'anchorNow'
void VwapFeed(VwapAcc &a, datetime anchorNow, datetime barTime, double h, double l, double c, double v)
  {
   if(barTime >= anchorNow && a.anchor != anchorNow)
      VwapReset(a, anchorNow);
   VwapAdd(a, (h + l + c) / 3.0, v);
  }

void VwapInit()
  {
   datetime dAnchor = iTime(g_sym, PERIOD_D1, 0);
   datetime wAnchor = iTime(g_sym, PERIOD_W1, 0);
   VwapReset(g_vwD, dAnchor);
   VwapReset(g_vwW, wAnchor);
   MqlRates b[];
   datetime curM1 = iTime(g_sym, PERIOD_M1, 0);
   int got = CopyRates(g_sym, PERIOD_M1, dAnchor, curM1, b);
   for(int i = 0; i < got; i++)
     {
      if(b[i].time >= curM1)
         continue;
      VwapAdd(g_vwD, (b[i].high + b[i].low + b[i].close) / 3.0, (double)b[i].tick_volume);
     }
   MqlRates w[];
   datetime curM5 = iTime(g_sym, PERIOD_M5, 0);
   int gw = CopyRates(g_sym, PERIOD_M5, wAnchor, curM5, w);
   for(int i = 0; i < gw; i++)
     {
      if(w[i].time >= curM5)
         continue;
      VwapAdd(g_vwW, (w[i].high + w[i].low + w[i].close) / 3.0, (double)w[i].tick_volume);
     }
  }

//+------------------------------------------------------------------+
//| Volume profile giornaliero (barre M5)                            |
//+------------------------------------------------------------------+
struct Profile
  {
   datetime          anchor;
   double            base;
   double            bin;
   double            vol[];
   double            total;
   double            poc;
   double            vah;
   double            val;
   bool              valid;
  };
Profile g_prof[2];
int     g_profCur = 0;

void ProfReset(Profile &p, datetime anchor, double refPrice, double bin)
  {
   p.anchor = anchor;
   p.bin = MathMax(bin, g_tick);
   p.base = refPrice - 100.0 * p.bin;
   ArrayResize(p.vol, 200);
   ArrayInitialize(p.vol, 0.0);
   p.total = 0.0;
   p.poc = 0.0;
   p.vah = 0.0;
   p.val = 0.0;
   p.valid = false;
  }

int ProfIndex(Profile &p, double price)
  {
   int n = ArraySize(p.vol);
   int idx = (int)MathFloor((price - p.base) / p.bin);
   if(idx < 0)
     {
      int k = -idx + 20;
      if(n + k > 3000)
         return 0;
      ArrayResize(p.vol, n + k);
      for(int i = n - 1; i >= 0; i--)
         p.vol[i + k] = p.vol[i];
      for(int i = 0; i < k; i++)
         p.vol[i] = 0.0;
      p.base -= k * p.bin;
      idx += k;
      n += k;
     }
   if(idx >= n)
     {
      int nn = idx + 20;
      if(nn > 3000)
         return n - 1;
      ArrayResize(p.vol, nn);
      for(int i = n; i < nn; i++)
         p.vol[i] = 0.0;
     }
   return idx;
  }

void ProfAddBar(Profile &p, double lo, double hi, double v)
  {
   if(p.bin <= 0.0 || v <= 0.0)
      return;
   int a = ProfIndex(p, lo);
   int b = ProfIndex(p, hi);
   a = ProfIndex(p, lo);   // l'indice basso puo' spostarsi dopo un'estensione
   if(b < a)
     {
      int t = a;
      a = b;
      b = t;
     }
   int cnt = b - a + 1;
   double each = v / cnt;
   for(int i = a; i <= b; i++)
      p.vol[i] += each;
   p.total += v;
  }

void ProfCompute(Profile &p)
  {
   int n = ArraySize(p.vol);
   p.valid = false;
   if(n <= 0 || p.total <= 0.0)
      return;
   int pi = 0;
   for(int i = 1; i < n; i++)
      if(p.vol[i] > p.vol[pi])
         pi = i;
   double target = p.total * 0.70;
   double acc = p.vol[pi];
   int lo = pi, hi = pi;
   while(acc < target && (lo > 0 || hi < n - 1))
     {
      double up = (hi < n - 1) ? p.vol[hi + 1] : -1.0;
      double dn = (lo > 0) ? p.vol[lo - 1] : -1.0;
      if(up >= dn)
        {
         hi++;
         acc += p.vol[hi];
        }
      else
        {
         lo--;
         acc += p.vol[lo];
        }
     }
   p.poc = p.base + (pi + 0.5) * p.bin;
   p.val = p.base + lo * p.bin;
   p.vah = p.base + (hi + 1) * p.bin;
   p.valid = true;
  }

double ProfileBin()
  {
   double a = AtrOf(g_d1);
   double b = (a > 0.0) ? a / 60.0 : 50.0 * g_tick;
   return MathMax(10.0 * g_tick, NormPrice(b));
  }

//--- barra M5 chiusa -> profilo del giorno del broker
void ProfileFeed(datetime dayAnchorNow, datetime barTime, double lo, double hi, double v)
  {
   if(barTime >= dayAnchorNow && g_prof[g_profCur].anchor != dayAnchorNow)
     {
      ProfCompute(g_prof[g_profCur]);
      g_profCur = 1 - g_profCur;
      ProfReset(g_prof[g_profCur], dayAnchorNow, (lo + hi) / 2.0, ProfileBin());
     }
   ProfAddBar(g_prof[g_profCur], lo, hi, v);
  }

void ProfileInit()
  {
   datetime today = iTime(g_sym, PERIOD_D1, 0);
   datetime yday = iTime(g_sym, PERIOD_D1, 1);
   double bin = ProfileBin();
   double ref = PxBid();
   g_profCur = 0;
   ProfReset(g_prof[1], yday, ref, bin);
   ProfReset(g_prof[0], today, ref, bin);
   MqlRates b[];
   datetime curM5 = iTime(g_sym, PERIOD_M5, 0);
   int got = CopyRates(g_sym, PERIOD_M5, yday, curM5, b);
   for(int i = 0; i < got; i++)
     {
      if(b[i].time >= curM5)
         continue;
      if(b[i].time < today)
         ProfAddBar(g_prof[1], b[i].low, b[i].high, (double)b[i].tick_volume);
      else
         ProfAddBar(g_prof[0], b[i].low, b[i].high, (double)b[i].tick_volume);
     }
   ProfCompute(g_prof[1]);
   ProfCompute(g_prof[0]);
  }

bool PrevProfileOk() { return g_prof[1 - g_profCur].valid; }
double PrevVAH() { return g_prof[1 - g_profCur].vah; }
double PrevVAL() { return g_prof[1 - g_profCur].val; }
double PrevPOC() { return g_prof[1 - g_profCur].poc; }

//+------------------------------------------------------------------+
//| VSA: climax e assorbimento                                       |
//+------------------------------------------------------------------+
//--- barra di climax nella direzione 'dir' (volume molto alto, barra ampia, chiusura all'estremo)
bool IsClimax(const TfData &d, int sh, int dir)
  {
   double a = Ind(d.atr, sh + 1);
   if(a <= 0.0)
      return false;
   double rg = BarH(d, sh) - BarL(d, sh);
   if(RvolBar(d, sh) < 2.2 || rg < 1.5 * a)
      return false;
   double cp = ClosePos(d, sh);
   if(dir > 0)
      return (BarC(d, sh) > BarO(d, sh) && cp > 0.7);
   return (BarC(d, sh) < BarO(d, sh) && cp < 0.3);
  }

//--- assorbimento: molto volume ma poco movimento
bool IsAbsorption(const TfData &d, int sh)
  {
   double a = Ind(d.atr, sh + 1);
   if(a <= 0.0)
      return false;
   double rg = BarH(d, sh) - BarL(d, sh);
   return (RvolBar(d, sh) >= 1.8 && rg <= 0.6 * a);
  }

//+------------------------------------------------------------------+
//| DOM (book) - solo se il broker lo fornisce                       |
//+------------------------------------------------------------------+
bool     g_domOn = false;
double   g_domImb = 0.0;
datetime g_domTime = 0;

bool DomFresh() { return (g_domOn && TimeCurrent() - g_domTime <= 10); }

void DomUpdate()
  {
   MqlBookInfo book[];
   if(!MarketBookGet(g_sym, book))
      return;
   int n = ArraySize(book);
   double bv = 0.0, av = 0.0;
   for(int i = 0; i < n; i++)
     {
      double v = (book[i].volume_real > 0.0) ? book[i].volume_real : (double)book[i].volume;
      if(book[i].type == BOOK_TYPE_BUY || book[i].type == BOOK_TYPE_BUY_MARKET)
         bv += v;
      else
         if(book[i].type == BOOK_TYPE_SELL || book[i].type == BOOK_TYPE_SELL_MARKET)
            av += v;
     }
   if(bv + av <= 0.0)
      return;
   g_domImb = (bv - av) / (bv + av);
   g_domTime = TimeCurrent();
  }
//+------------------------------------------------------------------+
//| Sessioni (UTC con ora legale), mappa della liquidita', regime    |
//+------------------------------------------------------------------+
struct OrState
  {
   double            h;
   double            l;
   bool              started;
   bool              done;
   int               brk;
   datetime          brkT;
   bool              used;
  };

struct SessionState
  {
   int               dayKey;
   double            asiaH;
   double            asiaL;
   bool              asiaOn;
   bool              asiaDone;
   double            lonH;
   double            lonL;
   bool              lonOn;
   bool              lonDone;
   double            dayH;
   double            dayL;
   OrState           orLon;
   OrState           orNy;
  };
SessionState g_sess;

void OrReset(OrState &o)
  {
   o.h = 0.0;
   o.l = 0.0;
   o.started = false;
   o.done = false;
   o.brk = 0;
   o.brkT = 0;
   o.used = false;
  }

void SessReset(int dayKey)
  {
   g_sess.dayKey = dayKey;
   g_sess.asiaH = 0.0;
   g_sess.asiaL = 0.0;
   g_sess.asiaOn = false;
   g_sess.asiaDone = false;
   g_sess.lonH = 0.0;
   g_sess.lonL = 0.0;
   g_sess.lonOn = false;
   g_sess.lonDone = false;
   g_sess.dayH = 0.0;
   g_sess.dayL = 0.0;
   OrReset(g_sess.orLon);
   OrReset(g_sess.orNy);
  }

void OrFeed(OrState &o, double hu, double openH, double hi, double lo)
  {
   if(hu >= openH && hu < openH + 0.25)
     {
      if(!o.started)
        {
         o.h = hi;
         o.l = lo;
         o.started = true;
        }
      else
        {
         o.h = MathMax(o.h, hi);
         o.l = MathMin(o.l, lo);
        }
     }
   if(hu >= openH + 0.25 && o.started)
      o.done = true;
  }

//--- barra M1 chiusa (tempo server) -> stato delle sessioni del giorno UTC
void SessFeed(datetime barSrv, double hi, double lo)
  {
   datetime u = ToUTC(barSrv);
   int dk = DayKey(u);
   if(dk != g_sess.dayKey)
      SessReset(dk);
   double hu = HourOf(u);
   double lon = LondonOpenUTC(u);
   double nyd = NYDataUTC(u);
   double nyo = NYOpenUTC(u);
   if(g_sess.dayH == 0.0 || hi > g_sess.dayH)
      g_sess.dayH = hi;
   if(g_sess.dayL == 0.0 || lo < g_sess.dayL)
      g_sess.dayL = lo;
   if(hu < lon)
     {
      if(!g_sess.asiaOn)
        {
         g_sess.asiaH = hi;
         g_sess.asiaL = lo;
         g_sess.asiaOn = true;
        }
      else
        {
         g_sess.asiaH = MathMax(g_sess.asiaH, hi);
         g_sess.asiaL = MathMin(g_sess.asiaL, lo);
        }
     }
   else
      if(g_sess.asiaOn)
         g_sess.asiaDone = true;
   if(hu >= lon && hu < nyd)
     {
      if(!g_sess.lonOn)
        {
         g_sess.lonH = hi;
         g_sess.lonL = lo;
         g_sess.lonOn = true;
        }
      else
        {
         g_sess.lonH = MathMax(g_sess.lonH, hi);
         g_sess.lonL = MathMin(g_sess.lonL, lo);
        }
     }
   if(hu >= nyd && g_sess.lonOn)
      g_sess.lonDone = true;
   OrFeed(g_sess.orLon, hu, lon, hi, lo);
   OrFeed(g_sess.orNy, hu, nyo, hi, lo);
  }

void SessInit()
  {
   datetime nowU = ToUTC(TimeCurrent());
   SessReset(DayKey(nowU));
   datetime startSrv = ToServer((datetime)(DayKey(nowU)) * 86400);
   MqlRates b[];
   datetime curM1 = iTime(g_sym, PERIOD_M1, 0);
   int got = CopyRates(g_sym, PERIOD_M1, startSrv, curM1, b);
   for(int i = 0; i < got; i++)
     {
      if(b[i].time >= curM1)
         continue;
      SessFeed(b[i].time, b[i].high, b[i].low);
     }
   //--- gli OR gia' passati non vanno piu' tradati dopo un riavvio
   if(g_sess.orLon.done)
      g_sess.orLon.used = true;
   if(g_sess.orNy.done)
      g_sess.orNy.used = true;
  }

//+------------------------------------------------------------------+
//| Mappa dei livelli di liquidita'                                  |
//+------------------------------------------------------------------+
#define LV_PDH     0
#define LV_PDL     1
#define LV_PDC     2
#define LV_PWH     3
#define LV_PWL     4
#define LV_ASIAH   5
#define LV_ASIAL   6
#define LV_LONH    7
#define LV_LONL    8
#define LV_VAH     9
#define LV_VAL     10
#define LV_POC     11
#define LV_VWAP    12
#define LV_VWAPB1  13
#define LV_VWAPB2  14
#define LV_WVWAP   15
#define LV_SWING   16
#define LV_ROUND   17
#define LV_ROUNDM  18
#define LV_GC      19
#define LV_DAYHL   20

string g_lvName[21] = {"PDH", "PDL", "PDC", "PWH", "PWL", "Asia H", "Asia L", "Londra H", "Londra L", "VAH ieri", "VAL ieri", "POC ieri", "VWAP", "VWAP 1s", "VWAP 2s", "VWAP sett", "swing H1", "tondo", "tondo forte", "livello GC", "max/min oggi"};

struct TLevel
  {
   double            price;
   int               type;
   double            weight;
  };
TLevel g_lv[MAX_LEVELS];
int    g_lvN = 0;
double g_pwH = 0.0;
double g_pwL = 0.0;

void LvAdd(double price, int type, double weight)
  {
   if(price <= 0.0 || g_lvN >= MAX_LEVELS)
      return;
   g_lv[g_lvN].price = price;
   g_lv[g_lvN].type = type;
   g_lv[g_lvN].weight = weight;
   g_lvN++;
  }

bool IsMajorLevel(int type)
  {
   return (type == LV_PDH || type == LV_PDL || type == LV_PWH || type == LV_PWL || type == LV_ROUNDM ||
           type == LV_VAH || type == LV_VAL || type == LV_POC || type == LV_GC);
  }

void UpdateWeekly()
  {
   MqlRates w[];
   if(CopyRates(g_sym, PERIOD_W1, 1, 1, w) == 1)
     {
      g_pwH = w[0].high;
      g_pwL = w[0].low;
     }
  }

//--- livelli GC (futures CME) mappati sul prezzo spot: riempiti dal modulo web
double   g_gcPoc = 0.0, g_gcVah = 0.0, g_gcVal = 0.0, g_gcLast = 0.0, g_gcDeltaTrend = 0.0;
datetime g_gcTime = 0;
bool GcFresh() { return (g_gcLast > 0.0 && ToUTC(TimeCurrent()) - g_gcTime <= 4 * 3600); }

void BuildLevels()
  {
   g_lvN = 0;
   if(g_d1.n >= 2)
     {
      LvAdd(BarH(g_d1, 0), LV_PDH, 1.0);
      LvAdd(BarL(g_d1, 0), LV_PDL, 1.0);
      LvAdd(BarC(g_d1, 0), LV_PDC, 0.6);
     }
   LvAdd(g_pwH, LV_PWH, 1.0);
   LvAdd(g_pwL, LV_PWL, 1.0);
   if(g_sess.asiaDone)
     {
      LvAdd(g_sess.asiaH, LV_ASIAH, 0.8);
      LvAdd(g_sess.asiaL, LV_ASIAL, 0.8);
     }
   if(g_sess.lonDone)
     {
      LvAdd(g_sess.lonH, LV_LONH, 0.8);
      LvAdd(g_sess.lonL, LV_LONL, 0.8);
     }
   if(PrevProfileOk())
     {
      LvAdd(PrevVAH(), LV_VAH, 0.9);
      LvAdd(PrevVAL(), LV_VAL, 0.9);
      LvAdd(PrevPOC(), LV_POC, 0.9);
     }
   double vw = VwapVal(g_vwD), sg = VwapSigma(g_vwD);
   if(vw > 0.0)
     {
      LvAdd(vw, LV_VWAP, 0.7);
      if(sg > 0.0)
        {
         LvAdd(vw + sg, LV_VWAPB1, 0.5);
         LvAdd(vw - sg, LV_VWAPB1, 0.5);
         LvAdd(vw + 2.0 * sg, LV_VWAPB2, 0.6);
         LvAdd(vw - 2.0 * sg, LV_VWAPB2, 0.6);
        }
     }
   double wv = VwapVal(g_vwW);
   if(wv > 0.0)
      LvAdd(wv, LV_WVWAP, 0.8);
   //--- swing H1 (frattali a 2 barre) delle ultime 48 ore
   int foundH = 0, foundL = 0;
   for(int sh = 2; sh < 48 && sh + 2 < g_h1.n; sh++)
     {
      double h = BarH(g_h1, sh), l = BarL(g_h1, sh);
      if(foundH < 4 && h > BarH(g_h1, sh - 1) && h > BarH(g_h1, sh - 2) && h > BarH(g_h1, sh + 1) && h > BarH(g_h1, sh + 2))
        {
         LvAdd(h, LV_SWING, 0.7);
         foundH++;
        }
      if(foundL < 4 && l < BarL(g_h1, sh - 1) && l < BarL(g_h1, sh - 2) && l < BarL(g_h1, sh + 1) && l < BarL(g_h1, sh + 2))
        {
         LvAdd(l, LV_SWING, 0.7);
         foundL++;
        }
     }
   //--- numeri tondi (oro a 4000: ogni 10 e forti ogni 50)
   double px = PxBid();
   if(px > 0.0)
     {
      double mag = MathPow(10.0, MathFloor(MathLog10(px)) - 2.0);
      double major = 5.0 * mag;
      double base = MathFloor(px / mag) * mag;
      for(int k = -3; k <= 4; k++)
        {
         double rp = base + k * mag;
         double rem = MathAbs(rp / major - MathRound(rp / major));
         if(rem < 0.0001)
            LvAdd(rp, LV_ROUNDM, 1.0);
         else
            LvAdd(rp, LV_ROUND, 0.5);
        }
     }
   if(GcFresh())
     {
      double basis = PxBid() - g_gcLast;
      if(g_gcPoc > 0.0)
         LvAdd(g_gcPoc + basis, LV_GC, 1.0);
      if(g_gcVah > 0.0)
         LvAdd(g_gcVah + basis, LV_GC, 0.9);
      if(g_gcVal > 0.0)
         LvAdd(g_gcVal + basis, LV_GC, 0.9);
     }
  }

//--- distanza dal primo livello oltre 'from' nella direzione dir (piu' lontano di minDist). -1 se nessuno
double NearestLevelDist(double from, int dir, double minDist, int &typeOut)
  {
   double best = -1.0;
   typeOut = -1;
   for(int i = 0; i < g_lvN; i++)
     {
      double d = (g_lv[i].price - from) * dir;
      if(d <= minDist)
         continue;
      if(best < 0.0 || d < best)
        {
         best = d;
         typeOut = g_lv[i].type;
        }
     }
   return best;
  }

//--- un livello forte molto vicino a un prezzo (es. lo stop messo proprio sul livello)
bool PriceOnMajorLevel(double price, double tol)
  {
   for(int i = 0; i < g_lvN; i++)
      if(IsMajorLevel(g_lv[i].type) && MathAbs(g_lv[i].price - price) <= tol)
         return true;
   return false;
  }

//+------------------------------------------------------------------+
//| Regime di mercato (H1)                                           |
//+------------------------------------------------------------------+
int    g_regime = REG_RANGE;
double g_atrRatioH1 = 1.0;

void UpdateRegime()
  {
   if(g_h1.n < 120)
      return;
   double a = AtrOf(g_h1);
   //--- mediana dell'ATR delle ultime 100 ore
   double tmp[100];
   int m = 0;
   for(int k = 0; k < 100; k++)
     {
      int i = ArraySize(g_h1.atr) - 1 - k;
      if(i < 0)
         break;
      tmp[m] = g_h1.atr[i];
      m++;
     }
   for(int i = 1; i < m; i++)
     {
      double v = tmp[i];
      int j = i - 1;
      while(j >= 0 && tmp[j] > v)
        {
         tmp[j + 1] = tmp[j];
         j--;
        }
      tmp[j + 1] = v;
     }
   double med = (m > 0) ? tmp[m / 2] : a;
   g_atrRatioH1 = (med > 0.0) ? a / med : 1.0;
   double adx = AdxOf(g_h1);
   double e20 = Ind(g_h1.ema20, 0), e50 = Ind(g_h1.ema50, 0), c = BarC(g_h1, 0);
   double slope = (a > 0.0) ? (Ind(g_h1.ema50, 0) - Ind(g_h1.ema50, 5)) / a : 0.0;
   if(g_atrRatioH1 > 1.8)
      g_regime = REG_VOLATILE;
   else
      if(adx >= 22.0 && e20 > e50 && c > e50 && slope > 0.1)
         g_regime = REG_UP;
      else
         if(adx >= 22.0 && e20 < e50 && c < e50 && slope < -0.1)
            g_regime = REG_DOWN;
         else
            if(g_atrRatioH1 < 0.6)
               g_regime = REG_QUIET;
            else
               g_regime = REG_RANGE;
  }

//--- quanto la strategia si adatta al regime
double RegimeFit(int stype)
  {
   bool trend = (g_regime == REG_UP || g_regime == REG_DOWN);
   if(trend)
     {
      if(stype == STYPE_TREND)
         return 0.15;
      if(stype == STYPE_BREAKOUT)
         return 0.10;
      if(stype == STYPE_REVERSAL)
         return -0.10;
      if(stype == STYPE_MEANREV)
         return -0.15;
      return 0.05;
     }
   if(g_regime == REG_RANGE)
     {
      if(stype == STYPE_TREND)
         return -0.10;
      if(stype == STYPE_REVERSAL)
         return 0.10;
      if(stype == STYPE_MEANREV)
         return 0.15;
      return 0.0;
     }
   if(g_regime == REG_VOLATILE)
     {
      if(stype == STYPE_MEANREV)
         return -0.15;
      if(stype == STYPE_BREAKOUT)
         return 0.05;
      if(stype == STYPE_REVERSAL)
         return -0.05;
      return 0.0;
     }
   //--- calmo
   if(stype == STYPE_BREAKOUT)
      return -0.10;
   if(stype == STYPE_MEANREV)
      return 0.10;
   if(stype == STYPE_REVERSAL)
      return 0.05;
   return -0.05;
  }
//+------------------------------------------------------------------+
//| CAPO "CONTESTO HTF": struttura, ritracciamento, compressione ed  |
//| espansione su W1 / D1 / H4. Dice in che fase e' il mercato e     |
//| quali strategie hanno senso in quel momento.                     |
//+------------------------------------------------------------------+
#define PH_LATERALE       0
#define PH_IMPULSO        1
#define PH_RITRACCIAMENTO 2
#define PH_COMPRESSIONE   3
#define PH_ESPANSIONE     4
#define PH_ESAURIMENTO    5

string g_phName[6] = {"laterale", "impulso", "ritracciamento", "compressione", "espansione", "esaurimento"};

struct TfContext
  {
   bool              valid;
   int               structure;  // +1 massimi e minimi crescenti, -1 decrescenti, 0 misto
   int               bos;        // rottura dell'ultimo swing: +1 sopra il massimo, -1 sotto il minimo
   int               emaDir;     // posizione rispetto alle medie
   int               dir;        // direzione dominante
   double            rangeHi;    // estremi del range di riferimento (dealing range)
   double            rangeLo;
   double            rangePos;   // 0 = sul minimo, 1 = sul massimo
   double            retr;       // profondita' del ritracciamento contro la direzione dominante (0..1)
   double            atrRatio;   // ATR attuale / mediana ATR (volatilita' relativa)
   double            bwPct;      // percentile larghezza Bollinger (0 = compressa, 1 = espansa)
   double            extAtr;     // distanza dalla EMA20 in ATR (con segno)
   bool              nr7;        // barra piu' stretta delle ultime 7
   int               phase;
  };

TfData    g_w1;
TfContext g_cxW1;
TfContext g_cxD1;
TfContext g_cxH4;
double    g_ctxBias = 0.0;     // -1..+1: direzione suggerita dai timeframe alti
string    g_ctxText = "";

void CtxReset(TfContext &c)
  {
   c.valid = false;
   c.structure = 0;
   c.bos = 0;
   c.emaDir = 0;
   c.dir = 0;
   c.rangeHi = 0.0;
   c.rangeLo = 0.0;
   c.rangePos = 0.5;
   c.retr = 0.0;
   c.atrRatio = 1.0;
   c.bwPct = 0.5;
   c.extAtr = 0.0;
   c.nr7 = false;
   c.phase = PH_LATERALE;
  }

//--- mediana degli ultimi 'count' valori di un array
double MedianLast(const double &a[], int count)
  {
   int n = ArraySize(a);
   int m = IMin(count, n);
   if(m <= 0)
      return 0.0;
   double tmp[200];
   if(m > 200)
      m = 200;
   for(int k = 0; k < m; k++)
      tmp[k] = a[n - 1 - k];
   for(int i = 1; i < m; i++)
     {
      double v = tmp[i];
      int j = i - 1;
      while(j >= 0 && tmp[j] > v)
        {
         tmp[j + 1] = tmp[j];
         j--;
        }
      tmp[j + 1] = v;
     }
   return tmp[m / 2];
  }

//--- larghezza relativa delle Bollinger(period,2) chiuse alla barra i
double BollWidthAt(const TfData &d, int i, int period)
  {
   double s = 0.0, s2 = 0.0;
   for(int k = i - period + 1; k <= i; k++)
     {
      s += d.r[k].close;
      s2 += d.r[k].close * d.r[k].close;
     }
   double mean = s / period;
   double var = s2 / period - mean * mean;
   return (mean > 0.0 && var > 0.0) ? 4.0 * MathSqrt(var) / mean : 0.0;
  }

//--- percentile (0..1) della larghezza attuale delle Bollinger sulle ultime 'lookback' barre
double BollWidthPct(const TfData &d, int period, int lookback)
  {
   int n = d.n;
   if(n < period + 10)
      return 0.5;
   double cur = BollWidthAt(d, n - 1, period);
   int start = IMax(period - 1, n - lookback);
   int below = 0, cnt = 0;
   for(int i = start; i < n - 1; i++)
     {
      cnt++;
      if(BollWidthAt(d, i, period) < cur)
         below++;
     }
   return (cnt > 0) ? (double)below / cnt : 0.5;
  }

//--- analisi di un timeframe: strength = barre per lato dei pivot, lookback = barre del range
void AnalyzeTf(const TfData &d, TfContext &c, int strength, int lookback)
  {
   CtxReset(c);
   int n = d.n;
   if(n < 2 * strength + 25)
      return;
   //--- pivot (swing) piu' recenti
   double ph[3];
   double pl[3];
   int nh = 0, nl = 0;
   int maxSh = IMin(lookback * 2, n - strength - 1);
   for(int sh = strength; sh <= maxSh && (nh < 3 || nl < 3); sh++)
     {
      int i = n - 1 - sh;
      bool isH = true, isL = true;
      for(int k = 1; k <= strength; k++)
        {
         if(d.r[i].high <= d.r[i - k].high || d.r[i].high < d.r[i + k].high)
            isH = false;
         if(d.r[i].low >= d.r[i - k].low || d.r[i].low > d.r[i + k].low)
            isL = false;
        }
      if(isH && nh < 3)
        {
         ph[nh] = d.r[i].high;
         nh++;
        }
      if(isL && nl < 3)
        {
         pl[nl] = d.r[i].low;
         nl++;
        }
     }
   double c0 = d.r[n - 1].close;
   if(nh >= 2 && nl >= 2)
     {
      bool hh = ph[0] > ph[1], hl = pl[0] > pl[1];
      bool lh = ph[0] < ph[1], ll = pl[0] < pl[1];
      if(hh && hl)
         c.structure = 1;
      else
         if(lh && ll)
            c.structure = -1;
     }
   if(nh >= 1 && c0 > ph[0])
      c.bos = 1;
   else
      if(nl >= 1 && c0 < pl[0])
         c.bos = -1;
   //--- medie (sui settimanali con poche barre uso solo EMA20)
   double e20 = Ind(d.ema20, 0), e50 = Ind(d.ema50, 0);
   if(n >= 60)
     {
      if(e20 > e50 && c0 > e50)
         c.emaDir = 1;
      else
         if(e20 < e50 && c0 < e50)
            c.emaDir = -1;
     }
   else
      c.emaDir = (c0 > e20) ? 1 : -1;
   c.dir = c.structure;
   if(c.dir == 0)
      c.dir = (c.bos != 0) ? c.bos : c.emaDir;
   //--- range di riferimento e ritracciamento
   int lb = IMin(lookback, n);
   double hi = HighestH(d, 0, lb), lo = LowestL(d, 0, lb);
   c.rangeHi = hi;
   c.rangeLo = lo;
   double rg = hi - lo;
   c.rangePos = (rg > 0.0) ? (c0 - lo) / rg : 0.5;
   if(c.dir > 0)
      c.retr = (rg > 0.0) ? (hi - c0) / rg : 0.0;
   else
      if(c.dir < 0)
         c.retr = (rg > 0.0) ? (c0 - lo) / rg : 0.0;
   //--- volatilita': compressione / espansione
   double a = Ind(d.atr, 0);
   double med = MedianLast(d.atr, 100);
   c.atrRatio = (med > 0.0) ? a / med : 1.0;
   c.bwPct = BollWidthPct(d, 20, 120);
   c.extAtr = (a > 0.0) ? (c0 - e20) / a : 0.0;
   double rg0 = d.r[n - 1].high - d.r[n - 1].low;
   c.nr7 = true;
   for(int k = 1; k < 7 && n - 1 - k >= 0; k++)
      if(d.r[n - 1 - k].high - d.r[n - 1 - k].low <= rg0)
         c.nr7 = false;
   bool comp = (c.bwPct <= 0.20 || c.atrRatio <= 0.75 || (c.nr7 && c.bwPct <= 0.35));
   bool expn = (c.bwPct >= 0.80 || c.atrRatio >= 1.35);
   double rsi = Ind(d.rsi, 0);
   bool exhaust = expn && (MathAbs(c.extAtr) >= 2.5 || (c.extAtr > 0.0 && rsi >= 75.0) || (c.extAtr < 0.0 && rsi <= 25.0));
   if(exhaust)
      c.phase = PH_ESAURIMENTO;
   else
      if(comp)
         c.phase = PH_COMPRESSIONE;
      else
         if(c.dir != 0 && c.structure != 0)
           {
            if(c.retr < 0.382)
               c.phase = expn ? PH_ESPANSIONE : PH_IMPULSO;
            else
               c.phase = PH_RITRACCIAMENTO;
           }
         else
            c.phase = expn ? PH_ESPANSIONE : PH_LATERALE;
   c.valid = true;
  }

double TfCtxScore(const TfContext &c)
  {
   if(!c.valid)
      return 0.0;
   double s = 0.6 * c.structure + 0.4 * c.emaDir;
   if(c.bos != 0 && c.bos != c.structure)
      s += 0.3 * c.bos;
   if(c.phase == PH_RITRACCIAMENTO && c.retr > 0.786)
      s *= 0.5;                              // struttura a rischio
   return Clamp(s, -1.0, 1.0);
  }

string DirWord(int d) { return (d > 0) ? "rialzo" : ((d < 0) ? "ribasso" : "neutro"); }

string TfCtxText(string name, const TfContext &c)
  {
   if(!c.valid)
      return name + " n.d.";
   string t = name + " " + DirWord(c.dir) + ", " + g_phName[c.phase];
   if(c.phase == PH_RITRACCIAMENTO)
      t += " " + DoubleToString(c.retr * 100.0, 0) + "%";
   return t;
  }

//--- ricalcolo (a ogni nuova barra H4 e all'avvio)
void UpdateContext()
  {
   AnalyzeTf(g_w1, g_cxW1, 2, 52);
   AnalyzeTf(g_d1, g_cxD1, 2, 60);
   AnalyzeTf(g_h4, g_cxH4, 3, 90);
   double w = 0.0, s = 0.0;
   if(g_cxW1.valid)
     {
      s += 0.30 * TfCtxScore(g_cxW1);
      w += 0.30;
     }
   if(g_cxD1.valid)
     {
      s += 0.45 * TfCtxScore(g_cxD1);
      w += 0.45;
     }
   if(g_cxH4.valid)
     {
      s += 0.25 * TfCtxScore(g_cxH4);
      w += 0.25;
     }
   g_ctxBias = (w > 0.0) ? Clamp(s / w, -1.0, 1.0) : 0.0;
   g_ctxText = TfCtxText("W1", g_cxW1) + " | " + TfCtxText("D1", g_cxD1) + " | " + TfCtxText("H4", g_cxH4) +
               " -> bias " + DoubleToString(g_ctxBias, 2);
  }

//--- contesto del timeframe "di fase" per ogni motore
int PhaseFor(int engine)
  {
   if(engine == ENG_SWING)
      return g_cxD1.phase;
   return g_cxH4.phase;
  }

int PhaseDirFor(int engine) { return (engine == ENG_SWING) ? g_cxD1.dir : g_cxH4.dir; }
double PhaseRetrFor(int engine) { return (engine == ENG_SWING) ? g_cxD1.retr : g_cxH4.retr; }
double PhaseExtFor(int engine) { return (engine == ENG_SWING) ? g_cxD1.extAtr : g_cxH4.extAtr; }

//--- quali strategie hanno senso adesso (testo per briefing e pannello)
string FavoredText()
  {
   int ph = g_cxH4.phase;
   int phD = g_cxD1.phase;
   string d = (g_ctxBias > 0.2) ? " long" : ((g_ctxBias < -0.2) ? " short" : "");
   if(ph == PH_COMPRESSIONE || phD == PH_COMPRESSIONE)
      return "breakout" + d + " (mercato compresso: in arrivo espansione)";
   if(ph == PH_ESAURIMENTO || phD == PH_ESAURIMENTO)
      return "inversioni / stop run (movimento esausto), niente inseguimenti";
   if(ph == PH_RITRACCIAMENTO && g_cxH4.retr <= 0.786)
      return "pullback" + d + " nella zona di sconto del trend";
   if(ph == PH_IMPULSO || ph == PH_ESPANSIONE)
      return "pullback" + d + " piccoli, evitare di inseguire l'estensione";
   return "range e ritorno alla media (VWAP, value area)";
  }
//+------------------------------------------------------------------+
//| News: calendario MT5 (live), calendario di riserva nel tester,   |
//| vista pre-news, dati macro/AI/GC da GitHub (WebRequest)          |
//+------------------------------------------------------------------+
struct NewsEvent
  {
   datetime          utc;
   int               tier;
   string            title;
   int               preDir;
   double            preConf;
   bool              viewTaken;
   int               viewDir;
   double            preClose;
   double            preAtr;
   double            extreme;
   bool              eUsed;
  };
NewsEvent g_news[MAX_NEWS];
int       g_newsN = 0;
datetime  g_newsRefreshedAt = 0;
int       g_testerNewsDay = 0;

void NewsClearSlot(int i)
  {
   g_news[i].utc = 0;
   g_news[i].tier = 4;
   g_news[i].title = "";
   g_news[i].preDir = 0;
   g_news[i].preConf = 0.0;
   g_news[i].viewTaken = false;
   g_news[i].viewDir = 0;
   g_news[i].preClose = 0.0;
   g_news[i].preAtr = 0.0;
   g_news[i].extreme = 0.0;
   g_news[i].eUsed = false;
  }

void NewsCopy(int dst, int src)
  {
   g_news[dst].utc = g_news[src].utc;
   g_news[dst].tier = g_news[src].tier;
   g_news[dst].title = g_news[src].title;
   g_news[dst].preDir = g_news[src].preDir;
   g_news[dst].preConf = g_news[src].preConf;
   g_news[dst].viewTaken = g_news[src].viewTaken;
   g_news[dst].viewDir = g_news[src].viewDir;
   g_news[dst].preClose = g_news[src].preClose;
   g_news[dst].preAtr = g_news[src].preAtr;
   g_news[dst].extreme = g_news[src].extreme;
   g_news[dst].eUsed = g_news[src].eUsed;
  }

//--- toglie gli eventi piu' vecchi di 'keepHours'
void NewsPrune(datetime nowUtc, int keepHours)
  {
   int w = 0;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].utc < nowUtc - keepHours * 3600)
         continue;
      if(w != i)
         NewsCopy(w, i);
      w++;
     }
   for(int i = w; i < g_newsN; i++)
      NewsClearSlot(i);
   g_newsN = w;
  }

int NewsFind(datetime utc, string title, int tolSec)
  {
   for(int i = 0; i < g_newsN; i++)
     {
      long d = (long)(g_news[i].utc - utc);
      if(d < 0)
         d = -d;
      if(d <= tolSec && (title == "" || g_news[i].title == title))
         return i;
     }
   return -1;
  }

int NewsUpsert(datetime utc, int tier, string title)
  {
   int i = NewsFind(utc, title, 120);
   if(i >= 0)
     {
      if(tier < g_news[i].tier)
         g_news[i].tier = tier;
      return i;
     }
   if(g_newsN >= MAX_NEWS)
      return -1;
   i = g_newsN;
   NewsClearSlot(i);
   g_news[i].utc = utc;
   g_news[i].tier = tier;
   g_news[i].title = title;
   g_newsN++;
   return i;
  }

//--- classificazione (come nel servizio Python)
int TierOf(string name, int importance)
  {
   string t = name;
   StringToLower(t);
   if(importance < (int)CALENDAR_IMPORTANCE_MODERATE)
      return 4;
   bool high = (importance >= (int)CALENDAR_IMPORTANCE_HIGH);
   bool speech = (StringFind(t, "speech") >= 0 || StringFind(t, "speaks") >= 0 || StringFind(t, "testimony") >= 0);
   if(speech && StringFind(t, "chair") < 0)
      return high ? 2 : 3;
   if(StringFind(t, "nonfarm") >= 0 || StringFind(t, "non-farm") >= 0 || StringFind(t, "fomc") >= 0 ||
      StringFind(t, "interest rate decision") >= 0 || StringFind(t, "federal funds") >= 0 ||
      StringFind(t, "cpi") >= 0 || StringFind(t, "consumer price index") >= 0 || StringFind(t, "pce") >= 0 ||
      StringFind(t, "chair") >= 0 || StringFind(t, "jackson hole") >= 0)
      return 1;
   return high ? 2 : 3;
  }

//+------------------------------------------------------------------+
//| Calendario di riserva per il tester (il calendario MT5 non       |
//| funziona nel tester): NFP, FOMC e CPI con le date vere 2023-2027 |
//+------------------------------------------------------------------+
int g_fomcDates[41] = {20230201, 20230322, 20230503, 20230614, 20230726, 20230920, 20231101, 20231213,
                       20240131, 20240320, 20240501, 20240612, 20240731, 20240918, 20241107, 20241218,
                       20250129, 20250319, 20250507, 20250618, 20250730, 20250917, 20251029, 20251210,
                       20260128, 20260318, 20260429, 20260617, 20260729, 20260916, 20261028, 20261209,
                       20270127, 20270317, 20270428, 20270609, 20270728, 20270915, 20271027, 20271208,
                       20280126
                      };
//--- CPI: date vere di uscita (ForexFactory e BLS). Nel 2025 lo shutdown ha spostato settembre al 24/10,
//--- ottobre non e' uscito e novembre e' uscito il 18/12
int g_cpiDates[59] = {20230112, 20230214, 20230314, 20230412, 20230510, 20230613, 20230712, 20230810, 20230913, 20231012, 20231114, 20231212,
                      20240111, 20240213, 20240312, 20240410, 20240515, 20240612, 20240711, 20240814, 20240911, 20241010, 20241113, 20241211,
                      20250115, 20250212, 20250312, 20250410, 20250513, 20250611, 20250715, 20250812, 20250911, 20251024, 20251218,
                      20260113, 20260213, 20260311, 20260410, 20260512, 20260610, 20260714, 20260812, 20260911, 20261014, 20261110, 20261210,
                      20270113, 20270211, 20270310, 20270413, 20270512, 20270610, 20270714, 20270811, 20270914, 20271014, 20271110, 20271210
                     };
//--- NFP: date vere di uscita 2023-2027 (fuori da questo intervallo vale la regola del primo venerdi')
int g_nfpDates[59] = {20230106, 20230203, 20230310, 20230407, 20230505, 20230602, 20230707, 20230804, 20230901, 20231006, 20231103, 20231208,
                      20240105, 20240202, 20240308, 20240405, 20240503, 20240607, 20240705, 20240802, 20240906, 20241004, 20241101, 20241206,
                      20250110, 20250207, 20250307, 20250404, 20250502, 20250606, 20250703, 20250801, 20250905, 20251120, 20251216,
                      20260109, 20260211, 20260306, 20260403, 20260508, 20260605, 20260702, 20260807, 20260904, 20261002, 20261106, 20261204,
                      20270108, 20270205, 20270305, 20270402, 20270507, 20270604, 20270702, 20270806, 20270903, 20271008, 20271105, 20271203
                     };

bool InIntList(const int &arr[], int v)
  {
   int n = ArraySize(arr);
   for(int i = 0; i < n; i++)
      if(arr[i] == v)
         return true;
   return false;
  }

//--- ora ET -> UTC per una data (giorno UTC a mezzanotte)
datetime EtToUtc(datetime dayUtc, int hh, int mm)
  {
   datetime t = dayUtc + hh * 3600 + mm * 60 + 5 * 3600;
   if(IsUSDST(t))
      t -= 3600;
   return t;
  }

void TesterNewsRefresh(datetime nowUtc)
  {
   int dk = DayKey(nowUtc);
   if(dk == g_testerNewsDay)
      return;
   g_testerNewsDay = dk;
   NewsPrune(nowUtc, 12);
   for(int k = 0; k <= 7; k++)
     {
      datetime day = (datetime)(dk + k) * 86400;
      int ymd = Ymd(day);
      MqlDateTime d;
      TimeToStruct(day, d);
      bool nfp = (ymd >= 20230101 && ymd <= 20271231) ? InIntList(g_nfpDates, ymd) : (d.day_of_week == 5 && d.day <= 7);
      if(nfp)
         NewsUpsert(EtToUtc(day, 8, 30), 1, "Nonfarm Payrolls");
      if(InIntList(g_fomcDates, ymd))
         NewsUpsert(EtToUtc(day, 14, 0), 1, "Fed Interest Rate Decision");
      if(InIntList(g_cpiDates, ymd))
         NewsUpsert(EtToUtc(day, 8, 30), 1, "CPI m/m");
     }
  }

//+------------------------------------------------------------------+
//| Calendario MT5 (solo live/demo)                                  |
//+------------------------------------------------------------------+
void CalendarRefresh()
  {
   datetime srv = TimeTradeServer();
   g_newsRefreshedAt = TimeCurrent();
   MqlCalendarValue vals[];
   int n = CalendarValueHistory(vals, srv - 6 * 3600, srv + 36 * 3600, "US", "USD");
   NewsPrune(ToUTC(srv), 12);
   if(n <= 0)
      return;
   for(int i = 0; i < n; i++)
     {
      MqlCalendarEvent ev;
      if(!CalendarEventById(vals[i].event_id, ev))
         continue;
      int tier = TierOf(ev.name, (int)ev.importance);
      if(tier > 2)
         continue;
      NewsUpsert(ToUTC(vals[i].time), tier, ev.name);
     }
  }

//--- minuti alla prossima news tier1 (-1 se nessuna nelle prossime 36 ore)
int MinutesToNextTier1(datetime nowUtc)
  {
   int best = -1;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier != 1)
         continue;
      long d = (long)(g_news[i].utc - nowUtc);
      if(d < 0)
         continue;
      int m = (int)(d / 60);
      if(best < 0 || m < best)
         best = m;
     }
   return best;
  }

int NextTier1Index(datetime nowUtc)
  {
   int bi = -1;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier != 1 || g_news[i].utc < nowUtc)
         continue;
      if(bi < 0 || g_news[i].utc < g_news[bi].utc)
         bi = i;
     }
   return bi;
  }

//--- tipo di evento FOMC: 0 = no, 1 = decisione/comunicato/proiezioni, 2 = conferenza stampa
int FomcKind(string title)
  {
   string t = title;
   StringToLower(t);
   if(StringFind(t, "minutes") >= 0 || StringFind(t, "speak") >= 0 || StringFind(t, "speech") >= 0 ||
      StringFind(t, "testimony") >= 0 || StringFind(t, "member") >= 0)
      return 0;
   if(StringFind(t, "press conference") >= 0)
      return (StringFind(t, "fomc") >= 0 || StringFind(t, "fed") >= 0) ? 2 : 0;
   if(StringFind(t, "fomc") >= 0 || StringFind(t, "federal funds") >= 0 || StringFind(t, "fed interest rate") >= 0)
      return 1;
   return 0;
  }

//--- blocco ingressi per news. strat = strategia che chiede (IN-NEWS puo' entrare dopo +5 min).
//--- FOMC (studio banche centrali, 9 nov 2026): la conferenza parte a +30 e raddoppia o ribalta la mossa,
//--- quindi niente ingressi, IN-NEWS compreso, fino a +InpNewsBlockFomcAfter minuti dalla decisione
bool NewsBlocked(int engine, datetime nowUtc, int strat, string &why)
  {
   for(int i = 0; i < g_newsN; i++)
     {
      double dt = (double)(nowUtc - g_news[i].utc) / 60.0;
      double before = 0.0, after = 0.0;
      int fk = (InpNewsBlockFomcAfter > 0) ? FomcKind(g_news[i].title) : 0;
      if(g_news[i].tier == 1 || fk > 0)
        {
         before = (engine == ENG_SWING) ? InpNewsBlockSwingBefore : InpNewsBlockBefore;
         after = (engine == ENG_SWING) ? InpNewsBlockSwingAfter : InpNewsBlockAfter;
         if(fk == 1)
            after = MathMax(after, (double)InpNewsBlockFomcAfter);
         if(fk == 2)
            after = MathMax(after, (double)InpNewsBlockFomcAfter - 30.0);
        }
      else
         if(g_news[i].tier == 2)
           {
            before = (engine == ENG_SWING) ? 30.0 : 15.0;
            after = (engine == ENG_SWING) ? 30.0 : 10.0;
           }
         else
            continue;
      if(dt >= -before && dt <= after)
        {
         if(strat == ST_IN_NEWS && dt >= 5.0 && fk == 0)
            continue;
         why = "news " + g_news[i].title + (dt < 0 ? " tra " : " uscita da ") + IntegerToString((int)MathAbs(dt)) + " min";
         return true;
        }
     }
   return false;
  }

//+------------------------------------------------------------------+
//| JSON minimo (solo quello che serve)                              |
//+------------------------------------------------------------------+
ushort JsCh(const string &s, int i) { return StringGetCharacter(s, i); }

int JsSkipSpace(const string &s, int i)
  {
   int n = StringLen(s);
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c != ' ' && c != '\n' && c != '\r' && c != '\t')
         break;
      i++;
     }
   return i;
  }

//--- fine di una stringa che inizia con " in posizione i (ritorna indice del " di chiusura)
int JsStringEnd(const string &s, int i)
  {
   int n = StringLen(s);
   i++;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '\\')
        {
         i += 2;
         continue;
        }
      if(c == '"')
         return i;
      i++;
     }
   return n - 1;
  }

//--- posizione del valore della chiave 'key' al primo livello dell'oggetto in s (-1 se manca)
int JsonTopKey(const string &s, string key)
  {
   int n = StringLen(s);
   int depth = 0;
   int i = 0;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '"')
        {
         int e = JsStringEnd(s, i);
         if(depth == 1)
           {
            int j = JsSkipSpace(s, e + 1);
            if(j < n && JsCh(s, j) == ':')
              {
               if(StringSubstr(s, i + 1, e - i - 1) == key)
                  return JsSkipSpace(s, j + 1);
              }
           }
         i = e + 1;
         continue;
        }
      if(c == '{' || c == '[')
         depth++;
      else
         if(c == '}' || c == ']')
            depth--;
      i++;
     }
   return -1;
  }

double JsonNum(const string &s, string key, double def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0)
      return def;
   int n = StringLen(s);
   int e = p;
   while(e < n)
     {
      ushort c = JsCh(s, e);
      if((c >= '0' && c <= '9') || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E')
         e++;
      else
         break;
     }
   if(e == p)
      return def;
   return StringToDouble(StringSubstr(s, p, e - p));
  }

bool JsonBool(const string &s, string key, bool def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0)
      return def;
   if(StringSubstr(s, p, 4) == "true")
      return true;
   if(StringSubstr(s, p, 5) == "false")
      return false;
   return def;
  }

string JsonStr(const string &s, string key, string def)
  {
   int p = JsonTopKey(s, key);
   if(p < 0 || JsCh(s, p) != '"')
      return def;
   int e = JsStringEnd(s, p);
   return StringSubstr(s, p + 1, e - p - 1);
  }

//--- oggetti di un array: a partire dalla '[' in posizione p
int JsonArrayObjects(const string &s, int p, string &objs[])
  {
   ArrayResize(objs, 0);
   int n = StringLen(s);
   if(p < 0 || p >= n || JsCh(s, p) != '[')
      return 0;
   int depth = 0;
   int start = -1;
   int cnt = 0;
   int i = p + 1;
   while(i < n)
     {
      ushort c = JsCh(s, i);
      if(c == '"')
        {
         i = JsStringEnd(s, i) + 1;
         continue;
        }
      if(c == '{')
        {
         if(depth == 0)
            start = i;
         depth++;
        }
      else
         if(c == '}')
           {
            depth--;
            if(depth == 0 && start >= 0)
              {
               ArrayResize(objs, cnt + 1);
               objs[cnt] = StringSubstr(s, start, i - start + 1);
               cnt++;
               start = -1;
              }
           }
         else
            if(c == ']' && depth == 0)
               break;
      i++;
     }
   return cnt;
  }

datetime ParseIsoUtc(string s)
  {
   string t = s;
   StringReplace(t, "-", ".");
   StringReplace(t, "T", " ");
   StringReplace(t, "Z", "");
   return StringToTime(t);
  }

//+------------------------------------------------------------------+
//| Dati esterni da GitHub                                           |
//+------------------------------------------------------------------+
double   g_macroBias = 0.0, g_macroConf = 0.0, g_macroRiskMult = 1.0;
bool     g_macroHalt = false;
string   g_macroHaltReason = "";
datetime g_macroTime = 0;
string   g_aiStance = "";
double   g_aiConv = 0.0;
datetime g_aiTime = 0;
datetime g_webLastTry = 0;
double   g_mBias = 0.0;       // macro combinata usata dal comitato (GitHub + storico + intermarket)
double   g_mConf = 0.0;
string   g_mSource = "";
bool     g_webWarned = false;

bool MacroFresh() { return (g_macroTime > 0 && ToUTC(TimeCurrent()) - g_macroTime <= 6 * 3600); }
bool AiFresh()    { return (g_aiTime > 0 && ToUTC(TimeCurrent()) - g_aiTime <= 8 * 3600); }

bool HttpGet(string url, string &body)
  {
   char data[];
   char res[];
   string hdr;
   ResetLastError();
   int code = WebRequest("GET", url, "", 5000, data, res, hdr);
   if(code == -1)
     {
      int err = GetLastError();
      if(!g_webWarned)
        {
         g_webWarned = true;
         Notify("Dati esterni non leggibili (errore " + IntegerToString(err) + "). In MT5: Strumenti > Opzioni > Expert Advisors > spunta 'Consenti WebRequest' e aggiungi https://raw.githubusercontent.com");
        }
      return false;
     }
   if(code != 200)
      return false;
   body = CharArrayToString(res, 0, WHOLE_ARRAY, CP_UTF8);
   return (StringLen(body) > 2);
  }

void ParseMacro(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   g_macroTime = ParseIsoUtc(ts);
   g_macroBias = Clamp(JsonNum(js, "bias", 0.0), -1.0, 1.0);
   g_macroConf = Clamp(JsonNum(js, "confidence", 0.0), 0.0, 1.0);
   g_macroRiskMult = Clamp(JsonNum(js, "risk_multiplier", 1.0), 0.3, 1.5);
   g_macroHalt = JsonBool(js, "halt_trading", false);
   g_macroHaltReason = JsonStr(js, "halt_reason", "");
   //--- viste pre-news del servizio di ricerca
   string objs[];
   int n = JsonArrayObjects(js, JsonTopKey(js, "pre_news"), objs);
   for(int i = 0; i < n; i++)
     {
      string t = JsonStr(objs[i], "time_utc", "");
      if(t == "")
         continue;
      datetime u = ParseIsoUtc(t);
      int tier = (int)JsonNum(objs[i], "tier", 1.0);
      string title = JsonStr(objs[i], "event", "evento");
      int k = NewsFind(u, "", 600);
      if(k < 0)
         k = NewsUpsert(u, IMax(1, IMin(tier, 2)), title);
      if(k < 0)
         continue;
      g_news[k].preDir = (int)MathRound(Clamp(JsonNum(objs[i], "gold_direction", 0.0), -1.0, 1.0));
      g_news[k].preConf = Clamp(JsonNum(objs[i], "confidence", 0.0), 0.0, 1.0);
     }
  }

void ParseCommittee(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   g_aiTime = ParseIsoUtc(ts);
   g_aiStance = JsonStr(js, "stance", "flat");
   g_aiConv = Clamp(JsonNum(js, "conviction", 0.0), 0.0, 1.0);
  }

void ParseVolumeLevels(const string &js)
  {
   string ts = JsonStr(js, "timestamp_utc", "");
   if(ts == "")
      return;
   double last = JsonNum(js, "gc_last", 0.0);
   int p = JsonTopKey(js, "composite");
   if(p < 0 || last <= 0.0)
      return;
   //--- l'oggetto composite: lo isolo e leggo poc/vah/val
   int n = StringLen(js);
   int depth = 0, e = p;
   for(int i = p; i < n; i++)
     {
      ushort c = JsCh(js, i);
      if(c == '"')
        {
         i = JsStringEnd(js, i);
         continue;
        }
      if(c == '{')
         depth++;
      if(c == '}')
        {
         depth--;
         if(depth == 0)
           {
            e = i;
            break;
           }
        }
     }
   string comp = StringSubstr(js, p, e - p + 1);
   g_gcPoc = JsonNum(comp, "poc", 0.0);
   g_gcVah = JsonNum(comp, "vah", 0.0);
   g_gcVal = JsonNum(comp, "val", 0.0);
   g_gcLast = last;
   g_gcDeltaTrend = Clamp(JsonNum(js, "delta_trend", 0.0), -1.0, 1.0);
   g_gcTime = ParseIsoUtc(ts);
  }

//--- calendario di riserva dal JSON (se il calendario MT5 e' vuoto)
void ParseNewsCalendar(const string &js)
  {
   string objs[];
   int n = JsonArrayObjects(js, JsSkipSpace(js, 0), objs);
   for(int i = 0; i < n; i++)
     {
      string t = JsonStr(objs[i], "time_utc", "");
      int tier = (int)JsonNum(objs[i], "tier", 4.0);
      if(t == "" || tier > 2)
         continue;
      NewsUpsert(ParseIsoUtc(t), tier, JsonStr(objs[i], "title", "news"));
     }
  }

void WebRefresh()
  {
   if(!InpUseWebData || g_isTester)
      return;
   g_webLastTry = TimeCurrent();
   string body;
   if(InpMacroUrl != "" && HttpGet(InpMacroUrl, body))
      ParseMacro(body);
   if(InpCommitteeUrl != "" && HttpGet(InpCommitteeUrl, body))
      ParseCommittee(body);
   if(InpVolumeUrl != "" && HttpGet(InpVolumeUrl, body))
      ParseVolumeLevels(body);
   if(InpNewsUrl != "" && g_newsN == 0 && HttpGet(InpNewsUrl, body))
      ParseNewsCalendar(body);
  }

//+------------------------------------------------------------------+
//| Vista pre-news: 30 minuti prima della news il desk news fissa    |
//| la direzione attesa; dopo la news si entra SOLO se conferma      |
//+------------------------------------------------------------------+
void NewsTrack()
  {
   datetime nowU = g_ctx.nowUtc;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier > 2)
         continue;
      long dt = (long)(nowU - g_news[i].utc);
      if(!g_news[i].viewTaken && dt >= -30 * 60 && dt < 0)
        {
         int trend = TrendDir(g_h1);
         int vw = (g_ctx.vwap > 0.0) ? ((BarC(g_m5, 0) > g_ctx.vwap) ? 1 : -1) : 0;
         int macro = 0;
         if(g_mConf >= 0.3 && MathAbs(g_mBias) >= 0.15)
            macro = (g_mBias > 0.0) ? 1 : -1;
         int dir = 0;
         if(g_news[i].preConf >= 0.5 && g_news[i].preDir != 0)
            dir = g_news[i].preDir;
         else
            if(trend != 0 && trend == vw && (macro == 0 || macro == trend))
               dir = trend;
         g_news[i].viewDir = dir;
         g_news[i].preClose = BarC(g_m5, 0);
         g_news[i].preAtr = MathMax(AtrOf(g_m15), g_tick * 10);
         g_news[i].extreme = g_news[i].preClose;
         g_news[i].viewTaken = true;
         string vtxt = (dir > 0) ? "rialzo" : ((dir < 0) ? "ribasso" : "neutra");
         Logf("Vista pre-news su " + g_news[i].title + ": " + vtxt);
        }
      if(g_news[i].viewTaken && g_news[i].viewDir != 0 && dt >= 0 && dt <= 120 * 60)
        {
         if(g_news[i].viewDir > 0)
            g_news[i].extreme = MathMax(g_news[i].extreme, BarH(g_m5, 0));
         else
            g_news[i].extreme = MathMin(g_news[i].extreme, BarL(g_m5, 0));
        }
     }
  }

//--- vista per la prossima news tier1 entro 'horizonMin' (dal servizio di ricerca o dalla vista fissata)
int NextEventView(datetime nowUtc, int horizonMin)
  {
   int k = NextTier1Index(nowUtc);
   if(k < 0)
      return 0;
   if((g_news[k].utc - nowUtc) / 60 > horizonMin)
      return 0;
   if(g_news[k].viewTaken)
      return g_news[k].viewDir;
   if(g_news[k].preConf >= 0.5)
      return g_news[k].preDir;
   return 0;
  }
//+------------------------------------------------------------------+
//| CAPO MACRO sempre informato:                                     |
//| 1) intermarket dai simboli del broker (funziona anche nel tester)|
//|    dollaro sintetico (pesi DXY), USDJPY come proxy dei           |
//|    rendimenti, argento, indice azionario, correlazione oro-dollaro|
//| 2) servizio di ricerca su GitHub (rendimenti reali, Fed, news)   |
//| 3) storico macro (macro_history.csv) per i backtest              |
//+------------------------------------------------------------------+
#define IM_EURUSD 0
#define IM_USDJPY 1
#define IM_GBPUSD 2
#define IM_USDCAD 3
#define IM_USDSEK 4
#define IM_USDCHF 5
#define IM_XAGUSD 6
#define IM_INDEX  7
#define IM_DXY    8
#define IM_N      9

string g_imSym[IM_N];
double g_imDxyW[6] = {-0.576, 0.136, -0.119, 0.091, 0.042, 0.036};

double g_dollarScore = 0.0;   // + dollaro forte
double g_dollarFast = 0.0;    // momento H4 del dollaro
double g_yieldProxy = 0.0;    // + USDJPY in salita (rendimenti USA su)
double g_silverConf = 0.0;    // + argento conferma l'oro
double g_riskOff = 0.0;       // + fuga dal rischio (azionario in calo forte)
double g_goldDxyCorr = 0.0;   // correlazione 60 giorni rendimenti oro / dollaro
double g_imBias = 0.0;
double g_imConf = 0.0;
int    g_imFx = 0;            // quanti cambi disponibili per il dollaro
bool   g_imOk = false;


//--- storico macro (dal servizio GitHub, anche nel tester)
int    g_mhDate[];
double g_mhBias[];
double g_mhConf[];
int    g_mhN = 0;
datetime g_mhLastTry = 0;

bool TrySymbol(string s)
  {
   if(s == "")
      return false;
   if(!SymbolSelect(s, true))
      return false;
   return true;
  }

//--- trova il simbolo del broker (con eventuali prefissi/suffissi come XAUUSD.a o XAUUSDm)
string ResolveSymbol(string base)
  {
   string up = g_sym;
   StringToUpper(up);
   int p = StringFind(up, "XAUUSD");
   string pre = "", suf = "";
   if(p >= 0)
     {
      pre = StringSubstr(g_sym, 0, p);
      suf = StringSubstr(g_sym, p + 6);
     }
   if(TrySymbol(pre + base + suf))
      return pre + base + suf;
   if(suf != "" && TrySymbol(base + suf))
      return base + suf;
   if(TrySymbol(base))
      return base;
   return "";
  }

void IntermarketInit()
  {
   g_imSym[IM_EURUSD] = ResolveSymbol("EURUSD");
   g_imSym[IM_USDJPY] = ResolveSymbol("USDJPY");
   g_imSym[IM_GBPUSD] = ResolveSymbol("GBPUSD");
   g_imSym[IM_USDCAD] = ResolveSymbol("USDCAD");
   g_imSym[IM_USDSEK] = ResolveSymbol("USDSEK");
   g_imSym[IM_USDCHF] = ResolveSymbol("USDCHF");
   g_imSym[IM_XAGUSD] = ResolveSymbol("XAGUSD");
   if(g_imSym[IM_XAGUSD] == "")
      g_imSym[IM_XAGUSD] = ResolveSymbol("SILVER");
   string idx[6];
   idx[0] = "US500";
   idx[1] = "SPX500";
   idx[2] = "SP500";
   idx[3] = "US500Cash";
   idx[4] = "USA500";
   idx[5] = "SPX";
   g_imSym[IM_INDEX] = "";
   for(int i = 0; i < 6 && g_imSym[IM_INDEX] == ""; i++)
      g_imSym[IM_INDEX] = ResolveSymbol(idx[i]);
   string dx[4];
   dx[0] = "USDX";
   dx[1] = "DXY";
   dx[2] = "DX";
   dx[3] = "USDOLLAR";
   g_imSym[IM_DXY] = "";
   for(int i = 0; i < 4 && g_imSym[IM_DXY] == ""; i++)
     {
      string c = ResolveSymbol(dx[i]);
      //--- accetto solo un vero indice del dollaro (DXY intorno a 70-130), non ETF o altri strumenti
      MqlRates t[];
      if(c != "" && CopyRates(c, PERIOD_D1, 1, 1, t) == 1 && t[0].close > 70.0 && t[0].close < 130.0)
         g_imSym[IM_DXY] = c;
     }
   string found = "";
   for(int i = 0; i < IM_N; i++)
      if(g_imSym[i] != "")
         found += g_imSym[i] + " ";
   if(found == "")
      found = "nessuno (la macro usera' GitHub e lo storico)";
   Logf("Macro intermarket: simboli trovati: " + found);
  }

//--- rendimento logaritmico del simbolo per la barra con tempo t (0 se manca)
double LogRetAt(const MqlRates &r[], int n, datetime t, int &pos)
  {
   while(pos < n && r[pos].time < t)
      pos++;
   if(pos >= n || pos == 0 || r[pos].time != t)
      return 0.0;
   if(r[pos - 1].close <= 0.0 || r[pos].close <= 0.0)
      return 0.0;
   return MathLog(r[pos].close / r[pos - 1].close);
  }

double Tanh(double x)
  {
   if(x > 20.0)
      return 1.0;
   if(x < -20.0)
      return -1.0;
   double e = MathExp(2.0 * x);
   return (e - 1.0) / (e + 1.0);
  }

//--- z-score del movimento delle ultime k barre rispetto alla volatilita'
double ZMove(const double &ret[], int n, int k, double vol)
  {
   if(n < k || vol <= 0.0)
      return 0.0;
   double s = 0.0;
   for(int i = n - k; i < n; i++)
      s += ret[i];
   return s / (vol * MathSqrt((double)k));
  }

double StdLast(const double &ret[], int n, int k)
  {
   int m = IMin(k, n);
   if(m < 5)
      return 0.0;
   double s = 0.0, s2 = 0.0;
   for(int i = n - m; i < n; i++)
     {
      s += ret[i];
      s2 += ret[i] * ret[i];
     }
   double mean = s / m;
   double v = s2 / m - mean * mean;
   return (v > 0.0) ? MathSqrt(v) : 0.0;
  }

//--- serie di rendimenti del dollaro sui tempi delle barre dell'oro (tf = D1 o H4)
int DollarReturns(ENUM_TIMEFRAMES tf, const TfData &gold, int bars, double &dret[], double &gret[])
  {
   ArrayResize(dret, 0);
   ArrayResize(gret, 0);
   int gn = gold.n;
   if(gn < bars + 2)
      return 0;
   MqlRates fx[];
   int cnt = 0;
   ArrayResize(dret, bars);
   ArrayResize(gret, bars);
   ArrayInitialize(dret, 0.0);
   ArrayInitialize(gret, 0.0);
   double wsum[];
   ArrayResize(wsum, bars);
   ArrayInitialize(wsum, 0.0);
   //--- preferisco il paniere dei cambi (24 ore, pesi DXY); l'indice del broker solo se mancano i cambi
   int fxAvail = 0;
   for(int s0 = IM_EURUSD; s0 <= IM_USDCHF; s0++)
      if(g_imSym[s0] != "")
         fxAvail++;
   bool useDxy = (g_imSym[IM_DXY] != "" && (g_imSym[IM_EURUSD] == "" || fxAvail < 3));
   int first = useDxy ? IM_DXY : IM_EURUSD;
   int last = useDxy ? IM_DXY : IM_USDCHF;
   for(int s = first; s <= last; s++)
     {
      if(g_imSym[s] == "")
         continue;
      int got = CopyRates(g_imSym[s], tf, 1, bars + 40, fx);
      if(got <= bars / 2)
         continue;
      double w = useDxy ? 1.0 : g_imDxyW[s];
      int pos = 0;
      int ok = 0;
      for(int j = 0; j < bars; j++)
        {
         int gi = gn - bars + j;
         double lr = LogRetAt(fx, got, gold.r[gi].time, pos);
         if(lr != 0.0)
           {
            dret[j] += w * lr;
            wsum[j] += MathAbs(w);
            ok++;
           }
        }
      if(ok > bars / 2)
         cnt++;
     }
   if(cnt == 0)
      return 0;
   double wfull = 0.0;
   if(useDxy)
      wfull = 1.0;
   else
      for(int s = IM_EURUSD; s <= IM_USDCHF; s++)
         if(g_imSym[s] != "")
            wfull += MathAbs(g_imDxyW[s]);
   for(int j = 0; j < bars; j++)
     {
      if(wsum[j] > 0.0 && wfull > 0.0)
         dret[j] *= wfull / wsum[j];       // rinormalizza se manca qualche cambio quel giorno
      int gi = gn - bars + j;
      if(gi >= 1 && gold.r[gi - 1].close > 0.0)
         gret[j] = MathLog(gold.r[gi].close / gold.r[gi - 1].close);
     }
   return useDxy ? 6 : cnt;
  }

double Corr(const double &a[], const double &b[], int n, int k)
  {
   int m = IMin(k, n);
   if(m < 10)
      return 0.0;
   double sa = 0, sb = 0, saa = 0, sbb = 0, sab = 0;
   for(int i = n - m; i < n; i++)
     {
      sa += a[i];
      sb += b[i];
      saa += a[i] * a[i];
      sbb += b[i] * b[i];
      sab += a[i] * b[i];
     }
   double va = saa / m - (sa / m) * (sa / m);
   double vb = sbb / m - (sb / m) * (sb / m);
   if(va <= 0.0 || vb <= 0.0)
      return 0.0;
   return (sab / m - (sa / m) * (sb / m)) / MathSqrt(va * vb);
  }

//--- momento di un singolo simbolo (z-score a 20 barre D1)
double SymbolZ(string sym, ENUM_TIMEFRAMES tf, int k)
  {
   if(sym == "")
      return 0.0;
   MqlRates r[];
   int got = CopyRates(sym, tf, 1, 80, r);
   if(got < k + 25)
      return 0.0;
   double ret[];
   ArrayResize(ret, got - 1);
   for(int i = 1; i < got; i++)
      ret[i - 1] = (r[i - 1].close > 0.0 && r[i].close > 0.0) ? MathLog(r[i].close / r[i - 1].close) : 0.0;
   double vol = StdLast(ret, got - 1, 60);
   return ZMove(ret, got - 1, k, vol);
  }

void IntermarketUpdate()
  {
   double dret[];
   double gret[];
   int bars = 70;
   g_imFx = DollarReturns(PERIOD_D1, g_d1, bars, dret, gret);
   g_imOk = (g_imFx > 0);
   if(!g_imOk)
     {
      g_imBias = 0.0;
      g_imConf = 0.0;
      return;
     }
   double vol = StdLast(dret, bars, 60);
   double z5 = ZMove(dret, bars, 5, vol);
   double z20 = ZMove(dret, bars, 20, vol);
   //--- trend del livello sintetico (somma cumulata) con due medie
   double lvl = 0.0, e10 = 0.0, e30 = 0.0;
   for(int j = 0; j < bars; j++)
     {
      lvl += dret[j];
      if(j == 0)
        {
         e10 = lvl;
         e30 = lvl;
        }
      else
        {
         e10 += (lvl - e10) * 2.0 / 11.0;
         e30 += (lvl - e30) * 2.0 / 31.0;
        }
     }
   double emaSign = (e10 > e30) ? 1.0 : -1.0;
   g_dollarScore = Clamp(0.4 * Tanh(z5 / 1.5) + 0.4 * Tanh(z20 / 1.5) + 0.2 * emaSign, -1.0, 1.0);
   g_goldDxyCorr = Corr(gret, dret, bars, 60);
   //--- dollaro veloce (H4, ultime 6 barre = un giorno)
   double dh[];
   double gh[];
   int hb = DollarReturns(PERIOD_H4, g_h4, 60, dh, gh);
   g_dollarFast = 0.0;
   if(hb > 0)
     {
      double vh = StdLast(dh, 60, 60);
      g_dollarFast = Tanh(ZMove(dh, 60, 6, vh) / 1.5);
     }
   g_yieldProxy = Tanh(SymbolZ(g_imSym[IM_USDJPY], PERIOD_D1, 20) / 1.5);
   //--- argento: conferma se si muove come l'oro
   double zs = SymbolZ(g_imSym[IM_XAGUSD], PERIOD_D1, 10);
   double zg = ZMove(gret, bars, 10, StdLast(gret, bars, 60));
   g_silverConf = 0.0;
   if(g_imSym[IM_XAGUSD] != "")
     {
      if(zs * zg > 0.0)
         g_silverConf = Tanh(MathMin(MathAbs(zs), MathAbs(zg)) / 1.5) * ((zg > 0.0) ? 1.0 : -1.0);
      else
         g_silverConf = -0.3 * ((zg > 0.0) ? 1.0 : -1.0);   // divergenza: l'oro va da solo, meno affidabile
     }
   double zi = SymbolZ(g_imSym[IM_INDEX], PERIOD_D1, 5);
   g_riskOff = (zi < -1.5) ? Tanh((-zi - 1.5)) : 0.0;
   //--- quanto conta il dollaro adesso: dipende dalla correlazione recente
   double wD = (g_goldDxyCorr < -0.2) ? 1.0 : ((g_goldDxyCorr < 0.2) ? 0.6 : 0.3);
   double wRiskOff = InpP3NoRiskOffBonus ? 0.0 : 0.10;   // P3 (1.17): interruttore del bonus fuga dal rischio
   g_imBias = Clamp(-0.55 * wD * g_dollarScore - 0.15 * g_yieldProxy + 0.20 * g_silverConf + wRiskOff * g_riskOff, -1.0, 1.0);
   double avail = MathMin(1.0, g_imFx / 4.0);
   g_imConf = Clamp((0.30 + 0.35 * MathAbs(g_goldDxyCorr)) * avail, 0.0, 0.65);
  }

//+------------------------------------------------------------------+
//| Storico macro (macro_history.csv in Common\Files)                |
//+------------------------------------------------------------------+
void MacroHistLoad()
  {
   g_mhN = 0;
   ArrayResize(g_mhDate, 0);
   ArrayResize(g_mhBias, 0);
   ArrayResize(g_mhConf, 0);
   if(!FileIsExist("macro_history.csv", FILE_COMMON))
      return;
   int h = FileOpen("macro_history.csv", FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      if(StringSplit(l, ',', p) < 3)
         continue;
      if(StringLen(p[0]) < 10 || StringGetCharacter(p[0], 0) < '0' || StringGetCharacter(p[0], 0) > '9')
         continue;
      int ymd = (int)StringToInteger(StringSubstr(p[0], 0, 4)) * 10000 + (int)StringToInteger(StringSubstr(p[0], 5, 2)) * 100 +
                (int)StringToInteger(StringSubstr(p[0], 8, 2));
      ArrayResize(g_mhDate, g_mhN + 1, 4096);
      ArrayResize(g_mhBias, g_mhN + 1, 4096);
      ArrayResize(g_mhConf, g_mhN + 1, 4096);
      g_mhDate[g_mhN] = ymd;
      g_mhBias[g_mhN] = Clamp(StringToDouble(p[1]), -1.0, 1.0);
      g_mhConf[g_mhN] = Clamp(StringToDouble(p[2]), 0.0, 1.0);
      g_mhN++;
     }
   FileClose(h);
   if(g_mhN > 0)
      Logf("Storico macro caricato: " + IntegerToString(g_mhN) + " giorni (" + IntegerToString(g_mhDate[0]) + " - " + IntegerToString(g_mhDate[g_mhN - 1]) + ")");
  }

//--- valore macro di ieri o prima (mai di oggi: nessuna informazione dal futuro), entro 5 giorni
bool MacroHistGet(datetime utc, double &b, double &c)
  {
   if(g_mhN <= 0)
      return false;
   int today = Ymd(utc);
   int lo = 0, hi = g_mhN - 1, best = -1;
   while(lo <= hi)
     {
      int mid = (lo + hi) / 2;
      if(g_mhDate[mid] < today)
        {
         best = mid;
         lo = mid + 1;
        }
      else
         hi = mid - 1;
     }
   if(best < 0)
      return false;
   int y = g_mhDate[best] / 10000, m = (g_mhDate[best] / 100) % 100, d = g_mhDate[best] % 100;
   MqlDateTime dt;
   dt.year = y;
   dt.mon = m;
   dt.day = d;
   dt.hour = 0;
   dt.min = 0;
   dt.sec = 0;
   dt.day_of_week = 0;
   dt.day_of_year = 0;
   if(utc - StructToTime(dt) > 6 * 86400)
      return false;
   b = g_mhBias[best];
   c = g_mhConf[best];
   return true;
  }

//--- in live scarica lo storico da GitHub e lo salva per il tester
void MacroHistDownload(string url)
  {
   if(g_isTester || url == "" || TimeCurrent() - g_mhLastTry < 12 * 3600)
      return;
   g_mhLastTry = TimeCurrent();
   string body;
   if(!HttpGet(url, body))
      return;
   if(StringFind(body, "date,bias") != 0)
      return;
   int h = FileOpen("macro_history.csv", FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   FileWriteString(h, body);
   FileClose(h);
   MacroHistLoad();
  }

//+------------------------------------------------------------------+
//| Macro combinata usata dal comitato                               |
//+------------------------------------------------------------------+
void MacroCombine()
  {
   double hb = 0.0, hc = 0.0;
   bool hist = MacroHistGet(ToUTC(TimeCurrent()), hb, hc);
   if(MacroFresh())
     {
      double wim = g_imOk ? 0.35 : 0.0;
      g_mBias = Clamp((1.0 - wim) * g_macroBias + wim * g_imBias, -1.0, 1.0);
      g_mConf = Clamp(MathMax(g_macroConf, g_imConf) * ((g_macroBias * g_imBias >= 0.0 || !g_imOk) ? 1.0 : 0.7), 0.0, 1.0);
      g_mSource = "GitHub";
      if(g_imOk)
         g_mSource += " + intermarket";
     }
   else
      if(hist && hc > 0.0)
        {
         double wim = g_imOk ? 0.4 : 0.0;
         g_mBias = Clamp((1.0 - wim) * hb + wim * g_imBias, -1.0, 1.0);
         g_mConf = Clamp(MathMax(hc * 0.9, g_imConf) * ((hb * g_imBias >= 0.0 || !g_imOk) ? 1.0 : 0.7), 0.0, 1.0);
         g_mSource = "storico macro";
         if(g_imOk)
            g_mSource += " + intermarket";
        }
      else
         if(g_imOk)
           {
            g_mBias = g_imBias;
            g_mConf = g_imConf * 0.85;
            g_mSource = "intermarket";
           }
         else
           {
            g_mBias = 0.0;
            g_mConf = 0.0;
            g_mSource = "nessuna";
           }
  }

string MacroText()
  {
   string t = "bias " + DoubleToString(g_mBias, 2) + " conf " + DoubleToString(g_mConf, 2) + " (" + g_mSource + ")";
   if(g_imOk)
     {
      string dw = "neutro";
      if(g_dollarScore > 0.25)
         dw = "forte";
      if(g_dollarScore < -0.25)
         dw = "debole";
      t += " | dollaro " + dw + " " + DoubleToString(g_dollarScore, 2) + ", corr oro-dollaro " + DoubleToString(g_goldDxyCorr, 2);
      if(g_imSym[IM_XAGUSD] != "")
        {
         if(g_silverConf > 0.2)
            t += ", argento conferma";
         else
            if(g_silverConf < -0.2)
               t += ", argento contrario";
            else
               t += ", argento neutro";
        }
      if(g_yieldProxy > 0.3)
         t += ", rendimenti in salita";
      if(g_yieldProxy < -0.3)
         t += ", rendimenti in calo";
     }
   if(MacroFresh() && g_macroHalt)
      t += " | STOP dal servizio: " + g_macroHaltReason;
   return t;
  }

//+------------------------------------------------------------------+
//| Motori del prezzo (1.17): corsa verticale, feste, calendario     |
//| Dallo studio del 9 nov 2026 (proposte P1-P6, ognuna con input)   |
//+------------------------------------------------------------------+
//--- borse USA chiuse 2023-2027 (data di New York)
int g_usHolidays[50] = {20230102, 20230116, 20230220, 20230407, 20230529, 20230619, 20230704, 20230904, 20231123, 20231225,
                        20240101, 20240115, 20240219, 20240329, 20240527, 20240619, 20240704, 20240902, 20241128, 20241225,
                        20250101, 20250120, 20250217, 20250418, 20250526, 20250619, 20250704, 20250901, 20251127, 20251225,
                        20260101, 20260119, 20260216, 20260403, 20260525, 20260619, 20260703, 20260907, 20261126, 20261225,
                        20270101, 20270118, 20270215, 20270326, 20270531, 20270618, 20270705, 20270906, 20271125, 20271224};
//--- Borsa di Tokyo chiusa 2023-2027, solo giorni feriali (data di Tokyo)
int g_jpHolidays[85] = {20230102, 20230103, 20230109, 20230223, 20230321, 20230503, 20230504, 20230505, 20230717, 20230811, 20230918, 20231009, 20231103, 20231123,
                        20240101, 20240102, 20240103, 20240108, 20240212, 20240223, 20240320, 20240429, 20240503, 20240506, 20240715, 20240812, 20240916, 20240923, 20241014, 20241104, 20241231,
                        20250101, 20250102, 20250103, 20250113, 20250211, 20250224, 20250320, 20250429, 20250505, 20250506, 20250721, 20250811, 20250915, 20250923, 20251013, 20251103, 20251124, 20251231,
                        20260101, 20260102, 20260112, 20260211, 20260223, 20260320, 20260429, 20260504, 20260505, 20260506, 20260720, 20260811, 20260921, 20260922, 20260923, 20261012, 20261103, 20261123, 20261231,
                        20270101, 20270111, 20270211, 20270223, 20270322, 20270429, 20270503, 20270504, 20270505, 20270719, 20270811, 20270920, 20270923, 20271011, 20271103, 20271123, 20271231};

int  EtYmd(datetime utc)  { return Ymd(utc - (IsUSDST(utc) ? 4 : 5) * 3600); }
int  JstYmd(datetime utc) { return Ymd(utc + 9 * 3600); }
bool IsUsHoliday(int ymd) { return InIntList(g_usHolidays, ymd); }
bool IsJpHoliday(int ymd) { return InIntList(g_jpHolidays, ymd); }

//--- giorno della settimana da anno/mese/giorno (0 = domenica)
int DowYmd(int y, int m, int d)
  {
   int t[12] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
   if(m < 3)
      y -= 1;
   return (y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7;
  }

int DaysInMonth(int y, int m)
  {
   if(m == 2)
      return ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0) ? 29 : 28;
   if(m == 4 || m == 6 || m == 9 || m == 11)
      return 30;
   return 31;
  }

bool IsTradingYmd(int y, int m, int d)
  {
   int w = DowYmd(y, m, d);
   if(w == 0 || w == 6)
      return false;
   return !IsUsHoliday(y * 10000 + m * 100 + d);
  }

//--- posizione del giorno contando dalla fine del mese (1 = ultimo giorno di borsa); 0 se non si tratta
int TradingPosFromEnd(int ymd)
  {
   int y = ymd / 10000, m = (ymd / 100) % 100, d = ymd % 100;
   if(!IsTradingYmd(y, m, d))
      return 0;
   int pos = 1;
   for(int k = d + 1; k <= DaysInMonth(y, m); k++)
      if(IsTradingYmd(y, m, k))
         pos++;
   return pos;
  }

//--- P4: primo giorno di borsa del mese (data di New York)
bool IsFirstTradingDay(int ymd)
  {
   int y = ymd / 10000, m = (ymd / 100) % 100, d = ymd % 100;
   if(!IsTradingYmd(y, m, d))
      return false;
   for(int k = 1; k < d; k++)
      if(IsTradingYmd(y, m, k))
         return false;
   return true;
  }

//--- P6: scadenza opzioni oro COMEX (4o ultimo giorno di borsa del mese) e il giorno dopo
bool IsExpiryWindow(int ymd)
  {
   int pos = TradingPosFromEnd(ymd);
   return (pos == 4 || pos == 3);
  }

//--- P1: corsa degli ultimi 20 giorni in sigma e distanza dalla media a 200 giorni (barre D1 chiuse)
double   g_runZ = 0.0;
double   g_ma200Dist = 0.0;
bool     g_runBrake = false;
datetime g_runCalcBar = 0;

void RunBrakeCompute(const MqlRates &r[], int got)
  {
   g_runZ = 0.0;
   g_ma200Dist = 0.0;
   g_runBrake = false;
   if(got < 82)
      return;
   int L = got - 1;
   //--- volatilita' giornaliera delle 60 sedute prima dell'ultima (come nello studio)
   double sum = 0.0, sum2 = 0.0;
   int n = 0;
   for(int i = L - 60; i <= L - 1; i++)
     {
      if(r[i].close <= 0.0 || r[i - 1].close <= 0.0)
         continue;
      double x = MathLog(r[i].close / r[i - 1].close);
      sum += x;
      sum2 += x * x;
      n++;
     }
   if(n < 40 || r[L].close <= 0.0 || r[L - 20].close <= 0.0)
      return;
   double var = (sum2 - sum * sum / n) / (n - 1);
   if(var <= 0.0)
      return;
   g_runZ = MathLog(r[L].close / r[L - 20].close) / (MathSqrt(var) * MathSqrt(20.0));
   bool dist = false;
   if(got >= 200)
     {
      double ma = 0.0;
      for(int i = L - 199; i <= L; i++)
         ma += r[i].close;
      ma /= 200.0;
      if(ma > 0.0)
        {
         g_ma200Dist = (r[L].close / ma - 1.0) * 100.0;
         dist = (g_ma200Dist > InpP1Ma200DistPct);
        }
     }
   g_runBrake = InpP1RunBrake && (g_runZ > InpP1RunSigma || dist);
  }

void RunBrakeUpdate()
  {
   datetime t = iTime(g_sym, PERIOD_D1, 0);
   if(t == 0 || t == g_runCalcBar)
      return;
   g_runCalcBar = t;
   MqlRates r[];
   int got = CopyRates(g_sym, PERIOD_D1, 1, 230, r);
   bool was = g_runBrake;
   RunBrakeCompute(r, got);
   string stato = g_runBrake ? "ACCESO" : "spento";
   if(g_runBrake != was && !g_isOptim)
      Logf("P1 freno corsa verticale " + stato + ": corsa 20 giorni " + DoubleToString(g_runZ, 2) +
           " sigma, distanza dalla media 200 " + DoubleToString(g_ma200Dist, 1) + "%");
  }

string RunBrakeText()
  {
   return "corsa 20 giorni " + DoubleToString(g_runZ, 1) + " sigma, " + DoubleToString(g_ma200Dist, 1) + "% dalla media 200" +
          (g_runBrake ? " -> FRENO P1 ACCESO (rischio x" + DoubleToString(InpP1RiskMult, 2) + ", niente long in rottura)" : "");
  }

//--- P2: liquidita' sottile (feste USA tutto il giorno, feste giapponesi nelle ore asiatiche, prima ora dopo una riapertura)
bool ThinLiquidity(datetime nowUtc, double hUtc, double lonOpen, string &why)
  {
   if(!InpP2ThinLiquidity)
      return false;
   int et = EtYmd(nowUtc);
   if(IsUsHoliday(et))
     {
      why = "P2 festa negli USA (" + IntegerToString(et) + "): liquidita' sottile";
      return true;
     }
   if((hUtc >= 21.0 || hUtc < lonOpen) && IsJpHoliday(JstYmd(nowUtc)))
     {
      why = "P2 festa in Giappone, ore asiatiche: liquidita' sottile";
      return true;
     }
   if(InpP2ReopenMin > 0 && g_m1.n > 3)
     {
      int look = IMin(g_m1.n - 2, InpP2ReopenMin + 2);
      datetime nowSrv = ToServer(nowUtc);
      for(int sh = 0; sh < look; sh++)
        {
         datetime t1 = BarT(g_m1, sh);
         datetime t0 = BarT(g_m1, sh + 1);
         if(t1 == 0 || t0 == 0)
            break;
         if(nowSrv - t1 > InpP2ReopenMin * 60)
            break;
         if(t1 - t0 > 3 * 3600)
           {
            why = "P2 prima ora dopo una riapertura: liquidita' sottile";
            return true;
           }
        }
     }
   return false;
  }
//+------------------------------------------------------------------+
//| Segnale comune: tutte le strategie parlano questa lingua         |
//+------------------------------------------------------------------+
struct TSignal
  {
   int               strat;
   int               engine;
   int               stype;
   int               dir;
   double            entry;
   double            sl;
   double            tp;
   double            quality;
   string            why;
   double            desk[NDESK];
   bool              veto;
   string            vetoWhy;
   double            score;
   int               quorum;
   int               devil;
   bool              strong;
   bool              recovery;
   bool              reentry;
   bool              aplus;
   double            cushion;
   double            obstacleR;
   double            cvdRatio;
   bool              passed;

   void              Reset()
     {
      strat = 0;
      engine = 0;
      stype = 0;
      dir = 0;
      entry = 0.0;
      sl = 0.0;
      tp = 0.0;
      quality = 0.0;
      why = "";
      for(int i = 0; i < NDESK; i++)
         desk[i] = 0.5;
      veto = false;
      vetoWhy = "";
      score = 0.0;
      quorum = 0;
      devil = 0;
      strong = false;
      recovery = false;
      reentry = false;
      aplus = false;
      cushion = 0.0;
      obstacleR = -1.0;
      cvdRatio = 0.0;
      passed = false;
     }
  };

double RiskPx(const TSignal &s) { return (s.entry - s.sl) * s.dir; }

//--- copia esplicita (piu' sicura dell'assegnazione di struct con stringhe)
void SigCopy(TSignal &d, const TSignal &s)
  {
   d.strat = s.strat;
   d.engine = s.engine;
   d.stype = s.stype;
   d.dir = s.dir;
   d.entry = s.entry;
   d.sl = s.sl;
   d.tp = s.tp;
   d.quality = s.quality;
   d.why = s.why;
   for(int i = 0; i < NDESK; i++)
      d.desk[i] = s.desk[i];
   d.veto = s.veto;
   d.vetoWhy = s.vetoWhy;
   d.score = s.score;
   d.quorum = s.quorum;
   d.devil = s.devil;
   d.strong = s.strong;
   d.recovery = s.recovery;
   d.reentry = s.reentry;
   d.aplus = s.aplus;
   d.cushion = s.cushion;
   d.obstacleR = s.obstacleR;
   d.cvdRatio = s.cvdRatio;
   d.passed = s.passed;
  }

//--- costruisce il segnale con target in R (mai sotto il minimo 1:2)
bool MakeSignal(TSignal &s, int strat, int dir, double entry, double sl, double rr, double quality, string why)
  {
   s.Reset();
   s.strat = strat;
   s.engine = g_stratEngine[strat];
   s.stype = g_stratType[strat];
   s.dir = dir;
   s.entry = entry;
   s.sl = NormPrice(sl);
   double risk = (entry - s.sl) * dir;
   if(risk <= 2.0 * g_tick)
      return false;
   s.tp = NormPrice(entry + dir * risk * MathMax(rr, InpMinRR));
   s.quality = Clamp(quality, 0.0, 1.0);
   s.why = why;
   return true;
  }

//--- come sopra ma con target strutturale: valido solo se rispetta l'R:R minimo
bool MakeSignalTP(TSignal &s, int strat, int dir, double entry, double sl, double tp, double quality, string why)
  {
   s.Reset();
   s.strat = strat;
   s.engine = g_stratEngine[strat];
   s.stype = g_stratType[strat];
   s.dir = dir;
   s.entry = entry;
   s.sl = NormPrice(sl);
   double risk = (entry - s.sl) * dir;
   if(risk <= 2.0 * g_tick)
      return false;
   if((tp - entry) * dir < InpMinRR * risk)
      return false;
   s.tp = NormPrice(tp);
   s.quality = Clamp(quality, 0.0, 1.0);
   s.why = why;
   return true;
  }

double EntryPx(int dir) { return (dir > 0) ? g_ctx.ask : g_ctx.bid; }

//--- stop strutturale + buffer; per le vendite aggiunge lo spread (lo stop scatta sull'ask)
double StopFrom(double extreme, int dir, double buffer)
  {
   if(dir > 0)
      return extreme - buffer;
   return extreme + buffer + g_ctx.spread;
  }

//--- aggiusta la distanza dello stop dentro [minD, maxD]; false se troppo largo
bool FitStop(double entry, int dir, double &sl, double minD, double maxD)
  {
   double risk = (entry - sl) * dir;
   if(risk < minD)
      sl = entry - dir * minD;
   risk = (entry - sl) * dir;
   return (risk <= maxD);
  }

bool StratEnabled(int st)
  {
   if(InpOnlyStrategy != PICK_ALL && (int)InpOnlyStrategy != st)
      return false;
   switch(st)
     {
      case ST_SC_VWAP:
         return InpSC_VWAP;
      case ST_SC_SWEEP:
         return InpSC_SWEEP;
      case ST_SC_ORB:
         return InpSC_ORB;
      case ST_IN_PULLBACK:
         return InpIN_PULLBACK;
      case ST_IN_SWEEP:
         return InpIN_SWEEP;
      case ST_IN_BREAKOUT:
         return InpIN_BREAKOUT;
      case ST_IN_VALUE:
         return InpIN_VALUE;
      case ST_IN_NEWS:
         return InpIN_NEWS;
      case ST_IN_RANGE:
         return InpIN_RANGE;
      case ST_SW_TREND:
         return InpSW_TREND;
      case ST_SW_WYCKOFF:
         return InpSW_WYCKOFF;
     }
   return false;
  }

//+------------------------------------------------------------------+
//| SCALPING                                                         |
//+------------------------------------------------------------------+
//--- SC-VWAP: trend M15+M5, pullback sulla VWAP/EMA20 M5, ripartenza su M1
bool S_ScVwap(TSignal &s)
  {
   int t15 = TrendDir(g_m15), t5 = TrendDir(g_m5);
   if(t15 == 0 || t5 != t15)
      return false;
   int dir = t15;
   double vw = g_ctx.vwap, a5 = g_ctx.atrM5;
   if(vw <= 0.0 || a5 <= 0.0)
      return false;
   double c1 = BarC(g_m1, 0);
   if((c1 - vw) * dir <= 0.0)
      return false;
   double e20m5 = Ind(g_m5.ema20, 0);
   double zone = (dir > 0) ? MathMax(vw, e20m5) : MathMin(vw, e20m5);
   double ext = (dir > 0) ? LowestL(g_m1, 0, 7) : HighestH(g_m1, 0, 7);
   if(dir > 0)
     {
      if(ext > zone + 0.15 * a5 || ext < vw - 0.6 * a5)
         return false;
      if(!(c1 > BarH(g_m1, 1) && c1 > Ind(g_m1.ema20, 0) && c1 > BarO(g_m1, 0)))
         return false;
     }
   else
     {
      if(ext < zone - 0.15 * a5 || ext > vw + 0.6 * a5)
         return false;
      if(!(c1 < BarL(g_m1, 1) && c1 < Ind(g_m1.ema20, 0) && c1 < BarO(g_m1, 0)))
         return false;
     }
   if(MicroDelta(0) * dir < 0.0)
      return false;
   double entry = EntryPx(dir);
   double sl = StopFrom(ext, dir, 0.25 * g_ctx.atrM1);
   if(!FitStop(entry, dir, sl, 0.5 * a5, 2.0 * a5))
      return false;
   double q = 0.55;
   double rsi5 = Ind(g_m5.rsi, 0);
   if((dir > 0 && rsi5 > 45.0 && rsi5 < 68.0) || (dir < 0 && rsi5 < 55.0 && rsi5 > 32.0))
      q += 0.1;
   if(RvolBar(g_m1, 0) >= 1.2)
      q += 0.1;
   if(MicroCvdRatio(30) * dir > 0.0)
      q += 0.1;
   return MakeSignal(s, ST_SC_VWAP, dir, entry, sl, InpScalpRR, q, "pullback sulla VWAP in trend M15/M5");
  }

//--- SC-SWEEP: spazzata di un livello (stop run) e rientro rapido
bool S_ScSweep(TSignal &s)
  {
   double a5 = g_ctx.atrM5;
   if(a5 <= 0.0)
      return false;
   double lv[8];
   string nm[8];
   int n = 0;
   if(g_sess.asiaDone)
     {
      lv[n] = g_sess.asiaH;
      nm[n] = "Asia H";
      n++;
      lv[n] = g_sess.asiaL;
      nm[n] = "Asia L";
      n++;
     }
   if(g_sess.lonDone)
     {
      lv[n] = g_sess.lonH;
      nm[n] = "Londra H";
      n++;
      lv[n] = g_sess.lonL;
      nm[n] = "Londra L";
      n++;
     }
   if(g_d1.n >= 2)
     {
      lv[n] = BarH(g_d1, 0);
      nm[n] = "PDH";
      n++;
      lv[n] = BarL(g_d1, 0);
      nm[n] = "PDL";
      n++;
     }
   if(g_h1.n >= 2)
     {
      lv[n] = BarH(g_h1, 0);
      nm[n] = "max ora prec.";
      n++;
      lv[n] = BarL(g_h1, 0);
      nm[n] = "min ora prec.";
      n++;
     }
   double c = BarC(g_m1, 0), o = BarO(g_m1, 0);
   double lo5 = LowestL(g_m1, 0, 5), hi5 = HighestH(g_m1, 0, 5);
   bool found = false;
   double bestQ = 0.0;
   TSignal tmp;
   for(int i = 0; i < n; i++)
     {
      double L = lv[i];
      if(L <= 0.0)
         continue;
      for(int dir = -1; dir <= 1; dir += 2)
        {
         double ext = (dir > 0) ? lo5 : hi5;
         bool swept = (dir > 0) ? (ext < L - 0.1 * a5 && ext > L - 1.2 * a5) : (ext > L + 0.1 * a5 && ext < L + 1.2 * a5);
         bool reclaim = (dir > 0) ? (c > L && c > o) : (c < L && c < o);
         bool approach = (dir > 0) ? (BarC(g_m1, 6) > L) : (BarC(g_m1, 6) < L);
         if(!swept || !reclaim || !approach)
            continue;
         //--- barra della spazzata
         int sb = 0;
         for(int k = 0; k < 5; k++)
           {
            double x = (dir > 0) ? BarL(g_m1, k) : BarH(g_m1, k);
            if(x == ext)
              {
               sb = k;
               break;
              }
           }
         double wick = WickRatio(g_m1, sb, dir);
         double rv = RvolBar(g_m1, sb);
         if(wick < 0.4 && rv < 1.5)
            continue;
         if((MicroDelta(0) + MicroDelta(1)) * dir <= 0.0)
            continue;
         double entry = EntryPx(dir);
         double sl = StopFrom(ext, dir, 0.2 * g_ctx.atrM1);
         if(!FitStop(entry, dir, sl, 0.4 * a5, 2.0 * a5))
            continue;
         double q = 0.55;
         if(wick >= 0.5)
            q += 0.1;
         if(rv >= 1.5)
            q += 0.1;
         if(nm[i] == "PDH" || nm[i] == "PDL")
            q += 0.05;
         if(q > bestQ && MakeSignal(tmp, ST_SC_SWEEP, dir, entry, sl, InpScalpRR, q, "stop run su " + nm[i] + " e rientro"))
           {
            bestQ = q;
            SigCopy(s, tmp);
            found = true;
           }
        }
     }
   return found;
  }

//--- SC-ORB: range dei primi 15 minuti di Londra/NY, rottura con volume, retest
bool OrbCheck(TSignal &s, OrState &o, double openUtc, string name)
  {
   if(!o.done || o.used)
      return false;
   double h = g_ctx.hUtc;
   double a5 = g_ctx.atrM5;
   if(h > openUtc + 1.5 || a5 <= 0.0)
     {
      o.used = true;
      return false;
     }
   double height = o.h - o.l;
   if(height < 0.4 * a5 || height > 3.0 * a5)
     {
      o.used = true;
      return false;
     }
   double c = BarC(g_m1, 0);
   if(o.brk == 0)
     {
      double rv = RvolBar(g_m1, 0);
      if(c > o.h + 0.05 * a5 && rv >= 1.3)
        {
         o.brk = 1;
         o.brkT = BarT(g_m1, 0);
        }
      else
         if(c < o.l - 0.05 * a5 && rv >= 1.3)
           {
            o.brk = -1;
            o.brkT = BarT(g_m1, 0);
           }
      return false;
     }
   if(BarT(g_m1, 0) - o.brkT > 30 * 60)
     {
      o.used = true;
      return false;
     }
   int dir = o.brk;
   double lvl = (dir > 0) ? o.h : o.l;
   if((dir > 0 && c < o.l) || (dir < 0 && c > o.h))
     {
      o.used = true;
      return false;
     }
   double ext = (dir > 0) ? BarL(g_m1, 0) : BarH(g_m1, 0);
   bool touched = (dir > 0) ? (ext <= lvl + 0.15 * a5) : (ext >= lvl - 0.15 * a5);
   bool held = (dir > 0) ? (c > lvl && c > BarO(g_m1, 0)) : (c < lvl && c < BarO(g_m1, 0));
   if(!touched || !held)
      return false;
   o.used = true;
   double entry = EntryPx(dir);
   double ref = (dir > 0) ? MathMin(ext, lvl) : MathMax(ext, lvl);
   double sl = StopFrom(ref, dir, 0.2 * g_ctx.atrM1);
   if(!FitStop(entry, dir, sl, 0.4 * a5, 2.0 * a5))
      return false;
   double q = 0.6;
   if(height < 1.5 * a5)
      q += 0.05;
   if(MicroCvdRatio(10) * dir > 0.05)
      q += 0.1;
   return MakeSignal(s, ST_SC_ORB, dir, entry, sl, InpScalpRR, q, "range di apertura " + name + ": rottura e retest");
  }

bool S_ScOrb(TSignal &s)
  {
   if(OrbCheck(s, g_sess.orLon, g_ctx.lonOpen, "Londra"))
      return true;
   return OrbCheck(s, g_sess.orNy, g_ctx.nyOpen, "New York");
  }

//+------------------------------------------------------------------+
//| INTRADAY                                                         |
//+------------------------------------------------------------------+
//--- IN-PULLBACK: trend H1, pullback sull'EMA20 M15 con RSI scarico, ripartenza M5
bool S_InPullback(TSignal &s)
  {
   int dir = TrendDir(g_h1);
   if(dir == 0 || AdxOf(g_h1) < 18.0 || EmaDir(g_m15) != dir)
      return false;
   double a15 = g_ctx.atrM15;
   if(a15 <= 0.0)
      return false;
   double e20 = Ind(g_m15.ema20, 0), e50 = Ind(g_m15.ema50, 0);
   double ext = (dir > 0) ? LowestL(g_m15, 0, 4) : HighestH(g_m15, 0, 4);
   if(dir > 0 && (ext > e20 + 0.2 * a15 || ext < e50 - 0.3 * a15))
      return false;
   if(dir < 0 && (ext < e20 - 0.2 * a15 || ext > e50 + 0.3 * a15))
      return false;
   if(dir > 0)
     {
      double rmin = MinInd(g_m15.rsi, 0, 4);
      if(rmin < 35.0 || rmin > 52.0)
         return false;
     }
   else
     {
      double rmax = MaxInd(g_m15.rsi, 0, 4);
      if(rmax > 65.0 || rmax < 48.0)
         return false;
     }
   double c5 = BarC(g_m5, 0);
   if(dir > 0 && !(c5 > HighestH(g_m5, 1, 3) && c5 > Ind(g_m5.ema20, 0) && c5 > BarO(g_m5, 0)))
      return false;
   if(dir < 0 && !(c5 < LowestL(g_m5, 1, 3) && c5 < Ind(g_m5.ema20, 0) && c5 < BarO(g_m5, 0)))
      return false;
   double ext5 = (dir > 0) ? LowestL(g_m5, 0, 12) : HighestH(g_m5, 0, 12);
   double ref = (dir > 0) ? MathMin(ext, ext5) : MathMax(ext, ext5);
   double entry = EntryPx(dir);
   double sl = StopFrom(ref, dir, 0.2 * a15);
   if(!FitStop(entry, dir, sl, 0.6 * a15, 2.0 * a15))
      return false;
   double q = 0.6;
   if(AdxOf(g_h1) > 25.0)
      q += 0.1;
   if(TrendDir(g_h4) == dir)
      q += 0.1;
   if(RvolBar(g_m5, 0) >= 1.1)
      q += 0.05;
   return MakeSignal(s, ST_IN_PULLBACK, dir, entry, sl, InpIntraRR, q, "trend H1, pullback su EMA20 M15");
  }

//--- IN-SWEEP: barra M15 che spazza PDH/PDL/Asia/Londra/settimana e rientra
datetime g_lastInSweepBar = 0;

bool S_InSweep(TSignal &s)
  {
   double a15 = g_ctx.atrM15;
   if(a15 <= 0.0 || BarT(g_m15, 0) == g_lastInSweepBar)
      return false;
   double lv[8];
   string nm[8];
   int n = 0;
   if(g_d1.n >= 2)
     {
      lv[n] = BarH(g_d1, 0);
      nm[n] = "PDH";
      n++;
      lv[n] = BarL(g_d1, 0);
      nm[n] = "PDL";
      n++;
     }
   if(g_pwH > 0.0)
     {
      lv[n] = g_pwH;
      nm[n] = "PWH";
      n++;
      lv[n] = g_pwL;
      nm[n] = "PWL";
      n++;
     }
   if(g_sess.asiaDone)
     {
      lv[n] = g_sess.asiaH;
      nm[n] = "Asia H";
      n++;
      lv[n] = g_sess.asiaL;
      nm[n] = "Asia L";
      n++;
     }
   if(g_sess.lonDone)
     {
      lv[n] = g_sess.lonH;
      nm[n] = "Londra H";
      n++;
      lv[n] = g_sess.lonL;
      nm[n] = "Londra L";
      n++;
     }
   double hb = BarH(g_m15, 0), lb = BarL(g_m15, 0), cb = BarC(g_m15, 0);
   double c5 = BarC(g_m5, 0), o5 = BarO(g_m5, 0);
   bool found = false;
   double bestQ = 0.0;
   TSignal tmp;
   for(int i = 0; i < n; i++)
     {
      double L = lv[i];
      if(L <= 0.0)
         continue;
      for(int dir = -1; dir <= 1; dir += 2)
        {
         double ext = (dir > 0) ? lb : hb;
         bool swept = (dir > 0) ? (ext < L - 0.15 * a15 && ext > L - 1.5 * a15) : (ext > L + 0.15 * a15 && ext < L + 1.5 * a15);
         bool reclaim = (dir > 0) ? (cb > L) : (cb < L);
         bool approach = (dir > 0) ? (BarC(g_m15, 1) > L) : (BarC(g_m15, 1) < L);
         bool trig = (dir > 0) ? (c5 > L && c5 > o5) : (c5 < L && c5 < o5);
         if(!swept || !reclaim || !approach || !trig)
            continue;
         double wick = WickRatio(g_m15, 0, dir);
         double rv = RvolBar(g_m15, 0);
         if(wick < 0.5 && rv < 1.3)
            continue;
         double entry = EntryPx(dir);
         double sl = StopFrom(ext, dir, 0.15 * a15);
         if(!FitStop(entry, dir, sl, 0.5 * a15, 2.2 * a15))
            continue;
         double q = 0.55;
         if(wick >= 0.5)
            q += 0.1;
         if(rv >= 1.3)
            q += 0.1;
         if(nm[i] == "PDH" || nm[i] == "PDL" || nm[i] == "PWH" || nm[i] == "PWL")
            q += 0.05;
         //--- divergenza del delta: prezzo su nuovo estremo ma CVD a favore
         if(MicroCvdRatio(60) * dir > 0.05)
            q += 0.1;
         if(q > bestQ && MakeSignal(tmp, ST_IN_SWEEP, dir, entry, sl, InpIntraRR, q, "stop run M15 su " + nm[i]))
           {
            bestQ = q;
            SigCopy(s, tmp);
            found = true;
           }
        }
     }
   if(found)
      g_lastInSweepBar = BarT(g_m15, 0);
   return found;
  }

//--- IN-BREAKOUT: rottura con volume di un livello chiave su M15, ingresso al retest su M5
struct BrkState
  {
   double            lvl;
   int               dir;
   datetime          brkT;
   bool              used;
   double            rvol;
   string            name;
  };
BrkState g_brk[8];
int      g_brkN = 0;
int      g_brkDay = 0;

void BrkRegister(double L, string name)
  {
   if(L <= 0.0)
      return;
   for(int i = 0; i < g_brkN; i++)
      if(MathAbs(g_brk[i].lvl - L) < g_tick * 0.5)
         return;
   double a15 = g_ctx.atrM15;
   double c = BarC(g_m15, 0), cp = ClosePos(g_m15, 0), rv = RvolBar(g_m15, 0);
   int dir = 0;
   if(c > L + 0.1 * a15 && BarO(g_m15, 0) < L + 0.1 * a15 && cp >= 0.7 && rv >= 1.3)
      dir = 1;
   if(c < L - 0.1 * a15 && BarO(g_m15, 0) > L - 0.1 * a15 && cp <= 0.3 && rv >= 1.3)
      dir = -1;
   if(dir == 0 || g_brkN >= 8)
      return;
   g_brk[g_brkN].lvl = L;
   g_brk[g_brkN].dir = dir;
   g_brk[g_brkN].brkT = BarT(g_m15, 0);
   g_brk[g_brkN].used = false;
   g_brk[g_brkN].rvol = rv;
   g_brk[g_brkN].name = name;
   g_brkN++;
  }

//--- chiamata a ogni nuova barra M15
void BrkOnM15()
  {
   int dk = DayKey(g_ctx.nowUtc);
   if(dk != g_brkDay)
     {
      g_brkDay = dk;
      g_brkN = 0;
     }
   if(g_ctx.atrM15 <= 0.0)
      return;
   if(g_sess.asiaDone && g_ctx.hUtc < 17.0)
     {
      BrkRegister(g_sess.asiaH, "Asia H");
      BrkRegister(g_sess.asiaL, "Asia L");
     }
   if(g_sess.lonDone)
     {
      BrkRegister(g_sess.lonH, "Londra H");
      BrkRegister(g_sess.lonL, "Londra L");
     }
   if(g_d1.n >= 2)
     {
      BrkRegister(BarH(g_d1, 0), "PDH");
      BrkRegister(BarL(g_d1, 0), "PDL");
     }
  }

bool S_InBreakout(TSignal &s)
  {
   double a15 = g_ctx.atrM15;
   if(a15 <= 0.0)
      return false;
   double l5 = BarL(g_m5, 0), h5 = BarH(g_m5, 0), c5 = BarC(g_m5, 0), o5 = BarO(g_m5, 0);
   for(int i = 0; i < g_brkN; i++)
     {
      if(g_brk[i].used)
         continue;
      if(BarT(g_m5, 0) - g_brk[i].brkT > 2 * 3600)
        {
         g_brk[i].used = true;
         continue;
        }
      if(BarT(g_m5, 0) <= g_brk[i].brkT + 15 * 60)
         continue;
      int dir = g_brk[i].dir;
      double L = g_brk[i].lvl;
      if((L - c5) * dir > 0.3 * a15)
        {
         g_brk[i].used = true;
         continue;
        }
      bool touched = (dir > 0) ? (l5 <= L + 0.15 * a15) : (h5 >= L - 0.15 * a15);
      bool held = (dir > 0) ? (c5 > L && c5 > o5) : (c5 < L && c5 < o5);
      if(!touched || !held)
         continue;
      g_brk[i].used = true;
      double entry = EntryPx(dir);
      double ref = (dir > 0) ? MathMin(l5, L) : MathMax(h5, L);
      double sl = StopFrom(ref, dir, 0.25 * a15);
      if(!FitStop(entry, dir, sl, 0.5 * a15, 1.8 * a15))
         continue;
      double q = 0.6;
      if(TrendDir(g_h1) == dir)
         q += 0.1;
      if(g_brk[i].rvol >= 1.8)
         q += 0.1;
      return MakeSignal(s, ST_IN_BREAKOUT, dir, entry, sl, InpIntraRR, q, "breakout " + g_brk[i].name + " con volume e retest");
     }
   return false;
  }

//--- IN-VALUE80: apertura fuori dalla value area di ieri, rientro con 2 chiusure M15 -> lato opposto
int      g_vaDay = 0;
int      g_vaOpenSide = 0;
int      g_vaInside = 0;
bool     g_vaUsed = false;
bool     g_vaNewM15 = false;

void ValueOnM15()
  {
   g_vaNewM15 = true;
   datetime anchor = iTime(g_sym, PERIOD_D1, 0);
   int dk = (int)(anchor / 86400);
   if(dk != g_vaDay)
     {
      g_vaDay = dk;
      g_vaOpenSide = 0;
      g_vaInside = 0;
      g_vaUsed = false;
      if(PrevProfileOk())
        {
         double op = BarO(g_m15, 0);
         if(op > PrevVAH())
            g_vaOpenSide = 1;
         else
            if(op < PrevVAL())
               g_vaOpenSide = -1;
        }
      return;
     }
   if(g_vaOpenSide == 0 || g_vaUsed)
      return;
   double c = BarC(g_m15, 0);
   bool inside = (c < PrevVAH() && c > PrevVAL());
   g_vaInside = inside ? g_vaInside + 1 : 0;
  }

bool S_InValue(TSignal &s)
  {
   if(!g_vaNewM15)
      return false;
   g_vaNewM15 = false;
   if(g_vaOpenSide == 0 || g_vaUsed || g_vaInside < 2 || !PrevProfileOk())
      return false;
   g_vaUsed = true;
   int dir = -g_vaOpenSide;
   double a15 = g_ctx.atrM15;
   double entry = EntryPx(dir);
   double edge = (dir > 0) ? PrevVAL() : PrevVAH();
   double ext = (dir > 0) ? LowestL(g_m15, 0, 3) : HighestH(g_m15, 0, 3);
   double ref = (dir > 0) ? MathMin(ext, edge - 0.3 * a15) : MathMax(ext, edge + 0.3 * a15);
   double sl = StopFrom(ref, dir, 0.1 * a15);
   if(!FitStop(entry, dir, sl, 0.5 * a15, 2.0 * a15))
      return false;
   double tp = (dir > 0) ? PrevVAH() : PrevVAL();
   double q = 0.6;
   if(RvolBar(g_m15, 0) >= 1.0)
      q += 0.05;
   if(MicroCvdRatio(60) * dir > 0.05)
      q += 0.1;
   return MakeSignalTP(s, ST_IN_VALUE, dir, entry, sl, tp, q, "regola 80%: rientro nella value area di ieri");
  }

//--- IN-NEWS: continuation dopo la news SOLO nella direzione della vista pre-news
bool S_InNews(TSignal &s)
  {
   datetime nowU = g_ctx.nowUtc;
   for(int i = 0; i < g_newsN; i++)
     {
      if(g_news[i].tier > 2 || !g_news[i].viewTaken || g_news[i].viewDir == 0 || g_news[i].eUsed)
         continue;
      double mins = (double)(nowU - g_news[i].utc) / 60.0;
      if(mins < 5.0 || mins > 90.0)
         continue;
      int dir = g_news[i].viewDir;
      double c = BarC(g_m5, 0);
      double imp = (g_news[i].extreme - g_news[i].preClose) * dir;
      if((c - g_news[i].preClose) * dir < 0.0)
        {
         g_news[i].eUsed = true;   // il mercato ha smentito la vista
         continue;
        }
      if(imp < 1.5 * g_news[i].preAtr)
         continue;
      double barExt = (dir > 0) ? BarL(g_m5, 0) : BarH(g_m5, 0);
      double retr = (g_news[i].extreme - barExt) * dir / imp;
      if(retr < 0.30 || retr > 0.62)
         continue;
      if(!((dir > 0 && c > BarO(g_m5, 0)) || (dir < 0 && c < BarO(g_m5, 0))))
         continue;
      g_news[i].eUsed = true;
      double entry = EntryPx(dir);
      double sl = StopFrom(barExt, dir, 0.25 * g_ctx.atrM5);
      if(!FitStop(entry, dir, sl, 0.5 * g_ctx.atrM15, 2.5 * g_ctx.atrM15))
         continue;
      double q = 0.65;
      if(g_news[i].preConf >= 0.6)
         q += 0.1;
      double tp = g_news[i].extreme + dir * 0.5 * imp;
      if(MakeSignalTP(s, ST_IN_NEWS, dir, entry, sl, tp, q, "continuation dopo " + g_news[i].title + " coerente con la vista"))
         return true;
      return MakeSignal(s, ST_IN_NEWS, dir, entry, sl, InpMinRR, q, "continuation dopo " + g_news[i].title + " coerente con la vista");
     }
   return false;
  }

//--- IN-RANGE: in laterale, rifiuto a VWAP +-2 sigma con RSI estremo, target VWAP
bool S_InRange(TSignal &s)
  {
   if(g_regime != REG_RANGE && g_regime != REG_QUIET)
      return false;
   if(AdxOf(g_h1) > 20.0)
      return false;
   double vw = g_ctx.vwap, sg = g_ctx.vwSig;
   if(vw <= 0.0 || sg <= 0.0)
      return false;
   double l = BarL(g_m5, 0), h = BarH(g_m5, 0), c = BarC(g_m5, 0);
   int dir = 0;
   if(l <= vw - 2.0 * sg && c > vw - 2.0 * sg && WickRatio(g_m5, 0, 1) >= 0.5 && MinInd(g_m5.rsi, 0, 3) <= 30.0)
      dir = 1;
   if(h >= vw + 2.0 * sg && c < vw + 2.0 * sg && WickRatio(g_m5, 0, -1) >= 0.5 && MaxInd(g_m5.rsi, 0, 3) >= 70.0)
      dir = -1;
   if(dir == 0)
      return false;
   double entry = EntryPx(dir);
   double ext = (dir > 0) ? l : h;
   double sl = StopFrom(ext, dir, 0.3 * g_ctx.atrM5);
   if(!FitStop(entry, dir, sl, 0.4 * g_ctx.atrM15, 1.5 * g_ctx.atrM15))
      return false;
   double q = 0.55;
   if(IsAbsorption(g_m5, 0) || RvolBar(g_m5, 0) >= 1.5)
      q += 0.1;
   if(MicroCvdRatio(10) * dir > 0.05)
      q += 0.1;
   return MakeSignalTP(s, ST_IN_RANGE, dir, entry, sl, vw, q, "laterale: rifiuto a VWAP 2 sigma, target VWAP");
  }

//+------------------------------------------------------------------+
//| SWING                                                            |
//+------------------------------------------------------------------+
//--- SW-TREND: trend H4 (D1 non contrario), pullback sull'EMA20 H4, ripartenza H1
bool S_SwTrend(TSignal &s)
  {
   int dir = TrendDir(g_h4);
   if(dir == 0 || AdxOf(g_h4) < 20.0)
      return false;
   int td = EmaDir(g_d1);
   if(td != 0 && td != dir)
      return false;
   double a1 = g_ctx.atrH1, a4 = g_ctx.atrH4;
   if(a1 <= 0.0 || a4 <= 0.0)
      return false;
   double e20 = Ind(g_h4.ema20, 0), e50 = Ind(g_h4.ema50, 0);
   double ext = (dir > 0) ? LowestL(g_h1, 0, 6) : HighestH(g_h1, 0, 6);
   if(dir > 0 && (ext > e20 + 0.3 * a4 || ext < e50 - 0.3 * a4))
      return false;
   if(dir < 0 && (ext < e20 - 0.3 * a4 || ext > e50 + 0.3 * a4))
      return false;
   if(dir > 0)
     {
      double rmin = MinInd(g_h1.rsi, 0, 6);
      if(rmin < 35.0 || rmin > 52.0)
         return false;
     }
   else
     {
      double rmax = MaxInd(g_h1.rsi, 0, 6);
      if(rmax > 65.0 || rmax < 48.0)
         return false;
     }
   double c = BarC(g_h1, 0);
   if(dir > 0 && !(c > HighestH(g_h1, 1, 3) && c > BarO(g_h1, 0)))
      return false;
   if(dir < 0 && !(c < LowestL(g_h1, 1, 3) && c < BarO(g_h1, 0)))
      return false;
   double entry = EntryPx(dir);
   double sl = StopFrom(ext, dir, 0.25 * a1);
   if(!FitStop(entry, dir, sl, 1.0 * a1, 1.2 * a4))
      return false;
   double q = 0.6;
   if(AdxOf(g_h4) > 25.0)
      q += 0.1;
   if(RvolBar(g_h1, 0) >= 1.1)
      q += 0.05;
   if(td == dir)
      q += 0.05;
   return MakeSignal(s, ST_SW_TREND, dir, entry, sl, InpSwingRR, q, "trend H4, pullback su EMA20 H4");
  }

//--- SW-WYCKOFF: range H4, spring (falsa rottura del minimo) o upthrust con volume
datetime g_lastWyckBar = 0;

bool S_SwWyckoff(TSignal &s)
  {
   if(g_h4.n < 40 || BarT(g_h1, 0) == g_lastWyckBar)
      return false;
   double a1 = g_ctx.atrH1, a4 = g_ctx.atrH4;
   if(a1 <= 0.0 || a4 <= 0.0)
      return false;
   double rh = HighestH(g_h4, 1, 30), rl = LowestL(g_h4, 1, 30);
   double height = rh - rl;
   if(height < 2.0 * a4 || height > 7.0 * a4 || AdxOf(g_h4) > 22.0)
      return false;
   double l = BarL(g_h1, 0), h = BarH(g_h1, 0), c = BarC(g_h1, 0);
   double cp = ClosePos(g_h1, 0), rv = RvolBar(g_h1, 0);
   int dir = 0;
   if(l < rl - 0.1 * a4 && l > rl - 1.0 * a4 && c > rl && cp >= 0.5 && rv >= 1.3)
      dir = 1;
   if(h > rh + 0.1 * a4 && h < rh + 1.0 * a4 && c < rh && cp <= 0.5 && rv >= 1.3)
      dir = -1;
   if(dir == 0)
      return false;
   g_lastWyckBar = BarT(g_h1, 0);
   double entry = EntryPx(dir);
   double ext = (dir > 0) ? l : h;
   double sl = StopFrom(ext, dir, 0.2 * a1);
   if(!FitStop(entry, dir, sl, 0.8 * a1, 1.5 * a4))
      return false;
   double tp = (dir > 0) ? rh - 0.1 * a4 : rl + 0.1 * a4;
   double q = 0.6;
   if(rv >= 1.8)
      q += 0.1;
   if(MicroCvdRatio(120) * dir > 0.05)
      q += 0.1;
   string nm = (dir > 0) ? "spring" : "upthrust";
   return MakeSignalTP(s, ST_SW_WYCKOFF, dir, entry, sl, tp, q, "Wyckoff " + nm + " nel range H4");
  }
//+------------------------------------------------------------------+
//| Stato: statistiche per strategia, metadati posizioni, rischio    |
//+------------------------------------------------------------------+
struct StratStat
  {
   int               n;
   int               wins;
   int               losses;
   double            sumR;
   double            sumR2;
   double            grossWinR;
   double            grossLossR;
   double            net;
   double            last[10];
   int               lastN;
   int               lastHead;
   datetime          benchUntil;

   void              Reset()
     {
      n = 0;
      wins = 0;
      losses = 0;
      sumR = 0.0;
      sumR2 = 0.0;
      grossWinR = 0.0;
      grossLossR = 0.0;
      net = 0.0;
      for(int i = 0; i < 10; i++)
         last[i] = 0.0;
      lastN = 0;
      lastHead = 0;
      benchUntil = 0;
     }

   void              Add(double r, double money)
     {
      n++;
      sumR += r;
      sumR2 += r * r;
      net += money;
      if(r > 0.05)
        {
         wins++;
         grossWinR += r;
        }
      else
         if(r < -0.05)
           {
            losses++;
            grossLossR += -r;
           }
      last[lastHead] = r;
      lastHead = (lastHead + 1) % 10;
      if(lastN < 10)
         lastN++;
     }

   double            Expectancy() const { return (n > 0) ? sumR / n : 0.0; }
   double            WinRate() const { return (n > 0) ? 100.0 * wins / n : 0.0; }
   double            ProfitFactor() const { return (grossLossR > 0.0) ? grossWinR / grossLossR : ((grossWinR > 0.0) ? 99.0 : 0.0); }

   //--- perdite negli ultimi k trade
   int               RecentLosses(int k) const
     {
      int c = 0;
      for(int j = 0; j < k && j < lastN; j++)
        {
         int idx = (lastHead - 1 - j + 20) % 10;
         if(last[idx] < -0.05)
            c++;
        }
      return c;
     }

   double            RecentSum(int k) const
     {
      double s = 0.0;
      for(int j = 0; j < k && j < lastN; j++)
        {
         int idx = (lastHead - 1 - j + 20) % 10;
         s += last[idx];
        }
      return s;
     }
  };

StratStat g_ss[NSTRAT];     // statistiche usate dal comitato (si azzerano in panchina)
StratStat g_rep[NSTRAT];    // statistiche complete per il report
StratStat g_es[3];
StratStat g_all;

//+------------------------------------------------------------------+
//| Metadati di ogni posizione/ordine aperto dall'EA                 |
//+------------------------------------------------------------------+
struct PosMeta
  {
   long              id;
   int               strat;
   int               engine;
   int               dir;
   int               tranche;
   int               idea;
   double            entry;
   double            sl0;
   double            tp;
   double            riskPx;
   double            riskMoney;
   double            lots0;
   double            score;
   double            cushion;
   bool              recovery;
   bool              reentry;
   bool              aplus;
   bool              thirdDone;
   bool              beDone;
   bool              partialDone;
   bool              isPending;
   bool              active;
   datetime          openTime;
   int               expiryMin;
   int               sweepTries;

   void              Reset()
     {
      id = 0;
      strat = 0;
      engine = 0;
      dir = 0;
      tranche = 0;
      idea = 0;
      entry = 0.0;
      sl0 = 0.0;
      tp = 0.0;
      riskPx = 0.0;
      riskMoney = 0.0;
      lots0 = 0.0;
      score = 0.0;
      cushion = 0.0;
      recovery = false;
      reentry = false;
      aplus = false;
      thirdDone = false;
      beDone = false;
      partialDone = false;
      isPending = false;
      active = false;
      openTime = 0;
      expiryMin = 0;
      sweepTries = 0;
     }
  };
PosMeta g_meta[MAX_META];
int     g_ideaSeq = 0;
bool    g_needSweep = false;
bool    g_needFlowScan = false;

int MetaFind(long id)
  {
   for(int i = 0; i < MAX_META; i++)
      if(g_meta[i].active && g_meta[i].id == id)
         return i;
   return -1;
  }

int MetaFree()
  {
   for(int i = 0; i < MAX_META; i++)
      if(!g_meta[i].active)
         return i;
   return -1;
  }

void MetaRemove(int i)
  {
   if(i >= 0 && i < MAX_META)
      g_meta[i].Reset();
  }

bool IsOurMagic(long magic) { return (magic > InpMagicBase && magic <= InpMagicBase + 3); }
int  EngineOfMagic(long magic) { return (int)(magic - InpMagicBase - 1); }
long MagicOfEngine(int e) { return InpMagicBase + 1 + e; }

int StratByName(string name)
  {
   for(int i = 1; i < NSTRAT; i++)
      if(g_stratName[i] == name)
         return i;
   return 0;
  }

//+------------------------------------------------------------------+
//| Conteggi del portafoglio                                         |
//+------------------------------------------------------------------+
int    g_cntAll = 0;
int    g_cntEng[3];
int    g_cntDir[2];        // [0]=buy [1]=sell (posizioni non a pareggio)
double g_openRiskMoney = 0.0;

bool PositionExistsById(long id)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetInteger(POSITION_IDENTIFIER) == id)
         return true;
     }
   return false;
  }

bool OrderExists(long ticket)
  {
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong tk = OrderGetTicket(i);
      if(tk == 0)
         continue;
      if((long)tk == ticket)
         return true;
     }
   return false;
  }

void PortfolioScan()
  {
   g_cntAll = 0;
   g_cntEng[0] = 0;
   g_cntEng[1] = 0;
   g_cntEng[2] = 0;
   g_cntDir[0] = 0;
   g_cntDir[1] = 0;
   g_openRiskMoney = 0.0;
   double vpu = ValuePerPriceUnit();
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym)
         continue;
      long mg = PositionGetInteger(POSITION_MAGIC);
      if(!IsOurMagic(mg))
         continue;
      int e = EngineOfMagic(mg);
      int dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
      double op = PositionGetDouble(POSITION_PRICE_OPEN);
      double sl = PositionGetDouble(POSITION_SL);
      double vol = PositionGetDouble(POSITION_VOLUME);
      g_cntAll++;
      if(e >= 0 && e < 3)
         g_cntEng[e]++;
      double riskPx = (sl > 0.0) ? (op - sl) * dir : AtrOf(g_h1);
      if(riskPx > 0.0)
        {
         g_openRiskMoney += riskPx * vol * vpu;
         g_cntDir[(dir > 0) ? 0 : 1]++;
        }
     }
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong tk = OrderGetTicket(i);
      if(tk == 0)
         continue;
      if(OrderGetString(ORDER_SYMBOL) != g_sym)
         continue;
      long mg = OrderGetInteger(ORDER_MAGIC);
      if(!IsOurMagic(mg))
         continue;
      int e = EngineOfMagic(mg);
      ENUM_ORDER_TYPE ot = (ENUM_ORDER_TYPE)OrderGetInteger(ORDER_TYPE);
      int dir = (ot == ORDER_TYPE_BUY_LIMIT || ot == ORDER_TYPE_BUY_STOP) ? 1 : -1;
      double op = OrderGetDouble(ORDER_PRICE_OPEN);
      double sl = OrderGetDouble(ORDER_SL);
      double vol = OrderGetDouble(ORDER_VOLUME_CURRENT);
      g_cntAll++;
      if(e >= 0 && e < 3)
         g_cntEng[e]++;
      double riskPx = (sl > 0.0) ? (op - sl) * dir : 0.0;
      if(riskPx > 0.0)
        {
         g_openRiskMoney += riskPx * vol * vpu;
         g_cntDir[(dir > 0) ? 0 : 1]++;
        }
     }
  }

int MaxPositionsEff() { return g_netting ? 1 : InpMaxPositions; }

int EngineMaxPos(int e)
  {
   if(g_netting)
      return 1;
   if(e == ENG_SCALP)
      return 1;
   return 2;
  }

//+------------------------------------------------------------------+
//| Stato del rischio del conto                                      |
//+------------------------------------------------------------------+
double   g_dayStartEq = 0.0;
double   g_weekStartEq = 0.0;
double   g_weekStartBal = 0.0;
double   g_peakEq = 0.0;
datetime g_dayAnchor = 0;
datetime g_weekAnchor = 0;
bool     g_dayHalt = false;
bool     g_weekHalt = false;
bool     g_ddHalt = false;
int      g_tradesToday[3];
int      g_lossesInRowToday = 0;
int      g_lossStreak = 0;
bool     g_recoveryArmed = false;
datetime g_recoveryArmedT = 0;
datetime g_recoveryCooldownUntil = 0;
//--- rientro dopo pareggio (1.17), uno per motore
bool     g_reArmed[3];
int      g_reDir[3];
datetime g_reT[3];

string GvName(string key) { return "XC." + IntegerToString(g_login) + "." + IntegerToString(InpMagicBase) + "." + key; }

void GvSave()
  {
   GlobalVariableSet(GvName("dayEq"), g_dayStartEq);
   GlobalVariableSet(GvName("dayAnchor"), (double)g_dayAnchor);
   GlobalVariableSet(GvName("weekEq"), g_weekStartEq);
   GlobalVariableSet(GvName("weekBal"), g_weekStartBal);
   GlobalVariableSet(GvName("weekAnchor"), (double)g_weekAnchor);
   GlobalVariableSet(GvName("peak"), g_peakEq);
   GlobalVariableSet(GvName("halt"), g_ddHalt ? 1.0 : 0.0);
   GlobalVariableSet(GvName("dayHalt"), g_dayHalt ? 1.0 : 0.0);
   GlobalVariableSet(GvName("weekHalt"), g_weekHalt ? 1.0 : 0.0);
  }

double GvGet(string key, double def)
  {
   string n = GvName(key);
   if(!GlobalVariableCheck(n))
      return def;
   return GlobalVariableGet(n);
  }

//+------------------------------------------------------------------+
//| Capitale virtuale: il bot si comporta come se il conto fosse di  |
//| InpVirtualCapital (+ i profitti/perdite fatti da quando parte)   |
//+------------------------------------------------------------------+
double g_vStartEq = 0.0;
double g_vStartBal = 0.0;

//--- ora del server affidabile anche a mercato chiuso (TimeCurrent si ferma all'ultimo tick del venerdi')
datetime ServerNow()
  {
   datetime t = TimeTradeServer();
   if(t < TimeCurrent())
      t = TimeCurrent();
   return t;
  }

void VirtualInit()
  {
   if(InpVirtualCapital <= 0.0)
      return;
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   bool ok = (GvGet("vCap", -1.0) == InpVirtualCapital && GvGet("vStartBal", 0.0) > 0.0);
   if(ok)
     {
      g_vStartEq = GvGet("vStartEq", eq);
      g_vStartBal = GvGet("vStartBal", bal);
      //--- valore impossibile (lo stop al 50% lo avrebbe fermato prima): dati vecchi o sbagliati -> riparto
      double v = InpVirtualCapital + (bal - g_vStartBal);
      if(v < 0.3 * InpVirtualCapital || v > 50.0 * InpVirtualCapital)
        {
         ok = false;
         GlobalVariableDel(GvName("capMode"));
        }
     }
   if(!ok)
     {
      g_vStartEq = eq;
      g_vStartBal = bal;
      GlobalVariableSet(GvName("vCap"), InpVirtualCapital);
      GlobalVariableSet(GvName("vStartEq"), g_vStartEq);
      GlobalVariableSet(GvName("vStartBal"), g_vStartBal);
     }
  }

double AccEquity()
  {
   double eq = AccountInfoDouble(ACCOUNT_EQUITY);
   if(InpVirtualCapital <= 0.0)
      return eq;
   return InpVirtualCapital + (eq - g_vStartBal);
  }

double AccBalance()
  {
   double bal = AccountInfoDouble(ACCOUNT_BALANCE);
   if(InpVirtualCapital <= 0.0)
      return bal;
   return InpVirtualCapital + (bal - g_vStartBal);
  }

#define STATE_VER 115

void RiskStateInit()
  {
   if(!g_isTester && GvGet("stateVer", 0.0) < STATE_VER)
     {
      GlobalVariableDel(GvName("vCap"));
      GlobalVariableDel(GvName("capMode"));
      GlobalVariableDel(GvName("peak"));
      GlobalVariableSet(GvName("flowTo"), (double)ServerNow());
      GlobalVariableSet(GvName("stateVer"), STATE_VER);
      Logf("Stato del rischio azzerato per la versione " + g_version + " (riferimenti ripartono da adesso)");
     }
   VirtualInit();
   double eq = AccEquity();
   double bal = AccBalance();
   datetime dA = iTime(g_sym, PERIOD_D1, 0);
   datetime wA = iTime(g_sym, PERIOD_W1, 0);
   g_peakEq = MathMax(eq, GvGet("peak", eq));
   g_ddHalt = (GvGet("halt", 0.0) > 0.5);
   //--- capitale virtuale attivato/cambiato/tolto: i vecchi riferimenti (picco, inizio giorno/settimana)
   //--- erano su un'altra base e farebbero scattare stop falsi -> riparto da qui
   bool capChanged = (GvGet("capMode", -1.0) != InpVirtualCapital);
   if(capChanged)
     {
      g_peakEq = eq;
      GlobalVariableSet(GvName("capMode"), InpVirtualCapital);
      GlobalVariableDel(GvName("dayAnchor"));
      GlobalVariableDel(GvName("weekAnchor"));
      Logf("Base del capitale cambiata: picco e riferimenti giornalieri/settimanali ripartono da " + Money(eq));
     }
   if(InpResetHalt)
     {
      g_ddHalt = false;
      g_peakEq = eq;
     }
   if((datetime)GvGet("dayAnchor", 0.0) == dA)
     {
      g_dayAnchor = dA;
      g_dayStartEq = GvGet("dayEq", eq);
      g_dayHalt = (GvGet("dayHalt", 0.0) > 0.5);
     }
   else
     {
      g_dayAnchor = dA;
      g_dayStartEq = eq;
      g_dayHalt = false;
     }
   if((datetime)GvGet("weekAnchor", 0.0) == wA)
     {
      g_weekAnchor = wA;
      g_weekStartEq = GvGet("weekEq", eq);
      g_weekStartBal = GvGet("weekBal", bal);
      g_weekHalt = (GvGet("weekHalt", 0.0) > 0.5);
     }
   else
     {
      g_weekAnchor = wA;
      g_weekStartEq = eq;
      g_weekStartBal = bal;
      g_weekHalt = false;
     }
   g_tradesToday[0] = 0;
   g_tradesToday[1] = 0;
   g_tradesToday[2] = 0;
   GvSave();
  }
//+------------------------------------------------------------------+
//| Comitato: ogni desk vota 0..1 (e puo' mettere il veto),          |
//| poi avvocato del diavolo, quorum e punteggio pesato per motore   |
//+------------------------------------------------------------------+
double DeskWeight(int engine, int desk)
  {
   if(engine == ENG_SCALP)
     {
      switch(desk)
        {
         case D_STRAT:   return 0.15;
         case D_TREND:   return 0.08;
         case D_VOLUME:  return 0.16;
         case D_LIQ:     return 0.10;
         case D_MACRO:   return 0.08;
         case D_NEWS:    return 0.05;
         case D_SESSION: return 0.09;
         case D_COST:    return 0.13;
         case D_STATS:   return 0.06;
         case D_CONTEXT: return 0.10;
        }
      return 0.0;
     }
   if(engine == ENG_INTRA)
     {
      switch(desk)
        {
         case D_STRAT:   return 0.16;
         case D_TREND:   return 0.10;
         case D_VOLUME:  return 0.12;
         case D_LIQ:     return 0.10;
         case D_MACRO:   return 0.14;
         case D_NEWS:    return 0.04;
         case D_SESSION: return 0.05;
         case D_COST:    return 0.07;
         case D_STATS:   return 0.08;
         case D_CONTEXT: return 0.14;
        }
      return 0.0;
     }
   switch(desk)
     {
      case D_STRAT:   return 0.14;
      case D_TREND:   return 0.10;
      case D_VOLUME:  return 0.08;
      case D_LIQ:     return 0.08;
      case D_MACRO:   return 0.20;
      case D_NEWS:    return 0.03;
      case D_SESSION: return 0.02;
      case D_COST:    return 0.03;
      case D_STATS:   return 0.10;
      case D_CONTEXT: return 0.22;
     }
   return 0.0;
  }

double MinScoreFor(int engine)
  {
   if(engine == ENG_SCALP)
      return InpMinScoreScalp;
   if(engine == ENG_INTRA)
      return InpMinScoreIntra;
   return InpMinScoreSwing;
  }

void Veto(TSignal &s, string why)
  {
   if(!s.veto)
     {
      s.veto = true;
      s.vetoWhy = why;
     }
   else
      if(StringLen(s.vetoWhy) < 120)
         s.vetoWhy += "; " + why;
  }

//--- trend del timeframe di contesto (which=1 vicino, 2 superiore) per ogni motore
int CtxTrend(int engine, int which)
  {
   if(engine == ENG_SCALP)
      return (which == 1) ? TrendDir(g_m15) : TrendDir(g_h1);
   if(engine == ENG_INTRA)
      return (which == 1) ? TrendDir(g_h1) : TrendDir(g_h4);
   return (which == 1) ? TrendDir(g_h4) : EmaDir(g_d1);
  }

double CtxAdx(int engine)
  {
   if(engine == ENG_SCALP)
      return AdxOf(g_m15);
   if(engine == ENG_INTRA)
      return AdxOf(g_h1);
   return AdxOf(g_h4);
  }

double CtxRsi(int engine)
  {
   if(engine == ENG_SCALP)
      return Ind(g_m15.rsi, 0);
   if(engine == ENG_INTRA)
      return Ind(g_h1.rsi, 0);
   return Ind(g_h4.rsi, 0);
  }

double ExecRvol(int engine)
  {
   if(engine == ENG_SCALP)
      return RvolBar(g_m1, 0);
   if(engine == ENG_INTRA)
      return RvolBar(g_m5, 0);
   return RvolBar(g_h1, 0);
  }

int CvdWindow(int engine)
  {
   if(engine == ENG_SCALP)
      return 20;
   if(engine == ENG_INTRA)
      return 60;
   return 240;
  }

bool IsTrendLike(int stype) { return (stype == STYPE_TREND || stype == STYPE_BREAKOUT || stype == STYPE_NEWS); }

//--- climax contrario nelle ultime 3 barre del timeframe di esecuzione
bool ClimaxAgainst(int engine, int dir)
  {
   for(int sh = 0; sh < 3; sh++)
     {
      if(engine == ENG_SCALP && IsClimax(g_m1, sh, -dir))
         return true;
      if(engine == ENG_INTRA && IsClimax(g_m5, sh, -dir))
         return true;
      if(engine == ENG_SWING && IsClimax(g_h1, sh, -dir))
         return true;
     }
   return false;
  }

//--- DESK TREND
double DeskTrend(TSignal &s)
  {
   int a1 = CtxTrend(s.engine, 1) * s.dir;
   int a2 = CtxTrend(s.engine, 2) * s.dir;
   double adx = CtxAdx(s.engine);
   double sc;
   if(IsTrendLike(s.stype))
     {
      sc = 0.5 + 0.2 * a1 + 0.15 * a2;
      if(a1 > 0 && adx > 25.0)
         sc += 0.1;
      if(a1 < 0 && a2 < 0)
         Veto(s, "contro il trend su due timeframe");
     }
   else
     {
      sc = 0.55;
      if(adx < 20.0)
         sc += 0.1;
      if(a1 < 0 && adx > 30.0)
         sc -= 0.25;
      if(a2 > 0)
         sc += 0.15;
      if(a2 < 0 && a1 < 0)
         sc -= 0.1;
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK VOLUMI (delta, VWAP, RVOL, VSA, DOM, order flow GC)
double DeskVolume(TSignal &s)
  {
   double sc = 0.5;
   double cr = MicroCvdRatio(CvdWindow(s.engine));
   s.cvdRatio = cr;
   if(IsTrendLike(s.stype))
     {
      if(cr * s.dir > 0.05)
         sc += 0.15;
      else
         if(cr * s.dir < -0.05)
            sc -= 0.15;
     }
   else
     {
      double crs = MicroCvdRatio(5);
      if(crs * s.dir > 0.1)
         sc += 0.15;
      else
         if(crs * s.dir < -0.1)
            sc -= 0.1;
     }
   double vw = g_ctx.vwap, sg = g_ctx.vwSig;
   if(vw > 0.0)
     {
      if(IsTrendLike(s.stype))
         sc += ((s.entry - vw) * s.dir > 0.0) ? 0.1 : -0.1;
      else
         if(sg > 0.0 && (vw - s.entry) * s.dir >= sg)
            sc += 0.1;
     }
   double rv = ExecRvol(s.engine);
   if(rv >= 1.2)
      sc += 0.1;
   else
      if(rv < 0.6)
         sc -= 0.1;
   if(ClimaxAgainst(s.engine, s.dir))
      sc += IsTrendLike(s.stype) ? -0.15 : 0.1;
   //--- profilo di ieri: comprare vicino a VAL/POC (o vendere vicino a VAH/POC) e' un supporto
   if(PrevProfileOk())
     {
      double tol = 0.3 * g_ctx.atrM15;
      if(s.dir > 0 && (MathAbs(s.entry - PrevVAL()) < tol || MathAbs(s.entry - PrevPOC()) < tol))
         sc += 0.05;
      if(s.dir < 0 && (MathAbs(s.entry - PrevVAH()) < tol || MathAbs(s.entry - PrevPOC()) < tol))
         sc += 0.05;
     }
   if(s.engine == ENG_SCALP && DomFresh())
     {
      if(g_domImb * s.dir > 0.2)
         sc += 0.05;
      else
         if(g_domImb * s.dir < -0.2)
            sc -= 0.05;
     }
   if(GcFresh() && MathAbs(g_gcDeltaTrend) > 0.2)
      sc += (g_gcDeltaTrend * s.dir > 0.0) ? 0.05 : -0.05;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK LIQUIDITA' (strada libera verso il target, stop protetto)
double DeskLiquidity(TSignal &s)
  {
   double risk = RiskPx(s);
   double reward = (s.tp - s.entry) * s.dir;
   double sc = 0.5;
   int t = -1;
   double d = NearestLevelDist(s.entry, s.dir, 0.25 * risk, t);
   //--- ritorno alla media: il target E' un livello (VWAP/value area), i livelli intermedi fanno parte del percorso
   if(s.stype == STYPE_MEANREV)
     {
      s.obstacleR = 99.0;
      sc = 0.6;
      int tm = -1;
      double dm = NearestLevelDist(s.entry, -s.dir, 0.0, tm);
      if(dm > 0.0 && dm < risk * 0.95)
         sc += 0.1;
      return Clamp(sc, 0.0, 1.0);
     }
   if(d < 0.0)
     {
      sc += 0.2;
      s.obstacleR = 99.0;
     }
   else
     {
      double dR = d / risk;
      s.obstacleR = dR;
      if(dR >= reward / risk)
         sc += 0.2;
      else
         if(dR >= 1.5)
            sc += 0.1;
         else
            if(dR < 1.0)
              {
               sc -= 0.2;
               if(IsMajorLevel(t) && dR < 0.7)
                  Veto(s, "livello forte (" + g_lvName[t] + ") a " + DoubleToString(dR, 2) + "R");
              }
     }
   int t2 = -1;
   double ds = NearestLevelDist(s.entry, -s.dir, 0.0, t2);
   if(ds > 0.0 && ds < risk * 0.95)
      sc += 0.1;
   if(PriceOnMajorLevel(s.sl, 0.05 * g_ctx.atrM15))
      sc -= 0.1;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK MACRO (servizio GitHub + storico + intermarket dai simboli del broker)
double DeskMacro(TSignal &s)
  {
   if(MacroFresh() && g_macroHalt)
     {
      Veto(s, "servizio macro: stop (" + g_macroHaltReason + ")");
      return 0.0;
     }
   if(g_mConf <= 0.0)
      return 0.5;
   double al = g_mBias * s.dir;
   double sc = 0.5 + 0.45 * al * Clamp(g_mConf * 1.4, 0.0, 1.0);
   //--- il dollaro di oggi conta per chi lavora intraday
   if(s.engine != ENG_SWING && g_imOk)
      sc -= 0.08 * g_dollarFast * s.dir;
   if(AiFresh())
     {
      if(g_aiStance == "long")
         sc += 0.1 * g_aiConv * s.dir;
      else
         if(g_aiStance == "short")
            sc -= 0.1 * g_aiConv * s.dir;
         else
            if(g_aiStance == "stand_aside")
               sc -= 0.05;
     }
   //--- macro forte e contraria: niente trade di trend intraday/swing contro
   if(s.engine != ENG_SCALP && al <= -InpMacroVetoLevel && g_mConf >= 0.45)
     {
      if(IsTrendLike(s.stype) || s.engine == ENG_SWING)
         Veto(s, "macro contraria (" + DoubleToString(g_mBias, 2) + ", " + g_mSource + ")");
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK CONTESTO HTF (struttura, ritracciamento, compressione/espansione)
double DeskContext(TSignal &s)
  {
   if(!g_cxD1.valid && !g_cxH4.valid)
      return 0.5;
   double al = g_ctxBias * s.dir;
   int ph = PhaseFor(s.engine);
   int pdir = PhaseDirFor(s.engine);
   double retr = PhaseRetrFor(s.engine);
   double ext = PhaseExtFor(s.engine);
   double sc = 0.5;
   if(s.stype == STYPE_TREND || s.stype == STYPE_NEWS)
     {
      sc += 0.3 * al;
      if(pdir == s.dir && ph == PH_RITRACCIAMENTO && retr >= 0.382 && retr <= 0.786)
         sc += 0.12;                                    // compra lo sconto dentro il trend
      if(pdir == s.dir && (ph == PH_IMPULSO || ph == PH_ESPANSIONE) && retr < 0.236)
         sc -= 0.08;                                    // inseguire l'estensione
      if(ph == PH_ESAURIMENTO && ext * s.dir > 0.0)
         sc -= 0.15;                                    // entrare nel verso di un movimento esausto
      if(s.engine != ENG_SCALP && al <= -InpContextVetoLevel)
         Veto(s, "contesto dei timeframe alti contrario (" + DoubleToString(g_ctxBias, 2) + ")");
     }
   else
      if(s.stype == STYPE_BREAKOUT)
        {
         sc += 0.2 * al;
         if(ph == PH_COMPRESSIONE || g_cxD1.phase == PH_COMPRESSIONE)
            sc += 0.15;                                 // energia accumulata: la rottura ha piu' benzina
         if(ph == PH_ESAURIMENTO)
            sc -= 0.15;
         if(s.engine != ENG_SCALP && al <= -InpContextVetoLevel)
            Veto(s, "contesto dei timeframe alti contrario (" + DoubleToString(g_ctxBias, 2) + ")");
        }
      else
        {
         sc += 0.1 * al;
         if(ph == PH_ESAURIMENTO && ext * s.dir < 0.0)
            sc += 0.15;                                 // inversione contro un movimento esausto
         if((ph == PH_IMPULSO || ph == PH_ESPANSIONE) && pdir == -s.dir)
            sc -= 0.15;                                 // contro un impulso fresco
         if(ph == PH_LATERALE || ph == PH_COMPRESSIONE)
            sc += 0.05;
        }
   //--- premium / discount del range giornaliero
   double rp = g_cxD1.rangePos;
   if(g_cxD1.valid)
     {
      if((s.dir > 0 && rp < 0.35) || (s.dir < 0 && rp > 0.65))
         sc += 0.06;
      else
         if((s.dir > 0 && rp > 0.85) || (s.dir < 0 && rp < 0.15))
            sc -= 0.08;
     }
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK NEWS
double DeskNews(TSignal &s)
  {
   string why = "";
   if(NewsBlocked(s.engine, g_ctx.nowUtc, s.strat, why))
     {
      Veto(s, why);
      return 0.0;
     }
   if(s.strat == ST_IN_NEWS)
      return 0.75;
   double sc = 0.6;
   int mins = MinutesToNextTier1(g_ctx.nowUtc);
   int horizon = (s.engine == ENG_SWING) ? 720 : 120;
   if(mins >= 0 && mins < horizon)
      sc = 0.4;
   int v = NextEventView(g_ctx.nowUtc, 600);
   if(v != 0)
      sc += (v == s.dir) ? 0.1 : -0.15;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK SESSIONE
double DeskSession(TSignal &s)
  {
   double h = g_ctx.hUtc;
   double lo = g_ctx.lonOpen, nyd = g_ctx.nyData, nyo = g_ctx.nyOpen, nyc = g_ctx.nyClose;
   double sc = 0.6;
   if(s.engine == ENG_SCALP)
     {
      if(h >= nyd - 0.25 && h < nyo + 2.5)
         sc = 0.8;
      else
         if(h >= lo && h < lo + 3.0)
            sc = 0.75;
         else
            if(h >= lo && h < nyd)
               sc = 0.55;
            else
               if(h < lo)
                  sc = 0.25;
               else
                  sc = 0.4;
     }
   else
      if(s.engine == ENG_INTRA)
        {
         if(h >= lo && h < nyc - 2.0)
            sc = 0.7;
         else
            if(h < lo)
               sc = 0.35;
            else
               sc = 0.4;
        }
   if(g_ctx.dow == 5 && h >= 16.0)
      sc -= 0.2;
   if(g_ctx.dow == 1 && h < lo)
      sc -= 0.1;
   return Clamp(sc, 0.0, 1.0);
  }

//--- DESK COSTI (spread + commissione rispetto allo stop)
double DeskCost(TSignal &s)
  {
   double risk = RiskPx(s);
   if(risk <= 0.0)
      return 0.0;
   double cost = g_ctx.spread + CommissionPx() + 0.1 * g_ctx.spread;
   double cr = cost / risk;
   if(cr > InpMaxCostR)
      Veto(s, "costi " + DoubleToString(cr * 100.0, 0) + "% di R");
   if(SpreadAbnormal())
      Veto(s, "spread anomalo");
   return Clamp(1.0 - cr * 4.0, 0.0, 1.0);
  }

//--- DESK STATISTICA (risultati reali della strategia + adattamento al regime)
double DeskStats(TSignal &s)
  {
   double sc = 0.5;
   int k = s.strat;
   if(g_ss[k].n >= 10)
      sc += Clamp(g_ss[k].Expectancy(), -0.5, 0.5) * 0.6;
   int rl = g_ss[k].RecentLosses(5);
   if(rl >= 4)
      sc -= 0.15;
   else
      if(rl >= 3)
         sc -= 0.1;
   sc += RegimeFit(s.stype);
   if(InpUseBench && InpOnlyStrategy == PICK_ALL && g_ss[k].benchUntil > TimeCurrent())
      Veto(s, "strategia in panchina fino al " + TimeToString(g_ss[k].benchUntil, TIME_DATE));
   return Clamp(sc, 0.0, 1.0);
  }

//--- controlli di portafoglio (slot, direzione, limiti giornalieri)
void PortfolioChecks(TSignal &s)
  {
   PortfolioScan();
   if(g_cntAll >= MaxPositionsEff())
      Veto(s, "posizioni massime (" + IntegerToString(MaxPositionsEff()) + ")");
   if(g_cntEng[s.engine] >= EngineMaxPos(s.engine))
      Veto(s, "slot del motore " + g_engName[s.engine] + " pieni");
   int opp = (s.dir > 0) ? g_cntDir[1] : g_cntDir[0];
   if(opp > 0)
      Veto(s, "c'e' una posizione opposta a rischio");
   int maxDay = (s.engine == ENG_SCALP) ? InpScalpMaxTradesDay : ((s.engine == ENG_INTRA) ? InpIntraMaxTradesDay : InpSwingMaxTradesDay);
   if(g_tradesToday[s.engine] >= maxDay)
      Veto(s, "trade massimi di oggi per " + g_engName[s.engine]);
   if(g_lossesInRowToday >= InpMaxLossesInRowDay)
      Veto(s, IntegerToString(g_lossesInRowToday) + " perdite di fila oggi");
  }

//--- AVVOCATO DEL DIAVOLO: conta gli argomenti contrari
int DevilsAdvocate(TSignal &s, string &list)
  {
   int c = 0;
   list = "";
   double rsi = CtxRsi(s.engine);
   if(IsTrendLike(s.stype) && ((s.dir > 0 && rsi > 75.0) || (s.dir < 0 && rsi < 25.0)))
     {
      c++;
      list += "RSI estremo; ";
     }
   bool div = false;
   if(s.engine == ENG_SCALP)
      div = RsiDivergenceAgainst(g_m5, s.dir, 20);
   else
      if(s.engine == ENG_INTRA)
         div = RsiDivergenceAgainst(g_m15, s.dir, 20);
      else
         div = RsiDivergenceAgainst(g_h4, s.dir, 20);
   if(IsTrendLike(s.stype) && div)
     {
      c++;
      list += "divergenza RSI; ";
     }
   if(s.obstacleR >= 0.0 && s.obstacleR < 1.0)
     {
      c++;
      list += "livello prima di 1R; ";
     }
   if(g_mBias * s.dir < -0.3 && g_mConf >= 0.4)
     {
      c++;
      list += "macro contraria; ";
     }
   if(g_ctxBias * s.dir < -0.3)
     {
      c++;
      list += "contesto HTF contrario; ";
     }
   if(IsTrendLike(s.stype) && PhaseFor(s.engine) == PH_ESAURIMENTO && PhaseExtFor(s.engine) * s.dir > 0.0)
     {
      c++;
      list += "movimento esausto; ";
     }
   if(IsTrendLike(s.stype) && g_cxD1.valid && ((s.dir > 0 && g_cxD1.rangePos > 0.9) || (s.dir < 0 && g_cxD1.rangePos < 0.1)))
     {
      c++;
      list += "prezzo agli estremi del range; ";
     }
   if(s.cvdRatio * s.dir < -0.1)
     {
      c++;
      list += "delta contrario; ";
     }
   if(s.desk[D_SESSION] < 0.4)
     {
      c++;
      list += "sessione debole; ";
     }
   if(g_ss[s.strat].RecentLosses(2) >= 2)
     {
      c++;
      list += "ultime 2 perse; ";
     }
   if(g_regime == REG_VOLATILE)
     {
      c++;
      list += "mercato volatile; ";
     }
   int v = NextEventView(g_ctx.nowUtc, 600);
   if(v != 0 && v != s.dir)
     {
      c++;
      list += "vista pre-news contraria; ";
     }
   return c;
  }

//--- P5 (1.17): nelle ore asiatiche lo stop non resta appoggiato su un livello ovvio
bool ObviousLevel(int type)
  {
   return (type == LV_PDH || type == LV_PDL || type == LV_PWH || type == LV_PWL || type == LV_ASIAH || type == LV_ASIAL ||
           type == LV_ROUND || type == LV_ROUNDM);
  }

void AsiaStopAdjust(TSignal &s)
  {
   if(!InpP5AsiaStopBuffer)
      return;
   double h = g_ctx.hUtc;
   if(!(h >= 21.0 || h < g_ctx.lonOpen))
      return;
   double buf = InpP5BufferAtrH1 * g_ctx.atrH1;
   double risk = RiskPx(s);
   if(buf <= 0.0 || risk <= 0.0)
      return;
   double rr = (s.tp - s.entry) * s.dir / risk;
   double sl = s.sl;
   string moved = "";
   for(int pass = 0; pass < 3; pass++)
     {
      bool any = false;
      for(int i = 0; i < g_lvN; i++)
        {
         if(!ObviousLevel(g_lv[i].type))
            continue;
         double L = g_lv[i].price;
         if((s.entry - L) * s.dir <= 0.0)
            continue;                       // il livello deve stare dalla parte dello stop
         if(MathAbs(sl - L) > buf)
            continue;
         double target = (s.dir > 0) ? L - buf : L + buf + g_ctx.spread;
         if((sl - target) * s.dir > 0.0)
           {
            sl = target;
            any = true;
            moved = g_lvName[g_lv[i].type];
           }
        }
      if(!any)
         break;
     }
   if(moved == "")
      return;
   s.sl = NormPrice(sl);
   double nrisk = RiskPx(s);
   s.tp = NormPrice(s.entry + s.dir * nrisk * rr);
   s.why += " | P5 stop oltre " + moved + " (ore asiatiche)";
  }

//--- P6 (1.17): alla scadenza opzioni COMEX e il giorno dopo i breakout hanno meno strada
void ExpiryTargetAdjust(TSignal &s)
  {
   if(!InpP6ExpiryTargets || s.stype != STYPE_BREAKOUT)
      return;
   if(!IsExpiryWindow(EtYmd(g_ctx.nowUtc)))
      return;
   double risk = RiskPx(s);
   if(risk <= 0.0)
      return;
   double rr = (s.tp - s.entry) * s.dir / risk;
   double nr = MathMax(InpMinRR, rr * Clamp(InpP6TargetMult, 0.5, 1.0));
   if(nr >= rr)
      return;
   s.tp = NormPrice(s.entry + s.dir * risk * nr);
   s.why += " | P6 scadenza opzioni: target " + DoubleToString(nr, 2) + "R";
  }

//--- ritocchi del segnale prima del voto (P5, P6)
void SignalAdjust(TSignal &s)
  {
   AsiaStopAdjust(s);
   ExpiryTargetAdjust(s);
  }

//--- il comitato vota il segnale
void Committee(TSignal &s)
  {
   double risk = RiskPx(s);
   double reward = (s.tp - s.entry) * s.dir;
   if(risk <= 0.0 || reward < InpMinRR * risk - g_tick)
      Veto(s, "R:R sotto 1:" + DoubleToString(InpMinRR, 1));
   //--- motori del prezzo (1.17)
   string thin = "";
   if(ThinLiquidity(g_ctx.nowUtc, g_ctx.hUtc, g_ctx.lonOpen, thin))
      Veto(s, thin);
   if(g_runBrake && s.dir > 0 && s.stype == STYPE_BREAKOUT)
      Veto(s, "P1 corsa verticale (" + DoubleToString(g_runZ, 1) + " sigma, distanza dalla media 200 " + DoubleToString(g_ma200Dist, 0) + "%): niente long in rottura");
   s.desk[D_STRAT] = s.quality;
   s.desk[D_TREND] = DeskTrend(s);
   s.desk[D_VOLUME] = DeskVolume(s);
   s.desk[D_LIQ] = DeskLiquidity(s);
   s.desk[D_MACRO] = DeskMacro(s);
   s.desk[D_NEWS] = DeskNews(s);
   s.desk[D_SESSION] = DeskSession(s);
   s.desk[D_COST] = DeskCost(s);
   s.desk[D_STATS] = DeskStats(s);
   s.desk[D_CONTEXT] = DeskContext(s);
   PortfolioChecks(s);
   string objections = "";
   s.devil = DevilsAdvocate(s, objections);
   if(s.devil >= InpDevilMax)
      Veto(s, "avvocato del diavolo: " + objections);
   //--- quorum sugli 8 desk principali
   s.quorum = 0;
   if(s.desk[D_CONTEXT] >= 0.5)
      s.quorum++;
   if(s.desk[D_MACRO] >= 0.5)
      s.quorum++;
   if(s.desk[D_STRAT] >= 0.5)
      s.quorum++;
   if(s.desk[D_TREND] >= 0.5)
      s.quorum++;
   if(s.desk[D_VOLUME] >= 0.5)
      s.quorum++;
   if(s.desk[D_LIQ] >= 0.5)
      s.quorum++;
   if(s.desk[D_NEWS] >= 0.5)
      s.quorum++;
   if(s.desk[D_COST] >= 0.5)
      s.quorum++;
   double score = 0.0;
   bool unanimous = true;
   for(int d = 0; d < NDESK; d++)
     {
      score += DeskWeight(s.engine, d) * s.desk[d];
      if(s.desk[d] < 0.55)
         unanimous = false;
     }
   if(unanimous)
      score += 0.03;
   if(InpP4FirstDayLong && s.dir > 0 && IsFirstTradingDay(EtYmd(g_ctx.nowUtc)))
      score += InpP4Bonus;                  // P4 (1.17): primo giorno di borsa del mese
   s.score = score;
   //--- coda (1.17): con altre posizioni o ordini aperti, la nuova idea deve essere piu' sicura
   //    (solo per le idee che passerebbero da sole: le altre restano respinte con il loro motivo)
   if(InpQueueOn && !s.veto && g_cntAll > 0 && score >= MinScoreFor(s.engine) && s.quorum >= InpQuorum &&
      (score < MinScoreFor(s.engine) + InpQueueExtraScore || s.quorum < InpQuorum + 1))
      Veto(s, "coda: c'e' gia' una posizione aperta, servono punteggio " + DoubleToString(MinScoreFor(s.engine) + InpQueueExtraScore, 2) +
           " e quorum " + IntegerToString(InpQuorum + 1) + "/8");
   s.strong = (!s.veto && score >= InpStrongScore && s.quorum >= 7);
   s.passed = (!s.veto && s.quorum >= InpQuorum && score >= MinScoreFor(s.engine));
  }

string DeskLine(const TSignal &s)
  {
   string t = "";
   for(int d = 0; d < NDESK; d++)
      t += g_deskShort[d] + " " + DoubleToString(s.desk[d], 2) + (d < NDESK - 1 ? " | " : "");
   return t;
  }
//+------------------------------------------------------------------+
//| Risk manager: limiti del conto, lotti dinamici, profit cushion,  |
//| recupero, scaglioni, esecuzione                                  |
//+------------------------------------------------------------------+
bool TradingHalted(string &why)
  {
   if(g_ddHalt)
     {
      why = "STOP per drawdown massimo: per ripartire imposta 'Sblocca' = true";
      return true;
     }
   if(g_weekHalt)
     {
      why = "stop settimanale raggiunto (-" + DoubleToString(InpWeeklyLossPct, 1) + "%)";
      return true;
     }
   if(g_dayHalt)
     {
      why = "stop giornaliero raggiunto (-" + DoubleToString(InpDailyLossPct, 1) + "%)";
      return true;
     }
   if(!g_isTester && (!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED)))
     {
      why = "trading automatico disattivato (pulsante Algo Trading)";
      return true;
     }
   return false;
  }

void CloseAll(string why)
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym || !IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      g_trade.PositionClose(tk);
     }
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong tk = OrderGetTicket(i);
      if(tk == 0)
         continue;
      if(OrderGetString(ORDER_SYMBOL) != g_sym || !IsOurMagic(OrderGetInteger(ORDER_MAGIC)))
         continue;
      g_trade.OrderDelete(tk);
     }
   g_needSweep = true;
   Notify("CHIUSO TUTTO: " + why);
  }

//--- nuovo giorno / nuova settimana del broker
void RiskPeriodCheck()
  {
   datetime dA = iTime(g_sym, PERIOD_D1, 0);
   datetime wA = iTime(g_sym, PERIOD_W1, 0);
   bool changed = false;
   if(dA != 0 && dA != g_dayAnchor)
     {
      g_dayAnchor = dA;
      g_dayStartEq = AccEquity();
      g_dayHalt = false;
      g_tradesToday[0] = 0;
      g_tradesToday[1] = 0;
      g_tradesToday[2] = 0;
      g_lossesInRowToday = 0;
      changed = true;
     }
   if(wA != 0 && wA != g_weekAnchor)
     {
      g_weekAnchor = wA;
      g_weekStartEq = AccEquity();
      g_weekStartBal = AccBalance();
      g_weekHalt = false;
      changed = true;
     }
   if(changed)
      GvSave();
  }

//+------------------------------------------------------------------+
//| Depositi e prelievi: il bot si adatta al nuovo saldo ma NON li   |
//| scambia per guadagni o perdite (niente falsi stop giornalieri)   |
//+------------------------------------------------------------------+
datetime g_flowCheckedTo = 0;
double   g_lastRealBal = 0.0;

void ApplyCashFlow(double amount, datetime when)
  {
   if(amount == 0.0)
      return;
   if(InpVirtualCapital > 0.0)
     {
      //--- con il capitale virtuale i movimenti del conto vero non lo cambiano
      g_vStartBal += amount;
      g_vStartEq += amount;
      GlobalVariableSet(GvName("vStartBal"), g_vStartBal);
      GlobalVariableSet(GvName("vStartEq"), g_vStartEq);
     }
   else
     {
      //--- conto vero: i riferimenti si spostano insieme al saldo (non e' un guadagno ne' una perdita)
      g_dayStartEq += amount;
      g_weekStartEq += amount;
      g_weekStartBal += amount;
      g_peakEq = MathMax(g_peakEq + amount, AccEquity());
     }
   GvSave();
   string what = (amount > 0.0) ? "Deposito" : "Prelievo";
   Notify(what + " di " + Money(MathAbs(amount)) + ": lotti e limiti ricalcolati sul nuovo saldo (" + Money(AccEquity()) + ")");
  }

//--- cerca depositi/prelievi nello storico dall'ultimo controllo
void CashFlowScan()
  {
   if(g_isTester)
      return;
   datetime now = ServerNow();
   datetime from = g_flowCheckedTo;
   if(from <= 0)
     {
      from = (datetime)GvGet("flowTo", 0.0);
      if(from <= 0)
        {
         g_flowCheckedTo = now;
         GlobalVariableSet(GvName("flowTo"), (double)now);
         return;
        }
     }
   if(!HistorySelect(from + 1, now + 60))
      return;
   int n = HistoryDealsTotal();
   for(int i = 0; i < n; i++)
     {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0)
         continue;
      if(HistoryDealGetInteger(d, DEAL_TYPE) != DEAL_TYPE_BALANCE)
         continue;
      ApplyCashFlow(HistoryDealGetDouble(d, DEAL_PROFIT), (datetime)HistoryDealGetInteger(d, DEAL_TIME));
     }
   g_flowCheckedTo = now;
   GlobalVariableSet(GvName("flowTo"), (double)now);
  }

//--- il saldo vero e' cambiato: prima di tutto controllo se e' un deposito/prelievo
void FlowCheck()
  {
   if(g_isTester)
      return;
   double rb = AccountInfoDouble(ACCOUNT_BALANCE);
   if(rb != g_lastRealBal)
     {
      g_lastRealBal = rb;
      CashFlowScan();
     }
  }

//--- controllato a ogni tick
void RiskCheckLimits()
  {
   FlowCheck();
   double eq = AccEquity();
   if(eq <= 0.0)
      return;
   if(eq > g_peakEq)
     {
      g_peakEq = eq;
      if(!g_isTester && MathRand() % 50 == 0)
         GlobalVariableSet(GvName("peak"), g_peakEq);
     }
   if(!g_ddHalt && g_peakEq > 0.0 && eq <= g_peakEq * (1.0 - InpMaxDrawdownPct / 100.0))
     {
      g_ddHalt = true;
      CloseAll("drawdown " + Pct(InpMaxDrawdownPct) + " dal picco. L'EA si ferma.");
      GvSave();
      return;
     }
   if(!g_weekHalt && g_weekStartEq > 0.0 && eq <= g_weekStartEq * (1.0 - InpWeeklyLossPct / 100.0))
     {
      g_weekHalt = true;
      CloseAll("stop settimanale -" + Pct(InpWeeklyLossPct));
      GvSave();
      return;
     }
   if(!g_dayHalt && g_dayStartEq > 0.0 && eq <= g_dayStartEq * (1.0 - InpDailyLossPct / 100.0))
     {
      g_dayHalt = true;
      CloseAll("stop giornaliero -" + Pct(InpDailyLossPct));
      GvSave();
     }
  }

//--- perdita per 1 lotto fino allo stop, commissione inclusa (valuta del conto)
double LossPerLot(int dir, double entry, double sl)
  {
   double p = 0.0;
   ENUM_ORDER_TYPE t = (dir > 0) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   if(!OrderCalcProfit(t, g_sym, 1.0, entry, sl, p) || p == 0.0)
      p = -(entry - sl) * dir * ValuePerPriceUnit();
   return MathAbs(p) + MathMax(InpCommissionPerLot, 0.0);
  }

double BaseCapital()
  {
   return MathMin(AccEquity(), AccBalance());
  }

//--- recupero: una sola volta dopo una perdita, solo con idee di altissima qualita'
bool RecoveryEligible(const TSignal &s)
  {
   if(!InpRecoveryEnabled || !g_recoveryArmed)
      return false;
   if(TimeCurrent() - g_recoveryArmedT > 24 * 3600)
      return false;
   if(!(s.strat == ST_SC_VWAP || s.strat == ST_IN_PULLBACK || s.strat == ST_SW_TREND))
      return false;
   if(s.score < InpRecoveryMinScore || s.desk[D_VOLUME] < 0.6 || s.desk[D_MACRO] < 0.5 || s.desk[D_CONTEXT] < 0.55)
      return false;
   int conf = 0;
   if(s.desk[D_TREND] >= 0.6)
      conf++;
   if(s.desk[D_VOLUME] >= 0.6)
      conf++;
   if(s.desk[D_LIQ] >= 0.6)
      conf++;
   if(s.desk[D_SESSION] >= 0.6)
      conf++;
   if(conf < 3)
      return false;
   int m = MinutesToNextTier1(g_ctx.nowUtc);
   int need = (s.engine == ENG_SWING) ? 720 : 240;
   if(m >= 0 && m < need)
      return false;
   if(g_regime == REG_VOLATILE)
      return false;
   return true;
  }

//--- rientro (1.17): il trade di prima e' tornato a pareggio e le conferme ci sono ancora
bool ReentryEligible(const TSignal &s)
  {
   int e = s.engine;
   if(!InpReentryOn || s.recovery || e < 0 || e > 2 || !g_reArmed[e] || s.dir != g_reDir[e])
      return false;
   int win = (e == ENG_SCALP) ? 60 : ((e == ENG_INTRA) ? 240 : 1440);
   if(TimeCurrent() - g_reT[e] > win * 60)
      return false;
   if(s.score < MinScoreFor(e) + 0.03 || s.quorum < InpQuorum + 1 || s.devil > 1)
      return false;
   if(s.desk[D_CONTEXT] < 0.55 || s.desk[D_MACRO] < 0.5)
      return false;
   return true;
  }

//--- idea A+ (1.18): tutte le conferme insieme -> rischio piu' alto, lotti fino a InpAplusMaxLots
bool AplusEligible(const TSignal &s, int against)
  {
   if(!InpAplusOn || s.recovery || against > 0 || g_regime == REG_VOLATILE || g_runBrake || g_lossStreak >= 2)
      return false;
   double need = MathMax(InpAplusMinScore, MinScoreFor(s.engine) + 0.05);
   if(s.score < need - 0.000001 || s.quorum < 7 || s.devil > 1)
      return false;
   if(s.desk[D_CONTEXT] < 0.55 || s.desk[D_MACRO] < 0.5)
      return false;
   return true;
  }

//--- riduce i lotti finche' il margine resta sopra il livello minimo
double FitMargin(int dir, double entry, double lots, string &why)
  {
   double m1 = 0.0;
   ENUM_ORDER_TYPE t = (dir > 0) ? ORDER_TYPE_BUY : ORDER_TYPE_SELL;
   if(!OrderCalcMargin(t, g_sym, 1.0, entry, m1) || m1 <= 0.0)
      return lots;
   double eq = AccEquity();
   double used = AccountInfoDouble(ACCOUNT_MARGIN);
   double allow = eq * 100.0 / MathMax(InpMinMarginLevel, 100.0) - used;
   double maxLots = FloorLot(allow / m1);
   if(maxLots < lots)
     {
      lots = maxLots;
      if(lots < g_minLot)
         why = "margine insufficiente: con questa leva 0.01 lotti richiedono " + Money(m1 * g_minLot);
     }
   return lots;
  }

//--- lotti per il segnale: rischio % -> denaro -> lotti, con tutti i limiti
double LotsFor(TSignal &s, double &riskMoneyOut, string &why)
  {
   riskMoneyOut = 0.0;
   double base = BaseCapital();
   if(base <= 0.0)
     {
      why = "conto senza capitale";
      return 0.0;
     }
   double pct = InpRiskPercent;
   if(s.engine == ENG_SCALP)
      pct *= InpScalpRiskMult;
   else
      if(s.engine == ENG_SWING)
         pct *= InpSwingRiskMult;
   if(g_regime == REG_VOLATILE)
      pct *= 0.5;
   if(g_runBrake)
      pct *= Clamp(InpP1RiskMult, 0.0, 1.0);   // P1 (1.17): corsa verticale, rischio ridotto
   if(MacroFresh())
      pct *= Clamp(g_macroRiskMult, 0.5, 1.2);
   //--- macro o contesto contrari (ma non abbastanza per il veto): posizione piu' piccola
   int against = 0;
   if(g_mConf >= 0.3 && g_mBias * s.dir < -0.2)
      against++;
   if(g_ctxBias * s.dir < -0.2)
      against++;
   pct *= (1.0 - 0.25 * against);
   s.recovery = RecoveryEligible(s);
   if(s.recovery)
      pct *= InpRecoveryMult;
   else
      if(g_lossStreak >= 3)
         pct *= 0.5;
      else
         if(g_lossStreak == 2)
            pct *= 0.75;
   s.reentry = ReentryEligible(s);
   if(s.reentry)
      pct *= Clamp(InpReentryMult, 1.0, 2.0);
   s.aplus = AplusEligible(s, against);
   if(s.aplus)
      pct = MathMax(pct, Clamp(InpAplusRiskPct, 0.0, InpMaxRiskPerTrade) * (s.reentry ? Clamp(InpReentryMult, 1.0, 2.0) : 1.0));
   pct = MathMin(pct, InpMaxRiskPerTrade);
   double money = base * pct / 100.0;
   //--- profit cushion: le idee forti possono rischiare in piu' SOLO profitti gia' incassati in settimana
   double extra = 0.0;
   if(InpUseProfitCushion && s.strong && !s.recovery && !s.aplus)
     {
      double cushion = AccBalance() - g_weekStartBal;
      if(cushion > 0.0)
         extra = MathMin(cushion * InpCushionUse, money * InpCushionMaxMult);
     }
   s.cushion = extra;
   money += extra;
   PortfolioScan();
   double room = base * InpMaxOpenRiskPct / 100.0 + extra - g_openRiskMoney;
   if(room <= 0.0)
     {
      why = "rischio aperto gia' al massimo (" + Pct(InpMaxOpenRiskPct) + ")";
      return 0.0;
     }
   money = MathMin(money, room);
   double lpl = LossPerLot(s.dir, s.entry, s.sl);
   if(lpl <= 0.0)
     {
      why = "calcolo della perdita per lotto fallito";
      return 0.0;
     }
   double lots = FloorLot(money / lpl);
   if(lots < g_minLot)
     {
      double minRisk = lpl * g_minLot;
      double minPct = 100.0 * minRisk / base;
      if(minPct <= InpMinLotMaxRiskPct && minRisk <= room + base * 0.005)
         lots = g_minLot;
      else
        {
         why = "conto piccolo per questo stop: " + DoubleToString(g_minLot, g_lotDigits) + " lotti = " + Pct(minPct) +
               " di rischio (max " + Pct(InpMinLotMaxRiskPct) + ")";
         return 0.0;
        }
     }
   lots = MathMin(lots, MathMin(InpMaxLots, g_maxLot));
   if(s.aplus && InpAplusMaxLots > 0.0)
      lots = MathMin(lots, MathMax(FloorLot(InpAplusMaxLots), g_minLot));
   lots = FitMargin(s.dir, s.entry, lots, why);
   if(lots < g_minLot)
     {
      if(why == "")
         why = "lotti sotto il minimo";
      return 0.0;
     }
   riskMoneyOut = lots * lpl;
   return lots;
  }

//--- distanza minima dello stop dal prezzo imposta dal broker
double StopsMinDist()
  {
   long lvl = SymbolInfoInteger(g_sym, SYMBOL_TRADE_STOPS_LEVEL);
   long frz = SymbolInfoInteger(g_sym, SYMBOL_TRADE_FREEZE_LEVEL);
   long m = (lvl > frz) ? lvl : frz;
   return (double)m * g_point + g_tick;
  }

bool RetOk(uint rc) { return (rc == TRADE_RETCODE_DONE || rc == TRADE_RETCODE_PLACED || rc == TRADE_RETCODE_DONE_PARTIAL); }

int MetaRecord(const TSignal &s, long id, int tranche, double lots, double entry, bool pending, int expiryMin)
  {
   int k = MetaFree();
   if(k < 0)
      return -1;
   g_meta[k].Reset();
   g_meta[k].active = true;
   g_meta[k].id = id;
   g_meta[k].strat = s.strat;
   g_meta[k].engine = s.engine;
   g_meta[k].dir = s.dir;
   g_meta[k].tranche = tranche;
   g_meta[k].idea = g_ideaSeq;
   g_meta[k].entry = entry;
   g_meta[k].sl0 = s.sl;
   g_meta[k].tp = s.tp;
   g_meta[k].riskPx = (entry - s.sl) * s.dir;
   g_meta[k].riskMoney = lots * LossPerLot(s.dir, entry, s.sl);
   g_meta[k].lots0 = lots;
   g_meta[k].score = s.score;
   g_meta[k].cushion = s.cushion;
   g_meta[k].recovery = s.recovery;
   g_meta[k].reentry = s.reentry;
   g_meta[k].aplus = s.aplus;
   g_meta[k].isPending = pending;
   g_meta[k].openTime = TimeCurrent();
   g_meta[k].expiryMin = expiryMin;
   return k;
  }

bool SendMarket(const TSignal &s, double lots, long &idOut)
  {
   double sl = NormPrice(s.sl), tp = NormPrice(s.tp);
   double px = (s.dir > 0) ? PxAsk() : PxBid();
   double md = StopsMinDist();
   if((px - sl) * s.dir < md || (tp - px) * s.dir < md)
     {
      Logf("Ordine saltato: stop o target troppo vicini al prezzo per il broker");
      return false;
     }
   g_trade.SetExpertMagicNumber((ulong)MagicOfEngine(s.engine));
   string cmt = "XC " + g_stratName[s.strat];
   bool ok = (s.dir > 0) ? g_trade.Buy(lots, g_sym, 0.0, sl, tp, cmt) : g_trade.Sell(lots, g_sym, 0.0, sl, tp, cmt);
   uint rc = g_trade.ResultRetcode();
   if(!ok || !RetOk(rc))
     {
      Logf("Ordine rifiutato: " + IntegerToString((int)rc) + " " + g_trade.ResultRetcodeDescription());
      return false;
     }
   idOut = (long)g_trade.ResultOrder();
   ulong deal = g_trade.ResultDeal();
   if(deal > 0 && HistoryDealSelect(deal))
     {
      long pid = HistoryDealGetInteger(deal, DEAL_POSITION_ID);
      if(pid > 0)
         idOut = pid;
     }
   return true;
  }

bool SendLimit(const TSignal &s, double lots, double price, long &idOut)
  {
   price = NormPrice(price);
   double sl = NormPrice(s.sl), tp = NormPrice(s.tp);
   double px = (s.dir > 0) ? PxAsk() : PxBid();
   double md = StopsMinDist();
   if((px - price) * s.dir < md || (price - sl) * s.dir < md)
      return false;
   g_trade.SetExpertMagicNumber((ulong)MagicOfEngine(s.engine));
   string cmt = "XC " + g_stratName[s.strat] + " T";
   bool ok = (s.dir > 0) ? g_trade.BuyLimit(lots, price, g_sym, sl, tp, ORDER_TIME_GTC, 0, cmt)
             : g_trade.SellLimit(lots, price, g_sym, sl, tp, ORDER_TIME_GTC, 0, cmt);
   if(!ok || !RetOk(g_trade.ResultRetcode()))
      return false;
   idOut = (long)g_trade.ResultOrder();
   return true;
  }

int ExpiryFor(int engine)
  {
   if(engine == ENG_SCALP)
      return 10;
   if(engine == ENG_INTRA)
      return 60;
   return 480;
  }

//--- esegue un segnale approvato (con eventuali ingressi scaglionati)
bool Execute(TSignal &s)
  {
   double riskMoney = 0.0;
   string why = "";
   double lots = LotsFor(s, riskMoney, why);
   if(lots <= 0.0)
     {
      string line = "[" + g_engName[s.engine] + "] " + g_stratName[s.strat] + " " + DirName(s.dir) + " approvato ma NON eseguito: " + why;
      Logf(line);
      RememberDecision(line);
      return false;
     }
   g_ideaSeq++;
   double w[3];
   w[0] = 1.0;
   w[1] = 0.0;
   w[2] = 0.0;
   double depth[3];
   depth[0] = 0.0;
   depth[1] = 0.25;
   depth[2] = 0.5;
   int nTr = 1;
   PortfolioScan();
   int slots = MaxPositionsEff() - g_cntAll;
   //--- coda (1.17): gli ingressi scaglionati lasciano un posto a ogni altro motore attivo e vuoto
   if(InpQueueOn)
     {
      if(s.engine != ENG_SCALP && InpEnableScalping && g_cntEng[ENG_SCALP] == 0)
         slots--;
      if(s.engine != ENG_INTRA && InpEnableIntraday && g_cntEng[ENG_INTRA] == 0)
         slots--;
      if(s.engine != ENG_SWING && InpEnableSwing && g_cntEng[ENG_SWING] == 0)
         slots--;
     }
   if(InpAllowTranches && s.strong && s.engine != ENG_SCALP && !g_netting && !s.recovery && !s.aplus)
     {
      if(slots >= 3 && FloorLot(lots * 0.3) >= g_minLot)
        {
         nTr = 3;
         w[0] = 0.4;
         w[1] = 0.3;
         w[2] = 0.3;
        }
      else
         if(slots >= 2 && FloorLot(lots * 0.4) >= g_minLot)
           {
            nTr = 2;
            w[0] = 0.6;
            w[1] = 0.4;
           }
     }
   double risk = RiskPx(s);
   int opened = 0;
   double total = 0.0;
   for(int k = 0; k < nTr; k++)
     {
      double lk = (nTr == 1) ? lots : FloorLot(lots * w[k]);
      if(lk < g_minLot)
         continue;
      long id = 0;
      if(k == 0)
        {
         if(!SendMarket(s, lk, id))
            break;
         double fill = g_trade.ResultPrice();
         if(fill <= 0.0)
            fill = s.entry;
         MetaRecord(s, id, 0, lk, fill, false, 0);
        }
      else
        {
         double price = s.entry - s.dir * depth[k] * risk;
         if(!SendLimit(s, lk, price, id))
            continue;
         MetaRecord(s, id, k, lk, price, true, ExpiryFor(s.engine));
        }
      opened++;
      total += lk;
     }
   if(opened == 0)
      return false;
   g_tradesToday[s.engine]++;
   if(s.recovery)
      g_recoveryArmed = false;
   if(s.reentry)
      g_reArmed[s.engine] = false;
   string extra = "";
   if(s.recovery)
      extra += " | RECUPERO x" + DoubleToString(InpRecoveryMult, 2);
   if(s.reentry)
      extra += " | RIENTRO dopo pareggio x" + DoubleToString(InpReentryMult, 2);
   if(s.aplus)
      extra += " | A+ tutte le conferme";
   if(s.cushion > 0.0)
      extra += " | extra dai profitti " + Money(s.cushion);
   if(opened > 1)
      extra += " | " + IntegerToString(opened) + " ingressi scaglionati";
   double base = BaseCapital();
   string msg = "APERTO [" + g_engName[s.engine] + "] " + g_stratName[s.strat] + " " + DirName(s.dir) + " " +
                DoubleToString(total, g_lotDigits) + " lotti @ " + DoubleToString(s.entry, g_digits) +
                " SL " + DoubleToString(s.sl, g_digits) + " TP " + DoubleToString(s.tp, g_digits) +
                " | rischio " + Money(riskMoney) + " (" + Pct(100.0 * riskMoney / MathMax(base, 0.01)) + ")" +
                " | score " + DoubleToString(s.score, 2) + extra;
   Notify(msg);
   RememberDecision(msg);
   return true;
  }
//+------------------------------------------------------------------+
//| Gestione: pareggio a +1.5R con parziale, trailing, uscite a      |
//| tempo, news, venerdi', ordini scaglionati, chiusure e statistica |
//+------------------------------------------------------------------+
double BeOffsetPx() { return CommissionPx() + g_tick; }

bool ModifySL(ulong tk, double sl, double tp)
  {
   sl = NormPrice(sl);
   if(!g_trade.PositionModify(tk, sl, tp))
      return false;
   return RetOk(g_trade.ResultRetcode());
  }

bool CloseTicket(ulong tk, string why)
  {
   bool ok = g_trade.PositionClose(tk);
   if(ok && RetOk(g_trade.ResultRetcode()))
     {
      Logf("Chiusura: " + why);
      g_needSweep = true;
      return true;
     }
   return false;
  }

double TrailLevel(int eng, int dir)
  {
   if(eng == ENG_SCALP)
     {
      double ext = (dir > 0) ? HighestH(g_m1, 0, 10) : LowestL(g_m1, 0, 10);
      return ext - dir * 2.0 * g_ctx.atrM1;
     }
   if(eng == ENG_INTRA)
     {
      double ext = (dir > 0) ? HighestH(g_m15, 0, 8) : LowestL(g_m15, 0, 8);
      return ext - dir * 2.0 * g_ctx.atrM15;
     }
   double ext = (dir > 0) ? HighestH(g_h4, 0, 6) : LowestL(g_h4, 0, 6);
   return ext - dir * 2.5 * g_ctx.atrH4;
  }

//--- uscite obbligate (tempo, fine giornata, venerdi', news)
bool ForcedExit(int mi, string &why)
  {
   int eng = g_meta[mi].engine;
   bool be = g_meta[mi].beDone;
   int ageMin = (int)((TimeCurrent() - g_meta[mi].openTime) / 60);
   double h = HourOf(ToUTC(TimeCurrent()));
   int dow = DowOf(ToUTC(TimeCurrent()));
   if(eng == ENG_SCALP)
     {
      if(ageMin >= InpScalpMaxMinutes && !be)
        {
         why = "scalp: tempo scaduto senza pareggio";
         return true;
        }
      if(ageMin >= 3 * InpScalpMaxMinutes)
        {
         why = "scalp: tempo massimo";
         return true;
        }
     }
   if(eng == ENG_INTRA && ageMin >= InpIntraMaxHours * 60 && !be)
     {
      why = "intraday: tempo scaduto senza pareggio";
      return true;
     }
   if(eng != ENG_SWING && h >= InpIntraCloseUTC)
     {
      why = "fine sessione intraday";
      return true;
     }
   if(eng == ENG_SWING)
     {
      int bars = ageMin / 240;
      if(bars >= InpSwingMaxBarsH4 && !be)
        {
         why = "swing: " + IntegerToString(bars) + " barre H4 senza pareggio";
         return true;
        }
      if(bars >= 2 * InpSwingMaxBarsH4)
        {
         why = "swing: tempo massimo";
         return true;
        }
      if(dow == 5 && h >= 20.0 && !be && !InpSwingHoldWeekend)
        {
         why = "swing non a pareggio prima del weekend";
         return true;
        }
     }
   if(dow == 5 && h >= 20.0 && eng != ENG_SWING)
     {
      why = "venerdi' sera";
      return true;
     }
   if(InpCloseBeforeNews)
     {
      int m = MinutesToNextTier1(ToUTC(TimeCurrent()));
      if(m >= 0 && m <= 5 && (eng == ENG_SCALP || (eng == ENG_INTRA && !be)))
        {
         why = "news tier1 tra " + IntegerToString(m) + " minuti";
         return true;
        }
     }
   return false;
  }

//--- posizione dell'EA senza metadati (riavvio, file perso): la adotto
int MetaAdopt(ulong tk)
  {
   int k = MetaFree();
   if(k < 0)
      return -1;
   long mg = PositionGetInteger(POSITION_MAGIC);
   int dir = (PositionGetInteger(POSITION_TYPE) == POSITION_TYPE_BUY) ? 1 : -1;
   double op = PositionGetDouble(POSITION_PRICE_OPEN);
   double sl = PositionGetDouble(POSITION_SL);
   double vol = PositionGetDouble(POSITION_VOLUME);
   string cmt = PositionGetString(POSITION_COMMENT);
   g_meta[k].Reset();
   g_meta[k].active = true;
   g_meta[k].id = PositionGetInteger(POSITION_IDENTIFIER);
   g_meta[k].engine = IMax(0, IMin(2, EngineOfMagic(mg)));
   g_meta[k].dir = dir;
   g_meta[k].entry = op;
   g_meta[k].sl0 = sl;
   g_meta[k].tp = PositionGetDouble(POSITION_TP);
   g_meta[k].lots0 = vol;
   g_meta[k].openTime = (datetime)PositionGetInteger(POSITION_TIME);
   if(StringFind(cmt, "XC ") == 0)
     {
      string nm = StringSubstr(cmt, 3);
      int sp = StringFind(nm, " ");
      if(sp > 0)
         nm = StringSubstr(nm, 0, sp);
      g_meta[k].strat = StratByName(nm);
     }
   double r = (sl > 0.0) ? (op - sl) * dir : 0.0;
   if(r <= 0.0)
     {
      g_meta[k].beDone = (sl > 0.0);
      r = MathMax(AtrOf(g_m15), 10.0 * g_tick);
     }
   g_meta[k].riskPx = r;
   g_meta[k].riskMoney = vol * (r * ValuePerPriceUnit() + MathMax(InpCommissionPerLot, 0.0));
   return k;
  }

void ManageOne(ulong tk, int mi)
  {
   int dir = g_meta[mi].dir;
   double open = PositionGetDouble(POSITION_PRICE_OPEN);
   double sl = PositionGetDouble(POSITION_SL);
   double tp = PositionGetDouble(POSITION_TP);
   double vol = PositionGetDouble(POSITION_VOLUME);
   double px = (dir > 0) ? PxBid() : PxAsk();
   double r = g_meta[mi].riskPx;
   if(r <= 0.0)
      return;
   string why = "";
   if(ForcedExit(mi, why))
     {
      CloseTicket(tk, why);
      return;
     }
   double pr = (px - open) * dir / r;
   double md = StopsMinDist();
   //--- A+ (1.18): gestione attiva a terzi, il primo terzo si chiude a +InpAplusPartialR
   if(g_meta[mi].aplus && !g_meta[mi].thirdDone && !g_meta[mi].beDone && InpAplusPartialR > 0.0 &&
      InpAplusPartialR < InpBE_R && pr >= InpAplusPartialR)
     {
      g_meta[mi].thirdDone = true;
      double third = MathMax(FloorLot(g_meta[mi].lots0 / 3.0), g_minLot);
      if(vol >= g_meta[mi].lots0 - g_minLot * 0.5 && vol - third >= g_minLot - 0.0000001)
         if(g_trade.PositionClosePartial(tk, third))
           {
            vol -= third;
            Logf(g_stratName[g_meta[mi].strat] + ": A+ primo terzo chiuso a +" + DoubleToString(pr, 2) + "R (" +
                 DoubleToString(third, g_lotDigits) + " lotti)");
           }
     }
   //--- regola fissa: a +1.5R lo stop va al prezzo di entrata (+ commissione)
   if(!g_meta[mi].beDone && pr >= InpBE_R)
     {
      double be = open + dir * (BeOffsetPx() + MathMax(InpBeLockR, 0.0) * r);   // 1.17: cuscinetto oltre l'entrata
      bool better = (sl <= 0.0) || ((be - sl) * dir > g_tick * 0.5);
      bool roomOk = ((px - be) * dir >= md);
      if(!better)
         g_meta[mi].beDone = true;
      else
         if(roomOk && ModifySL(tk, be, tp))
           {
            g_meta[mi].beDone = true;
            sl = be;
            Logf(g_stratName[g_meta[mi].strat] + ": stop a pareggio a +" + DoubleToString(pr, 2) + "R");
           }
      double ppct = g_meta[mi].aplus ? 50.0 : InpPartialPct;   // A+: al pareggio meta' di quello che resta
      if(g_meta[mi].beDone && !g_meta[mi].partialDone && ppct > 0.0)
        {
         g_meta[mi].partialDone = true;
         double pv = FloorLot(vol * ppct / 100.0);
         if(pv >= g_minLot && vol - pv >= g_minLot - 0.0000001)
            if(g_trade.PositionClosePartial(tk, pv))
               Logf(g_stratName[g_meta[mi].strat] + ": chiusura parziale " + DoubleToString(pv, g_lotDigits) + " lotti");
        }
     }
   //--- trailing da +2R
   if(g_meta[mi].beDone && pr >= InpTrailStartR)
     {
      double ns = NormPrice(TrailLevel(g_meta[mi].engine, dir));
      if(ns > 0.0 && (ns - sl) * dir > g_tick && (px - ns) * dir >= md && (ns - open) * dir > 0.0)
         ModifySL(tk, ns, tp);
     }
  }

void ManagePending()
  {
   for(int i = OrdersTotal() - 1; i >= 0; i--)
     {
      ulong ot = OrderGetTicket(i);
      if(ot == 0)
         continue;
      if(OrderGetString(ORDER_SYMBOL) != g_sym || !IsOurMagic(OrderGetInteger(ORDER_MAGIC)))
         continue;
      int mi = MetaFind((long)ot);
      bool kill = false;
      if(mi < 0)
         kill = true;
      else
        {
         int age = (int)((TimeCurrent() - g_meta[mi].openTime) / 60);
         if(age >= g_meta[mi].expiryMin)
            kill = true;
         //--- se il primo ingresso dell'idea e' gia' chiuso, gli scaglioni non servono piu'
         bool mainAlive = false;
         for(int j = 0; j < MAX_META; j++)
            if(g_meta[j].active && g_meta[j].idea == g_meta[mi].idea && g_meta[j].tranche == 0)
               mainAlive = true;
         if(!mainAlive)
            kill = true;
         double px = (g_meta[mi].dir > 0) ? PxBid() : PxAsk();
         if((px - g_meta[mi].tp) * g_meta[mi].dir >= 0.0)
            kill = true;
         int m = MinutesToNextTier1(ToUTC(TimeCurrent()));
         if(m >= 0 && m <= 15)
            kill = true;
        }
      if(kill && g_trade.OrderDelete(ot))
        {
         if(mi >= 0)
            MetaRemove(mi);
        }
     }
  }

void ManagePositions()
  {
   for(int i = PositionsTotal() - 1; i >= 0; i--)
     {
      ulong tk = PositionGetTicket(i);
      if(tk == 0)
         continue;
      if(PositionGetString(POSITION_SYMBOL) != g_sym)
         continue;
      if(!IsOurMagic(PositionGetInteger(POSITION_MAGIC)))
         continue;
      long id = PositionGetInteger(POSITION_IDENTIFIER);
      int mi = MetaFind(id);
      if(mi < 0)
         mi = MetaAdopt(tk);
      if(mi < 0)
         continue;
      if(g_meta[mi].isPending)
        {
         //--- scaglione eseguito: ricalcolo rischio reale
         g_meta[mi].isPending = false;
         g_meta[mi].openTime = (datetime)PositionGetInteger(POSITION_TIME);
         double op = PositionGetDouble(POSITION_PRICE_OPEN);
         g_meta[mi].entry = op;
         g_meta[mi].riskPx = (op - g_meta[mi].sl0) * g_meta[mi].dir;
         g_meta[mi].riskMoney = PositionGetDouble(POSITION_VOLUME) * LossPerLot(g_meta[mi].dir, op, g_meta[mi].sl0);
        }
      if(!PositionSelectByTicket(tk))
         continue;
      ManageOne(tk, mi);
     }
   ManagePending();
  }

//+------------------------------------------------------------------+
//| Chiusure: risultato in R dallo storico, statistiche, giornale    |
//+------------------------------------------------------------------+
void BenchCheck(int k)
  {
   if(!InpUseBench || InpOnlyStrategy != PICK_ALL || k <= 0)
      return;
   if(g_ss[k].n >= 25 && g_ss[k].Expectancy() < -0.2 && g_ss[k].RecentSum(10) < 0.0)
     {
      g_ss[k].Reset();
      g_ss[k].benchUntil = TimeCurrent() + 7 * 86400;
      Notify("Strategia " + g_stratName[k] + " in panchina per 7 giorni (aspettativa negativa)");
     }
  }

void JournalWrite(int mi, double R, double net)
  {
   if(g_isOptim)
      return;
   string fn = g_isTester ? "XauCommittee_tester_trades.csv" : "XauCommittee_" + IntegerToString(g_login) + "_trades.csv";
   int h = FileOpen(fn, FILE_READ | FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON | FILE_SHARE_READ);
   if(h == INVALID_HANDLE)
      return;
   if(FileSize(h) == 0)
      FileWriteString(h, "chiusura;motore;strategia;direzione;lotti;entrata;stop;target;R;netto;score;recupero;extra_profitti\r\n");
   FileSeek(h, 0, SEEK_END);
   string line = TimeToString(TimeCurrent(), TIME_DATE | TIME_MINUTES) + ";" + g_engName[g_meta[mi].engine] + ";" +
                 g_stratName[g_meta[mi].strat] + ";" + DirName(g_meta[mi].dir) + ";" + DoubleToString(g_meta[mi].lots0, g_lotDigits) + ";" +
                 DoubleToString(g_meta[mi].entry, g_digits) + ";" + DoubleToString(g_meta[mi].sl0, g_digits) + ";" +
                 DoubleToString(g_meta[mi].tp, g_digits) + ";" + DoubleToString(R, 2) + ";" + DoubleToString(net, 2) + ";" +
                 DoubleToString(g_meta[mi].score, 2) + ";" + (g_meta[mi].recovery ? "si" : "no") + ";" + DoubleToString(g_meta[mi].cushion, 2) + "\r\n";
   FileWriteString(h, line);
   FileClose(h);
  }

void StatsSave();

void FinalizeTrade(int mi, double net)
  {
   double R = (g_meta[mi].riskMoney > 0.0) ? net / g_meta[mi].riskMoney : 0.0;
   int k = g_meta[mi].strat;
   int e = g_meta[mi].engine;
   if(k > 0)
     {
      g_ss[k].Add(R, net);
      g_rep[k].Add(R, net);
     }
   if(e >= 0 && e < 3)
      g_es[e].Add(R, net);
   g_all.Add(R, net);
   //--- rientro (1.17): idea tornata a pareggio dopo aver toccato +BE_R -> si puo' rientrare una volta
   if(e >= 0 && e < 3)
     {
      if(R < -0.3)
         g_reArmed[e] = false;
      else
         if(InpReentryOn && g_meta[mi].beDone && g_meta[mi].tranche == 0 && !g_meta[mi].reentry && !g_meta[mi].recovery && R < 1.0)
           {
            g_reArmed[e] = true;
            g_reDir[e] = g_meta[mi].dir;
            g_reT[e] = TimeCurrent();
           }
     }
   if(R < -0.3)
     {
      g_lossStreak++;
      g_lossesInRowToday++;
      if(g_meta[mi].recovery)
        {
         g_recoveryArmed = false;
         g_recoveryCooldownUntil = TimeCurrent() + 24 * 3600;
        }
      else
         if(InpRecoveryEnabled && TimeCurrent() >= g_recoveryCooldownUntil)
           {
            g_recoveryArmed = true;
            g_recoveryArmedT = TimeCurrent();
           }
     }
   else
      if(R > 0.3)
        {
         g_lossStreak = 0;
         g_lossesInRowToday = 0;
         g_recoveryArmed = false;
        }
   BenchCheck(k);
   JournalWrite(mi, R, net);
   string msg = "CHIUSO [" + g_engName[e] + "] " + g_stratName[k] + " " + DirName(g_meta[mi].dir) + ": " +
                (net >= 0.0 ? "+" : "") + Money(net) + " (" + (R >= 0.0 ? "+" : "") + DoubleToString(R, 2) + "R)";
   Notify(msg);
   RememberDecision(msg);
   MetaRemove(mi);
   StatsSave();
  }

//--- somma netta di tutti i deal di una posizione (entrata + uscite + commissioni + swap)
bool PositionNetFromHistory(long id, double &net, int &deals)
  {
   net = 0.0;
   deals = 0;
   if(!HistorySelectByPosition(id))
      return false;
   int n = HistoryDealsTotal();
   for(int i = 0; i < n; i++)
     {
      ulong d = HistoryDealGetTicket(i);
      if(d == 0)
         continue;
      net += HistoryDealGetDouble(d, DEAL_PROFIT) + HistoryDealGetDouble(d, DEAL_COMMISSION) +
             HistoryDealGetDouble(d, DEAL_SWAP) + HistoryDealGetDouble(d, DEAL_FEE);
      deals++;
     }
   return true;
  }

//--- metadati senza piu' posizione/ordine -> trade chiuso (o ordine scaduto)
void MetaSweep()
  {
   g_needSweep = false;
   for(int i = 0; i < MAX_META; i++)
     {
      if(!g_meta[i].active)
         continue;
      long id = g_meta[i].id;
      if(g_meta[i].isPending)
        {
         if(OrderExists(id) || PositionExistsById(id))
            continue;
        }
      else
         if(PositionExistsById(id))
            continue;
      double net = 0.0;
      int deals = 0;
      PositionNetFromHistory(id, net, deals);
      if(deals >= 2)
         FinalizeTrade(i, net);
      else
        {
         //--- lo storico puo' arrivare con un attimo di ritardo: riprovo prima di arrendermi
         g_meta[i].sweepTries++;
         if(!g_meta[i].isPending && g_meta[i].sweepTries < 20)
            continue;
         MetaRemove(i);
        }
     }
  }

//+------------------------------------------------------------------+
//| Salvataggio su file (solo live): metadati e statistiche          |
//+------------------------------------------------------------------+
string MetaFile() { return "XauCommittee_" + IntegerToString(g_login) + "_" + IntegerToString(InpMagicBase) + "_meta.txt"; }
string StatsFile() { return "XauCommittee_" + IntegerToString(g_login) + "_" + IntegerToString(InpMagicBase) + "_stats.txt"; }

void MetaSave()
  {
   if(g_isTester)
      return;
   int h = FileOpen(MetaFile(), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   for(int i = 0; i < MAX_META; i++)
     {
      if(!g_meta[i].active)
         continue;
      string l = IntegerToString(g_meta[i].id) + ";" + IntegerToString(g_meta[i].strat) + ";" + IntegerToString(g_meta[i].engine) + ";" +
                 IntegerToString(g_meta[i].dir) + ";" + IntegerToString(g_meta[i].tranche) + ";" + IntegerToString(g_meta[i].idea) + ";" +
                 DoubleToString(g_meta[i].entry, 5) + ";" + DoubleToString(g_meta[i].sl0, 5) + ";" + DoubleToString(g_meta[i].tp, 5) + ";" +
                 DoubleToString(g_meta[i].riskPx, 5) + ";" + DoubleToString(g_meta[i].riskMoney, 2) + ";" + DoubleToString(g_meta[i].lots0, 2) + ";" +
                 DoubleToString(g_meta[i].score, 3) + ";" + IntegerToString(g_meta[i].recovery ? 1 : 0) + ";" +
                 IntegerToString(g_meta[i].beDone ? 1 : 0) + ";" + IntegerToString(g_meta[i].partialDone ? 1 : 0) + ";" +
                 IntegerToString(g_meta[i].isPending ? 1 : 0) + ";" + IntegerToString((long)g_meta[i].openTime) + ";" +
                 IntegerToString(g_meta[i].expiryMin) + ";" + IntegerToString(g_meta[i].reentry ? 1 : 0) + ";" +
                 IntegerToString(g_meta[i].aplus ? 1 : 0) + "\r\n";
      FileWriteString(h, l);
     }
   FileClose(h);
  }

void MetaLoad()
  {
   if(g_isTester || !FileIsExist(MetaFile(), FILE_COMMON))
      return;
   int h = FileOpen(MetaFile(), FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      int np = StringSplit(l, ';', p);
      if(np < 19)
         continue;
      int k = MetaFree();
      if(k < 0)
         break;
      g_meta[k].Reset();
      g_meta[k].active = true;
      g_meta[k].id = StringToInteger(p[0]);
      g_meta[k].strat = (int)StringToInteger(p[1]);
      g_meta[k].engine = (int)StringToInteger(p[2]);
      g_meta[k].dir = (int)StringToInteger(p[3]);
      g_meta[k].tranche = (int)StringToInteger(p[4]);
      g_meta[k].idea = (int)StringToInteger(p[5]);
      g_meta[k].entry = StringToDouble(p[6]);
      g_meta[k].sl0 = StringToDouble(p[7]);
      g_meta[k].tp = StringToDouble(p[8]);
      g_meta[k].riskPx = StringToDouble(p[9]);
      g_meta[k].riskMoney = StringToDouble(p[10]);
      g_meta[k].lots0 = StringToDouble(p[11]);
      g_meta[k].score = StringToDouble(p[12]);
      g_meta[k].recovery = (StringToInteger(p[13]) != 0);
      g_meta[k].beDone = (StringToInteger(p[14]) != 0);
      g_meta[k].partialDone = (StringToInteger(p[15]) != 0);
      g_meta[k].isPending = (StringToInteger(p[16]) != 0);
      g_meta[k].openTime = (datetime)StringToInteger(p[17]);
      g_meta[k].expiryMin = (int)StringToInteger(p[18]);
      g_meta[k].reentry = (np >= 20 && StringToInteger(p[19]) != 0);
      g_meta[k].aplus = (np >= 21 && StringToInteger(p[20]) != 0);
      if(g_meta[k].strat < 0 || g_meta[k].strat >= NSTRAT || g_meta[k].engine < 0 || g_meta[k].engine > 2)
         g_meta[k].Reset();
      else
         if(g_meta[k].idea > g_ideaSeq)
            g_ideaSeq = g_meta[k].idea;
     }
   FileClose(h);
  }

void StatsSave()
  {
   if(g_isTester)
      return;
   int h = FileOpen(StatsFile(), FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   for(int k = 1; k < NSTRAT; k++)
     {
      string l = IntegerToString(k) + ";" + IntegerToString(g_ss[k].n) + ";" + IntegerToString(g_ss[k].wins) + ";" +
                 IntegerToString(g_ss[k].losses) + ";" + DoubleToString(g_ss[k].sumR, 4) + ";" + DoubleToString(g_ss[k].sumR2, 4) + ";" +
                 DoubleToString(g_ss[k].grossWinR, 4) + ";" + DoubleToString(g_ss[k].grossLossR, 4) + ";" +
                 DoubleToString(g_ss[k].net, 2) + ";" + IntegerToString((long)g_ss[k].benchUntil);
      for(int j = 0; j < 10; j++)
         l += ";" + DoubleToString(g_ss[k].last[j], 3);
      l += ";" + IntegerToString(g_ss[k].lastN) + ";" + IntegerToString(g_ss[k].lastHead) + "\r\n";
      FileWriteString(h, l);
     }
   FileClose(h);
   MetaSave();
  }

void StatsLoad()
  {
   for(int k = 0; k < NSTRAT; k++)
     {
      g_ss[k].Reset();
      g_rep[k].Reset();
     }
   for(int e = 0; e < 3; e++)
      g_es[e].Reset();
   g_all.Reset();
   if(g_isTester || !FileIsExist(StatsFile(), FILE_COMMON))
      return;
   int h = FileOpen(StatsFile(), FILE_READ | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   while(!FileIsEnding(h))
     {
      string l = FileReadString(h);
      string p[];
      if(StringSplit(l, ';', p) < 22)
         continue;
      int k = (int)StringToInteger(p[0]);
      if(k <= 0 || k >= NSTRAT)
         continue;
      g_ss[k].n = (int)StringToInteger(p[1]);
      g_ss[k].wins = (int)StringToInteger(p[2]);
      g_ss[k].losses = (int)StringToInteger(p[3]);
      g_ss[k].sumR = StringToDouble(p[4]);
      g_ss[k].sumR2 = StringToDouble(p[5]);
      g_ss[k].grossWinR = StringToDouble(p[6]);
      g_ss[k].grossLossR = StringToDouble(p[7]);
      g_ss[k].net = StringToDouble(p[8]);
      g_ss[k].benchUntil = (datetime)StringToInteger(p[9]);
      for(int j = 0; j < 10; j++)
         g_ss[k].last[j] = StringToDouble(p[10 + j]);
      g_ss[k].lastN = IMin(10, IMax(0, (int)StringToInteger(p[20])));
      g_ss[k].lastHead = IMin(9, IMax(0, (int)StringToInteger(p[21])));
     }
   FileClose(h);
  }
//+------------------------------------------------------------------+
//| Motori, pannello, eventi MT5                                     |
//+------------------------------------------------------------------+
void CtxUpdate()
  {
   g_ctx.bid = PxBid();
   g_ctx.ask = PxAsk();
   g_ctx.spread = MathMax(g_ctx.ask - g_ctx.bid, 0.0);
   g_ctx.atrM1 = AtrOf(g_m1);
   g_ctx.atrM5 = AtrOf(g_m5);
   g_ctx.atrM15 = AtrOf(g_m15);
   g_ctx.atrH1 = AtrOf(g_h1);
   g_ctx.atrH4 = AtrOf(g_h4);
   g_ctx.atrD1 = AtrOf(g_d1);
   g_ctx.vwap = VwapVal(g_vwD);
   g_ctx.vwSig = VwapSigma(g_vwD);
   g_ctx.wvwap = VwapVal(g_vwW);
   g_ctx.nowSrv = TimeCurrent();
   g_ctx.nowUtc = ToUTC(g_ctx.nowSrv);
   g_ctx.hUtc = HourOf(g_ctx.nowUtc);
   g_ctx.lonOpen = LondonOpenUTC(g_ctx.nowUtc);
   g_ctx.nyData = NYDataUTC(g_ctx.nowUtc);
   g_ctx.nyOpen = NYOpenUTC(g_ctx.nowUtc);
   g_ctx.nyClose = NYCloseUTC(g_ctx.nowUtc);
   g_ctx.dow = DowOf(g_ctx.nowUtc);
  }

//--- finestre operative dei motori (UTC, con ora legale)
bool InRollover()
  {
   double h = g_ctx.hUtc, c = g_ctx.nyClose;
   double d = h - c;
   if(d < -12.0)
      d += 24.0;
   return (d >= -0.25 && d <= 1.25);
  }

bool EngineWindow(int e)
  {
   double h = g_ctx.hUtc;
   int dow = g_ctx.dow;
   if(dow == 0 || dow == 6 || InRollover())
      return false;
   if(dow == 5 && h >= 18.0)
      return false;
   if(e == ENG_SCALP)
     {
      bool lon = (h >= g_ctx.lonOpen && h < g_ctx.lonOpen + 3.0);
      bool ny = (h >= g_ctx.nyData - 0.25 && h < g_ctx.nyOpen + 2.5);
      return ((lon || ny) && h < InpIntraCloseUTC - 0.5);
     }
   if(e == ENG_INTRA)
      return (h >= g_ctx.lonOpen && h < InpIntraCloseUTC - 1.0);
   if(dow == 1 && h < 2.0)
      return false;
   return true;
  }

bool EngineEnabled(int e)
  {
   if(e == ENG_SCALP)
      return InpEnableScalping;
   if(e == ENG_INTRA)
      return InpEnableIntraday;
   return InpEnableSwing;
  }

string DecisionLine(const TSignal &s)
  {
   string verdict = s.passed ? "APPROVATO" : "RESPINTO";
   string t = "[" + g_engName[s.engine] + "] " + g_stratName[s.strat] + " " + DirName(s.dir) +
              " score " + DoubleToString(s.score, 2) + " quorum " + IntegerToString(s.quorum) + "/8 diavolo " +
              IntegerToString(s.devil) + " -> " + verdict;
   if(s.veto)
      t += " (" + s.vetoWhy + ")";
   return t;
  }

//--- valuta i segnali di un motore e esegue il migliore approvato
void RunEngine(int e, TSignal &cands[], int n)
  {
   int best = -1;
   for(int i = 0; i < n; i++)
     {
      SignalAdjust(cands[i]);
      Committee(cands[i]);
      string line = DecisionLine(cands[i]);
      if(cands[i].passed)
        {
         if(best < 0 || cands[i].score > cands[best].score)
            best = i;
        }
      if(InpVerboseLog)
         Logf(line + " | " + DeskLine(cands[i]) + " | " + cands[i].why);
      if(!cands[i].passed)
         RememberDecision(line);
     }
   if(best < 0)
      return;
   Logf(DecisionLine(cands[best]) + " | " + cands[best].why + " | " + DeskLine(cands[best]));
   Execute(cands[best]);
  }

void AddCand(TSignal &cands[], int &n, const TSignal &s)
  {
   ArrayResize(cands, n + 1);
   SigCopy(cands[n], s);
   n++;
  }

void EvalScalping()
  {
   if(!EngineEnabled(ENG_SCALP) || !EngineWindow(ENG_SCALP))
      return;
   TSignal cands[];
   int n = 0;
   TSignal s;
   if(StratEnabled(ST_SC_VWAP) && S_ScVwap(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_SC_SWEEP) && S_ScSweep(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_SC_ORB) && S_ScOrb(s))
      AddCand(cands, n, s);
   if(n > 0)
      RunEngine(ENG_SCALP, cands, n);
  }

void EvalIntraday(bool newM15)
  {
   if(!EngineEnabled(ENG_INTRA) || !EngineWindow(ENG_INTRA))
     {
      g_vaNewM15 = false;
      return;
     }
   TSignal cands[];
   int n = 0;
   TSignal s;
   if(StratEnabled(ST_IN_PULLBACK) && S_InPullback(s))
      AddCand(cands, n, s);
   if(newM15 && StratEnabled(ST_IN_SWEEP) && S_InSweep(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_BREAKOUT) && S_InBreakout(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_VALUE) && S_InValue(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_NEWS) && S_InNews(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_IN_RANGE) && S_InRange(s))
      AddCand(cands, n, s);
   g_vaNewM15 = false;
   if(n > 0)
      RunEngine(ENG_INTRA, cands, n);
  }

void EvalSwing()
  {
   if(!EngineEnabled(ENG_SWING) || !EngineWindow(ENG_SWING))
      return;
   TSignal cands[];
   int n = 0;
   TSignal s;
   if(StratEnabled(ST_SW_TREND) && S_SwTrend(s))
      AddCand(cands, n, s);
   if(StratEnabled(ST_SW_WYCKOFF) && S_SwWyckoff(s))
      AddCand(cands, n, s);
   if(n > 0)
      RunEngine(ENG_SWING, cands, n);
  }

//+------------------------------------------------------------------+
//| Pannello sul grafico                                             |
//+------------------------------------------------------------------+
string EngineStatus(int e)
  {
   if(!EngineEnabled(e))
      return g_engName[e] + ": spento";
   double slPx = (e == ENG_SCALP) ? g_ctx.atrM5 : ((e == ENG_INTRA) ? g_ctx.atrM15 : g_ctx.atrH4);
   double base = BaseCapital();
   if(slPx > 0.0 && base > 0.0)
     {
      double lpl = LossPerLot(1, g_ctx.ask, g_ctx.ask - slPx);
      double minRisk = lpl * g_minLot;
      double pct = 100.0 * minRisk / base;
      if(pct > InpMinLotMaxRiskPct)
         return g_engName[e] + ": in attesa (serve conto ~" + DoubleToString(minRisk * 100.0 / InpMinLotMaxRiskPct, 0) + " " + g_currency + ")";
     }
   return g_engName[e] + (EngineWindow(e) ? ": attivo" : ": fuori orario");
  }

string SessionName()
  {
   double h = g_ctx.hUtc;
   if(InRollover())
      return "rollover";
   if(h < g_ctx.lonOpen)
      return "Asia";
   if(h < g_ctx.nyData)
      return "Londra";
   if(h < g_ctx.nyClose - 4.0)
      return "Londra+New York";
   return "New York";
  }

void Panel()
  {
   if(g_isOptim)
      return;
   double eq = AccEquity();
   double dayPct = (g_dayStartEq > 0.0) ? 100.0 * (eq / g_dayStartEq - 1.0) : 0.0;
   double weekPct = (g_weekStartEq > 0.0) ? 100.0 * (eq / g_weekStartEq - 1.0) : 0.0;
   double dd = (g_peakEq > 0.0) ? 100.0 * (1.0 - eq / g_peakEq) : 0.0;
   string why = "";
   string st = TradingHalted(why) ? "FERMO - " + why : "operativo";
   string macro = MacroText();
   if(AiFresh())
      macro += " | comitato AI: " + g_aiStance + " " + DoubleToString(g_aiConv, 2);
   int k = NextTier1Index(g_ctx.nowUtc);
   string nx = "nessuna nelle prossime 36 ore";
   if(k >= 0)
      nx = g_news[k].title + " alle " + TimeToString(g_news[k].utc, TIME_MINUTES) + " UTC (tra " + IntegerToString(MinutesToNextTier1(g_ctx.nowUtc)) + " min)";
   PortfolioScan();
   string txt = "XAU COMMITTEE EA " + g_version + "  [" + g_sym + "]" + (g_netting ? "  ATTENZIONE: conto netting (1 posizione)" : "") + "\n";
   txt += "Stato: " + st + "\n";
   if(InpVirtualCapital > 0.0)
      txt += "Capitale virtuale " + Money(InpVirtualCapital) + " (conto vero " + Money(AccountInfoDouble(ACCOUNT_EQUITY)) + "): lotti e limiti calcolati sul virtuale\n";
   txt += "Equity " + Money(eq) + " | oggi " + DoubleToString(dayPct, 2) + "% | settimana " + DoubleToString(weekPct, 2) + "% | drawdown " + DoubleToString(dd, 1) + "%\n";
   txt += "Regime H1: " + g_regName[g_regime] + " | sessione: " + SessionName() + " | spread " + DoubleToString(g_ctx.spread, g_digits) + "\n";
   txt += "Macro: " + macro + "\n";
   txt += "Contesto: " + g_ctxText + "\n";
   txt += "Favoriti adesso: " + FavoredText() + "\n";
   txt += "Prossima news forte: " + nx + "\n";
   txt += EngineStatus(ENG_SCALP) + " | " + EngineStatus(ENG_INTRA) + " | " + EngineStatus(ENG_SWING) + "\n";
   txt += "Posizioni " + IntegerToString(g_cntAll) + "/" + IntegerToString(MaxPositionsEff()) + " | rischio aperto " + Money(g_openRiskMoney) +
          " | serie perdite " + IntegerToString(g_lossStreak) + (g_recoveryArmed ? " | recupero pronto" : "") +
          ((g_reArmed[0] || g_reArmed[1] || g_reArmed[2]) ? " | rientro pronto" : "") + "\n";
   txt += "Ultime decisioni:\n";
   for(int i = 0; i < 6; i++)
     {
      int idx = (g_lastDecisionHead - 1 - i + 12) % 6;
      if(g_lastDecision[idx] != "")
         txt += "  " + StringSubstr(g_lastDecision[idx], 0, 150) + "\n";
     }
   Comment(txt);
  }

//+------------------------------------------------------------------+
//| Report statistico (tester e chiusura EA)                         |
//+------------------------------------------------------------------+
string StatRow(string name, const StratStat &st)
  {
   return name + ": trade " + IntegerToString(st.n) + " | win " + DoubleToString(st.WinRate(), 1) + "% | aspettativa " +
          DoubleToString(st.Expectancy(), 2) + "R | PF " + DoubleToString(st.ProfitFactor(), 2) + " | netto " + DoubleToString(st.net, 2);
  }

void PrintReport()
  {
   if(g_isOptim)
      return;
   Print("===== REPORT XAU COMMITTEE (per strategia) =====");
   for(int k = 1; k < NSTRAT; k++)
      if(g_rep[k].n > 0)
         Print(StatRow(g_stratName[k], g_rep[k]));
   for(int e = 0; e < 3; e++)
      if(g_es[e].n > 0)
         Print(StatRow("MOTORE " + g_engName[e], g_es[e]));
   Print(StatRow("TOTALE", g_all));
   if(!g_isTester)
      return;
   int h = FileOpen("XauCommittee_tester_report.csv", FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h == INVALID_HANDLE)
      return;
   FileWriteString(h, "strategia;trade;win%;aspettativa_R;profit_factor;netto\r\n");
   for(int k = 1; k < NSTRAT; k++)
      FileWriteString(h, g_stratName[k] + ";" + IntegerToString(g_rep[k].n) + ";" + DoubleToString(g_rep[k].WinRate(), 1) + ";" +
                      DoubleToString(g_rep[k].Expectancy(), 3) + ";" + DoubleToString(g_rep[k].ProfitFactor(), 2) + ";" + DoubleToString(g_rep[k].net, 2) + "\r\n");
   FileClose(h);
  }

//+------------------------------------------------------------------+
//| Eventi                                                           |
//+------------------------------------------------------------------+
//--- briefing giornaliero: il quadro che il comitato usa per tutto il giorno
datetime g_lastBriefing = 0;

void Briefing()
  {
   if(g_isOptim)
      return;
   datetime d = iTime(g_sym, PERIOD_D1, 0);
   if(d == g_lastBriefing)
      return;
   g_lastBriefing = d;
   double tot = Clamp(0.5 * g_ctxBias + 0.5 * g_mBias * Clamp(g_mConf * 1.4, 0.0, 1.0), -1.0, 1.0);
   string verso = (tot > 0.25) ? "preferenza LONG" : ((tot < -0.25) ? "preferenza SHORT" : "nessuna direzione netta: solo setup molto puliti");
   string msg = "BRIEFING ORO " + TimeToString(TimeCurrent(), TIME_DATE) + "\n" +
                "Contesto: " + g_ctxText + "\n" +
                "Macro: " + MacroText() + "\n" +
                "Quadro: " + verso + " (" + DoubleToString(tot, 2) + ") | favoriti: " + FavoredText() + "\n" +
                "Motori del prezzo: " + RunBrakeText();
   Logf(msg);
   if(InpPushNotify && !g_isTester)
      SendNotification(StringSubstr("Oro: " + verso + " | " + FavoredText(), 0, 250));
  }

void OnNewM1(datetime m1open)
  {
   MicroFinalize();
   g_tkDelta = 0.0;
   g_tkCount = 0.0;
   g_tkBarOpen = m1open;
   g_m1.lastOpen = m1open;
   TfRefresh(g_m1);
   bool n5 = TfNewBar(g_m5);
   bool n15 = TfNewBar(g_m15);
   bool nh1 = TfNewBar(g_h1);
   bool nh4 = TfNewBar(g_h4);
   bool nd1 = TfNewBar(g_d1);
   bool nw1 = TfNewBar(g_w1);
   if(n5)
      TfRefresh(g_m5);
   if(n15)
      TfRefresh(g_m15);
   if(nh1)
      TfRefresh(g_h1);
   if(nh4)
      TfRefresh(g_h4);
   if(nd1)
     {
      TfRefresh(g_d1);
      UpdateWeekly();
     }
   if(nw1)
      TfRefresh(g_w1);
   if(nh1)
     {
      UpdateGmtOffset();
      UpdateRegime();
     }
   if(nh4 || nd1)
     {
      UpdateContext();
      IntermarketUpdate();
     }
   if(nh1 || nh4 || nd1)
      MacroCombine();
   CtxUpdate();
   RunBrakeUpdate();
   if(g_isTester)
      TesterNewsRefresh(g_ctx.nowUtc);
   //--- barra M1 appena chiusa -> VWAP del giorno e sessioni
   datetime dAnchor = iTime(g_sym, PERIOD_D1, 0);
   int i1 = TfIdx(g_m1, 0);
   if(i1 >= 0)
     {
      VwapFeed(g_vwD, dAnchor, g_m1.r[i1].time, g_m1.r[i1].high, g_m1.r[i1].low, g_m1.r[i1].close, (double)g_m1.r[i1].tick_volume);
      SessFeed(g_m1.r[i1].time, g_m1.r[i1].high, g_m1.r[i1].low);
     }
   if(n5)
     {
      int i5 = TfIdx(g_m5, 0);
      if(i5 >= 0)
        {
         RvolAdd(g_m5.r[i5].time, (double)g_m5.r[i5].tick_volume);
         ProfileFeed(dAnchor, g_m5.r[i5].time, g_m5.r[i5].low, g_m5.r[i5].high, (double)g_m5.r[i5].tick_volume);
         VwapFeed(g_vwW, iTime(g_sym, PERIOD_W1, 0), g_m5.r[i5].time, g_m5.r[i5].high, g_m5.r[i5].low, g_m5.r[i5].close, (double)g_m5.r[i5].tick_volume);
        }
     }
   CtxUpdate();
   if(n5)
     {
      NewsTrack();
      BuildLevels();
     }
   if(n15)
     {
      BrkOnM15();
      ValueOnM15();
     }
   RiskPeriodCheck();
   MetaSweep();
   if(nd1)
      Briefing();
   if(!DataReady())
      return;
   string why = "";
   if(TradingHalted(why))
      return;
   EvalScalping();
   if(n5)
      EvalIntraday(n15);
   if(nh1)
      EvalSwing();
  }

int OnInit()
  {
   g_isTester = (MQLInfoInteger(MQL_TESTER) != 0);
   g_isOptim = (MQLInfoInteger(MQL_OPTIMIZATION) != 0);
   g_isVisual = (MQLInfoInteger(MQL_VISUAL_MODE) != 0);
   g_sym = (InpSymbolOverride != "") ? InpSymbolOverride : _Symbol;
   if(!SymbolSelect(g_sym, true))
     {
      Print("Simbolo non trovato: ", g_sym);
      return INIT_FAILED;
     }
   if(InpRiskPercent <= 0.0 || InpRiskPercent > 10.0 || InpMinRR < 1.0 || InpBE_R <= 0.0 || InpMaxPositions < 1 ||
      InpDailyLossPct <= 0.0 || InpWeeklyLossPct <= 0.0 || InpMaxDrawdownPct <= 0.0 || InpMaxDrawdownPct > 100.0)
     {
      Print("Parametri non validi: controlla rischio, R:R, pareggio e limiti");
      return INIT_PARAMETERS_INCORRECT;
     }
   g_point = SymbolInfoDouble(g_sym, SYMBOL_POINT);
   g_tick = SymbolInfoDouble(g_sym, SYMBOL_TRADE_TICK_SIZE);
   if(g_tick <= 0.0)
      g_tick = g_point;
   g_digits = (int)SymbolInfoInteger(g_sym, SYMBOL_DIGITS);
   g_minLot = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_MIN);
   g_maxLot = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_MAX);
   g_lotStep = SymbolInfoDouble(g_sym, SYMBOL_VOLUME_STEP);
   g_contract = SymbolInfoDouble(g_sym, SYMBOL_TRADE_CONTRACT_SIZE);
   g_lotDigits = (g_lotStep >= 1.0) ? 0 : ((g_lotStep >= 0.1) ? 1 : ((g_lotStep >= 0.01) ? 2 : 3));
   g_currency = AccountInfoString(ACCOUNT_CURRENCY);
   g_login = AccountInfoInteger(ACCOUNT_LOGIN);
   g_netting = (AccountInfoInteger(ACCOUNT_MARGIN_MODE) != ACCOUNT_MARGIN_MODE_RETAIL_HEDGING);
   string up = g_sym;
   StringToUpper(up);
   if(StringFind(up, "XAU") < 0 && StringFind(up, "GOLD") < 0)
      Print("ATTENZIONE: ", g_sym, " non sembra l'oro. L'EA e' pensato per XAUUSD.");
   g_trade.SetDeviationInPoints((ulong)MathMax(10.0, MathRound(0.30 / MathMax(g_point, 0.00001))));
   g_trade.SetTypeFillingBySymbol(g_sym);
   g_trade.LogLevel(LOG_LEVEL_ERRORS);
   UpdateGmtOffset();
   TfInit(g_m1, PERIOD_M1, 240);
   TfInit(g_m5, PERIOD_M5, 400);
   TfInit(g_m15, PERIOD_M15, 400);
   TfInit(g_h1, PERIOD_H1, 400);
   TfInit(g_h4, PERIOD_H4, 300);
   TfInit(g_d1, PERIOD_D1, 160);
   TfInit(g_w1, PERIOD_W1, 150);
   TfNewBar(g_m1);
   TfNewBar(g_m5);
   TfNewBar(g_m15);
   TfNewBar(g_h1);
   TfNewBar(g_h4);
   TfNewBar(g_d1);
   TfNewBar(g_w1);
   TfRefresh(g_m1);
   TfRefresh(g_m5);
   TfRefresh(g_m15);
   TfRefresh(g_h1);
   TfRefresh(g_h4);
   TfRefresh(g_d1);
   TfRefresh(g_w1);
   g_tkBarOpen = g_m1.lastOpen;
   MicroInit();
   RvolInit();
   VwapInit();
   ProfileInit();
   SessInit();
   UpdateWeekly();
   CtxUpdate();
   UpdateRegime();
   BuildLevels();
   IntermarketInit();
   MacroHistLoad();
   UpdateContext();
   IntermarketUpdate();
   StatsLoad();
   for(int i = 0; i < MAX_META; i++)
      g_meta[i].Reset();
   MetaLoad();
   RiskStateInit();
   CashFlowScan();
   g_lastRealBal = AccountInfoDouble(ACCOUNT_BALANCE);
   //--- nel tester il giornale dei trade riparte vuoto a ogni test
   if(g_isTester && !g_isOptim)
     {
      int fh = FileOpen("XauCommittee_tester_trades.csv", FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
      if(fh != INVALID_HANDLE)
         FileClose(fh);
     }
   g_newsN = 0;
   if(g_isTester)
      TesterNewsRefresh(g_ctx.nowUtc);
   else
     {
      CalendarRefresh();
      WebRefresh();
      MacroHistDownload(InpMacroHistUrl);
      EventSetTimer(5);
      if(InpUseDOM)
         g_domOn = MarketBookAdd(g_sym);
     }
   MacroCombine();
   g_ready = true;
   double base = BaseCapital();
   Logf("XAU Committee EA " + g_version + " avviato su " + g_sym + " | conto " + Money(base) + " | lotto minimo " +
        DoubleToString(g_minLot, g_lotDigits) + " | contratto " + DoubleToString(g_contract, 0) + " | fuso server GMT" +
        (g_gmtOffset >= 0 ? "+" : "") + IntegerToString(g_gmtOffset) + (g_netting ? " | conto NETTING: massimo 1 posizione" : " | conto hedging"));
   Logf(EngineStatus(ENG_SCALP) + " | " + EngineStatus(ENG_INTRA) + " | " + EngineStatus(ENG_SWING));
   if(!g_isTester && (!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) || !MQLInfoInteger(MQL_TRADE_ALLOWED)))
      Notify("Attiva il pulsante 'Algo Trading' e la spunta 'Consenti trading algoritmico' nelle proprieta' dell'EA");
   if(g_ddHalt)
      Notify("EA fermo per drawdown massimo raggiunto. Per ripartire: proprieta' EA > 'Sblocca' = true");
   Briefing();
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   if(!g_isTester)
     {
      EventKillTimer();
      if(g_domOn)
         MarketBookRelease(g_sym);
      StatsSave();
      GvSave();
     }
   PrintReport();
   Comment("");
  }

void OnTick()
  {
   if(!g_ready)
      return;
   MqlTick tk;
   if(!SymbolInfoTick(g_sym, tk))
      return;
   FlowCheck();
   datetime m1open = iTime(g_sym, PERIOD_M1, 0);
   bool newM1 = (m1open != 0 && m1open != g_m1.lastOpen);
   if(newM1)
      OnNewM1(m1open);
   TickDelta(tk.bid);
   SpreadTrack(tk.ask - tk.bid);
   RiskCheckLimits();
   if(g_needSweep)
      MetaSweep();
   if(g_needFlowScan)
     {
      g_needFlowScan = false;
      CashFlowScan();
     }
   ManagePositions();
   if(newM1 && g_isTester && g_isVisual)
      Panel();
  }

void OnTimer()
  {
   if(TimeCurrent() - g_gmtCheckedAt >= 3600)
      UpdateGmtOffset();
   if(TimeCurrent() - g_newsRefreshedAt >= 15 * 60)
      CalendarRefresh();
   if(TimeCurrent() - g_webLastTry >= InpWebRefreshMin * 60)
     {
      WebRefresh();
      MacroHistDownload(InpMacroHistUrl);
      MacroCombine();
     }
   CtxUpdate();
   Panel();
  }

void OnTradeTransaction(const MqlTradeTransaction &trans, const MqlTradeRequest &request, const MqlTradeResult &result)
  {
   if(trans.type == TRADE_TRANSACTION_DEAL_ADD)
     {
      g_needSweep = true;
      g_needFlowScan = true;
     }
  }

void OnBookEvent(const string &symbol)
  {
   if(symbol == g_sym && g_domOn)
      DomUpdate();
  }

//--- criterio per l'ottimizzazione: SQN in R corretto per il drawdown
double OnTester()
  {
   int n = g_all.n;
   if(n < 20)
      return 0.0;
   double mean = g_all.sumR / n;
   double var = g_all.sumR2 / n - mean * mean;
   double sd = MathSqrt(MathMax(var, 0.000001));
   double sqn = mean / sd * MathSqrt((double)IMin(n, 100));
   double dd = TesterStatistics(STAT_EQUITY_DDREL_PERCENT);
   return NormalizeDouble(sqn * (1.0 - MathMin(dd, 90.0) / 100.0), 4);
  }
//+------------------------------------------------------------------+
